#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <iostream>
#include <vector>
#include <functional>

namespace
{
    struct Failure
    {
        int count = 0;
        void require (bool ok, const juce::String& message)
        {
            if (! ok)
            {
                ++count;
                std::cerr << "FAIL: " << message << "\n";
            }
        }
    };

    juce::Component* findByIdRecursive (juce::Component& parent, const juce::String& id)
    {
        if (parent.getComponentID() == id)
            return &parent;
        for (int i = 0; i < parent.getNumChildComponents(); ++i)
            if (auto* c = parent.getChildComponent (i))
                if (auto* found = findByIdRecursive (*c, id))
                    return found;
        return nullptr;
    }

    void collectPrefixRecursive (juce::Component& parent, const juce::String& prefix,
                                 std::vector<juce::Component*>& out)
    {
        if (parent.getComponentID().startsWith (prefix))
            out.push_back (&parent);
        for (int i = 0; i < parent.getNumChildComponents(); ++i)
            if (auto* c = parent.getChildComponent (i))
                collectPrefixRecursive (*c, prefix, out);
    }

    bool exerciseParameterControl (juce::AudioProcessorEditor& editor,
                                   juce::AudioProcessorValueTreeState& apvts,
                                   const juce::String& id)
    {
        auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (apvts.getParameter (id));
        if (parameter == nullptr)
            return false;

        const float before = parameter->getValue();

        if (auto* c = findByIdRecursive (editor, id))
        {
            if (auto* slider = dynamic_cast<juce::Slider*> (c))
            {
                const double lo = slider->getMinimum();
                const double hi = slider->getMaximum();
                const double mid = (lo + hi) * 0.5;
                double target = slider->getValue() <= mid ? hi : lo;
                if (std::abs (target - slider->getValue()) < 1.0e-9)
                    target = mid;
                slider->setValue (target, juce::sendNotificationSync);
            }
            else if (auto* button = dynamic_cast<juce::TextButton*> (c))
            {
                button->setToggleState (! button->getToggleState(), juce::sendNotificationSync);
            }
            else
            {
                return false;
            }
        }
        else
        {
            std::vector<juce::Component*> choices;
            collectPrefixRecursive (editor, id + "__", choices);
            if (choices.size() < 2)
                return false;

            const int raw = (int) std::lround (apvts.getRawParameterValue (id)->load());
            int targetVisual = 0;
            if (id == "compPeak")
                targetVisual = raw == 1 ? 1 : 0;
            else
                targetVisual = raw == 0 ? 1 : 0;

            const juce::String targetId = id + "__" + juce::String (targetVisual);
            auto* target = findByIdRecursive (editor, targetId);
            auto* button = dynamic_cast<juce::TextButton*> (target);
            if (button == nullptr)
                return false;
            if (button->onClick) button->onClick();
        }

        const float after = parameter->getValue();
        parameter->setValueNotifyingHost (before);
        return std::abs (after - before) > 1.0e-6f;
    }
    void setActual (ConsoleChannelStripXAudioProcessor& p, const char* id, float actual)
    {
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p.parameters().getParameter (id)))
            rp->setValueNotifyingHost (rp->convertTo0to1 (actual));
    }

    void neutralise (ConsoleChannelStripXAudioProcessor& p)
    {
        setActual (p, "inputOn", 1.0f); setActual (p, "inputDrive", 0.0f); setActual (p, "inputTrim", 0.0f);
        setActual (p, "inputMode", 0.0f); setActual (p, "inputPad", 0.0f); setActual (p, "polarity", 0.0f);

        setActual (p, "filtersOn", 0.0f); setActual (p, "hpOn", 0.0f); setActual (p, "lpOn", 0.0f);
        setActual (p, "hpSlope", 1.0f); setActual (p, "lpSlope", 1.0f);

        setActual (p, "eqOn", 0.0f); setActual (p, "hfGain", 0.0f); setActual (p, "hmfGain", 0.0f);
        setActual (p, "lmfGain", 0.0f); setActual (p, "lfGain", 0.0f); setActual (p, "hfBell", 0.0f); setActual (p, "lfBell", 0.0f);

        setActual (p, "dynOn", 0.0f); setActual (p, "compOn", 0.0f); setActual (p, "gateOn", 0.0f);
        setActual (p, "compFast", 0.0f); setActual (p, "gateFast", 0.0f); setActual (p, "gateExpand", 0.0f); setActual (p, "compMakeup", 0.0f);

        setActual (p, "saturationOn", 0.0f); setActual (p, "satTone", 0.0f); setActual (p, "satOutputTrim", 0.0f);
        setActual (p, "stereoOn", 0.0f); setActual (p, "stereoWidth", 0.0f); setActual (p, "pan", 0.0f);
        setActual (p, "stereoFocus", 120.0f); setActual (p, "stereoBalance", 0.0f); setActual (p, "stereoDetune", 0.0f);
        setActual (p, "stereoDelay", 0.0f); setActual (p, "bassMono", 0.0f); setActual (p, "stereoMode", 0.0f);

        setActual (p, "outputOn", 1.0f); setActual (p, "vcaFader", 0.0f); setActual (p, "outputTrim", 0.0f);
        setActual (p, "autoLevel", 0.0f); setActual (p, "mix", 100.0f); setActual (p, "mute", 0.0f); setActual (p, "bypass", 0.0f);
    }

    struct Rendered
    {
        std::vector<float> l, r;
    };

    Rendered render (const std::function<void(ConsoleChannelStripXAudioProcessor&)>& setup,
                     const std::function<void(juce::AudioBuffer<float>&, double)>& fill)
    {
        constexpr int n = 2048;
        constexpr double fs = 48000.0;
        ConsoleChannelStripXAudioProcessor p;
        neutralise (p);
        setup (p);
        p.prepareToPlay (fs, n);
        juce::AudioBuffer<float> b (2, n);
        b.clear();
        fill (b, fs);
        juce::MidiBuffer midi;
        p.processBlock (b, midi);
        Rendered out;
        out.l.assign (b.getReadPointer (0), b.getReadPointer (0) + n);
        out.r.assign (b.getReadPointer (1), b.getReadPointer (1) + n);
        return out;
    }

    void fillSine (juce::AudioBuffer<float>& b, double fs, float hz, float amp,
                   bool antiPhase = false)
    {
        for (int n = 0; n < b.getNumSamples(); ++n)
        {
            const float x = amp * std::sin (2.0 * juce::MathConstants<double>::pi * (double) hz * (double) n / fs);
            b.setSample (0, n, x);
            b.setSample (1, n, antiPhase ? -x : x);
        }
    }

    float meanAbsDiff (const std::vector<float>& a, const std::vector<float>& b, int start = 96)
    {
        const int n = (int) juce::jmin (a.size(), b.size());
        if (n <= start) return 0.0f;
        double sum = 0.0;
        for (int i = start; i < n; ++i) sum += std::abs ((double) a[(size_t) i] - (double) b[(size_t) i]);
        return (float) (sum / (double) (n - start));
    }

    float rms (const std::vector<float>& a, int start = 96, int end = -1)
    {
        if (end < 0 || end > (int) a.size()) end = (int) a.size();
        if (end <= start) return 0.0f;
        double sum = 0.0;
        for (int i = start; i < end; ++i) sum += (double) a[(size_t) i] * (double) a[(size_t) i];
        return (float) std::sqrt (sum / (double) (end - start));
    }

}

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;
    Failure f;
    ConsoleChannelStripXAudioProcessor processor;
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());

    f.require (editor != nullptr, "editor was not created");
    if (editor == nullptr) return 1;

    f.require (editor->getWidth() == 1536 && editor->getHeight() == 1024,
               "approved Silveton design surface must be exactly 1536x1024");

    const std::vector<juce::String> visibleParameterIds {
        "bypass", "mix",
        "inputOn", "inputDrive", "inputMode", "polarity", "inputPad", "inputTrim",
        "filtersOn", "hpOn", "hpFreq", "hpSlope", "lpOn", "lpFreq", "lpSlope",
        "eqOn", "hfFreq", "hfGain", "hfQ", "hmfFreq", "hmfGain", "hmfQ",
        "lmfFreq", "lmfGain", "lmfQ", "lfFreq", "lfGain", "lfQ", "hfBell", "lfBell",
        "dynOn", "gateOn", "gateExpand", "gateFast", "gateThreshold", "gateRange", "gateAttack", "gateRelease",
        "compOn", "compPeak", "compFast", "compThreshold", "compRatio", "compAttack", "compRelease", "compKnee", "compMakeup",
        "saturationOn", "satType", "satGain", "saturation", "satTone", "satMix", "satCharacter", "satOutputTrim",
        "stereoOn", "stereoMode", "stereoWidth", "pan", "stereoFocus", "stereoBalance", "stereoDetune", "stereoDelay", "bassMono",
        "outputOn", "vcaFader", "autoLevel"
    };

    f.require ((int) visibleParameterIds.size() == 67, "expected 67 approved visible parameter controls");

    for (const auto& id : visibleParameterIds)
    {
        auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter (id));
        f.require (parameter != nullptr, "missing APVTS parameter: " + id);

        auto* direct = findByIdRecursive (*editor, id);
        std::vector<juce::Component*> choices;
        collectPrefixRecursive (*editor, id + "__", choices);
        const bool exists = direct != nullptr || ! choices.empty();
        f.require (exists, "missing visible GUI control: " + id);

        if (direct != nullptr)
            f.require (direct->getWidth() > 0 && direct->getHeight() > 0, "control has zero bounds: " + id);
        else
            for (auto* c : choices)
                f.require (c->getWidth() > 0 && c->getHeight() > 0, "choice control has zero bounds: " + c->getComponentID());

        if (exists && parameter != nullptr)
            f.require (exerciseParameterControl (*editor, processor.parameters(), id),
                       "control is not functionally attached: " + id);
    }

    // Legacy parameters intentionally hidden from the approved face remain available to hosts/menu actions.
    for (const auto& id : { "eqModel", "routing", "mute", "gateHold", "outputTrim" })
        f.require (processor.parameters().getParameter (id) != nullptr, "legacy parameter was removed: " + juce::String (id));

    for (const auto& action : { "actionPrevPreset", "actionNextPreset", "actionAB", "actionUndo", "actionRedo", "actionMenu", "actionSettings", "presetBox" })
    {
        auto* c = findByIdRecursive (*editor, action);
        f.require (c != nullptr, "missing header action: " + juce::String (action));
        if (c != nullptr)
            f.require (c->getWidth() > 0 && c->getHeight() > 0, "header action has zero bounds: " + juce::String (action));
    }

    // Preset action must change a real parameter.
    if (auto* box = dynamic_cast<juce::ComboBox*> (findByIdRecursive (*editor, "presetBox")))
    {
        auto* threshold = processor.parameters().getRawParameterValue ("compThreshold");
        box->setSelectedId (1, juce::sendNotificationSync);
        const float before = threshold != nullptr ? threshold->load() : 0.0f;
        box->setSelectedId (2, juce::sendNotificationSync);
        const float after = threshold != nullptr ? threshold->load() : 0.0f;
        f.require (std::abs (after - before) > 1.0e-5f, "Vocal preset did not drive APVTS parameters");
    }

    // A/B action must store the active slot and recall the other slot.
    if (auto* ab = dynamic_cast<juce::TextButton*> (findByIdRecursive (*editor, "actionAB")))
    {
        auto* drive = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter ("inputDrive"));
        if (drive != nullptr)
        {
            drive->setValueNotifyingHost (drive->convertTo0to1 (12.0f));
            if (ab->onClick) ab->onClick();
            const float recalled = processor.parameters().getRawParameterValue ("inputDrive")->load();
            f.require (std::abs (recalled - 12.0f) > 0.5f, "A/B did not recall alternate state");
        }
    }


    // Audio-level extension tests: every new approved control family must alter the signal, not only APVTS state.
    {
        const auto hp6 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "hpOn", 1); setActual (p, "hpFreq", 120); setActual (p, "hpSlope", 0); },
                                 [] (auto& b, double fs) { fillSine (b, fs, 45.0f, 0.2f); });
        const auto hp24 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "hpOn", 1); setActual (p, "hpFreq", 120); setActual (p, "hpSlope", 2); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 45.0f, 0.2f); });
        f.require (std::abs (rms (hp6.l) - rms (hp24.l)) > 1.0e-4f, "HP 6/12/24 slope selector has no audio effect");

        const auto lp6 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "lpOn", 1); setActual (p, "lpFreq", 6000); setActual (p, "lpSlope", 0); },
                                 [] (auto& b, double fs) { fillSine (b, fs, 15000.0f, 0.2f); });
        const auto lp24 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "lpOn", 1); setActual (p, "lpFreq", 6000); setActual (p, "lpSlope", 2); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 15000.0f, 0.2f); });
        f.require (std::abs (rms (lp6.l) - rms (lp24.l)) > 1.0e-4f, "LP 6/12/24 slope selector has no audio effect");

        const auto hfQlo = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "hfBell", 1); setActual (p, "hfFreq", 8000); setActual (p, "hfGain", 8); setActual (p, "hfQ", 0.4f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 8000.0f, 0.08f); });
        const auto hfQhi = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "hfBell", 1); setActual (p, "hfFreq", 8000); setActual (p, "hfGain", 8); setActual (p, "hfQ", 2.8f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 8000.0f, 0.08f); });
        f.require (meanAbsDiff (hfQlo.l, hfQhi.l) > 1.0e-5f, "HF Q has no audio effect");

        const auto lfQlo = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "lfBell", 1); setActual (p, "lfFreq", 100); setActual (p, "lfGain", 8); setActual (p, "lfQ", 0.4f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 100.0f, 0.08f); });
        const auto lfQhi = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "lfBell", 1); setActual (p, "lfFreq", 100); setActual (p, "lfGain", 8); setActual (p, "lfQ", 2.8f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 100.0f, 0.08f); });
        f.require (meanAbsDiff (lfQlo.l, lfQhi.l) > 1.0e-5f, "LF Q has no audio effect");

        const auto attackFast = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -24); setActual (p, "compRatio", 10); setActual (p, "compAttack", 1); setActual (p, "compKnee", 0); },
                                        [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<300?0.0f:0.35f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        const auto attackSlow = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -24); setActual (p, "compRatio", 10); setActual (p, "compAttack", 80); setActual (p, "compKnee", 0); },
                                        [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<300?0.0f:0.35f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        f.require (meanAbsDiff (attackFast.l, attackSlow.l, 350) > 1.0e-5f, "Compressor ATTACK knob has no audio effect");

        const auto kneeHard = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -18); setActual (p, "compRatio", 4); setActual (p, "compAttack", 10); setActual (p, "compKnee", 0); },
                                       [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.14f); });
        const auto kneeSoft = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -18); setActual (p, "compRatio", 4); setActual (p, "compAttack", 10); setActual (p, "compKnee", 100); },
                                       [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.14f); });
        f.require (meanAbsDiff (kneeHard.l, kneeSoft.l) > 1.0e-6f, "Compressor KNEE knob has no audio effect");

        const auto makeup0 = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compMakeup", 0); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.08f); });
        const auto makeup6 = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compMakeup", 6); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.08f); });
        f.require (rms (makeup6.l) > rms (makeup0.l) * 1.3f, "Compressor MAKEUP knob has no audio effect");

        const auto gateFast = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "gateOn", 1); setActual (p, "gateThreshold", -30); setActual (p, "gateRange", 40); setActual (p, "gateAttack", 0.2f); },
                                      [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<400?0.0f:0.2f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        const auto gateSlow = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "gateOn", 1); setActual (p, "gateThreshold", -30); setActual (p, "gateRange", 40); setActual (p, "gateAttack", 200.0f); },
                                      [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<400?0.0f:0.2f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        f.require (meanAbsDiff (gateFast.l, gateSlow.l, 460) > 1.0e-5f, "Gate ATTACK knob has no audio effect");

        const auto tube = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satType", 0); setActual (p, "satGain", 8); setActual (p, "saturation", 70); setActual (p, "satMix", 100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto tape = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satType", 1); setActual (p, "satGain", 8); setActual (p, "saturation", 70); setActual (p, "satMix", 100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (tube.l, tape.l) > 1.0e-5f, "Saturation TYPE selector has no audio effect");

        const auto dark = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "saturation", 40); setActual (p, "satTone", -100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 9000.0f, 0.08f); });
        const auto bright = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "saturation", 40); setActual (p, "satTone", 100); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 9000.0f, 0.08f); });
        f.require (meanAbsDiff (dark.l, bright.l) > 1.0e-5f, "Saturation TONE knob has no audio effect");

        const auto satDry = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satGain", 10); setActual (p, "saturation", 80); setActual (p, "satMix", 0); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto satWet = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satGain", 10); setActual (p, "saturation", 80); setActual (p, "satMix", 100); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (satDry.l, satWet.l) > 1.0e-5f, "Saturation MIX knob has no audio effect");

        const auto clean = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satCharacter", 0); setActual (p, "saturation", 70); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto aggressive = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satCharacter", 2); setActual (p, "saturation", 70); },
                                        [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (clean.l, aggressive.l) > 1.0e-5f, "Saturation CHARACTER selector has no audio effect");

        const auto trim0 = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satOutputTrim", 0); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.05f); });
        const auto trim6 = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satOutputTrim", 6); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.05f); });
        f.require (rms (trim6.l) > rms (trim0.l) * 1.3f, "Saturation OUTPUT TRIM has no audio effect");

        const auto stereoMode = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "stereoMode", 0); setActual (p, "stereoBalance", 0.75f); },
                                        [] (auto& b, double fs) { for(int n=0;n<b.getNumSamples();++n){ float l=0.12f*std::sin(2.0*juce::MathConstants<double>::pi*700*n/fs); float r=0.08f*std::cos(2.0*juce::MathConstants<double>::pi*1100*n/fs); b.setSample(0,n,l); b.setSample(1,n,r);} });
        const auto midSideMode = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "stereoMode", 1); setActual (p, "stereoBalance", 0.75f); },
                                         [] (auto& b, double fs) { for(int n=0;n<b.getNumSamples();++n){ float l=0.12f*std::sin(2.0*juce::MathConstants<double>::pi*700*n/fs); float r=0.08f*std::cos(2.0*juce::MathConstants<double>::pi*1100*n/fs); b.setSample(0,n,l); b.setSample(1,n,r);} });
        f.require (meanAbsDiff (stereoMode.l, midSideMode.l) > 1.0e-5f, "STEREO / MID-SIDE mode selector has no audio effect");

        const auto bassOff = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "bassMono", 0); },
                                     [] (auto& b, double fs) { fillSine (b, fs, 70.0f, 0.12f, true); });
        const auto bassMono = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "bassMono", 3); },
                                      [] (auto& b, double fs) { fillSine (b, fs, 70.0f, 0.12f, true); });
        f.require (rms (bassMono.l) < rms (bassOff.l) * 0.8f, "BASS MONO selector does not collapse low-frequency side energy");
    }

    juce::Image image (juce::Image::RGB, editor->getWidth(), editor->getHeight(), true);
    juce::Graphics graphics (image);
    editor->paintEntireComponent (graphics, true);
    juce::File out = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-silveton-v0.5.1.png");
    juce::FileOutputStream stream (out);
    juce::PNGImageFormat png;
    f.require (stream.openedOk() && png.writeImageToStream (image, stream), "approved GUI preview PNG was not written");

    if (f.count != 0)
    {
        std::cerr << f.count << " Silveton approved-GUI smoke test(s) failed\n";
        return 1;
    }

    std::cout << "PASS: Silveton v0.5.1 approved 1536x1024 GUI; all 67 visible parameter controls are present and functional.\n";
    return 0;
}
