#include "PluginEditor.h"
#include <algorithm>
#include <cmath>

namespace
{
    constexpr int kDesignWidth = 1536;
    constexpr int kDesignHeight = 1024;

    const auto cBg = juce::Colour::fromRGB (9, 15, 19);
    const auto cHeader = juce::Colour::fromRGB (13, 23, 29);
    const auto cPanelTop = juce::Colour::fromRGB (23, 35, 42);
    const auto cPanelBottom = juce::Colour::fromRGB (12, 21, 27);
    const auto cEdge = juce::Colour::fromRGB (53, 75, 87);
    const auto cField = juce::Colour::fromRGB (10, 18, 23);
    const auto cText = juce::Colour::fromRGB (225, 234, 240);
    const auto cMuted = juce::Colour::fromRGB (138, 157, 170);
    const auto cBlue = juce::Colour::fromRGB (56, 181, 245);
    const auto cBlue2 = juce::Colour::fromRGB (26, 109, 159);
    const auto cGreen = juce::Colour::fromRGB (80, 210, 125);
    const auto cYellow = juce::Colour::fromRGB (231, 197, 73);
    const auto cRed = juce::Colour::fromRGB (238, 87, 78);

    struct Layout
    {
        static juce::Rectangle<int> input()      { return { 6, 90, 160, 830 }; }
        static juce::Rectangle<int> filters()    { return { 170, 90, 160, 830 }; }
        static juce::Rectangle<int> eq()         { return { 334, 90, 292, 830 }; }
        static juce::Rectangle<int> dynamics()   { return { 630, 90, 300, 830 }; }
        static juce::Rectangle<int> saturation() { return { 934, 90, 210, 830 }; }
        static juce::Rectangle<int> stereo()     { return { 1148, 90, 232, 830 }; }
        static juce::Rectangle<int> output()     { return { 1384, 90, 146, 830 }; }
    };

    bool containsIgnoreCase (const juce::String& s, const char* token)
    {
        return s.containsIgnoreCase (token);
    }
}

class SilvetonLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    SilvetonLookAndFeel()
    {
        setColour (juce::Slider::textBoxTextColourId, cText);
        setColour (juce::Slider::textBoxBackgroundColourId, cField);
        setColour (juce::Slider::textBoxOutlineColourId, cEdge);
        setColour (juce::Label::textColourId, cMuted);
        setColour (juce::ComboBox::backgroundColourId, cField);
        setColour (juce::ComboBox::outlineColourId, cEdge);
        setColour (juce::ComboBox::textColourId, cText);
        setColour (juce::PopupMenu::backgroundColourId, cPanelBottom);
        setColour (juce::PopupMenu::textColourId, cText);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, cBlue2);
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float pos, float startAngle, float endAngle, juce::Slider&) override
    {
        auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (8.0f, 4.0f);
        const float size = juce::jmin (area.getWidth(), area.getHeight());
        auto dial = juce::Rectangle<float> (0, 0, size, size).withCentre (area.getCentre());
        const auto centre = dial.getCentre();
        const float radius = size * 0.5f;
        const float angle = startAngle + pos * (endAngle - startAngle);

        for (int i = 0; i <= 18; ++i)
        {
            const float a = juce::jmap ((float) i, 0.0f, 18.0f, startAngle, endAngle);
            const float r1 = radius * 0.88f;
            const float r2 = radius * (i % 3 == 0 ? 0.98f : 0.94f);
            g.setColour ((i <= (int) std::round (pos * 18.0f) ? cBlue : cMuted).withAlpha (i % 3 == 0 ? 0.85f : 0.50f));
            g.drawLine (centre.x + std::sin (a) * r1, centre.y - std::cos (a) * r1,
                        centre.x + std::sin (a) * r2, centre.y - std::cos (a) * r2, 1.0f);
        }

        juce::ColourGradient rim (juce::Colour::fromRGB (82, 98, 108), dial.getX(), dial.getY(),
                                  juce::Colour::fromRGB (12, 19, 24), dial.getRight(), dial.getBottom(), false);
        g.setGradientFill (rim);
        g.fillEllipse (dial.reduced (radius * 0.12f));
        g.setColour (juce::Colour::fromRGB (4, 8, 11));
        g.fillEllipse (dial.reduced (radius * 0.20f));
        g.setColour (cEdge.withAlpha (0.85f));
        g.drawEllipse (dial.reduced (radius * 0.20f), 1.0f);

        juce::Path pointer;
        pointer.addRoundedRectangle (-1.2f, -radius * 0.52f, 2.4f, radius * 0.36f, 1.0f);
        pointer.applyTransform (juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
        g.setColour (juce::Colours::white.withAlpha (0.95f));
        g.fillPath (pointer);

        juce::Path arc;
        arc.addCentredArc (centre.x, centre.y, radius * 0.78f, radius * 0.78f, 0.0f,
                           startAngle, angle, true);
        g.setColour (cBlue.withAlpha (0.92f));
        g.strokePath (arc, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float, float, const juce::Slider::SliderStyle style,
                           juce::Slider& slider) override
    {
        if (style != juce::Slider::LinearVertical)
        {
            juce::LookAndFeel_V4::drawLinearSlider (g, x, y, width, height, sliderPos, 0, 0, style, slider);
            return;
        }

        const float cx = (float) x + width * 0.5f;
        g.setColour (juce::Colour::fromRGB (4, 9, 12));
        g.fillRoundedRectangle (cx - 5.0f, (float) y + 8.0f, 10.0f, (float) height - 16.0f, 4.0f);
        g.setColour (cEdge);
        g.drawRoundedRectangle (cx - 5.0f, (float) y + 8.0f, 10.0f, (float) height - 16.0f, 4.0f, 1.0f);

        auto thumb = juce::Rectangle<float> (cx - 16.0f, sliderPos - 8.0f, 32.0f, 16.0f);
        juce::ColourGradient grad (juce::Colour::fromRGB (191, 203, 211), thumb.getX(), thumb.getY(),
                                   juce::Colour::fromRGB (75, 89, 98), thumb.getX(), thumb.getBottom(), false);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (thumb, 2.0f);
        g.setColour (juce::Colours::white.withAlpha (0.35f));
        g.drawHorizontalLine ((int) thumb.getCentreY(), thumb.getX() + 4.0f, thumb.getRight() - 4.0f);
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                               bool highlighted, bool down) override
    {
        auto r = button.getLocalBounds().toFloat().reduced (0.5f);
        const bool on = button.getToggleState();
        auto fill = on ? cBlue2 : cField;
        if (highlighted) fill = fill.brighter (0.08f);
        if (down) fill = fill.darker (0.15f);

        g.setColour (fill);
        g.fillRoundedRectangle (r, 3.0f);
        g.setColour ((on ? cBlue : cEdge).withAlpha (0.95f));
        g.drawRoundedRectangle (r, 3.0f, on ? 1.4f : 1.0f);
        if (on)
        {
            g.setColour (cBlue.withAlpha (0.13f));
            g.drawRoundedRectangle (r.expanded (1.0f), 4.0f, 2.0f);
        }
    }

    void drawButtonText (juce::Graphics& g, juce::TextButton& button,
                         bool, bool) override
    {
        g.setColour (button.getToggleState() ? juce::Colours::white : cText);
        if (button.getButtonText() == "POWER")
        {
            const auto r = button.getLocalBounds().toFloat();
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.27f;
            g.drawEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f, 1.5f);
            g.drawLine (c.x, c.y - rad - 2.0f, c.x, c.y + 1.0f, 1.8f);
            return;
        }
        if (button.getButtonText() == "PHASEICON")
        {
            const auto r = button.getLocalBounds().toFloat();
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.24f;
            g.drawEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f, 1.4f);
            g.drawLine (c.x - rad * 0.72f, c.y + rad * 0.92f, c.x + rad * 0.72f, c.y - rad * 0.92f, 1.5f);
            return;
        }
        if (button.getButtonText() == "MENU")
        {
            const auto c = button.getLocalBounds().toFloat().getCentre();
            for (int dy : { -7, 0, 7 }) g.fillEllipse (c.x - 1.5f, c.y + (float) dy - 1.5f, 3.0f, 3.0f);
            return;
        }
        if (button.getButtonText() == "SETTINGS")
        {
            const auto c = button.getLocalBounds().toFloat().getCentre();
            g.drawEllipse (c.x - 7.0f, c.y - 7.0f, 14.0f, 14.0f, 1.5f);
            g.drawEllipse (c.x - 2.0f, c.y - 2.0f, 4.0f, 4.0f, 1.2f);
            g.drawLine (c.x - 10.0f, c.y, c.x - 7.0f, c.y, 1.5f);
            g.drawLine (c.x + 7.0f, c.y, c.x + 10.0f, c.y, 1.5f);
            g.drawLine (c.x, c.y - 10.0f, c.x, c.y - 7.0f, 1.5f);
            g.drawLine (c.x, c.y + 7.0f, c.x, c.y + 10.0f, 1.5f);
            return;
        }
        g.setFont (juce::Font (button.getHeight() <= 24 ? 9.5f : 10.5f, juce::Font::bold));
        g.drawFittedText (button.getButtonText(), button.getLocalBounds().reduced (4, 1),
                          juce::Justification::centred, 1);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool,
                       int, int, int, int, juce::ComboBox&) override
    {
        auto r = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
        g.setColour (cField);
        g.fillRoundedRectangle (r, 4.0f);
        g.setColour (cEdge);
        g.drawRoundedRectangle (r, 4.0f, 1.0f);

        juce::Path p;
        const float cx = width - 16.0f, cy = height * 0.5f;
        p.addTriangle (cx - 4.0f, cy - 2.0f, cx + 4.0f, cy - 2.0f, cx, cy + 3.0f);
        g.setColour (cMuted);
        g.fillPath (p);
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return juce::Font (11.0f); }
};

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), silvetonLookAndFeel (std::make_unique<SilvetonLookAndFeel>())
{
    setOpaque (true);
    setLookAndFeel (silvetonLookAndFeel.get());

    for (auto* b : { &prevPresetButton, &nextPresetButton, &abButton, &undoButton, &redoButton, &menuButton, &settingsButton })
        addAndMakeVisible (*b);

    prevPresetButton.setComponentID ("actionPrevPreset");
    nextPresetButton.setComponentID ("actionNextPreset");
    abButton.setComponentID ("actionAB");
    undoButton.setComponentID ("actionUndo");
    redoButton.setComponentID ("actionRedo");
    menuButton.setComponentID ("actionMenu");
    settingsButton.setComponentID ("actionSettings");

    addAndMakeVisible (presetBox);
    presetBox.setComponentID ("presetBox");
    presetBox.addItem ("INIT", 1);
    presetBox.addItem ("Vocal - Modern Clarity", 2);
    presetBox.addItem ("Drum - Punch", 3);
    presetBox.addItem ("Mix Bus - Glue", 4);
    presetBox.setSelectedId (2, juce::dontSendNotification);

    prevPresetButton.onClick = [this] { cyclePreset (-1); };
    nextPresetButton.onClick = [this] { cyclePreset (1); };
    presetBox.onChange = [this] { applyPreset (presetBox.getSelectedId()); };
    abButton.onClick = [this] { toggleAB(); };
    undoButton.onClick = [this] { audioProcessor.undo(); };
    redoButton.onClick = [this] { audioProcessor.redo(); };
    menuButton.onClick = [this] { showMainMenu(); };
    settingsButton.onClick = [this] { showSettingsMenu(); };

    addToggle ("bypass", "BYPASS");
    addSlider ("mix", "MIX");

    addToggle ("inputOn", "POWER");
    addSlider ("inputDrive", "GAIN");
    addChoice ("inputMode", { "LINE", "MIC" });
    addToggle ("polarity", "PHASEICON");
    addToggle ("inputPad", "-20 dB");
    addSlider ("inputTrim", "INPUT TRIM", true);

    addToggle ("filtersOn", "POWER");
    addToggle ("hpOn", "HIGH-PASS");
    addSlider ("hpFreq", "");
    addChoice ("hpSlope", { "6 dB", "12 dB", "24 dB" });
    addToggle ("lpOn", "LOW-PASS");
    addSlider ("lpFreq", "");
    addChoice ("lpSlope", { "6 dB", "12 dB", "24 dB" });

    addToggle ("eqOn", "POWER");
    addSlider ("hfFreq", "FREQ");
    addSlider ("hfGain", "GAIN");
    addSlider ("hfQ", "Q");
    addSlider ("hmfFreq", "FREQ");
    addSlider ("hmfGain", "GAIN");
    addSlider ("hmfQ", "Q");
    addSlider ("lmfFreq", "FREQ");
    addSlider ("lmfGain", "GAIN");
    addSlider ("lmfQ", "Q");
    addSlider ("lfFreq", "FREQ");
    addSlider ("lfGain", "GAIN");
    addSlider ("lfQ", "Q");
    addToggle ("hfBell", "BELL");
    addToggle ("lfBell", "BELL");

    addToggle ("dynOn", "POWER");
    addToggle ("gateOn", "GATE");
    addToggle ("gateExpand", "EXPAND");
    addToggle ("gateFast", "FAST");
    addSlider ("gateThreshold", "THRESHOLD");
    addSlider ("gateRange", "RANGE");
    addSlider ("gateAttack", "ATTACK");
    addSlider ("gateRelease", "RELEASE");

    addToggle ("compOn", "IN");
    addChoice ("compPeak", { "PEAK", "RMS" });
    addToggle ("compFast", "FAST");
    addSlider ("compThreshold", "THRESHOLD");
    addSlider ("compRatio", "RATIO");
    addSlider ("compAttack", "ATTACK");
    addSlider ("compRelease", "RELEASE");
    addSlider ("compKnee", "KNEE");
    addSlider ("compMakeup", "MAKEUP");

    addToggle ("saturationOn", "POWER");
    addChoice ("satType", { "TUBE", "TAPE", "SOLID STATE" });
    addSlider ("satGain", "DRIVE");
    addSlider ("saturation", "AMOUNT");
    addSlider ("satTone", "TONE");
    addSlider ("satMix", "MIX");
    addChoice ("satCharacter", { "CLEAN", "WARM", "AGGRESSIVE" });
    addSlider ("satOutputTrim", "OUTPUT TRIM");

    addToggle ("stereoOn", "POWER");
    addChoice ("stereoMode", { "STEREO", "MID / SIDE" });
    addSlider ("stereoWidth", "WIDTH");
    addSlider ("pan", "PAN");
    addSlider ("stereoFocus", "FOCUS");
    addSlider ("stereoBalance", "BALANCE");
    addSlider ("stereoDetune", "DETUNE");
    addSlider ("stereoDelay", "DELAY");
    addChoice ("bassMono", { "OFF", "80 Hz", "120 Hz", "200 Hz" });

    addToggle ("outputOn", "POWER");
    addSlider ("vcaFader", "LEVEL");
    addToggle ("autoLevel", "AUTO LEVEL");

    slotA = audioProcessor.parameters().copyState();
    slotB = slotA.createCopy();

    setSize (kDesignWidth, kDesignHeight);
    setResizable (false, false);
    startTimerHz (30);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void ConsoleChannelStripXAudioProcessorEditor::addSlider (const char* parameterId, const char* labelText, bool vertical)
{
    auto slot = std::make_unique<SliderControl>();
    slot->label = std::make_unique<juce::Label>();
    slot->slider = std::make_unique<juce::Slider>();

    slot->label->setText (labelText, juce::dontSendNotification);
    slot->label->setJustificationType (juce::Justification::centred);
    slot->label->setColour (juce::Label::textColourId, cMuted);
    slot->label->setFont (juce::Font (9.5f, juce::Font::bold));

    slot->slider->setComponentID (parameterId);
    slot->slider->setSliderStyle (vertical ? juce::Slider::LinearVertical : juce::Slider::RotaryHorizontalVerticalDrag);
    slot->slider->setTextBoxStyle (juce::Slider::TextBoxBelow, false, vertical ? 68 : 74, 20);
    slot->slider->setScrollWheelEnabled (true);
    slot->slider->setDoubleClickReturnValue (true, 0.0);

    if (auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (parameterId)))
    {
        const auto r = parameter->getNormalisableRange();
        juce::NormalisableRange<double> dr ((double) r.start, (double) r.end, (double) r.interval,
                                            (double) r.skew, r.symmetricSkew);
        slot->slider->setNormalisableRange (dr);
        const double def = (double) r.convertFrom0to1 (parameter->getDefaultValue());
        slot->slider->setDoubleClickReturnValue (true, def);
    }

    const juce::String id (parameterId);
    slot->slider->textFromValueFunction = [id] (double v) { return formatParameterValue (id, v); };
    slot->slider->valueFromTextFunction = [id] (const juce::String& s) { return parseParameterValue (id, s); };

    addAndMakeVisible (*slot->label);
    addAndMakeVisible (*slot->slider);
    slot->attachment = std::make_unique<SliderAttachment> (audioProcessor.parameters(), parameterId, *slot->slider);

    controlsById[parameterId] = slot->slider.get();
    labelsById[parameterId] = slot->label.get();
    sliderControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addToggle (const char* parameterId, const char* buttonText)
{
    auto slot = std::make_unique<ToggleControl>();
    slot->button = std::make_unique<juce::TextButton> (buttonText);
    slot->button->setComponentID (parameterId);
    slot->button->setClickingTogglesState (true);
    addAndMakeVisible (*slot->button);
    slot->attachment = std::make_unique<ButtonAttachment> (audioProcessor.parameters(), parameterId, *slot->button);
    controlsById[parameterId] = slot->button.get();
    toggleControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addChoice (const char* parameterId, std::initializer_list<const char*> labels)
{
    auto group = std::make_unique<ChoiceControl>();
    group->parameterId = parameterId;
    int index = 0;
    for (const auto* text : labels)
    {
        auto b = std::make_unique<juce::TextButton> (text);
        b->setComponentID (juce::String (parameterId) + "__" + juce::String (index));
        const int thisIndex = index;
        const std::string id = parameterId;
        b->onClick = [this, id, thisIndex]
        {
            if (auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (juce::String (id))))
            {
                const float actual = (id == "compPeak") ? (float) (1 - thisIndex) : (float) thisIndex;
                parameter->beginChangeGesture();
                parameter->setValueNotifyingHost (parameter->convertTo0to1 (actual));
                parameter->endChangeGesture();
            }
            syncChoiceButtons();
        };
        addAndMakeVisible (*b);
        group->buttons.push_back (std::move (b));
        ++index;
    }
    if (! group->buttons.empty())
        controlsById[parameterId] = group->buttons.front().get();
    choiceControls.push_back (std::move (group));
}

juce::Component* ConsoleChannelStripXAudioProcessorEditor::control (const char* id) const
{
    const auto it = controlsById.find (id);
    return it == controlsById.end() ? nullptr : it->second;
}

juce::Label* ConsoleChannelStripXAudioProcessorEditor::label (const char* id) const
{
    const auto it = labelsById.find (id);
    return it == labelsById.end() ? nullptr : it->second;
}

void ConsoleChannelStripXAudioProcessorEditor::placeSlider (const char* id, juce::Rectangle<int> bounds)
{
    auto* c = control (id);
    auto* l = label (id);
    if (c == nullptr || l == nullptr) return;
    auto labelArea = bounds.removeFromTop (15);
    l->setBounds (labelArea);
    c->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeToggle (const char* id, juce::Rectangle<int> bounds)
{
    if (auto* c = control (id)) c->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeChoice (const char* id, juce::Rectangle<int> bounds, int gap)
{
    for (auto& group : choiceControls)
    {
        if (group->parameterId != id) continue;
        const int count = (int) group->buttons.size();
        if (count <= 0) return;
        const int totalGap = gap * (count - 1);
        const int each = juce::jmax (1, (bounds.getWidth() - totalGap) / count);
        for (int i = 0; i < count; ++i)
        {
            group->buttons[(size_t) i]->setBounds (bounds.removeFromLeft (each));
            if (i + 1 < count) bounds.removeFromLeft (gap);
        }
        return;
    }
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    prevPresetButton.setBounds (548, 22, 32, 38);
    presetBox.setBounds (584, 22, 320, 38);
    nextPresetButton.setBounds (908, 22, 32, 38);
    abButton.setBounds (974, 24, 76, 34);
    undoButton.setBounds (1059, 24, 68, 34);
    redoButton.setBounds (1134, 24, 68, 34);
    menuButton.setBounds (1210, 24, 42, 34);
    placeToggle ("bypass", { 1272, 24, 78, 34 });
    placeSlider ("mix", { 1360, 7, 84, 62 });
    settingsButton.setBounds (1464, 22, 58, 38);

    const auto pIn = Layout::input();
    placeToggle ("inputOn", { pIn.getX() + 12, pIn.getY() + 12, 32, 28 });
    placeSlider ("inputDrive", { pIn.getX() + 25, pIn.getY() + 67, 110, 150 });
    placeChoice ("inputMode", { pIn.getX() + 16, pIn.getY() + 260, 128, 34 });
    placeToggle ("polarity", { pIn.getX() + 16, pIn.getY() + 310, 60, 34 });
    placeToggle ("inputPad", { pIn.getX() + 84, pIn.getY() + 310, 60, 34 });
    placeSlider ("inputTrim", { pIn.getX() + 44, pIn.getY() + 392, 72, 355 });

    const auto pF = Layout::filters();
    placeToggle ("filtersOn", { pF.getX() + 12, pF.getY() + 12, 32, 28 });
    placeToggle ("hpOn", { pF.getX() + 16, pF.getY() + 70, 128, 28 });
    placeSlider ("hpFreq", { pF.getX() + 20, pF.getY() + 112, 120, 175 });
    placeChoice ("hpSlope", { pF.getX() + 12, pF.getY() + 304, 136, 30 }, 3);
    placeToggle ("lpOn", { pF.getX() + 16, pF.getY() + 410, 128, 28 });
    placeSlider ("lpFreq", { pF.getX() + 20, pF.getY() + 452, 120, 175 });
    placeChoice ("lpSlope", { pF.getX() + 12, pF.getY() + 644, 136, 30 }, 3);

    const auto pEq = Layout::eq();
    placeToggle ("eqOn", { pEq.getX() + 12, pEq.getY() + 12, 32, 28 });
    placeSlider ("hfFreq", { pEq.getX() + 36, pEq.getY() + 108, 68, 110 });
    placeSlider ("hfGain", { pEq.getX() + 110, pEq.getY() + 108, 68, 110 });
    placeSlider ("hfQ", { pEq.getX() + 184, pEq.getY() + 108, 68, 110 });
    placeSlider ("hmfFreq", { pEq.getX() + 36, pEq.getY() + 303, 68, 110 });
    placeSlider ("hmfGain", { pEq.getX() + 110, pEq.getY() + 303, 68, 110 });
    placeSlider ("hmfQ", { pEq.getX() + 184, pEq.getY() + 303, 68, 110 });
    placeSlider ("lmfFreq", { pEq.getX() + 36, pEq.getY() + 498, 68, 110 });
    placeSlider ("lmfGain", { pEq.getX() + 110, pEq.getY() + 498, 68, 110 });
    placeSlider ("lmfQ", { pEq.getX() + 184, pEq.getY() + 498, 68, 110 });
    placeSlider ("lfFreq", { pEq.getX() + 36, pEq.getY() + 691, 68, 110 });
    placeSlider ("lfGain", { pEq.getX() + 110, pEq.getY() + 691, 68, 110 });
    placeSlider ("lfQ", { pEq.getX() + 184, pEq.getY() + 691, 68, 110 });
    placeToggle ("hfBell", { pEq.getX() + 214, pEq.getY() + 218, 54, 24 });
    placeToggle ("lfBell", { pEq.getX() + 214, pEq.getY() + 801, 54, 24 });

    const auto pD = Layout::dynamics();
    placeToggle ("dynOn", { pD.getX() + 12, pD.getY() + 12, 32, 28 });
    placeToggle ("gateOn", { pD.getX() + 16, pD.getY() + 78, 64, 30 });
    placeToggle ("gateExpand", { pD.getX() + 84, pD.getY() + 78, 70, 30 });
    placeToggle ("gateFast", { pD.getX() + 158, pD.getY() + 78, 60, 30 });
    placeSlider ("gateThreshold", { pD.getX() + 14, pD.getY() + 145, 64, 110 });
    placeSlider ("gateRange", { pD.getX() + 80, pD.getY() + 145, 64, 110 });
    placeSlider ("gateAttack", { pD.getX() + 14, pD.getY() + 270, 64, 110 });
    placeSlider ("gateRelease", { pD.getX() + 80, pD.getY() + 270, 64, 110 });

    placeToggle ("compOn", { pD.getX() + 16, pD.getY() + 450, 54, 30 });
    placeChoice ("compPeak", { pD.getX() + 74, pD.getY() + 450, 112, 30 }, 3);
    placeToggle ("compFast", { pD.getX() + 190, pD.getY() + 450, 60, 30 });
    placeSlider ("compThreshold", { pD.getX() + 10, pD.getY() + 512, 62, 105 });
    placeSlider ("compRatio", { pD.getX() + 72, pD.getY() + 512, 62, 105 });
    placeSlider ("compAttack", { pD.getX() + 134, pD.getY() + 512, 62, 105 });
    placeSlider ("compRelease", { pD.getX() + 196, pD.getY() + 512, 62, 105 });
    placeSlider ("compKnee", { pD.getX() + 41, pD.getY() + 650, 74, 112 });
    placeSlider ("compMakeup", { pD.getX() + 145, pD.getY() + 650, 74, 112 });

    const auto pS = Layout::saturation();
    placeToggle ("saturationOn", { pS.getX() + 12, pS.getY() + 12, 32, 28 });
    placeChoice ("satType", { pS.getX() + 12, pS.getY() + 76, 186, 34 }, 4);
    placeSlider ("satGain", { pS.getX() + 20, pS.getY() + 145, 78, 126 });
    placeSlider ("saturation", { pS.getX() + 112, pS.getY() + 145, 78, 126 });
    placeSlider ("satTone", { pS.getX() + 20, pS.getY() + 320, 78, 126 });
    placeSlider ("satMix", { pS.getX() + 112, pS.getY() + 320, 78, 126 });
    placeChoice ("satCharacter", { pS.getX() + 12, pS.getY() + 500, 186, 34 }, 4);
    placeSlider ("satOutputTrim", { pS.getX() + 63, pS.getY() + 610, 84, 142 });

    const auto pSt = Layout::stereo();
    placeToggle ("stereoOn", { pSt.getX() + 12, pSt.getY() + 12, 32, 28 });
    placeChoice ("stereoMode", { pSt.getX() + 18, pSt.getY() + 76, 196, 34 }, 4);
    placeSlider ("stereoWidth", { pSt.getX() + 18, pSt.getY() + 155, 84, 132 });
    placeSlider ("pan", { pSt.getX() + 128, pSt.getY() + 155, 84, 132 });
    placeSlider ("stereoFocus", { pSt.getX() + 18, pSt.getY() + 365, 84, 132 });
    placeSlider ("stereoBalance", { pSt.getX() + 128, pSt.getY() + 365, 84, 132 });
    placeSlider ("stereoDetune", { pSt.getX() + 18, pSt.getY() + 575, 84, 132 });
    placeSlider ("stereoDelay", { pSt.getX() + 128, pSt.getY() + 575, 84, 132 });
    placeChoice ("bassMono", { pSt.getX() + 16, pSt.getY() + 760, 200, 30 }, 3);

    const auto pO = Layout::output();
    placeToggle ("outputOn", { pO.getX() + 12, pO.getY() + 12, 32, 28 });
    placeSlider ("vcaFader", { pO.getX() + 28, pO.getY() + 90, 90, 150 });
    placeToggle ("autoLevel", { pO.getX() + 20, pO.getY() + 690, 106, 34 });
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (cBg);
    juce::ColourGradient headerGrad (juce::Colour::fromRGB (19, 33, 40), 0.0f, 0.0f,
                                     juce::Colour::fromRGB (9, 17, 22), (float) getWidth(), 80.0f, false);
    g.setGradientFill (headerGrad);
    g.fillRect (0, 0, getWidth(), 80);
    g.setColour (cEdge.withAlpha (0.85f));
    g.drawHorizontalLine (79, 0.0f, (float) getWidth());

    drawLogo (g, { 24.0f, 18.0f, 42.0f, 44.0f });
    g.setColour (cText);
    g.setFont (juce::Font (26.0f, juce::Font::bold));
    g.drawText ("S I L V E T O N", 78, 14, 240, 30, juce::Justification::centredLeft);
    g.setColour (cMuted);
    g.setFont (juce::Font (12.0f, juce::Font::plain));
    g.drawText ("C  H  A  N  N  E  L    S  T  R  I  P", 284, 25, 250, 22, juce::Justification::centredLeft);

    drawPanel (g, Layout::input(), "INPUT");
    drawPanel (g, Layout::filters(), "FILTERS");
    drawPanel (g, Layout::eq(), "EQUALIZER");
    drawPanel (g, Layout::dynamics(), "DYNAMICS");
    drawPanel (g, Layout::saturation(), "SATURATION");
    drawPanel (g, Layout::stereo(), "STEREO");
    drawPanel (g, Layout::output(), "OUTPUT");

    // Approved Stereo-section label. Keep this visible: it belongs to the Bass Mono selector below.
    const auto pStereo = Layout::stereo();
    g.setColour (cMuted);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText ("BASS MONO", pStereo.getX() + 18, pStereo.getY() + 735, 196, 18,
                juce::Justification::centred);

    // EQ band colour markers and labels.
    const auto pEq = Layout::eq();
    const struct { const char* name; int y; juce::Colour colour; } bands[] = {
        { "HF", 86, juce::Colour::fromRGB (247, 91, 126) },
        { "HMF", 281, juce::Colour::fromRGB (249, 159, 112) },
        { "LMF", 476, juce::Colour::fromRGB (86, 213, 123) },
        { "LF", 669, juce::Colour::fromRGB (65, 153, 242) }
    };
    for (const auto& b : bands)
    {
        g.setColour (b.colour);
        g.fillEllipse ((float) pEq.getX() + 14.0f, (float) pEq.getY() + b.y, 14.0f, 14.0f);
        g.setColour (b.colour.brighter (0.1f));
        g.setFont (juce::Font (11.0f, juce::Font::bold));
        g.drawText (b.name, pEq.getX() + 34, pEq.getY() + b.y - 3, 44, 20, juce::Justification::centredLeft);
    }

    // Dynamics subgroup labels and separators.
    const auto pD = Layout::dynamics();
    g.setColour (cText);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("GATE / EXPANDER", pD.getX() + 48, pD.getY() + 52, 150, 18, juce::Justification::centredLeft);
    g.drawText ("COMPRESSOR", pD.getX() + 48, pD.getY() + 424, 130, 18, juce::Justification::centredLeft);
    g.setColour (cEdge.withAlpha (0.8f));
    g.drawHorizontalLine (pD.getY() + 406, (float) pD.getX() + 12.0f, (float) pD.getRight() - 12.0f);

    drawReductionMeter (g, { pD.getX() + 232, pD.getY() + 142, 52, 238 }, gateGr);
    drawReductionMeter (g, { pD.getX() + 234, pD.getY() + 650, 50, 112 }, compGr);

    // Output meter.
    const auto pO = Layout::output();
    drawStereoMeter (g, { pO.getX() + 22, pO.getY() + 300, 102, 340 }, outL, outR, outHoldL, outHoldR);

    // Footer.
    juce::ColourGradient footerGrad (juce::Colour::fromRGB (13, 24, 30), 0.0f, 924.0f,
                                     juce::Colour::fromRGB (7, 13, 17), (float) getWidth(), 1024.0f, false);
    g.setGradientFill (footerGrad);
    g.fillRect (0, 924, getWidth(), 100);
    g.setColour (cEdge.withAlpha (0.85f));
    g.drawHorizontalLine (924, 0.0f, (float) getWidth());
    g.setColour (cMuted.withAlpha (0.80f));
    g.setFont (juce::Font (9.0f));
    g.drawText ("P R E C I S I O N   T O   C H A R A C T E R", 38, 958, 330, 22, juce::Justification::centredLeft);
    g.drawText ("M I X I N G   W I T H O U T   L I M I T S", 1234, 958, 240, 22, juce::Justification::centredRight);
    g.setColour (cEdge);
    g.drawLine (352.0f, 970.0f, 578.0f, 970.0f, 1.0f);
    g.drawLine (960.0f, 970.0f, 1184.0f, 970.0f, 1.0f);
    g.setColour (cText.withAlpha (0.85f));
    g.setFont (juce::Font (10.0f));
    g.drawText ("S I L V E T O N   C H A N N E L   S T R I P", 602, 952, 334, 36, juce::Justification::centred);
    g.setColour (cMuted);
    g.drawText ("v0.5.1", 1470, 957, 52, 20, juce::Justification::centredRight);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, juce::Rectangle<int> r,
                                                           const juce::String& title) const
{
    juce::ColourGradient grad (cPanelTop, (float) r.getX(), (float) r.getY(),
                               cPanelBottom, (float) r.getRight(), (float) r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (cEdge.withAlpha (0.95f));
    g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.0f);
    g.setColour (cText);
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText (title, r.getX() + 54, r.getY() + 13, r.getWidth() - 66, 22, juce::Justification::centredLeft);
    g.setColour (cEdge.withAlpha (0.85f));
    g.drawHorizontalLine (r.getY() + 51, (float) r.getX() + 12.0f, (float) r.getRight() - 12.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawLogo (juce::Graphics& g, juce::Rectangle<float> r) const
{
    juce::Path p;
    p.startNewSubPath (r.getX() + r.getWidth() * 0.72f, r.getY());
    p.cubicTo (r.getX() + r.getWidth() * 0.35f, r.getY() + r.getHeight() * 0.16f,
               r.getX() + r.getWidth() * 0.10f, r.getY() + r.getHeight() * 0.28f,
               r.getX() + r.getWidth() * 0.17f, r.getY() + r.getHeight() * 0.45f);
    p.cubicTo (r.getX() + r.getWidth() * 0.28f, r.getY() + r.getHeight() * 0.64f,
               r.getX() + r.getWidth() * 0.70f, r.getY() + r.getHeight() * 0.56f,
               r.getX() + r.getWidth() * 0.72f, r.getY() + r.getHeight() * 0.74f);
    p.cubicTo (r.getX() + r.getWidth() * 0.72f, r.getY() + r.getHeight() * 0.86f,
               r.getX() + r.getWidth() * 0.42f, r.getY() + r.getHeight(),
               r.getX() + r.getWidth() * 0.24f, r.getBottom());
    juce::ColourGradient grad (juce::Colour::fromRGB (185, 225, 244), r.getX(), r.getY(),
                               cBlue2, r.getRight(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.strokePath (p, juce::PathStrokeType (8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void ConsoleChannelStripXAudioProcessorEditor::drawStereoMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                 float leftDb, float rightDb,
                                                                 float holdLeftDb, float holdRightDb) const
{
    const int scaleW = 28;
    auto scale = r.removeFromLeft (scaleW);
    auto bars = r.reduced (4, 4);
    const int gap = 7;
    auto left = bars.removeFromLeft ((bars.getWidth() - gap) / 2);
    bars.removeFromLeft (gap);
    auto right = bars;

    const auto dbToNorm = [] (float db) { return juce::jmap (juce::jlimit (-60.0f, 6.0f, db), -60.0f, 6.0f, 0.0f, 1.0f); };
    for (int db : { 6, 0, -12, -24, -36, -48, -60 })
    {
        const int y = r.getBottom() - juce::roundToInt ((float) r.getHeight() * dbToNorm ((float) db));
        g.setColour (cMuted.withAlpha (0.75f));
        g.setFont (juce::Font (7.5f));
        g.drawText (juce::String (db), scale.getX(), y - 5, scale.getWidth() - 2, 10, juce::Justification::centredRight);
    }

    const auto drawBar = [&] (juce::Rectangle<int> bar, float db, float hold)
    {
        g.setColour (cField);
        g.fillRoundedRectangle (bar.toFloat(), 2.0f);
        const int fillH = juce::roundToInt ((float) bar.getHeight() * dbToNorm (db));
        auto fill = bar.withTop (bar.getBottom() - fillH);
        juce::ColourGradient meter (cGreen, 0.0f, (float) bar.getBottom(), cRed, 0.0f, (float) bar.getY(), false);
        meter.addColour (0.72, cYellow);
        g.setGradientFill (meter);
        g.fillRoundedRectangle (fill.toFloat(), 2.0f);
        const int holdY = bar.getBottom() - juce::roundToInt ((float) bar.getHeight() * dbToNorm (hold));
        g.setColour (juce::Colours::white.withAlpha (0.95f));
        g.fillRect (bar.getX(), juce::jlimit (bar.getY(), bar.getBottom() - 1, holdY), bar.getWidth(), 1);
    };

    drawBar (left, leftDb, holdLeftDb);
    drawBar (right, rightDb, holdRightDb);
}

void ConsoleChannelStripXAudioProcessorEditor::drawReductionMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                    float reductionDb) const
{
    g.setColour (cField);
    g.fillRoundedRectangle (r.toFloat(), 3.0f);
    const float n = juce::jlimit (0.0f, 1.0f, std::abs (reductionDb) / 30.0f);
    const int fillH = juce::roundToInt (r.getHeight() * n);
    auto fill = r.withTop (r.getBottom() - fillH);
    juce::ColourGradient meter (cBlue, 0.0f, (float) r.getBottom(), cYellow, 0.0f, (float) r.getY(), false);
    g.setGradientFill (meter);
    g.fillRoundedRectangle (fill.toFloat(), 3.0f);
    g.setColour (cMuted);
    g.setFont (juce::Font (8.0f, juce::Font::bold));
    g.drawText ("GR", r.getX(), r.getY() - 16, r.getWidth(), 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    inL = smoothMeter (inL, audioProcessor.inputMeterL());
    inR = smoothMeter (inR, audioProcessor.inputMeterR());
    outL = smoothMeter (outL, audioProcessor.outputMeterL());
    outR = smoothMeter (outR, audioProcessor.outputMeterR());
    compGr = smoothMeter (compGr, audioProcessor.compressorPeakReductionMeter());
    gateGr = smoothMeter (gateGr, audioProcessor.gatePeakReductionMeter());
    updatePeakHold (inL, inHoldL, inHoldTicksL);
    updatePeakHold (inR, inHoldR, inHoldTicksR);
    updatePeakHold (outL, outHoldL, outHoldTicksL);
    updatePeakHold (outR, outHoldR, outHoldTicksR);
    syncChoiceButtons();
    repaint();
}

void ConsoleChannelStripXAudioProcessorEditor::syncChoiceButtons()
{
    for (auto& group : choiceControls)
    {
        auto* raw = audioProcessor.parameters().getRawParameterValue (juce::String (group->parameterId));
        if (raw == nullptr) continue;
        const int rawSelected = (int) std::lround (raw->load());
        const int selected = group->parameterId == "compPeak" ? 1 - rawSelected : rawSelected;
        for (int i = 0; i < (int) group->buttons.size(); ++i)
            group->buttons[(size_t) i]->setToggleState (i == selected, juce::dontSendNotification);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::cyclePreset (int delta)
{
    int id = presetBox.getSelectedId();
    if (id < 1 || id > 4) id = 1;
    id += delta;
    if (id < 1) id = 4;
    if (id > 4) id = 1;
    presetBox.setSelectedId (id, juce::sendNotificationSync);
}

void ConsoleChannelStripXAudioProcessorEditor::setParameterActual (const char* id, float actual)
{
    if (auto* p = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (juce::String (id))))
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost (p->convertTo0to1 (actual));
        p->endChangeGesture();
    }
}

void ConsoleChannelStripXAudioProcessorEditor::applyPreset (int presetId)
{
    if (presetId == 1)
    {
        // True neutral INIT, independent of the approved Vocal factory presentation.
        setParameterActual ("inputOn", 1.0f); setParameterActual ("inputDrive", 0.0f); setParameterActual ("inputTrim", 0.0f);
        setParameterActual ("inputMode", 0.0f); setParameterActual ("inputPad", 0.0f); setParameterActual ("polarity", 0.0f);
        setParameterActual ("filtersOn", 1.0f); setParameterActual ("hpOn", 0.0f); setParameterActual ("lpOn", 0.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("hfGain", 0.0f); setParameterActual ("hmfGain", 0.0f);
        setParameterActual ("lmfGain", 0.0f); setParameterActual ("lfGain", 0.0f);
        setParameterActual ("dynOn", 0.0f); setParameterActual ("gateOn", 0.0f); setParameterActual ("compOn", 0.0f);
        setParameterActual ("compMakeup", 0.0f); setParameterActual ("saturationOn", 0.0f); setParameterActual ("saturation", 0.0f);
        setParameterActual ("stereoOn", 1.0f); setParameterActual ("stereoWidth", 0.0f); setParameterActual ("pan", 0.0f);
        setParameterActual ("stereoBalance", 0.0f); setParameterActual ("stereoDetune", 0.0f); setParameterActual ("stereoDelay", 0.0f);
        setParameterActual ("bassMono", 0.0f); setParameterActual ("outputOn", 1.0f); setParameterActual ("vcaFader", 0.0f);
        setParameterActual ("outputTrim", 0.0f); setParameterActual ("autoLevel", 0.0f); setParameterActual ("mix", 100.0f);
        setParameterActual ("mute", 0.0f); setParameterActual ("bypass", 0.0f);
        return;
    }

    if (presetId == 2)
    {
        setParameterActual ("hpOn", 1.0f); setParameterActual ("hpFreq", 80.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("hmfFreq", 2800.0f); setParameterActual ("hmfGain", 1.8f);
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 3.0f);
        setParameterActual ("compThreshold", -16.0f); setParameterActual ("saturationOn", 1.0f); setParameterActual ("saturation", 38.0f);
    }
    else if (presetId == 3)
    {
        setParameterActual ("hpOn", 1.0f); setParameterActual ("hpFreq", 35.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("lfGain", 2.5f); setParameterActual ("hmfGain", 2.0f);
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 4.0f);
        setParameterActual ("compAttack", 18.0f); setParameterActual ("saturation", 48.0f);
    }
    else if (presetId == 4)
    {
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 2.0f);
        setParameterActual ("compThreshold", -10.0f); setParameterActual ("compAttack", 30.0f); setParameterActual ("compRelease", 0.35f);
        setParameterActual ("saturationOn", 1.0f); setParameterActual ("saturation", 22.0f); setParameterActual ("satCharacter", 0.0f);
        setParameterActual ("stereoWidth", 10.0f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::toggleAB()
{
    if (usingA)
    {
        slotA = audioProcessor.parameters().copyState();
        audioProcessor.parameters().replaceState (slotB.createCopy());
        usingA = false;
    }
    else
    {
        slotB = audioProcessor.parameters().copyState();
        audioProcessor.parameters().replaceState (slotA.createCopy());
        usingA = true;
    }
    abButton.setTooltip (usingA ? "A active" : "B active");
}

void ConsoleChannelStripXAudioProcessorEditor::showMainMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("EQ MODEL");
    m.addItem (1, "02 Brown");
    m.addItem (2, "242 Black");
    m.addSeparator();
    m.addSectionHeader ("ROUTING");
    m.addItem (10, "FLT > EQ > DYN");
    m.addItem (11, "FLT > DYN > EQ");
    m.addItem (12, "DYN > FLT > EQ");
    m.addSeparator();
    m.addItem (20, "Mute / Unmute");

    auto safe = juce::Component::SafePointer<ConsoleChannelStripXAudioProcessorEditor> (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&menuButton), [safe] (int result)
    {
        if (safe == nullptr || result == 0) return;
        if (result == 1) safe->setParameterActual ("eqModel", 0.0f);
        else if (result == 2) safe->setParameterActual ("eqModel", 1.0f);
        else if (result >= 10 && result <= 12) safe->setParameterActual ("routing", (float) (result - 10));
        else if (result == 20)
        {
            const float current = safe->audioProcessor.parameters().getRawParameterValue ("mute")->load();
            safe->setParameterActual ("mute", current > 0.5f ? 0.0f : 1.0f);
        }
    });
}

void ConsoleChannelStripXAudioProcessorEditor::showSettingsMenu()
{
    juce::PopupMenu m;
    m.addItem (1, "Reset approved 1536 x 1024 view");
    m.addItem (2, "INIT all parameters");
    m.addSeparator();
    m.addItem (3, "Silveton Channel Strip v0.5.1", false, false);
    auto safe = juce::Component::SafePointer<ConsoleChannelStripXAudioProcessorEditor> (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&settingsButton), [safe] (int result)
    {
        if (safe == nullptr) return;
        if (result == 1) safe->setSize (kDesignWidth, kDesignHeight);
        else if (result == 2) safe->presetBox.setSelectedId (1, juce::sendNotificationSync);
    });
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatParameterValue (const juce::String& id, double value)
{
    if (containsIgnoreCase (id, "freq") || id == "stereoFocus")
    {
        if (value >= 1000.0)
            return juce::String (value / 1000.0, value >= 10000.0 ? 1 : 2) + " kHz";
        return juce::String (value, value < 100.0 ? 1 : 0) + " Hz";
    }
    if (id == "gateAttack" || id == "compAttack" || id == "stereoDelay")
        return juce::String (value, value < 10.0 ? 1 : 0) + " ms";
    if (id == "gateRelease" || id == "gateHold" || id == "compRelease")
        return value < 1.0 ? juce::String (value * 1000.0, 0) + " ms" : juce::String (value, 2) + " s";
    if (id == "stereoDetune")
        return juce::String (value, 1) + " ct";
    if (id == "mix" || id == "saturation" || id == "satMix" || id == "compKnee")
        return juce::String (value, 0) + " %";
    if (id == "stereoWidth")
        return juce::String (100.0 + value, 0) + " %";
    if (id == "satTone")
        return juce::String (value, 0) + " %";
    if (id == "pan" || id == "stereoBalance")
    {
        if (std::abs (value) < 0.005) return "C";
        return value < 0.0 ? "L " + juce::String (std::abs (value) * 100.0, 0)
                           : "R " + juce::String (value * 100.0, 0);
    }
    if (containsIgnoreCase (id, "q"))
        return juce::String (value, 2);
    if (id == "compRatio")
        return juce::String (value, 1) + ":1";
    return juce::String (value, 1) + " dB";
}

double ConsoleChannelStripXAudioProcessorEditor::parseParameterValue (const juce::String& id, const juce::String& raw)
{
    auto s = raw.trim().toLowerCase();
    double value = s.getDoubleValue();
    if ((containsIgnoreCase (id, "freq") || id == "stereoFocus") && s.containsChar ('k')) value *= 1000.0;
    if ((id == "gateRelease" || id == "gateHold" || id == "compRelease") && s.contains ("ms")) value *= 0.001;
    if (id == "stereoWidth" && s.containsChar ('%')) value -= 100.0;
    if (id == "pan" || id == "stereoBalance")
    {
        if (s.startsWithChar ('l')) return -std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('r')) return std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('c')) return 0.0;
    }
    return value;
}

float ConsoleChannelStripXAudioProcessorEditor::smoothMeter (float current, float target) noexcept
{
    if (target > current) return target;
    return current + (target - current) * 0.18f;
}

void ConsoleChannelStripXAudioProcessorEditor::updatePeakHold (float value, float& hold, int& ticks) noexcept
{
    if (value >= hold) { hold = value; ticks = 28; }
    else if (ticks > 0) --ticks;
    else hold = juce::jmax (value, hold - 1.25f);
}
