SILVETON CHANNEL STRIP v0.5.1 — APPROVED GUI BUILD PATCH

База: заключената работеща Console Channel Strip X v0.4.1 Wien RC.
Цел: Mac Intel x86_64, deployment target macOS 10.13.

Тази версия следва одобрения 1536x1024 Silveton mockup: INPUT, FILTERS, EQUALIZER, DYNAMICS, SATURATION, STEREO, OUTPUT, preset bar, A/B, Undo/Redo, Mix и meters.

Всички 67 видими параметърни контроли имат реални APVTS параметри. GUI тестът ги упражнява и допълнително проверява аудио ефект за новите slope/Q/attack/knee/makeup/saturation/stereo функции.
Заключените core DSP файлове от v0.4.1 се fingerprint-ват преди/след и workflow-ът пада, ако са променени.

За build: качи build-silveton-v051-macos-intel.yml в .github/workflows/ и пусни workflow-а.
