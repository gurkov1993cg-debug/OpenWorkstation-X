#pragma once
#include <JuceHeader.h>
#include <map>
#include <memory>
#include "PluginProcessor.h"

class ConsoleLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    ConsoleLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                           float sliderPosProportional, float rotaryStartAngle,
                           float rotaryEndAngle, juce::Slider&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool shouldDrawButtonAsHighlighted,
                           bool shouldDrawButtonAsDown) override;
    void drawComboBox (juce::Graphics&, int width, int height, bool isButtonDown,
                       int buttonX, int buttonY, int buttonW, int buttonH,
                       juce::ComboBox&) override;
};

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    enum class ValueStyle { dB, frequency, q, ratio, attackMs, release, percent, plain };

    void addKnob (const juce::String& id, const juce::String& label,
                  juce::Colour accent, ValueStyle style);
    void addButton (const juce::String& id, const juce::String& label, juce::Colour accent);
    void timerCallback() override;
    void placeKnob (const juce::String& id, int x, int y, int w = 92, int h = 112);
    void placeButton (const juce::String& id, int x, int y, int w = 88, int h = 26);

    static juce::String formatValue (double value, ValueStyle style);
    static void drawPanel (juce::Graphics&, juce::Rectangle<int>, const juce::String& title);
    static void drawMeter (juce::Graphics&, juce::Rectangle<int>, float levelDb,
                           const juce::String& title, float minDb = -60.0f, float maxDb = 0.0f);
    static void drawGRMeter (juce::Graphics&, juce::Rectangle<int>, float reductionDb,
                             const juce::String& title, float maxReductionDb);

    ConsoleChannelStripXAudioProcessor& audioProcessor;
    ConsoleLookAndFeel consoleLook;

    std::map<juce::String, std::unique_ptr<juce::Slider>> knobs;
    std::map<juce::String, std::unique_ptr<juce::ToggleButton>> buttons;
    std::vector<std::unique_ptr<SliderAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<ButtonAttachment>> buttonAttachments;

    juce::ComboBox eqModelBox;
    juce::ComboBox routingBox;
    std::unique_ptr<ComboAttachment> eqModelAttachment;
    std::unique_ptr<ComboAttachment> routingAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
