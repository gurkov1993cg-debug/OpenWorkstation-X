#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_dsp/juce_dsp.h>
#include <atomic>

class DspEngine
{
public:
    using IIR = juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>>;

    struct Params
    {
        float inputTrimDb = 0.0f;
        float inputDrive = 0.0f;
        bool polarity = false;

        bool hpOn = false;
        float hpFreq = 80.0f;
        bool lpOn = false;
        float lpFreq = 18000.0f;

        bool eqOn = true;
        bool blackEq = true; // false = 02 Brown, true = 242 Black
        bool lfBell = false;
        float lfFreq = 80.0f;
        float lfGain = 0.0f;
        float lmfFreq = 500.0f;
        float lmfGain = 0.0f;
        float lmfQ = 1.0f;
        float hmfFreq = 2500.0f;
        float hmfGain = 0.0f;
        float hmfQ = 1.0f;
        bool hfBell = false;
        float hfFreq = 10000.0f;
        float hfGain = 0.0f;

        bool dynOn = true;
        bool compOn = true;
        float compThresholdDb = -10.0f;
        float compRatio = 4.0f;
        float compAttackMs = 10.0f;
        float compReleaseSec = 0.30f;
        bool compFast = false;

        bool gateOn = false;
        float gateThresholdDb = -30.0f;
        float gateRangeDb = 20.0f;
        float gateAttackMs = 1.5f;
        float gateReleaseSec = 0.30f;
        bool gateFast = false;
        bool gateExpand = false;

        int routing = 0;
        float vcaFaderDb = 0.0f;
        float outputTrimDb = 0.0f;
        float mix = 1.0f;
        bool mute = false;
        bool bypass = false;
    };

    void prepare (double sampleRate, int maximumBlockSize, int numChannels);
    void reset();
    void process (juce::AudioBuffer<float>& buffer, const Params& p);

    float getCompressorGainReductionDb() const noexcept { return compMeterDb.load(); }
    float getGateGainReductionDb() const noexcept { return gateMeterDb.load(); }
    float getInputPeakDb() const noexcept { return inputPeakDb.load(); }
    float getOutputPeakDb() const noexcept { return outputPeakDb.load(); }

private:
    void updateFilters (const Params& p);
    void processFilters (juce::AudioBuffer<float>& buffer, const Params& p);
    void processEQ (juce::AudioBuffer<float>& buffer, const Params& p);
    void processDynamics (juce::AudioBuffer<float>& buffer, const Params& p);
    void processInputStage (juce::AudioBuffer<float>& buffer, const Params& p);
    void processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p);

    static float softKneeGainReduction (float levelDb, float thresholdDb, float ratio, float kneeDb);
    static float consoleSaturate (float x, float amount);
    static float bufferPeakDb (const juce::AudioBuffer<float>& buffer);

    double sr = 48000.0;
    IIR hp1, hp2, lp, lf, lmf, hmf, hf;
    juce::AudioBuffer<float> dryBuffer;
    juce::AudioBuffer<float> globalDryBuffer;

    float compGainDb = 0.0f;
    float rmsSquare = 0.0f;
    float gateGainDb = 0.0f;
    bool gateOpen = true;

    std::atomic<float> compMeterDb { 0.0f };
    std::atomic<float> gateMeterDb { 0.0f };
    std::atomic<float> inputPeakDb { -100.0f };
    std::atomic<float> outputPeakDb { -100.0f };
};
