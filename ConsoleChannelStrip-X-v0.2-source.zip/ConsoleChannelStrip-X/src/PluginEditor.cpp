#include "PluginEditor.h"

namespace ColoursX
{
    const auto bg       = juce::Colour (0xff0c0e0f);
    const auto panel    = juce::Colour (0xff171a1c);
    const auto border   = juce::Colour (0xff3a3d40);
    const auto text     = juce::Colour (0xffe7e2d7);
    const auto muted    = juce::Colour (0xff8f9496);
    const auto gold     = juce::Colour (0xffd2a94b);
    const auto red      = juce::Colour (0xffa4483e);
    const auto orange   = juce::Colour (0xffc87935);
    const auto blue     = juce::Colour (0xff3f79ad);
    const auto green    = juce::Colour (0xff5a925b);
    const auto purple   = juce::Colour (0xff74578f);
    const auto cream    = juce::Colour (0xffc7b99b);
    const auto silver   = juce::Colour (0xffbdbbb2);
}

ConsoleLookAndFeel::ConsoleLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, ColoursX::text);
    setColour (juce::Slider::textBoxBackgroundColourId, juce::Colour (0xff0e1011));
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colour (0xff55585a));
    setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff0f1112));
    setColour (juce::ComboBox::textColourId, ColoursX::text);
    setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff515456));
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff151819));
    setColour (juce::PopupMenu::textColourId, ColoursX::text);
}

void ConsoleLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPosProportional, float rotaryStartAngle,
                                            float rotaryEndAngle, juce::Slider& slider)
{
    auto area = juce::Rectangle<float> (static_cast<float> (x), static_cast<float> (y),
                                        static_cast<float> (width), static_cast<float> (height));

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText (slider.getName(), area.removeFromTop (16.0f), juce::Justification::centred);

    const float diameter = juce::jmin (area.getWidth(), area.getHeight()) - 12.0f;
    auto knob = area.withSizeKeepingCentre (diameter, diameter).translated (0.0f, -2.0f);
    const float radius = diameter * 0.5f;
    const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

    g.setColour (juce::Colour (0xff272a2c));
    g.fillEllipse (knob);
    g.setColour (juce::Colour (0xff090a0b));
    g.drawEllipse (knob, 2.0f);

    juce::Path arc;
    arc.addCentredArc (knob.getCentreX(), knob.getCentreY(), radius - 5.0f, radius - 5.0f,
                       0.0f, rotaryStartAngle, angle, true);
    g.setColour (slider.findColour (juce::Slider::rotarySliderFillColourId));
    g.strokePath (arc, juce::PathStrokeType (5.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path pointer;
    const float pointerLength = radius * 0.62f;
    const float pointerThickness = 2.6f;
    pointer.addRoundedRectangle (-pointerThickness * 0.5f, -radius + 7.0f,
                                 pointerThickness, pointerLength, 1.2f);
    g.setColour (ColoursX::text);
    g.fillPath (pointer, juce::AffineTransform::rotation (angle).translated (knob.getCentreX(), knob.getCentreY()));

    g.setColour (juce::Colour (0xff4d5153));
    for (int i = 0; i <= 10; ++i)
    {
        const float a = rotaryStartAngle + (rotaryEndAngle - rotaryStartAngle) * static_cast<float> (i) / 10.0f;
        const auto c = knob.getCentre();
        const float r1 = radius + 1.0f;
        const float r2 = radius + 5.0f;
        g.drawLine (c.x + std::sin (a) * r1, c.y - std::cos (a) * r1,
                    c.x + std::sin (a) * r2, c.y - std::cos (a) * r2, 1.0f);
    }
}

void ConsoleLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                                            bool highlighted, bool down)
{
    auto r = button.getLocalBounds().toFloat().reduced (1.0f);
    const auto accent = button.findColour (juce::ToggleButton::tickColourId);
    auto fill = juce::Colour (0xff111314);
    if (button.getToggleState()) fill = accent.withAlpha (0.22f);
    if (highlighted) fill = fill.brighter (0.08f);
    if (down) fill = fill.darker (0.10f);

    g.setColour (fill);
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (button.getToggleState() ? accent : juce::Colour (0xff55595b));
    g.drawRoundedRectangle (r, 3.0f, button.getToggleState() ? 1.8f : 1.0f);

    auto led = r.removeFromLeft (15.0f).reduced (4.0f);
    g.setColour (button.getToggleState() ? accent : juce::Colour (0xff303335));
    g.fillEllipse (led);

    g.setColour (ColoursX::text);
    g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawText (button.getButtonText(), r.reduced (2.0f, 0.0f), juce::Justification::centred);
}

void ConsoleLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool,
                                        int, int, int, int, juce::ComboBox& box)
{
    auto r = juce::Rectangle<float> (0.0f, 0.0f, static_cast<float> (width), static_cast<float> (height)).reduced (0.5f);
    g.setColour (box.findColour (juce::ComboBox::backgroundColourId));
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (box.findColour (juce::ComboBox::outlineColourId));
    g.drawRoundedRectangle (r, 3.0f, 1.0f);

    juce::Path arrow;
    const float cx = width - 13.0f;
    const float cy = height * 0.5f;
    arrow.startNewSubPath (cx - 4.0f, cy - 2.0f);
    arrow.lineTo (cx, cy + 2.0f);
    arrow.lineTo (cx + 4.0f, cy - 2.0f);
    g.setColour (ColoursX::gold);
    g.strokePath (arrow, juce::PathStrokeType (1.5f));
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&consoleLook);
    setSize (1320, 780);
    setResizable (false, false);

    addKnob ("inputTrim", "INPUT TRIM", ColoursX::red, ValueStyle::dB);
    addKnob ("inputDrive", "DRIVE", ColoursX::red, ValueStyle::percent);
    addButton ("polarity", "PHASE Ø", ColoursX::cream);

    addButton ("hpOn", "HPF IN", ColoursX::green);
    addKnob ("hpFreq", "HIGH PASS", ColoursX::green, ValueStyle::frequency);
    addButton ("lpOn", "LPF IN", ColoursX::green);
    addKnob ("lpFreq", "LOW PASS", ColoursX::green, ValueStyle::frequency);

    addButton ("eqOn", "EQ IN", ColoursX::gold);
    eqModelBox.addItemList ({ "02 BROWN", "242 BLACK" }, 1);
    eqModelBox.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (eqModelBox);
    eqModelAttachment = std::make_unique<ComboAttachment> (audioProcessor.parameters(), "eqModel", eqModelBox);

    addButton ("hfBell", "HF BELL", ColoursX::green);
    addKnob ("hfGain", "HF GAIN", ColoursX::green, ValueStyle::dB);
    addKnob ("hfFreq", "HF FREQ", ColoursX::green, ValueStyle::frequency);

    addKnob ("hmfGain", "HMF GAIN", ColoursX::blue, ValueStyle::dB);
    addKnob ("hmfFreq", "HMF FREQ", ColoursX::blue, ValueStyle::frequency);
    addKnob ("hmfQ", "HMF Q", ColoursX::blue, ValueStyle::q);

    addKnob ("lmfGain", "LMF GAIN", ColoursX::orange, ValueStyle::dB);
    addKnob ("lmfFreq", "LMF FREQ", ColoursX::orange, ValueStyle::frequency);
    addKnob ("lmfQ", "LMF Q", ColoursX::orange, ValueStyle::q);

    addButton ("lfBell", "LF BELL", ColoursX::red);
    addKnob ("lfGain", "LF GAIN", ColoursX::red, ValueStyle::dB);
    addKnob ("lfFreq", "LF FREQ", ColoursX::red, ValueStyle::frequency);

    addButton ("dynOn", "DYN IN", ColoursX::gold);
    addButton ("compOn", "COMP IN", ColoursX::cream);
    addButton ("compFast", "FAST x¼", ColoursX::cream);
    addKnob ("compThreshold", "THRESHOLD", ColoursX::cream, ValueStyle::dB);
    addKnob ("compRatio", "RATIO", ColoursX::cream, ValueStyle::ratio);
    addKnob ("compAttack", "ATTACK", ColoursX::cream, ValueStyle::attackMs);
    addKnob ("compRelease", "RELEASE", ColoursX::cream, ValueStyle::release);

    addButton ("gateOn", "GATE IN", ColoursX::purple);
    addButton ("gateExpand", "EXPAND", ColoursX::purple);
    addButton ("gateFast", "FAST x¼", ColoursX::purple);
    addKnob ("gateThreshold", "THRESHOLD", ColoursX::purple, ValueStyle::dB);
    addKnob ("gateRange", "RANGE", ColoursX::purple, ValueStyle::dB);
    addKnob ("gateAttack", "ATTACK", ColoursX::purple, ValueStyle::attackMs);
    addKnob ("gateRelease", "RELEASE", ColoursX::purple, ValueStyle::release);

    addKnob ("vcaFader", "VCA FADER", ColoursX::silver, ValueStyle::dB);
    addKnob ("outputTrim", "OUTPUT TRIM", ColoursX::silver, ValueStyle::dB);
    addButton ("mute", "MUTE", ColoursX::red);

    routingBox.addItemList ({ "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" }, 1);
    routingBox.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (routingBox);
    routingAttachment = std::make_unique<ComboAttachment> (audioProcessor.parameters(), "routing", routingBox);

    addKnob ("mix", "MIX", ColoursX::gold, ValueStyle::percent);
    addButton ("bypass", "BYPASS", ColoursX::red);

    startTimerHz (30);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    setLookAndFeel (nullptr);
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double value, ValueStyle style)
{
    switch (style)
    {
        case ValueStyle::dB:        return juce::String (value, 1) + " dB";
        case ValueStyle::frequency: return value >= 1000.0 ? juce::String (value / 1000.0, value >= 10000.0 ? 1 : 2) + " kHz"
                                                            : juce::String (value, 0) + " Hz";
        case ValueStyle::q:         return juce::String (value, 2);
        case ValueStyle::ratio:     return value >= 19.95 ? juce::String ("∞:1") : juce::String (value, 1) + ":1";
        case ValueStyle::attackMs:  return value < 1.0 ? juce::String (value, 2) + " ms" : juce::String (value, 1) + " ms";
        case ValueStyle::release:   return value < 1.0 ? juce::String (value * 1000.0, 0) + " ms" : juce::String (value, 2) + " s";
        case ValueStyle::percent:   return juce::String (value, 0) + "%";
        case ValueStyle::plain:     return juce::String (value, 2);
    }
    return {};
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label,
                                                         juce::Colour accent, ValueStyle style)
{
    auto s = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::TextBoxBelow);
    s->setName (label);
    s->setTextBoxStyle (juce::Slider::TextBoxBelow, false, 78, 20);
    s->setColour (juce::Slider::rotarySliderFillColourId, accent);
    s->setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff26292b));
    s->setColour (juce::Slider::thumbColourId, ColoursX::text);
    s->textFromValueFunction = [style] (double v) { return formatValue (v, style); };
    addAndMakeVisible (*s);
    sliderAttachments.push_back (std::make_unique<SliderAttachment> (audioProcessor.parameters(), id, *s));
    knobs[id] = std::move (s);
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const juce::String& id, const juce::String& label,
                                                           juce::Colour accent)
{
    auto b = std::make_unique<juce::ToggleButton> (label);
    b->setColour (juce::ToggleButton::textColourId, ColoursX::text);
    b->setColour (juce::ToggleButton::tickColourId, accent);
    addAndMakeVisible (*b);
    buttonAttachments.push_back (std::make_unique<ButtonAttachment> (audioProcessor.parameters(), id, *b));
    buttons[id] = std::move (b);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    g.setColour (ColoursX::panel);
    g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (ColoursX::border);
    g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.0f);
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (12.5f, juce::Font::bold));
    g.drawText (title, r.removeFromTop (28), juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawMeter (juce::Graphics& g, juce::Rectangle<int> r, float levelDb,
                                                           const juce::String& title, float minDb, float maxDb)
{
    g.setColour (juce::Colour (0xff090b0c));
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    g.setColour (juce::Colour (0xff45494b));
    g.drawRoundedRectangle (r.toFloat(), 2.0f, 1.0f);

    const int segments = 18;
    const int gap = 2;
    const int segH = juce::jmax (2, (r.getHeight() - (segments - 1) * gap) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, (levelDb - minDb) / (maxDb - minDb));
    const int lit = static_cast<int> (std::round (norm * segments));

    for (int i = 0; i < segments; ++i)
    {
        auto seg = juce::Rectangle<int> (r.getX() + 3,
                                         r.getBottom() - 3 - (i + 1) * segH - i * gap,
                                         r.getWidth() - 6, segH);
        juce::Colour c = juce::Colour (0xff24452b);
        const float p = static_cast<float> (i) / static_cast<float> (segments - 1);
        if (p > 0.84f) c = juce::Colour (0xffb84a37);
        else if (p > 0.66f) c = juce::Colour (0xffc9aa39);
        else c = juce::Colour (0xff56a960);
        g.setColour (i < lit ? c : c.withAlpha (0.15f));
        g.fillRoundedRectangle (seg.toFloat(), 1.0f);
    }

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText (title, r.getX() - 12, r.getY() - 18, r.getWidth() + 24, 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawGRMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                             float reductionDb, const juce::String& title,
                                                             float maxReductionDb)
{
    g.setColour (juce::Colour (0xff090b0c));
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    g.setColour (juce::Colour (0xff45494b));
    g.drawRoundedRectangle (r.toFloat(), 2.0f, 1.0f);

    const float norm = juce::jlimit (0.0f, 1.0f, reductionDb / maxReductionDb);
    const int h = static_cast<int> (std::round (norm * (r.getHeight() - 6)));
    auto fill = juce::Rectangle<int> (r.getX() + 3, r.getY() + 3, r.getWidth() - 6, h);
    g.setColour (ColoursX::gold);
    g.fillRoundedRectangle (fill.toFloat(), 1.0f);

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText (title, r.getX() - 14, r.getY() - 18, r.getWidth() + 28, 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (ColoursX::bg);

    g.setColour (juce::Colour (0xff141718));
    g.fillRect (0, 0, getWidth(), 52);
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (22.0f, juce::Font::bold));
    g.drawText ("CONSOLE CHANNEL STRIP X", 18, 6, 460, 34, juce::Justification::centredLeft);
    g.setColour (ColoursX::gold);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("E-SERIES CONSOLE WORKFLOW  •  v0.2", 470, 12, 365, 24, juce::Justification::centred);
    g.setColour (ColoursX::muted);
    g.drawText ("Intel x86_64  •  macOS 10.13+  •  VST3", 875, 12, 420, 24, juce::Justification::centredRight);

    drawPanel (g, { 12, 60, 148, 600 }, "INPUT");
    drawPanel (g, { 166, 60, 170, 600 }, "FILTERS");
    drawPanel (g, { 342, 60, 520, 600 }, "4-BAND EQUALISER");
    drawPanel (g, { 868, 60, 300, 600 }, "DYNAMICS");
    drawPanel (g, { 1174, 60, 134, 600 }, "OUTPUT");

    // EQ band separators and labels.
    const int eqX = 352;
    const int eqW = 500;
    const int rows[] = { 172, 294, 416, 538 };
    const juce::Colour bandColours[] = { ColoursX::green, ColoursX::blue, ColoursX::orange, ColoursX::red };
    const char* bandNames[] = { "HF", "HMF", "LMF", "LF" };
    for (int i = 0; i < 4; ++i)
    {
        g.setColour (juce::Colour (0xff333739));
        if (i > 0) g.drawHorizontalLine (rows[i] - 10, static_cast<float> (eqX), static_cast<float> (eqX + eqW));
        g.setColour (bandColours[i]);
        g.setFont (juce::Font (12.0f, juce::Font::bold));
        g.drawText (bandNames[i], eqX + 4, rows[i] - 98, 34, 18, juce::Justification::centredLeft);
    }

    // Dynamics split.
    g.setColour (juce::Colour (0xff333739));
    g.drawHorizontalLine (365, 878.0f, 1158.0f);
    g.setColour (ColoursX::cream);
    g.setFont (juce::Font (11.5f, juce::Font::bold));
    g.drawText ("COMPRESSOR / LIMITER", 884, 95, 182, 20, juce::Justification::centredLeft);
    g.setColour (ColoursX::purple);
    g.drawText ("GATE / EXPANDER", 884, 382, 182, 20, juce::Justification::centredLeft);

    drawMeter (g, { 128, 425, 18, 190 }, audioProcessor.inputMeter(), "IN");
    drawMeter (g, { 1276, 425, 18, 190 }, audioProcessor.outputMeter(), "OUT");
    drawGRMeter (g, { 1122, 145, 17, 155 }, audioProcessor.compressorMeter(), "GR", 24.0f);
    drawGRMeter (g, { 1122, 425, 17, 155 }, audioProcessor.gateMeter(), "GATE", 40.0f);

    // Footer / routing strip.
    auto footer = juce::Rectangle<int> (12, 670, 1296, 98);
    g.setColour (juce::Colour (0xff141718));
    g.fillRoundedRectangle (footer.toFloat(), 5.0f);
    g.setColour (ColoursX::border);
    g.drawRoundedRectangle (footer.toFloat(), 5.0f, 1.0f);
    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawText ("ROUTING / ORDER", 36, 680, 180, 18, juce::Justification::centredLeft);
    g.drawText ("ALL VISIBLE CONTROLS ARE DSP-ACTIVE", 480, 680, 380, 18, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    repaint();
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = knobs.find (id); it != knobs.end())
        it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::placeButton (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = buttons.find (id); it != buttons.end())
        it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    // INPUT
    placeKnob ("inputTrim", 28, 108, 108, 118);
    placeKnob ("inputDrive", 28, 242, 108, 118);
    placeButton ("polarity", 36, 375, 100, 28);

    // FILTERS
    placeButton ("hpOn", 185, 112, 102, 27);
    placeKnob ("hpFreq", 202, 148, 100, 120);
    placeButton ("lpOn", 185, 330, 102, 27);
    placeKnob ("lpFreq", 202, 366, 100, 120);

    // EQ header
    placeButton ("eqOn", 360, 96, 84, 27);
    eqModelBox.setBounds (683, 96, 152, 27);

    // HF row
    placeKnob ("hfGain", 392, 128, 102, 112);
    placeKnob ("hfFreq", 510, 128, 102, 112);
    placeButton ("hfBell", 704, 168, 112, 27);

    // HMF row
    placeKnob ("hmfGain", 392, 250, 102, 112);
    placeKnob ("hmfFreq", 510, 250, 102, 112);
    placeKnob ("hmfQ", 628, 250, 102, 112);

    // LMF row
    placeKnob ("lmfGain", 392, 372, 102, 112);
    placeKnob ("lmfFreq", 510, 372, 102, 112);
    placeKnob ("lmfQ", 628, 372, 102, 112);

    // LF row
    placeKnob ("lfGain", 392, 494, 102, 112);
    placeKnob ("lfFreq", 510, 494, 102, 112);
    placeButton ("lfBell", 704, 534, 112, 27);

    // DYNAMICS master + comp
    placeButton ("dynOn", 1062, 92, 88, 27);
    placeButton ("compOn", 884, 120, 88, 27);
    placeButton ("compFast", 978, 120, 92, 27);
    placeKnob ("compThreshold", 884, 155, 94, 112);
    placeKnob ("compRatio", 985, 155, 94, 112);
    placeKnob ("compAttack", 884, 267, 94, 94);
    placeKnob ("compRelease", 985, 267, 94, 94);

    // gate
    placeButton ("gateOn", 884, 405, 88, 27);
    placeButton ("gateExpand", 978, 405, 84, 27);
    placeButton ("gateFast", 1066, 405, 84, 27);
    placeKnob ("gateThreshold", 884, 438, 94, 104);
    placeKnob ("gateRange", 985, 438, 94, 104);
    placeKnob ("gateAttack", 884, 545, 94, 104);
    placeKnob ("gateRelease", 985, 545, 94, 104);

    // OUTPUT
    placeKnob ("vcaFader", 1187, 112, 108, 118);
    placeKnob ("outputTrim", 1187, 250, 108, 118);
    placeButton ("mute", 1191, 386, 100, 28);

    // FOOTER
    routingBox.setBounds (36, 708, 280, 32);
    placeKnob ("mix", 950, 684, 106, 72);
    placeButton ("bypass", 1110, 710, 112, 30);
}
