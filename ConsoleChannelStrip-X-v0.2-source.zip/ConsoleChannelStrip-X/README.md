# Console Channel Strip X v0.2

A clean-room, E-series-inspired console channel-strip VST3 for Intel macOS.

## v0.2 goals

- New hardware-style GUI based on the approved dark E-series console layout.
- Every visible control is connected to a real DSP parameter.
- 02 Brown / 242 Black EQ model selector changes EQ/filter behaviour.
- Freely adjustable compressor Threshold, Ratio, Attack and Release.
- Compressor FAST mode scales the selected attack time by 1/4 instead of disabling the Attack knob.
- Gate/Expander with freely adjustable Threshold, Range, Attack and Release, plus FAST and EXPAND modes.
- Input Drive and VCA output stages add level-dependent non-linearity.
- Separate VCA Fader and clean Output Trim.
- Input, Output, Compressor GR and Gate GR meters.
- Three DSP routing orders and true global Dry/Wet Mix.
- Parameter smoke-test executable used by CI to catch disconnected controls.

## Reference behaviour

The implementation is an original clean-room approximation informed by public documentation and independent descriptions of SSL 4000 E-series workflows, including Universal Audio's SSL 4000 E documentation, SSL's public channel-strip documentation, Brainworx bx_console SSL 4000 E documentation, Waves SSL-family documentation, and independent engineering reviews. It does not contain proprietary code, impulse responses, schematics, trademarks in the product name, or copied artwork.

## Build target

- VST3
- x86_64 Intel
- macOS deployment target 10.13
- JUCE 7.0.12 with the existing macOS 15 SDK build compatibility patch
