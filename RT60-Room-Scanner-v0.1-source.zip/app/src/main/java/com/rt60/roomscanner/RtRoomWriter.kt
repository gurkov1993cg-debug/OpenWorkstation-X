package com.rt60.roomscanner

import android.content.Context
import android.net.Uri
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object RtRoomWriter {
    fun write(context: Context, uri: Uri, model: RoomModel) {
        context.contentResolver.openOutputStream(uri)?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                zip.putNextEntry(ZipEntry("room.json"))
                zip.write(model.toJson().toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()

                zip.putNextEntry(ZipEntry("manifest.txt"))
                zip.write(
                    "RT60 Room Scanner\nFormat: RTROOM/1\nContents: room geometry + wall descriptions\n"
                        .toByteArray(Charsets.UTF_8)
                )
                zip.closeEntry()
            }
        } ?: error("Cannot open output")
    }
}
