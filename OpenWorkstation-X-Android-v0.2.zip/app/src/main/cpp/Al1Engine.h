#pragma once

#include <array>
#include <atomic>
#include <cstdint>

class Al1Engine {
public:
    Al1Engine();

    void setSampleRate(float sampleRate);
    void noteOn(int note, float velocity);
    void noteOff(int note);
    void setParameter(int id, float normalizedValue);
    void render(float* interleavedStereo, int32_t frames);

private:
    enum class EnvStage : uint8_t { Idle, Attack, Decay, Sustain, Release };
    enum class VoiceMode : uint8_t { Poly = 0, Mono = 1 };
    enum class PortaMode : uint8_t { ConstantRate = 0, ConstantTime = 1 };
    enum class MonoPriority : uint8_t { Low = 0, High = 1, Last = 2 };

    struct Voice {
        int note = -1;
        float velocity = 0.0f;
        float currentMidi = 60.0f;
        float targetMidi = 60.0f;
        float glideStartMidi = 60.0f;
        int32_t glideSamplesDone = 0;
        int32_t glideSamplesTotal = 0;
        bool glideActive = false;
        float phase1 = 0.0f;
        float phase2 = 0.0f;
        float subPhase = 0.0f;
        float env = 0.0f;
        float lp1 = 0.0f;
        float lp2 = 0.0f;
        EnvStage stage = EnvStage::Idle;
    };

    enum class EventType : uint8_t { NoteOn, NoteOff };

    struct NoteEvent {
        EventType type = EventType::NoteOff;
        int note = 0;
        float velocity = 0.0f;
    };

    struct Params {
        float cutoff = 0.68f;
        float resonance = 0.22f;
        float detune = 0.28f;
        float attack = 0.07f;
        float release = 0.20f;
        VoiceMode voiceMode = VoiceMode::Poly;
        bool monoLegato = true;
        bool portaEnable = false;
        bool portaFingered = true;
        float portaTime = 0.22f;
        PortaMode portaMode = PortaMode::ConstantRate;
        MonoPriority priority = MonoPriority::Last;
    };

    static constexpr uint32_t kEventCapacity = 256;
    static constexpr int kMaxVoices = 64;

    class EventQueue {
    public:
        bool push(const NoteEvent& event);
        bool pop(NoteEvent& event);

    private:
        std::array<NoteEvent, kEventCapacity> events_{};
        std::atomic<uint32_t> write_{0};
        std::atomic<uint32_t> read_{0};
    };

    static float midiToHz(float note);
    static float polyBlep(float t, float dt);
    static float saw(float phase, float increment);
    static void advance(float& phase, float increment);

    Params snapshotParams() const;
    void processEvents(const Params& p);
    void applyNoteOn(int note, float velocity, const Params& p);
    void applyNoteOff(int note, const Params& p);

    void polyNoteOn(int note, float velocity, const Params& p, bool legatoInput);
    void polyNoteOff(int note);
    void monoNoteOn(const Params& p, bool hadHeldNotes);
    void monoNoteOff(int note, const Params& p);

    Voice& allocateVoice();
    void startVoice(Voice& v, int note, float velocity, bool retrigger,
                    bool usePortamento, float startMidi, const Params& p);
    void setVoiceTarget(Voice& v, int note, bool usePortamento, const Params& p);
    void configureGlide(Voice& v, float startMidi, float targetMidi, const Params& p);
    float portamentoSeconds(float distanceSemitones, const Params& p) const;
    void stepGlide(Voice& v);
    float renderVoice(Voice& voice, const Params& p);

    int chooseMonoNote(MonoPriority priority) const;
    float velocityForNote(int note) const;
    int heldCount() const;

    std::array<Voice, kMaxVoices> voices_{};
    EventQueue events_{};

    std::array<bool, 128> held_{};
    std::array<uint64_t, 128> heldOrder_{};
    std::array<float, 128> heldVelocity_{};
    uint64_t noteOrderCounter_ = 0;
    float lastTriggeredMidi_ = 60.0f;
    float lastMonoMidi_ = 60.0f;

    float sampleRate_ = 48000.0f;

    std::atomic<float> cutoffNorm_{0.68f};
    std::atomic<float> resonanceNorm_{0.22f};
    std::atomic<float> detuneNorm_{0.28f};
    std::atomic<float> attackNorm_{0.07f};
    std::atomic<float> releaseNorm_{0.20f};
    std::atomic<float> voiceModeNorm_{0.0f};
    std::atomic<float> monoLegatoNorm_{1.0f};
    std::atomic<float> portaEnableNorm_{0.0f};
    std::atomic<float> portaFingeredNorm_{1.0f};
    std::atomic<float> portaTimeNorm_{0.22f};
    std::atomic<float> portaModeNorm_{0.0f};
    std::atomic<float> monoPriorityNorm_{1.0f};
};
