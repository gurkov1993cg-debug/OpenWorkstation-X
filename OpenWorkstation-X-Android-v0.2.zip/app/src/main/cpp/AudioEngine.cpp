#include "AudioEngine.h"

#include <android/log.h>

namespace {
constexpr const char* kTag = "OpenWorkstationX";
}

AudioEngine& AudioEngine::instance() {
    static AudioEngine engine;
    return engine;
}

AudioEngine::~AudioEngine() {
    stop();
}

bool AudioEngine::openStream(aaudio_sharing_mode_t sharingMode) {
    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK || builder == nullptr) {
        return false;
    }

    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(builder, sharingMode);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(builder, 2);
    AAudioStreamBuilder_setDataCallback(builder, dataCallback, this);

    const aaudio_result_t result = AAudioStreamBuilder_openStream(builder, &stream_);
    AAudioStreamBuilder_delete(builder);

    if (result != AAUDIO_OK || stream_ == nullptr) {
        stream_ = nullptr;
        return false;
    }

    const int32_t sampleRate = AAudioStream_getSampleRate(stream_);
    synth_.setSampleRate(static_cast<float>(sampleRate));

    const int32_t burst = AAudioStream_getFramesPerBurst(stream_);
    if (burst > 0) {
        AAudioStream_setBufferSizeInFrames(stream_, burst * 2);
    }

    return true;
}

bool AudioEngine::start() {
    if (running_.load(std::memory_order_acquire)) return true;

    if (!openStream(AAUDIO_SHARING_MODE_EXCLUSIVE)) {
        if (!openStream(AAUDIO_SHARING_MODE_SHARED)) {
            __android_log_print(ANDROID_LOG_ERROR, kTag, "AAudio stream open failed");
            return false;
        }
    }

    const aaudio_result_t result = AAudioStream_requestStart(stream_);
    if (result != AAUDIO_OK) {
        __android_log_print(ANDROID_LOG_ERROR, kTag, "AAudio start failed: %s",
                            AAudio_convertResultToText(result));
        closeStream();
        return false;
    }

    running_.store(true, std::memory_order_release);
    return true;
}

void AudioEngine::stop() {
    if (!stream_) return;

    running_.store(false, std::memory_order_release);
    AAudioStream_requestStop(stream_);
    closeStream();
}

void AudioEngine::closeStream() {
    if (stream_) {
        AAudioStream_close(stream_);
        stream_ = nullptr;
    }
}

void AudioEngine::noteOn(int note, float velocity) {
    synth_.noteOn(note, velocity);
}

void AudioEngine::noteOff(int note) {
    synth_.noteOff(note);
}

void AudioEngine::setParameter(int id, float normalizedValue) {
    synth_.setParameter(id, normalizedValue);
}

aaudio_data_callback_result_t AudioEngine::dataCallback(
        AAudioStream*,
        void* userData,
        void* audioData,
        int32_t numFrames) {
    auto* engine = static_cast<AudioEngine*>(userData);
    auto* output = static_cast<float*>(audioData);
    engine->synth_.render(output, numFrames);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}
