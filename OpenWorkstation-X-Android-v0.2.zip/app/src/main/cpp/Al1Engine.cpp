#include "Al1Engine.h"

#include <algorithm>
#include <cmath>

namespace {
constexpr float kPi = 3.14159265358979323846f;
}

Al1Engine::Al1Engine() = default;

void Al1Engine::setSampleRate(float sampleRate) {
    if (sampleRate > 8000.0f) sampleRate_ = sampleRate;
}

bool Al1Engine::EventQueue::push(const NoteEvent& event) {
    const uint32_t write = write_.load(std::memory_order_relaxed);
    const uint32_t next = (write + 1u) % kEventCapacity;
    if (next == read_.load(std::memory_order_acquire)) return false;
    events_[write] = event;
    write_.store(next, std::memory_order_release);
    return true;
}

bool Al1Engine::EventQueue::pop(NoteEvent& event) {
    const uint32_t read = read_.load(std::memory_order_relaxed);
    if (read == write_.load(std::memory_order_acquire)) return false;
    event = events_[read];
    read_.store((read + 1u) % kEventCapacity, std::memory_order_release);
    return true;
}

void Al1Engine::noteOn(int note, float velocity) {
    NoteEvent e;
    e.type = EventType::NoteOn;
    e.note = std::clamp(note, 0, 127);
    e.velocity = std::clamp(velocity, 0.0f, 1.0f);
    events_.push(e);
}

void Al1Engine::noteOff(int note) {
    NoteEvent e;
    e.type = EventType::NoteOff;
    e.note = std::clamp(note, 0, 127);
    events_.push(e);
}

void Al1Engine::setParameter(int id, float normalizedValue) {
    const float v = std::clamp(normalizedValue, 0.0f, 1.0f);
    switch (id) {
        case 0: cutoffNorm_.store(v, std::memory_order_relaxed); break;
        case 1: resonanceNorm_.store(v, std::memory_order_relaxed); break;
        case 2: detuneNorm_.store(v, std::memory_order_relaxed); break;
        case 3: attackNorm_.store(v, std::memory_order_relaxed); break;
        case 4: releaseNorm_.store(v, std::memory_order_relaxed); break;
        case 5: voiceModeNorm_.store(v, std::memory_order_relaxed); break;
        case 6: monoLegatoNorm_.store(v, std::memory_order_relaxed); break;
        case 7: portaEnableNorm_.store(v, std::memory_order_relaxed); break;
        case 8: portaFingeredNorm_.store(v, std::memory_order_relaxed); break;
        case 9: portaTimeNorm_.store(v, std::memory_order_relaxed); break;
        case 10: portaModeNorm_.store(v, std::memory_order_relaxed); break;
        case 11: monoPriorityNorm_.store(v, std::memory_order_relaxed); break;
        default: break;
    }
}

Al1Engine::Params Al1Engine::snapshotParams() const {
    Params p;
    p.cutoff = cutoffNorm_.load(std::memory_order_relaxed);
    p.resonance = resonanceNorm_.load(std::memory_order_relaxed);
    p.detune = detuneNorm_.load(std::memory_order_relaxed);
    p.attack = attackNorm_.load(std::memory_order_relaxed);
    p.release = releaseNorm_.load(std::memory_order_relaxed);
    p.voiceMode = voiceModeNorm_.load(std::memory_order_relaxed) >= 0.5f
            ? VoiceMode::Mono : VoiceMode::Poly;
    p.monoLegato = monoLegatoNorm_.load(std::memory_order_relaxed) >= 0.5f;
    p.portaEnable = portaEnableNorm_.load(std::memory_order_relaxed) >= 0.5f;
    p.portaFingered = portaFingeredNorm_.load(std::memory_order_relaxed) >= 0.5f;
    p.portaTime = portaTimeNorm_.load(std::memory_order_relaxed);
    p.portaMode = portaModeNorm_.load(std::memory_order_relaxed) >= 0.5f
            ? PortaMode::ConstantTime : PortaMode::ConstantRate;
    const float pr = monoPriorityNorm_.load(std::memory_order_relaxed);
    p.priority = pr < 0.25f ? MonoPriority::Low
               : pr > 0.75f ? MonoPriority::Last
                             : MonoPriority::High;
    return p;
}

float Al1Engine::midiToHz(float note) {
    return 440.0f * std::exp2((note - 69.0f) / 12.0f);
}

float Al1Engine::polyBlep(float t, float dt) {
    if (dt <= 0.0f) return 0.0f;
    if (t < dt) {
        t /= dt;
        return t + t - t * t - 1.0f;
    }
    if (t > 1.0f - dt) {
        t = (t - 1.0f) / dt;
        return t * t + t + t + 1.0f;
    }
    return 0.0f;
}

float Al1Engine::saw(float phase, float increment) {
    float value = 2.0f * phase - 1.0f;
    value -= polyBlep(phase, increment);
    return value;
}

void Al1Engine::advance(float& phase, float increment) {
    phase += increment;
    phase -= std::floor(phase);
}

int Al1Engine::heldCount() const {
    int count = 0;
    for (bool h : held_) if (h) ++count;
    return count;
}

float Al1Engine::velocityForNote(int note) const {
    return heldVelocity_[std::clamp(note, 0, 127)];
}

int Al1Engine::chooseMonoNote(MonoPriority priority) const {
    if (priority == MonoPriority::Low) {
        for (int n = 0; n < 128; ++n) if (held_[n]) return n;
    } else if (priority == MonoPriority::High) {
        for (int n = 127; n >= 0; --n) if (held_[n]) return n;
    } else {
        uint64_t newest = 0;
        int chosen = -1;
        for (int n = 0; n < 128; ++n) {
            if (held_[n] && heldOrder_[n] >= newest) {
                newest = heldOrder_[n];
                chosen = n;
            }
        }
        return chosen;
    }
    return -1;
}

void Al1Engine::processEvents(const Params& p) {
    NoteEvent e;
    while (events_.pop(e)) {
        if (e.type == EventType::NoteOn) applyNoteOn(e.note, e.velocity, p);
        else applyNoteOff(e.note, p);
    }
}

void Al1Engine::applyNoteOn(int note, float velocity, const Params& p) {
    const bool hadHeldNotes = heldCount() > 0;
    held_[note] = true;
    heldVelocity_[note] = velocity;
    heldOrder_[note] = ++noteOrderCounter_;

    if (p.voiceMode == VoiceMode::Mono) monoNoteOn(p, hadHeldNotes);
    else polyNoteOn(note, velocity, p, hadHeldNotes);

    lastTriggeredMidi_ = static_cast<float>(note);
}

void Al1Engine::applyNoteOff(int note, const Params& p) {
    held_[note] = false;
    if (p.voiceMode == VoiceMode::Mono) monoNoteOff(note, p);
    else polyNoteOff(note);
}

Al1Engine::Voice& Al1Engine::allocateVoice() {
    for (auto& voice : voices_) {
        if (voice.stage == EnvStage::Idle) return voice;
    }

    auto* quietest = &voices_.front();
    for (auto& voice : voices_) {
        if (voice.env < quietest->env) quietest = &voice;
    }
    return *quietest;
}

float Al1Engine::portamentoSeconds(float distanceSemitones, const Params& p) const {
    if (!p.portaEnable || p.portaTime <= 0.0001f) return 0.0f;

    // Musical mapping for the KRONOS-style 0..127 Time control: fast at the
    // bottom, progressively longer towards the top. Time=0 remains instant.
    const float baseSeconds = 0.004f * std::pow(1000.0f, p.portaTime);
    if (p.portaMode == PortaMode::ConstantTime) return baseSeconds;

    // Constant Rate: baseSeconds is interpreted approximately per octave.
    return baseSeconds * std::max(distanceSemitones / 12.0f, 1.0f / 12.0f);
}

void Al1Engine::configureGlide(Voice& v, float startMidi, float targetMidi, const Params& p) {
    v.glideStartMidi = startMidi;
    v.currentMidi = startMidi;
    v.targetMidi = targetMidi;
    v.glideSamplesDone = 0;

    const float seconds = portamentoSeconds(std::fabs(targetMidi - startMidi), p);
    v.glideSamplesTotal = static_cast<int32_t>(seconds * sampleRate_);
    v.glideActive = v.glideSamplesTotal > 0 && std::fabs(targetMidi - startMidi) > 0.0001f;
    if (!v.glideActive) v.currentMidi = targetMidi;
}

void Al1Engine::stepGlide(Voice& v) {
    if (!v.glideActive) {
        v.currentMidi = v.targetMidi;
        return;
    }

    ++v.glideSamplesDone;
    const float t = std::clamp(
            static_cast<float>(v.glideSamplesDone) /
            static_cast<float>(std::max(1, v.glideSamplesTotal)), 0.0f, 1.0f);
    v.currentMidi = v.glideStartMidi + (v.targetMidi - v.glideStartMidi) * t;
    if (t >= 1.0f) {
        v.currentMidi = v.targetMidi;
        v.glideActive = false;
    }
}

void Al1Engine::startVoice(Voice& v, int note, float velocity, bool retrigger,
                           bool usePortamento, float startMidi, const Params& p) {
    v.note = note;
    v.velocity = velocity;

    if (retrigger) {
        v.phase1 = 0.0f;
        v.phase2 = 0.17f;
        v.subPhase = 0.0f;
        v.env = 0.0f;
        v.lp1 = 0.0f;
        v.lp2 = 0.0f;
        v.stage = EnvStage::Attack;
    } else if (v.stage == EnvStage::Release || v.stage == EnvStage::Idle) {
        v.stage = EnvStage::Attack;
    }

    if (usePortamento) configureGlide(v, startMidi, static_cast<float>(note), p);
    else {
        v.currentMidi = static_cast<float>(note);
        v.targetMidi = static_cast<float>(note);
        v.glideActive = false;
    }
}

void Al1Engine::setVoiceTarget(Voice& v, int note, bool usePortamento, const Params& p) {
    const float start = v.currentMidi;
    v.note = note;
    v.velocity = velocityForNote(note);
    if (usePortamento) configureGlide(v, start, static_cast<float>(note), p);
    else {
        v.currentMidi = static_cast<float>(note);
        v.targetMidi = static_cast<float>(note);
        v.glideActive = false;
    }
}

void Al1Engine::polyNoteOn(int note, float velocity, const Params& p, bool legatoInput) {
    for (auto& voice : voices_) {
        if (voice.note == note && voice.stage != EnvStage::Idle) {
            voice.velocity = velocity;
            voice.stage = EnvStage::Attack;
            return;
        }
    }

    Voice& v = allocateVoice();
    const bool glide = p.portaEnable && (!p.portaFingered || legatoInput);
    startVoice(v, note, velocity, true, glide, lastTriggeredMidi_, p);
}

void Al1Engine::polyNoteOff(int note) {
    for (auto& voice : voices_) {
        if (voice.note == note && voice.stage != EnvStage::Idle) voice.stage = EnvStage::Release;
    }
}

void Al1Engine::monoNoteOn(const Params& p, bool hadHeldNotes) {
    Voice& v = voices_[0];
    const int target = chooseMonoNote(p.priority);
    if (target < 0) return;

    const bool legatoInput = hadHeldNotes && v.stage != EnvStage::Idle;
    const bool glide = p.portaEnable && (!p.portaFingered || legatoInput);

    if (v.stage == EnvStage::Idle) {
        const float start = (!p.portaFingered && p.portaEnable) ? lastMonoMidi_
                                                               : static_cast<float>(target);
        startVoice(v, target, velocityForNote(target), true, glide, start, p);
        return;
    }

    if (target == v.note) {
        v.velocity = velocityForNote(target);
        return;
    }

    if (p.monoLegato && legatoInput) {
        // KRONOS Normal-style mono legato behaviour: keep the running sound
        // context and change pitch without restarting the amplitude envelope.
        setVoiceTarget(v, target, glide, p);
    } else {
        const float start = v.currentMidi;
        startVoice(v, target, velocityForNote(target), true, glide, start, p);
    }
}

void Al1Engine::monoNoteOff(int note, const Params& p) {
    Voice& v = voices_[0];
    if (v.stage == EnvStage::Idle) return;

    const int replacement = chooseMonoNote(p.priority);
    if (replacement >= 0) {
        if (replacement != v.note) {
            // A held key remains, so this is still a connected/legato phrase.
            const bool glide = p.portaEnable; // Fingered is active during overlap.
            if (p.monoLegato) setVoiceTarget(v, replacement, glide, p);
            else startVoice(v, replacement, velocityForNote(replacement), true,
                            glide, v.currentMidi, p);
        }
        return;
    }

    if (v.note == note || heldCount() == 0) {
        lastMonoMidi_ = v.currentMidi;
        v.stage = EnvStage::Release;
    }
}

float Al1Engine::renderVoice(Voice& v, const Params& p) {
    if (v.stage == EnvStage::Idle) return 0.0f;

    stepGlide(v);

    const float attackSeconds = 0.002f + p.attack * p.attack * 1.8f;
    const float decaySeconds = 0.18f;
    const float sustain = 0.74f;
    const float releaseSeconds = 0.02f + p.release * p.release * 3.5f;

    switch (v.stage) {
        case EnvStage::Attack:
            v.env += 1.0f / std::max(1.0f, attackSeconds * sampleRate_);
            if (v.env >= 1.0f) {
                v.env = 1.0f;
                v.stage = EnvStage::Decay;
            }
            break;
        case EnvStage::Decay: {
            const float c = 1.0f - std::exp(-1.0f / (decaySeconds * sampleRate_));
            v.env += (sustain - v.env) * c;
            if (std::fabs(v.env - sustain) < 0.001f) {
                v.env = sustain;
                v.stage = EnvStage::Sustain;
            }
            break;
        }
        case EnvStage::Sustain:
            v.env = sustain;
            break;
        case EnvStage::Release: {
            const float c = 1.0f - std::exp(-1.0f / (releaseSeconds * sampleRate_));
            v.env += (0.0f - v.env) * c;
            if (v.env < 0.0001f) {
                v.env = 0.0f;
                v.stage = EnvStage::Idle;
                v.note = -1;
                v.glideActive = false;
                return 0.0f;
            }
            break;
        }
        case EnvStage::Idle:
            return 0.0f;
    }

    const float baseHz = midiToHz(v.currentMidi);
    const float detuneCents = p.detune * 18.0f;
    const float detuneRatio = std::exp2(detuneCents / 1200.0f);

    const float inc1 = std::min(baseHz / sampleRate_, 0.45f);
    const float inc2 = std::min((baseHz * detuneRatio) / sampleRate_, 0.45f);
    const float subInc = std::min((baseHz * 0.5f) / sampleRate_, 0.45f);

    const float osc1 = saw(v.phase1, inc1);
    const float osc2 = saw(v.phase2, inc2);
    const float sub = v.subPhase < 0.5f ? 1.0f : -1.0f;

    advance(v.phase1, inc1);
    advance(v.phase2, inc2);
    advance(v.subPhase, subInc);

    float x = osc1 * 0.47f + osc2 * 0.43f + sub * 0.10f;

    const float resonance = p.resonance * 0.92f;
    float cutoffHz = 70.0f * std::pow(240.0f, p.cutoff);
    cutoffHz = std::min(cutoffHz, sampleRate_ * 0.44f);

    const float g = std::clamp(
            1.0f - std::exp(-2.0f * kPi * cutoffHz / sampleRate_),
            0.001f, 0.98f);

    x -= resonance * 1.35f * v.lp2;
    v.lp1 += g * (x - v.lp1);
    v.lp2 += g * (v.lp1 - v.lp2);

    return std::tanh(v.lp2 * 1.25f) * v.env * v.velocity;
}

void Al1Engine::render(float* out, int32_t frames) {
    const Params p = snapshotParams();
    processEvents(p);

    for (int32_t i = 0; i < frames; ++i) {
        float sample = 0.0f;
        const int voicesToRender = p.voiceMode == VoiceMode::Mono ? 1 : kMaxVoices;
        for (int v = 0; v < voicesToRender; ++v) sample += renderVoice(voices_[v], p);

        sample *= p.voiceMode == VoiceMode::Mono ? 0.28f : 0.10f;
        sample = std::tanh(sample * 1.15f);

        out[i * 2] = sample;
        out[i * 2 + 1] = sample;
    }
}
