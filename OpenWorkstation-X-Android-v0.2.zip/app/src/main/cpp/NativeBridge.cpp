#include <jni.h>

#include "AudioEngine.h"

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_openworkstationx_MainActivity_nativeStartAudio(JNIEnv*, jclass) {
    return AudioEngine::instance().start() ? JNI_TRUE : JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_openworkstationx_MainActivity_nativeStopAudio(JNIEnv*, jclass) {
    AudioEngine::instance().stop();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_openworkstationx_MainActivity_nativeNoteOn(
        JNIEnv*, jclass, jint note, jfloat velocity) {
    AudioEngine::instance().noteOn(static_cast<int>(note), velocity);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_openworkstationx_MainActivity_nativeNoteOff(
        JNIEnv*, jclass, jint note) {
    AudioEngine::instance().noteOff(static_cast<int>(note));
}

extern "C"
JNIEXPORT void JNICALL
Java_com_openworkstationx_MainActivity_nativeSetParameter(
        JNIEnv*, jclass, jint parameterId, jfloat normalizedValue) {
    AudioEngine::instance().setParameter(static_cast<int>(parameterId), normalizedValue);
}
