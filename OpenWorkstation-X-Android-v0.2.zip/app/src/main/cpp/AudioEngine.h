#pragma once

#include <aaudio/AAudio.h>
#include <atomic>

#include "Al1Engine.h"

class AudioEngine {
public:
    static AudioEngine& instance();

    bool start();
    void stop();

    void noteOn(int note, float velocity);
    void noteOff(int note);
    void setParameter(int id, float normalizedValue);

private:
    AudioEngine() = default;
    ~AudioEngine();

    AudioEngine(const AudioEngine&) = delete;
    AudioEngine& operator=(const AudioEngine&) = delete;

    static aaudio_data_callback_result_t dataCallback(
            AAudioStream* stream,
            void* userData,
            void* audioData,
            int32_t numFrames);

    bool openStream(aaudio_sharing_mode_t sharingMode);
    void closeStream();

    AAudioStream* stream_ = nullptr;
    Al1Engine synth_{};
    std::atomic<bool> running_{false};
};
