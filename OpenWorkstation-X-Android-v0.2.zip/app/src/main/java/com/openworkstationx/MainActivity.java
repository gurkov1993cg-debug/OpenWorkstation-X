package com.openworkstationx;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    static {
        System.loadLibrary("openworkstationx");
    }

    private static native boolean nativeStartAudio();
    private static native void nativeStopAudio();
    static native void nativeNoteOn(int note, float velocity);
    static native void nativeNoteOff(int note);
    private static native void nativeSetParameter(int parameterId, float normalizedValue);

    private static final int BG = Color.rgb(20, 22, 27);
    private static final int PANEL = Color.rgb(36, 39, 47);
    private static final int TEXT = Color.rgb(235, 238, 245);
    private static final int ACCENT = Color.rgb(80, 180, 255);

    private boolean mono = false;
    private boolean monoLegato = true;
    private boolean portamento = false;
    private boolean fingered = true;
    private boolean constantTime = false;
    private int priority = 2; // 0 Low, 1 High, 2 Last

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!nativeStartAudio()) {
            Toast.makeText(this, "Could not open low-latency audio output", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onPause() {
        nativeStopAudio();
        super.onPause();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(10), dp(6), dp(10), dp(6));

        TextView title = new TextView(this);
        title.setText("OpenWorkstation-X  •  PROGRAM  •  AL-1 DEMO v0.2");
        title.setTextColor(TEXT);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(12), dp(4), dp(12), dp(4));
        root.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(38)));

        root.addView(buildEngineBar(), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));

        root.addView(buildVoiceBar(), new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setBackgroundColor(PANEL);
        controls.setPadding(dp(6), dp(2), dp(6), dp(2));

        controls.addView(makeParameter("CUTOFF", 0, 68), weight());
        controls.addView(makeParameter("RESONANCE", 1, 22), weight());
        controls.addView(makeParameter("DETUNE", 2, 28), weight());
        controls.addView(makeParameter("ATTACK", 3, 7), weight());
        controls.addView(makeParameter("RELEASE", 4, 20), weight());
        controls.addView(makeParameter("PORTA TIME", 9, 22), weight());

        root.addView(controls, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.92f));

        TextView status = new TextView(this);
        status.setText("AL-1 VA CORE  •  64 VOICES  •  MONO/LEGATO  •  KRONOS-STYLE PORTAMENTO  •  AAudio");
        status.setTextColor(ACCENT);
        status.setTextSize(12);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(25)));

        KeyboardView keyboard = new KeyboardView(this);
        root.addView(keyboard, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.15f));

        return root;
    }

    private View buildEngineBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        String[] names = {"AL-1", "HD-1", "MOD-7", "CX-3", "STR-1", "EP", "PIANO", "MS-20", "POLYSIX"};
        for (int i = 0; i < names.length; i++) {
            Button b = new Button(this);
            b.setText(names[i]);
            b.setTextSize(10);
            b.setAllCaps(false);
            b.setEnabled(i == 0);
            if (i == 0) {
                b.setTextColor(Color.BLACK);
                b.setBackgroundColor(ACCENT);
            }
            bar.addView(b, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
        }
        return bar;
    }

    private View buildVoiceBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(PANEL);
        bar.setPadding(dp(4), dp(3), dp(4), dp(3));

        Button mode = makeStateButton("POLY");
        mode.setOnClickListener(v -> {
            mono = !mono;
            nativeSetParameter(5, mono ? 1.0f : 0.0f);
            mode.setText(mono ? "MONO" : "POLY");
        });

        Button legato = makeStateButton("LEGATO ON");
        legato.setOnClickListener(v -> {
            monoLegato = !monoLegato;
            nativeSetParameter(6, monoLegato ? 1.0f : 0.0f);
            legato.setText(monoLegato ? "LEGATO ON" : "LEGATO OFF");
        });

        Button porta = makeStateButton("PORTA OFF");
        porta.setOnClickListener(v -> {
            portamento = !portamento;
            nativeSetParameter(7, portamento ? 1.0f : 0.0f);
            porta.setText(portamento ? "PORTA ON" : "PORTA OFF");
        });

        Button finger = makeStateButton("FINGERED ON");
        finger.setOnClickListener(v -> {
            fingered = !fingered;
            nativeSetParameter(8, fingered ? 1.0f : 0.0f);
            finger.setText(fingered ? "FINGERED ON" : "FINGERED OFF");
        });

        Button portaMode = makeStateButton("CONST RATE");
        portaMode.setOnClickListener(v -> {
            constantTime = !constantTime;
            nativeSetParameter(10, constantTime ? 1.0f : 0.0f);
            portaMode.setText(constantTime ? "CONST TIME" : "CONST RATE");
        });

        Button prio = makeStateButton("PRIORITY LAST");
        prio.setOnClickListener(v -> {
            priority = (priority + 1) % 3;
            if (priority == 0) {
                nativeSetParameter(11, 0.0f);
                prio.setText("PRIORITY LOW");
            } else if (priority == 1) {
                nativeSetParameter(11, 0.5f);
                prio.setText("PRIORITY HIGH");
            } else {
                nativeSetParameter(11, 1.0f);
                prio.setText("PRIORITY LAST");
            }
        });

        nativeSetParameter(5, 0.0f);
        nativeSetParameter(6, 1.0f);
        nativeSetParameter(7, 0.0f);
        nativeSetParameter(8, 1.0f);
        nativeSetParameter(10, 0.0f);
        nativeSetParameter(11, 1.0f);

        bar.addView(mode, weight());
        bar.addView(legato, weight());
        bar.addView(porta, weight());
        bar.addView(finger, weight());
        bar.addView(portaMode, weight());
        bar.addView(prio, weight());
        return bar;
    }

    private Button makeStateButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(9);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        return b;
    }

    private View makeParameter(String name, int id, int initial) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5), dp(1), dp(5), dp(1));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(TEXT);
        label.setGravity(Gravity.CENTER);
        label.setTextSize(11);

        TextView value = new TextView(this);
        value.setText(initial + "%");
        value.setTextColor(ACCENT);
        value.setGravity(Gravity.CENTER);
        value.setTextSize(16);

        SeekBar slider = new SeekBar(this);
        slider.setMax(100);
        slider.setProgress(initial);
        nativeSetParameter(id, initial / 100.0f);

        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value.setText(progress + "%");
                nativeSetParameter(id, progress / 100.0f);
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        box.addView(label, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.28f));
        box.addView(value, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.30f));
        box.addView(slider, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.42f));
        return box;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
