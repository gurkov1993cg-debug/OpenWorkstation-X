package com.openworkstationx;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;

import java.util.HashSet;
import java.util.Set;

public final class KeyboardView extends View {
    private static final int[] WHITE_NOTES = {
            48, 50, 52, 53, 55, 57, 59,
            60, 62, 64, 65, 67, 69, 71
    };

    private static final int[] BLACK_AFTER_WHITE = {
            0, 1, 3, 4, 5,
            7, 8, 10, 11, 12
    };

    private static final int[] BLACK_NOTES = {
            49, 51, 54, 56, 58,
            61, 63, 66, 68, 70
    };

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SparseIntArray pointerNotes = new SparseIntArray();
    private final Set<Integer> activeNotes = new HashSet<>();

    public KeyboardView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(12, 13, 16));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float whiteWidth = getWidth() / (float) WHITE_NOTES.length;
        float h = getHeight();

        for (int i = 0; i < WHITE_NOTES.length; i++) {
            boolean active = activeNotes.contains(WHITE_NOTES[i]);
            paint.setColor(active ? Color.rgb(115, 205, 255) : Color.rgb(242, 242, 238));
            RectF r = new RectF(i * whiteWidth + 1, 1,
                    (i + 1) * whiteWidth - 1, h - 1);
            canvas.drawRect(r, paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2);
            paint.setColor(Color.rgb(45, 48, 55));
            canvas.drawRect(r, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        float blackWidth = whiteWidth * 0.62f;
        float blackHeight = h * 0.62f;
        for (int i = 0; i < BLACK_AFTER_WHITE.length; i++) {
            float center = (BLACK_AFTER_WHITE[i] + 1) * whiteWidth;
            RectF r = new RectF(center - blackWidth / 2, 0,
                    center + blackWidth / 2, blackHeight);
            boolean active = activeNotes.contains(BLACK_NOTES[i]);
            paint.setColor(active ? Color.rgb(40, 155, 225) : Color.rgb(20, 22, 28));
            canvas.drawRoundRect(r, 5, 5, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int actionIndex = event.getActionIndex();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                startPointer(event.getPointerId(actionIndex),
                        event.getX(actionIndex), event.getY(actionIndex));
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int pointerId = event.getPointerId(i);
                    int newNote = hitTest(event.getX(i), event.getY(i));
                    int oldNote = pointerNotes.get(pointerId, -1);
                    if (newNote != oldNote) {
                        if (oldNote >= 0) stopNote(oldNote);
                        if (newNote >= 0) {
                            pointerNotes.put(pointerId, newNote);
                            startNote(newNote);
                        } else {
                            pointerNotes.delete(pointerId);
                        }
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                stopPointer(event.getPointerId(actionIndex));
                break;

            case MotionEvent.ACTION_CANCEL:
                releaseAll();
                break;
        }

        invalidate();
        return true;
    }

    private void startPointer(int pointerId, float x, float y) {
        int note = hitTest(x, y);
        if (note >= 0) {
            pointerNotes.put(pointerId, note);
            startNote(note);
        }
    }

    private void stopPointer(int pointerId) {
        int note = pointerNotes.get(pointerId, -1);
        if (note >= 0) {
            stopNote(note);
            pointerNotes.delete(pointerId);
        }
    }

    private void startNote(int note) {
        activeNotes.add(note);
        MainActivity.nativeNoteOn(note, 0.90f);
    }

    private void stopNote(int note) {
        activeNotes.remove(note);
        MainActivity.nativeNoteOff(note);
    }

    private void releaseAll() {
        for (int i = 0; i < pointerNotes.size(); i++) {
            MainActivity.nativeNoteOff(pointerNotes.valueAt(i));
        }
        pointerNotes.clear();
        activeNotes.clear();
    }

    private int hitTest(float x, float y) {
        if (getWidth() <= 0 || getHeight() <= 0) return -1;

        float whiteWidth = getWidth() / (float) WHITE_NOTES.length;
        float blackHeight = getHeight() * 0.62f;
        float blackHalfWidth = whiteWidth * 0.31f;

        if (y <= blackHeight) {
            for (int i = 0; i < BLACK_AFTER_WHITE.length; i++) {
                float center = (BLACK_AFTER_WHITE[i] + 1) * whiteWidth;
                if (x >= center - blackHalfWidth && x <= center + blackHalfWidth) {
                    return BLACK_NOTES[i];
                }
            }
        }

        int whiteIndex = (int) (x / whiteWidth);
        if (whiteIndex < 0) whiteIndex = 0;
        if (whiteIndex >= WHITE_NOTES.length) whiteIndex = WHITE_NOTES.length - 1;
        return WHITE_NOTES[whiteIndex];
    }
}
