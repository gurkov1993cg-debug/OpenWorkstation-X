package com.openworkstationx;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    static { System.loadLibrary("openworkstationx"); }

    private static native boolean nativeStartAudio();
    private static native void nativeStopAudio();
    static native void nativeNoteOn(int note, float velocity);
    static native void nativeNoteOff(int note);
    private static native void nativeSetParameter(int parameterId, float normalizedValue);

    private static final int BG = Color.rgb(16, 18, 22);
    private static final int PANEL = Color.rgb(34, 37, 44);
    private static final int PANEL2 = Color.rgb(45, 49, 58);
    private static final int TEXT = Color.rgb(235, 238, 245);
    private static final int MUTED = Color.rgb(160, 168, 180);
    private static final int ACCENT = Color.rgb(78, 183, 255);

    private LinearLayout pageHost;
    private final float[] parameterValues = new float[42];

    private boolean mono = false;
    private boolean monoLegato = true;
    private boolean portamento = false;
    private boolean fingered = true;
    private boolean constantTime = false;
    private int priority = 2;
    private boolean sync = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initParameterDefaults();
        setContentView(buildUi());
        showOscPage();
    }


    private void initParameterDefaults() {
        float[] d = {
                0.68f,0.22f,0.28f,0.07f,0.20f,0f,1f,0f,1f,0.22f,0f,1f,
                0f,0f,0.75f,0.70f,0.10f,0f,0f,0f,0f,0.50f,
                0.68f,0.15f,0f,0f,0f,0.50f,0.02f,0.25f,0.45f,0.25f,
                0.20f,0.78f,0.08f,0f,0.22f,0f,0f,0f,0.12f,0f
        };
        System.arraycopy(d, 0, parameterValues, 0, d.length);
        for (int i = 0; i < parameterValues.length; i++) nativeSetParameter(i, parameterValues[i]);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!nativeStartAudio()) {
            Toast.makeText(this, "Could not open low-latency audio output", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onPause() {
        nativeStopAudio();
        super.onPause();
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(8), dp(4), dp(8), dp(4));

        TextView title = new TextView(this);
        title.setText("OpenWorkstation-X  •  PROGRAM  •  AL-1 CORE v0.3");
        title.setTextColor(TEXT);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(10), 0, dp(10), 0);
        root.addView(title, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34)));

        root.addView(buildEngineBar(), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36)));
        root.addView(buildPageTabs(), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(38)));

        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        pageHost.setBackgroundColor(PANEL);
        root.addView(pageHost, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));

        TextView status = new TextView(this);
        status.setText("REAL DSP: DUAL OSC • FM/SYNC/RING • DUAL FILTER • EG/LFO • UNISON • MONO/LEGATO/PORTA • AAudio");
        status.setTextColor(ACCENT);
        status.setTextSize(10);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(22)));

        KeyboardView keyboard = new KeyboardView(this);
        root.addView(keyboard, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.92f));
        return root;
    }

    private View buildEngineBar() {
        LinearLayout bar = new LinearLayout(this);
        String[] names = {"AL-1", "HD-1", "MOD-7", "CX-3", "STR-1", "EP", "PIANO", "MS-20", "POLYSIX"};
        for (int i = 0; i < names.length; i++) {
            Button b = new Button(this);
            b.setText(names[i]);
            b.setTextSize(9);
            b.setAllCaps(false);
            b.setEnabled(i == 0);
            if (i == 0) {
                b.setTextColor(Color.BLACK);
                b.setBackgroundColor(ACCENT);
            }
            bar.addView(b, weight());
        }
        return bar;
    }

    private View buildPageTabs() {
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(PANEL2);
        String[] labels = {"OSC / MIX", "FILTER", "ENV / LFO", "VOICE / PORTA"};
        View.OnClickListener[] listeners = {
                v -> showOscPage(), v -> showFilterPage(), v -> showEnvPage(), v -> showVoicePage()
        };
        for (int i = 0; i < labels.length; i++) {
            Button b = new Button(this);
            b.setText(labels[i]);
            b.setTextSize(10);
            b.setAllCaps(false);
            b.setTextColor(TEXT);
            b.setOnClickListener(listeners[i]);
            bar.addView(b, weight());
        }
        return bar;
    }

    private void clearPage(String title) {
        pageHost.removeAllViews();
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(ACCENT);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(2), dp(8), 0);
        pageHost.addView(t, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(25)));
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(dp(3), dp(2), dp(3), dp(2));
        pageHost.addView(r, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1.0f));
        return r;
    }

    private void showOscPage() {
        clearPage("OSCILLATORS / MIXER — controls below change the native signal path");
        LinearLayout r1 = row();
        r1.addView(makeSelector("OSC1 WAVE", 12, new String[]{"SAW", "PULSE", "TRI"}, 0), weight());
        r1.addView(makeSelector("OSC2 WAVE", 13, new String[]{"SAW", "PULSE", "TRI"}, 0), weight());
        r1.addView(makeParameter("OSC1 LEVEL", 14, 75), weight());
        r1.addView(makeParameter("OSC2 LEVEL", 15, 70), weight());
        r1.addView(makeParameter("OSC2 DETUNE", 2, 28), weight());
        r1.addView(makeParameter("PULSE WIDTH", 21, 50), weight());

        LinearLayout r2 = row();
        r2.addView(makeParameter("SUB", 16, 10), weight());
        r2.addView(makeParameter("NOISE", 17, 0), weight());
        r2.addView(makeParameter("RING MOD", 18, 0), weight());
        r2.addView(makeParameter("FM AMOUNT", 19, 0), weight());
        r2.addView(makeToggle("OSC SYNC", sync, value -> { sync = value; nativeSetParameter(20, value ? 1f : 0f); }), weight());
        r2.addView(makeSelector("UNISON", 39, new String[]{"1", "2", "3", "4"}, 0), weight());
    }

    private void showFilterPage() {
        clearPage("DUAL FILTER / DRIVER — Single, Serial, Parallel and cascaded 24 dB routes are real DSP routes");
        LinearLayout r1 = row();
        r1.addView(makeParameter("CUTOFF A", 0, 68), weight());
        r1.addView(makeParameter("RESONANCE A", 1, 22), weight());
        r1.addView(makeSelector("TYPE A", 25, new String[]{"LP", "BP", "HP"}, 0), weight());
        r1.addView(makeParameter("CUTOFF B", 22, 68), weight());
        r1.addView(makeParameter("RESONANCE B", 23, 15), weight());
        r1.addView(makeSelector("TYPE B", 26, new String[]{"LP", "BP", "HP"}, 0), weight());

        LinearLayout r2 = row();
        r2.addView(makeSelector("ROUTING", 24, new String[]{"SINGLE", "SERIAL", "PARALLEL", "24dB LP"}, 0), weight());
        r2.addView(makeParameter("FILTER EG +/-", 27, 50), weight());
        r2.addView(makeParameter("DRIVE", 34, 8), weight());
        r2.addView(makeParameter("LOW BOOST", 35, 0), weight());
        r2.addView(makeParameter("LFO→CUTOFF", 38, 0), weight());
        r2.addView(makeParameter("UNISON DETUNE", 40, 12), weight());
    }

    private void showEnvPage() {
        clearPage("ENVELOPES / LFO — independent AMP EG and FILTER EG run per voice");
        LinearLayout r1 = row();
        r1.addView(makeParameter("AMP ATTACK", 3, 7), weight());
        r1.addView(makeParameter("AMP DECAY", 32, 20), weight());
        r1.addView(makeParameter("AMP SUSTAIN", 33, 78), weight());
        r1.addView(makeParameter("AMP RELEASE", 4, 20), weight());
        r1.addView(makeParameter("LFO RATE", 36, 22), weight());
        r1.addView(makeParameter("LFO→PITCH", 37, 0), weight());

        LinearLayout r2 = row();
        r2.addView(makeParameter("FILT ATTACK", 28, 2), weight());
        r2.addView(makeParameter("FILT DECAY", 29, 25), weight());
        r2.addView(makeParameter("FILT SUSTAIN", 30, 45), weight());
        r2.addView(makeParameter("FILT RELEASE", 31, 25), weight());
        r2.addView(makeParameter("FILTER EG +/-", 27, 50), weight());
        r2.addView(makeParameter("LFO→CUTOFF", 38, 0), weight());
    }

    private void showVoicePage() {
        clearPage("VOICE / PORTAMENTO — held-note stack, legato retrigger logic and glide run in the native voice manager");
        LinearLayout r1 = row();
        r1.addView(makeToggle("MONO", mono, value -> { mono = value; nativeSetParameter(5, value ? 1f : 0f); }), weight());
        r1.addView(makeToggle("LEGATO", monoLegato, value -> { monoLegato = value; nativeSetParameter(6, value ? 1f : 0f); }), weight());
        r1.addView(makeToggle("PORTAMENTO", portamento, value -> { portamento = value; nativeSetParameter(7, value ? 1f : 0f); }), weight());
        r1.addView(makeToggle("FINGERED", fingered, value -> { fingered = value; nativeSetParameter(8, value ? 1f : 0f); }), weight());
        r1.addView(makeParameter("PORTA TIME", 9, 22), weight());
        r1.addView(makeParameter("UNISON DETUNE", 40, 12), weight());

        LinearLayout r2 = row();
        r2.addView(makeToggle("CONST TIME", constantTime, value -> { constantTime = value; nativeSetParameter(10, value ? 1f : 0f); }), weight());
        r2.addView(makePriorityButton(), weight());
        r2.addView(makeSelector("UNISON", 39, new String[]{"1", "2", "3", "4"}, 0), weight());
        r2.addView(infoBox("VOICE BUDGET", "64 / unison"), weight());
        r2.addView(infoBox("LEGATO", "no EG retrigger"), weight());
        r2.addView(infoBox("PRIORITY", "Low / High / Last"), weight());
    }

    private interface BoolSetter { void set(boolean value); }

    private View makeToggle(String name, boolean initial, BoolSetter setter) {
        LinearLayout box = baseBox(name);
        Button b = new Button(this);
        final boolean[] state = {initial};
        b.setText(initial ? "ON" : "OFF");
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            state[0] = !state[0];
            b.setText(state[0] ? "ON" : "OFF");
            setter.set(state[0]);
        });
        box.addView(b, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private View makePriorityButton() {
        LinearLayout box = baseBox("MONO PRIORITY");
        Button b = new Button(this);
        b.setText("LAST");
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            priority = (priority + 1) % 3;
            if (priority == 0) { b.setText("LOW"); nativeSetParameter(11, 0.0f); }
            else if (priority == 1) { b.setText("HIGH"); nativeSetParameter(11, 0.5f); }
            else { b.setText("LAST"); nativeSetParameter(11, 1.0f); }
        });
        box.addView(b, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private View makeSelector(String name, int id, String[] options, int initialIndex) {
        LinearLayout box = baseBox(name);
        Button b = new Button(this);
        int computed = Math.min(options.length - 1, (int)Math.floor(parameterValues[id] * options.length));
        final int[] index = {computed};
        b.setText(options[index[0]]);
        b.setTextSize(9);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            index[0] = (index[0] + 1) % options.length;
            b.setText(options[index[0]]);
            float normalized = (index[0] + 0.05f) / (float) options.length;
            parameterValues[id] = Math.min(1f, normalized);
            nativeSetParameter(id, parameterValues[id]);
        });
        box.addView(b, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private View makeParameter(String name, int id, int initial) {
        LinearLayout box = baseBox(name);
        TextView value = new TextView(this);
        value.setText(initial + "%");
        value.setTextColor(ACCENT);
        value.setGravity(Gravity.CENTER);
        value.setTextSize(12);

        SeekBar slider = new SeekBar(this);
        slider.setMax(100);
        int current = Math.round(parameterValues[id] * 100.0f);
        slider.setProgress(current);
        value.setText(current + "%");
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                value.setText(progress + "%");
                parameterValues[id] = progress / 100.0f;
                nativeSetParameter(id, parameterValues[id]);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        box.addView(value, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.32f));
        box.addView(slider, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 0.68f));
        return box;
    }

    private View infoBox(String name, String valueText) {
        LinearLayout box = baseBox(name);
        TextView value = new TextView(this);
        value.setText(valueText);
        value.setTextColor(ACCENT);
        value.setGravity(Gravity.CENTER);
        value.setTextSize(10);
        box.addView(value, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        return box;
    }

    private LinearLayout baseBox(String name) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(3), dp(1), dp(3), dp(1));
        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(MUTED);
        label.setGravity(Gravity.CENTER);
        label.setTextSize(9);
        box.addView(label, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(20)));
        return box;
    }

    private LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
