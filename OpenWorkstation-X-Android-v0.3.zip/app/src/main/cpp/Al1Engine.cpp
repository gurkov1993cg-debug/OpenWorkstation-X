#include "Al1Engine.h"

#include <algorithm>
#include <cmath>

namespace {
constexpr float kPi = 3.14159265358979323846f;
constexpr float kTwoPi = 6.28318530717958647692f;

float expCoeff(float seconds, float sampleRate) {
    seconds = std::max(seconds, 0.00005f);
    return 1.0f - std::exp(-1.0f / (seconds * sampleRate));
}
}

Al1Engine::Al1Engine() {
    const float defaults[42] = {
        0.68f, 0.22f, 0.28f, 0.07f, 0.20f, 0.0f, 1.0f, 0.0f, 1.0f, 0.22f, 0.0f, 1.0f,
        0.0f, 0.0f, 0.75f, 0.70f, 0.10f, 0.0f, 0.0f, 0.0f, 0.0f, 0.50f,
        0.68f, 0.15f, 0.0f, 0.0f, 0.0f, 0.50f, 0.02f, 0.25f, 0.45f, 0.25f,
        0.20f, 0.78f, 0.08f, 0.0f, 0.22f, 0.0f, 0.0f, 0.0f, 0.12f, 0.0f
    };
    for (size_t i = 0; i < param_.size(); ++i) param_[i].store(defaults[i], std::memory_order_relaxed);
}

void Al1Engine::setSampleRate(float sampleRate) {
    if (sampleRate > 8000.0f) sampleRate_ = sampleRate;
}

bool Al1Engine::EventQueue::push(const NoteEvent& event) {
    const uint32_t write = write_.load(std::memory_order_relaxed);
    const uint32_t next = (write + 1u) % kEventCapacity;
    if (next == read_.load(std::memory_order_acquire)) return false;
    events_[write] = event;
    write_.store(next, std::memory_order_release);
    return true;
}

bool Al1Engine::EventQueue::pop(NoteEvent& event) {
    const uint32_t read = read_.load(std::memory_order_relaxed);
    if (read == write_.load(std::memory_order_acquire)) return false;
    event = events_[read];
    read_.store((read + 1u) % kEventCapacity, std::memory_order_release);
    return true;
}

void Al1Engine::noteOn(int note, float velocity) {
    NoteEvent e{EventType::NoteOn, std::clamp(note, 0, 127), std::clamp(velocity, 0.0f, 1.0f)};
    events_.push(e);
}

void Al1Engine::noteOff(int note) {
    NoteEvent e{EventType::NoteOff, std::clamp(note, 0, 127), 0.0f};
    events_.push(e);
}

void Al1Engine::setParameter(int id, float normalizedValue) {
    if (id < 0 || id >= static_cast<int>(param_.size())) return;
    param_[static_cast<size_t>(id)].store(std::clamp(normalizedValue, 0.0f, 1.0f), std::memory_order_relaxed);
}

float Al1Engine::clamp01(float v) { return std::clamp(v, 0.0f, 1.0f); }

Al1Engine::Params Al1Engine::snapshotParams() const {
    std::array<float, 42> v{};
    for (size_t i = 0; i < v.size(); ++i) v[i] = param_[i].load(std::memory_order_relaxed);

    Params p;
    p.cutoffA = v[0];
    p.resonanceA = v[1];
    p.osc2Detune = v[2];
    p.ampAttack = v[3];
    p.ampRelease = v[4];
    p.voiceMode = v[5] >= 0.5f ? VoiceMode::Mono : VoiceMode::Poly;
    p.monoLegato = v[6] >= 0.5f;
    p.portaEnable = v[7] >= 0.5f;
    p.portaFingered = v[8] >= 0.5f;
    p.portaTime = v[9];
    p.portaMode = v[10] >= 0.5f ? PortaMode::ConstantTime : PortaMode::ConstantRate;
    p.priority = v[11] < 0.25f ? MonoPriority::Low : (v[11] > 0.75f ? MonoPriority::Last : MonoPriority::High);

    auto wave = [](float x) {
        int n = std::clamp(static_cast<int>(std::floor(x * 3.0f)), 0, 2);
        return static_cast<Waveform>(n);
    };
    auto ftype = [](float x) {
        int n = std::clamp(static_cast<int>(std::floor(x * 3.0f)), 0, 2);
        return static_cast<FilterType>(n);
    };

    p.osc1Wave = wave(v[12]);
    p.osc2Wave = wave(v[13]);
    p.osc1Level = v[14];
    p.osc2Level = v[15];
    p.subLevel = v[16];
    p.noiseLevel = v[17];
    p.ringLevel = v[18];
    p.fmAmount = v[19];
    p.sync = v[20] >= 0.5f;
    p.pulseWidth = 0.08f + 0.84f * v[21];

    p.cutoffB = v[22];
    p.resonanceB = v[23];
    p.filterRouting = static_cast<FilterRouting>(std::clamp(static_cast<int>(std::floor(v[24] * 4.0f)), 0, 3));
    p.filterTypeA = ftype(v[25]);
    p.filterTypeB = ftype(v[26]);
    p.filterEnvAmount = v[27];
    p.filterAttack = v[28];
    p.filterDecay = v[29];
    p.filterSustain = v[30];
    p.filterRelease = v[31];

    p.ampDecay = v[32];
    p.ampSustain = v[33];
    p.drive = v[34];
    p.lowBoost = v[35];
    p.lfoRate = v[36];
    p.lfoPitchAmount = v[37];
    p.lfoCutoffAmount = v[38];

    p.unisonVoices = 1 + std::clamp(static_cast<int>(std::floor(v[39] * 4.0f)), 0, 3);
    p.unisonDetune = v[40];
    return p;
}

float Al1Engine::midiToHz(float note) {
    return 440.0f * std::exp2((note - 69.0f) / 12.0f);
}

float Al1Engine::polyBlep(float t, float dt) {
    if (dt <= 0.0f) return 0.0f;
    if (t < dt) {
        t /= dt;
        return t + t - t * t - 1.0f;
    }
    if (t > 1.0f - dt) {
        t = (t - 1.0f) / dt;
        return t * t + t + t + 1.0f;
    }
    return 0.0f;
}

float Al1Engine::saw(float phase, float increment) {
    float value = 2.0f * phase - 1.0f;
    return value - polyBlep(phase, increment);
}

float Al1Engine::pulse(float phase, float increment, float width) {
    float value = phase < width ? 1.0f : -1.0f;
    value += polyBlep(phase, increment);
    float t2 = phase - width;
    if (t2 < 0.0f) t2 += 1.0f;
    value -= polyBlep(t2, increment);
    return value;
}

float Al1Engine::triangle(float phase) {
    return 1.0f - 4.0f * std::fabs(phase - 0.5f);
}

float Al1Engine::oscillator(Waveform waveform, float phase, float increment, float pulseWidth) {
    switch (waveform) {
        case Waveform::Saw: return saw(phase, increment);
        case Waveform::Pulse: return pulse(phase, increment, pulseWidth);
        case Waveform::Triangle: return triangle(phase);
    }
    return 0.0f;
}

bool Al1Engine::advance(float& phase, float increment) {
    phase += increment;
    if (phase >= 1.0f) {
        phase -= std::floor(phase);
        return true;
    }
    return false;
}

float Al1Engine::mapCutoff(float norm, float sampleRate) {
    const float hz = 20.0f * std::pow(1000.0f, clamp01(norm));
    return std::min(hz, sampleRate * 0.43f);
}

float Al1Engine::Svf::process(float input, float cutoffHz, float resonance,
                              FilterType type, float sampleRate) {
    // Chamberlin state-variable topology. We cap f for stability and run two
    // half-steps per sample, which gives substantially cleaner high-cutoff behaviour.
    const float f = std::clamp(2.0f * std::sin(kPi * cutoffHz / sampleRate), 0.001f, 0.92f);
    const float q = 1.95f - std::clamp(resonance, 0.0f, 1.0f) * 1.80f;
    float high = 0.0f;
    for (int i = 0; i < 2; ++i) {
        low += 0.5f * f * band;
        high = input - low - q * band;
        band += 0.5f * f * high;
    }
    if (type == FilterType::LowPass) return low;
    if (type == FilterType::BandPass) return band;
    return high;
}

int Al1Engine::heldCount() const {
    int count = 0;
    for (bool h : held_) if (h) ++count;
    return count;
}

float Al1Engine::velocityForNote(int note) const {
    return heldVelocity_[std::clamp(note, 0, 127)];
}

int Al1Engine::chooseMonoNote(MonoPriority priority) const {
    if (priority == MonoPriority::Low) {
        for (int n = 0; n < 128; ++n) if (held_[n]) return n;
    } else if (priority == MonoPriority::High) {
        for (int n = 127; n >= 0; --n) if (held_[n]) return n;
    } else {
        uint64_t newest = 0;
        int chosen = -1;
        for (int n = 0; n < 128; ++n) {
            if (held_[n] && heldOrder_[n] >= newest) {
                newest = heldOrder_[n];
                chosen = n;
            }
        }
        return chosen;
    }
    return -1;
}

void Al1Engine::processEvents(const Params& p) {
    NoteEvent e;
    while (events_.pop(e)) {
        if (e.type == EventType::NoteOn) applyNoteOn(e.note, e.velocity, p);
        else applyNoteOff(e.note, p);
    }
}

void Al1Engine::applyNoteOn(int note, float velocity, const Params& p) {
    const bool hadHeldNotes = heldCount() > 0;
    held_[note] = true;
    heldVelocity_[note] = velocity;
    heldOrder_[note] = ++noteOrderCounter_;
    if (p.voiceMode == VoiceMode::Mono) monoNoteOn(p, hadHeldNotes);
    else polyNoteOn(note, velocity, p, hadHeldNotes);
    lastTriggeredMidi_ = static_cast<float>(note);
}

void Al1Engine::applyNoteOff(int note, const Params& p) {
    held_[note] = false;
    if (p.voiceMode == VoiceMode::Mono) monoNoteOff(note, p);
    else polyNoteOff(note);
}

int Al1Engine::voiceBudget(const Params& p) const {
    // Keep total oscillator work roughly bounded as unison expands. This mirrors
    // workstation-style dynamic resource budgeting instead of blindly multiplying CPU.
    return std::max(8, kMaxVoices / std::max(1, p.unisonVoices));
}

Al1Engine::Voice& Al1Engine::allocateVoice(int voiceLimit) {
    voiceLimit = std::clamp(voiceLimit, 1, kMaxVoices);
    for (int i = 0; i < voiceLimit; ++i) {
        if (voices_[i].ampEnv.stage == EnvStage::Idle) return voices_[i];
    }
    int quietest = 0;
    for (int i = 1; i < voiceLimit; ++i) {
        if (voices_[i].ampEnv.value < voices_[quietest].ampEnv.value) quietest = i;
    }
    return voices_[quietest];
}

void Al1Engine::resetVoiceForTrigger(Voice& v) {
    for (int i = 0; i < kMaxUnison; ++i) {
        v.phase1[i] = 0.0f;
        v.phase2[i] = 0.17f + 0.11f * static_cast<float>(i);
    }
    v.subPhase = 0.0f;
    v.lfoPhase = 0.0f;
    v.ampEnv = {};
    v.filterEnv = {};
    v.ampEnv.stage = EnvStage::Attack;
    v.filterEnv.stage = EnvStage::Attack;
    v.filterA.reset();
    v.filterB.reset();
    v.lowBoostState = 0.0f;
    v.noiseState ^= static_cast<uint32_t>((v.note + 129) * 2654435761u);
}

float Al1Engine::portamentoSeconds(float distanceSemitones, const Params& p) const {
    if (!p.portaEnable || p.portaTime <= 0.0001f) return 0.0f;
    const float baseSeconds = 0.003f * std::pow(1200.0f, p.portaTime);
    if (p.portaMode == PortaMode::ConstantTime) return baseSeconds;
    return baseSeconds * std::max(distanceSemitones / 12.0f, 1.0f / 12.0f);
}

void Al1Engine::configureGlide(Voice& v, float startMidi, float targetMidi, const Params& p) {
    v.glideStartMidi = startMidi;
    v.currentMidi = startMidi;
    v.targetMidi = targetMidi;
    v.glideSamplesDone = 0;
    const float seconds = portamentoSeconds(std::fabs(targetMidi - startMidi), p);
    v.glideSamplesTotal = static_cast<int32_t>(seconds * sampleRate_);
    v.glideActive = v.glideSamplesTotal > 0 && std::fabs(targetMidi - startMidi) > 0.0001f;
    if (!v.glideActive) v.currentMidi = targetMidi;
}

void Al1Engine::stepGlide(Voice& v) {
    if (!v.glideActive) {
        v.currentMidi = v.targetMidi;
        return;
    }
    ++v.glideSamplesDone;
    const float t = std::clamp(static_cast<float>(v.glideSamplesDone) /
                               static_cast<float>(std::max(1, v.glideSamplesTotal)), 0.0f, 1.0f);
    // Smoothstep avoids zippery starts/stops while preserving total glide time.
    const float s = t * t * (3.0f - 2.0f * t);
    v.currentMidi = v.glideStartMidi + (v.targetMidi - v.glideStartMidi) * s;
    if (t >= 1.0f) {
        v.currentMidi = v.targetMidi;
        v.glideActive = false;
    }
}

void Al1Engine::startVoice(Voice& v, int note, float velocity, bool retrigger,
                           bool usePortamento, float startMidi, const Params& p) {
    v.note = note;
    v.velocity = velocity;
    if (retrigger) resetVoiceForTrigger(v);
    else {
        if (v.ampEnv.stage == EnvStage::Idle || v.ampEnv.stage == EnvStage::Release) v.ampEnv.stage = EnvStage::Attack;
        if (v.filterEnv.stage == EnvStage::Idle || v.filterEnv.stage == EnvStage::Release) v.filterEnv.stage = EnvStage::Attack;
    }

    if (usePortamento) configureGlide(v, startMidi, static_cast<float>(note), p);
    else {
        v.currentMidi = static_cast<float>(note);
        v.targetMidi = static_cast<float>(note);
        v.glideActive = false;
    }
}

void Al1Engine::setVoiceTarget(Voice& v, int note, bool usePortamento, const Params& p) {
    const float start = v.currentMidi;
    v.note = note;
    v.velocity = velocityForNote(note);
    if (usePortamento) configureGlide(v, start, static_cast<float>(note), p);
    else {
        v.currentMidi = static_cast<float>(note);
        v.targetMidi = static_cast<float>(note);
        v.glideActive = false;
    }
}

void Al1Engine::polyNoteOn(int note, float velocity, const Params& p, bool legatoInput) {
    const int budget = voiceBudget(p);
    for (int i = 0; i < budget; ++i) {
        auto& voice = voices_[i];
        if (voice.note == note && voice.ampEnv.stage != EnvStage::Idle) {
            startVoice(voice, note, velocity, true, false, static_cast<float>(note), p);
            return;
        }
    }
    Voice& v = allocateVoice(budget);
    const bool glide = p.portaEnable && (!p.portaFingered || legatoInput);
    startVoice(v, note, velocity, true, glide, lastTriggeredMidi_, p);
}

void Al1Engine::polyNoteOff(int note) {
    for (auto& voice : voices_) {
        if (voice.note == note && voice.ampEnv.stage != EnvStage::Idle) {
            voice.ampEnv.stage = EnvStage::Release;
            voice.filterEnv.stage = EnvStage::Release;
        }
    }
}

void Al1Engine::monoNoteOn(const Params& p, bool hadHeldNotes) {
    Voice& v = voices_[0];
    const int target = chooseMonoNote(p.priority);
    if (target < 0) return;

    const bool legatoInput = hadHeldNotes && v.ampEnv.stage != EnvStage::Idle;
    const bool glide = p.portaEnable && (!p.portaFingered || legatoInput);

    if (v.ampEnv.stage == EnvStage::Idle) {
        const float start = (!p.portaFingered && p.portaEnable) ? lastMonoMidi_ : static_cast<float>(target);
        startVoice(v, target, velocityForNote(target), true, glide, start, p);
        return;
    }

    if (target == v.note) {
        v.velocity = velocityForNote(target);
        return;
    }

    if (p.monoLegato && legatoInput) {
        setVoiceTarget(v, target, glide, p);
    } else {
        startVoice(v, target, velocityForNote(target), true, glide, v.currentMidi, p);
    }
}

void Al1Engine::monoNoteOff(int note, const Params& p) {
    Voice& v = voices_[0];
    if (v.ampEnv.stage == EnvStage::Idle) return;

    const int replacement = chooseMonoNote(p.priority);
    if (replacement >= 0) {
        if (replacement != v.note) {
            const bool glide = p.portaEnable;
            if (p.monoLegato) setVoiceTarget(v, replacement, glide, p);
            else startVoice(v, replacement, velocityForNote(replacement), true, glide, v.currentMidi, p);
        }
        return;
    }

    if (v.note == note || heldCount() == 0) {
        lastMonoMidi_ = v.currentMidi;
        v.ampEnv.stage = EnvStage::Release;
        v.filterEnv.stage = EnvStage::Release;
    }
}

float Al1Engine::stepEnvelope(Envelope& env, float attackSec, float decaySec,
                              float sustain, float releaseSec) {
    sustain = clamp01(sustain);
    switch (env.stage) {
        case EnvStage::Attack: {
            const float c = expCoeff(std::max(0.001f, attackSec), sampleRate_);
            env.value += (1.0f - env.value) * c;
            if (env.value > 0.999f) {
                env.value = 1.0f;
                env.stage = EnvStage::Decay;
            }
            break;
        }
        case EnvStage::Decay: {
            const float c = expCoeff(std::max(0.001f, decaySec), sampleRate_);
            env.value += (sustain - env.value) * c;
            if (std::fabs(env.value - sustain) < 0.001f) {
                env.value = sustain;
                env.stage = EnvStage::Sustain;
            }
            break;
        }
        case EnvStage::Sustain:
            env.value = sustain;
            break;
        case EnvStage::Release: {
            const float c = expCoeff(std::max(0.001f, releaseSec), sampleRate_);
            env.value += (0.0f - env.value) * c;
            if (env.value < 0.00005f) {
                env.value = 0.0f;
                env.stage = EnvStage::Idle;
            }
            break;
        }
        case EnvStage::Idle:
            env.value = 0.0f;
            break;
    }
    return env.value;
}

float Al1Engine::nextNoise(Voice& v) {
    uint32_t x = v.noiseState;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    v.noiseState = x;
    return static_cast<float>(static_cast<int32_t>(x)) / 2147483648.0f;
}

float Al1Engine::renderVoice(Voice& v, const Params& p) {
    if (v.ampEnv.stage == EnvStage::Idle) return 0.0f;

    stepGlide(v);

    const float ampAttackSec = 0.0015f + p.ampAttack * p.ampAttack * 3.0f;
    const float ampDecaySec = 0.004f + p.ampDecay * p.ampDecay * 5.0f;
    const float ampReleaseSec = 0.004f + p.ampRelease * p.ampRelease * 7.0f;
    const float amp = stepEnvelope(v.ampEnv, ampAttackSec, ampDecaySec, p.ampSustain, ampReleaseSec);

    const float fAttackSec = 0.0015f + p.filterAttack * p.filterAttack * 4.0f;
    const float fDecaySec = 0.004f + p.filterDecay * p.filterDecay * 7.0f;
    const float fReleaseSec = 0.004f + p.filterRelease * p.filterRelease * 8.0f;
    const float fEnv = stepEnvelope(v.filterEnv, fAttackSec, fDecaySec, p.filterSustain, fReleaseSec);

    if (v.ampEnv.stage == EnvStage::Idle) {
        v.note = -1;
        v.glideActive = false;
        return 0.0f;
    }

    const float lfoHz = 0.03f * std::pow(700.0f, p.lfoRate);
    const float lfo = std::sin(kTwoPi * v.lfoPhase);
    advance(v.lfoPhase, std::min(lfoHz / sampleRate_, 0.25f));

    const float pitchLfoSemitones = lfo * (p.lfoPitchAmount * p.lfoPitchAmount) * 2.0f;
    const float baseMidi = v.currentMidi + pitchLfoSemitones;
    const float osc2BaseCents = (p.osc2Detune * 2.0f - 1.0f) * 50.0f;
    const float unisonSpreadCents = p.unisonDetune * 35.0f;

    float osc1Sum = 0.0f;
    float osc2Sum = 0.0f;
    for (int u = 0; u < p.unisonVoices; ++u) {
        const float pos = p.unisonVoices == 1 ? 0.0f : (2.0f * u / static_cast<float>(p.unisonVoices - 1) - 1.0f);
        const float uniCents = pos * unisonSpreadCents;

        const float hz1 = midiToHz(baseMidi + uniCents / 100.0f);
        const float hz2 = midiToHz(baseMidi + (uniCents + osc2BaseCents) / 100.0f);
        const float inc1 = std::min(hz1 / sampleRate_, 0.45f);
        const float inc2 = std::min(hz2 / sampleRate_, 0.45f);

        const float o1 = oscillator(p.osc1Wave, v.phase1[u], inc1, p.pulseWidth);

        // Audio-rate phase modulation: OSC1 directly modulates OSC2 phase.
        float phase2Read = v.phase2[u] + o1 * p.fmAmount * 0.35f;
        phase2Read -= std::floor(phase2Read);
        const float o2 = oscillator(p.osc2Wave, phase2Read, inc2, p.pulseWidth);

        const bool osc1Wrapped = advance(v.phase1[u], inc1);
        if (p.sync && osc1Wrapped) v.phase2[u] = 0.0f;
        else advance(v.phase2[u], inc2);

        osc1Sum += o1;
        osc2Sum += o2;
    }
    const float norm = 1.0f / std::sqrt(static_cast<float>(p.unisonVoices));
    osc1Sum *= norm;
    osc2Sum *= norm;

    const float subInc = std::min((midiToHz(baseMidi - 12.0f)) / sampleRate_, 0.45f);
    const float sub = pulse(v.subPhase, subInc, 0.5f);
    advance(v.subPhase, subInc);

    const float ring = osc1Sum * osc2Sum;
    const float noise = nextNoise(v);
    float x = osc1Sum * p.osc1Level + osc2Sum * p.osc2Level +
              sub * p.subLevel + noise * p.noiseLevel + ring * p.ringLevel;

    // Filter envelope is bipolar around center. The range is approximately +/- 5 octaves.
    const float envOct = (p.filterEnvAmount - 0.5f) * 10.0f * fEnv;
    const float lfoOct = p.lfoCutoffAmount * 2.0f * lfo;
    const float modRatio = std::exp2(envOct + lfoOct);

    const float cutoffA = std::clamp(mapCutoff(p.cutoffA, sampleRate_) * modRatio, 20.0f, sampleRate_ * 0.43f);
    const float cutoffB = std::clamp(mapCutoff(p.cutoffB, sampleRate_) * modRatio, 20.0f, sampleRate_ * 0.43f);

    float filtered = 0.0f;
    switch (p.filterRouting) {
        case FilterRouting::Single:
            filtered = v.filterA.process(x, cutoffA, p.resonanceA, p.filterTypeA, sampleRate_);
            break;
        case FilterRouting::Serial: {
            const float a = v.filterA.process(x, cutoffA, p.resonanceA, p.filterTypeA, sampleRate_);
            filtered = v.filterB.process(a, cutoffB, p.resonanceB, p.filterTypeB, sampleRate_);
            break;
        }
        case FilterRouting::Parallel: {
            const float a = v.filterA.process(x, cutoffA, p.resonanceA, p.filterTypeA, sampleRate_);
            const float b = v.filterB.process(x, cutoffB, p.resonanceB, p.filterTypeB, sampleRate_);
            filtered = 0.5f * (a + b);
            break;
        }
        case FilterRouting::LowPass24: {
            const float a = v.filterA.process(x, cutoffA, p.resonanceA, FilterType::LowPass, sampleRate_);
            filtered = v.filterB.process(a, cutoffA, p.resonanceA, FilterType::LowPass, sampleRate_);
            break;
        }
    }

    // Low boost is a simple broad LF emphasis before the nonlinear driver.
    const float lowCoeff = 1.0f - std::exp(-kTwoPi * 180.0f / sampleRate_);
    v.lowBoostState += lowCoeff * (filtered - v.lowBoostState);
    filtered += v.lowBoostState * p.lowBoost * 0.85f;

    const float driveGain = 1.0f + p.drive * p.drive * 18.0f;
    const float driven = std::tanh(filtered * driveGain) / std::tanh(driveGain);
    return driven * amp * v.velocity;
}

void Al1Engine::render(float* out, int32_t frames) {
    const Params p = snapshotParams();
    processEvents(p);

    const int budget = p.voiceMode == VoiceMode::Mono ? 1 : voiceBudget(p);
    for (int32_t i = 0; i < frames; ++i) {
        float sample = 0.0f;
        for (int v = 0; v < budget; ++v) sample += renderVoice(voices_[v], p);

        const float master = p.voiceMode == VoiceMode::Mono ? 0.28f : 0.16f / std::sqrt(static_cast<float>(std::max(1, budget / 8)));
        sample = std::tanh(sample * master * 1.4f);
        out[i * 2] = sample;
        out[i * 2 + 1] = sample;
    }
}
