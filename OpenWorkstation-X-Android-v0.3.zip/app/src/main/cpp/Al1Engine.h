#pragma once

#include <array>
#include <atomic>
#include <cstdint>

class Al1Engine {
public:
    Al1Engine();

    void setSampleRate(float sampleRate);
    void noteOn(int note, float velocity);
    void noteOff(int note);
    void setParameter(int id, float normalizedValue);
    void render(float* interleavedStereo, int32_t frames);

private:
    enum class EnvStage : uint8_t { Idle, Attack, Decay, Sustain, Release };
    enum class VoiceMode : uint8_t { Poly = 0, Mono = 1 };
    enum class PortaMode : uint8_t { ConstantRate = 0, ConstantTime = 1 };
    enum class MonoPriority : uint8_t { Low = 0, High = 1, Last = 2 };
    enum class Waveform : uint8_t { Saw = 0, Pulse = 1, Triangle = 2 };
    enum class FilterType : uint8_t { LowPass = 0, BandPass = 1, HighPass = 2 };
    enum class FilterRouting : uint8_t { Single = 0, Serial = 1, Parallel = 2, LowPass24 = 3 };

    struct Envelope {
        EnvStage stage = EnvStage::Idle;
        float value = 0.0f;
    };

    struct Svf {
        float low = 0.0f;
        float band = 0.0f;
        void reset() { low = band = 0.0f; }
        float process(float input, float cutoffHz, float resonance,
                      FilterType type, float sampleRate);
    };

    struct Voice {
        int note = -1;
        float velocity = 0.0f;
        float currentMidi = 60.0f;
        float targetMidi = 60.0f;
        float glideStartMidi = 60.0f;
        int32_t glideSamplesDone = 0;
        int32_t glideSamplesTotal = 0;
        bool glideActive = false;

        std::array<float, 4> phase1{};
        std::array<float, 4> phase2{};
        float subPhase = 0.0f;
        float lfoPhase = 0.0f;
        uint32_t noiseState = 0x12345678u;

        Envelope ampEnv{};
        Envelope filterEnv{};
        Svf filterA{};
        Svf filterB{};
        float lowBoostState = 0.0f;
    };

    enum class EventType : uint8_t { NoteOn, NoteOff };

    struct NoteEvent {
        EventType type = EventType::NoteOff;
        int note = 0;
        float velocity = 0.0f;
    };

    struct Params {
        float cutoffA = 0.68f;
        float resonanceA = 0.22f;
        float osc2Detune = 0.28f;
        float ampAttack = 0.07f;
        float ampRelease = 0.20f;
        VoiceMode voiceMode = VoiceMode::Poly;
        bool monoLegato = true;
        bool portaEnable = false;
        bool portaFingered = true;
        float portaTime = 0.22f;
        PortaMode portaMode = PortaMode::ConstantRate;
        MonoPriority priority = MonoPriority::Last;

        Waveform osc1Wave = Waveform::Saw;
        Waveform osc2Wave = Waveform::Saw;
        float osc1Level = 0.75f;
        float osc2Level = 0.70f;
        float subLevel = 0.10f;
        float noiseLevel = 0.0f;
        float ringLevel = 0.0f;
        float fmAmount = 0.0f;
        bool sync = false;
        float pulseWidth = 0.50f;

        float cutoffB = 0.68f;
        float resonanceB = 0.15f;
        FilterRouting filterRouting = FilterRouting::Single;
        FilterType filterTypeA = FilterType::LowPass;
        FilterType filterTypeB = FilterType::LowPass;
        float filterEnvAmount = 0.50f; // 0.5 = zero, bipolar around center
        float filterAttack = 0.02f;
        float filterDecay = 0.25f;
        float filterSustain = 0.45f;
        float filterRelease = 0.25f;

        float ampDecay = 0.20f;
        float ampSustain = 0.78f;
        float drive = 0.08f;
        float lowBoost = 0.0f;

        float lfoRate = 0.22f;
        float lfoPitchAmount = 0.0f;
        float lfoCutoffAmount = 0.0f;

        int unisonVoices = 1;
        float unisonDetune = 0.12f;
    };

    static constexpr uint32_t kEventCapacity = 256;
    static constexpr int kMaxVoices = 64;
    static constexpr int kMaxUnison = 4;

    class EventQueue {
    public:
        bool push(const NoteEvent& event);
        bool pop(NoteEvent& event);

    private:
        std::array<NoteEvent, kEventCapacity> events_{};
        std::atomic<uint32_t> write_{0};
        std::atomic<uint32_t> read_{0};
    };

    static float midiToHz(float note);
    static float polyBlep(float t, float dt);
    static float saw(float phase, float increment);
    static float pulse(float phase, float increment, float width);
    static float triangle(float phase);
    static float oscillator(Waveform waveform, float phase, float increment, float pulseWidth);
    static bool advance(float& phase, float increment);
    static float clamp01(float v);
    static float mapCutoff(float norm, float sampleRate);

    Params snapshotParams() const;
    void processEvents(const Params& p);
    void applyNoteOn(int note, float velocity, const Params& p);
    void applyNoteOff(int note, const Params& p);

    void polyNoteOn(int note, float velocity, const Params& p, bool legatoInput);
    void polyNoteOff(int note);
    void monoNoteOn(const Params& p, bool hadHeldNotes);
    void monoNoteOff(int note, const Params& p);

    int voiceBudget(const Params& p) const;
    Voice& allocateVoice(int voiceLimit);
    void resetVoiceForTrigger(Voice& v);
    void startVoice(Voice& v, int note, float velocity, bool retrigger,
                    bool usePortamento, float startMidi, const Params& p);
    void setVoiceTarget(Voice& v, int note, bool usePortamento, const Params& p);
    void configureGlide(Voice& v, float startMidi, float targetMidi, const Params& p);
    float portamentoSeconds(float distanceSemitones, const Params& p) const;
    void stepGlide(Voice& v);

    float stepEnvelope(Envelope& env, float attackSec, float decaySec,
                       float sustain, float releaseSec);
    float renderVoice(Voice& voice, const Params& p);
    float nextNoise(Voice& voice);

    int chooseMonoNote(MonoPriority priority) const;
    float velocityForNote(int note) const;
    int heldCount() const;

    std::array<Voice, kMaxVoices> voices_{};
    EventQueue events_{};

    std::array<bool, 128> held_{};
    std::array<uint64_t, 128> heldOrder_{};
    std::array<float, 128> heldVelocity_{};
    uint64_t noteOrderCounter_ = 0;
    float lastTriggeredMidi_ = 60.0f;
    float lastMonoMidi_ = 60.0f;

    float sampleRate_ = 48000.0f;

    std::array<std::atomic<float>, 42> param_{};
};
