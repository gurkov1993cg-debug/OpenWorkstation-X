# OpenWorkstation-X Android v0.3 — AL-1 Core Rebuild

This release replaces the earlier minimal VA demo with a real modular native C++ synth signal path.
It is an original implementation inspired by workstation-class virtual-analog architecture; it does not contain Korg source code, firmware, samples, or proprietary algorithms.

## Working native DSP in v0.3

- Android AAudio low-latency output
- 64-base-voice native C++ voice pool with dynamic unison resource budgeting
- Poly / Mono voice modes
- Mono Legato with held-note stack
- Mono note priority: Low / High / Last
- Portamento On/Off
- Fingered portamento
- Constant Rate / Constant Time portamento modes
- Two anti-aliased oscillators per unison voice
- Saw / Pulse / Triangle waveforms
- Pulse width control
- OSC2 fine detune
- Hard oscillator sync (OSC1 resets OSC2)
- Audio-rate phase FM from OSC1 to OSC2
- Ring modulation
- Sub oscillator
- Noise generator
- 1–4 voice unison with detune spread
- Dual state-variable filters
- Filter A and B: LP / BP / HP
- Filter routing: Single / Serial / Parallel / cascaded 24 dB LP
- Independent filter cutoff and resonance
- Independent per-voice Amp ADSR
- Independent per-voice Filter ADSR
- Bipolar Filter EG amount
- Per-voice LFO with pitch and cutoff modulation
- Low-frequency boost stage
- Nonlinear drive stage
- Lock-free UI-to-audio note queue
- No mutex or heap allocation inside the render callback

## UI pages

- OSC / MIX
- FILTER
- ENV / LFO
- VOICE / PORTA

Every exposed sound control on these pages is connected to the native DSP engine.

## Important

v0.3 is still not a complete AL-1-class engine. Missing areas include deeper AMS routing/mixers,
multiple LFO shapes and sync modes, additional oscillator shaping, more filter models,
key tracking, velocity routings, pitch EG, step sequencer modulation, stereo unison placement,
and a workstation-grade modulation matrix. Those should be implemented as real DSP before
moving to the next synthesis engine.
