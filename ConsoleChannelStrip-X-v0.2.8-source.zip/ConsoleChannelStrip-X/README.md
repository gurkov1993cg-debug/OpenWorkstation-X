# Console Channel Strip X v0.2.8

Console Channel Strip X is an original C++17/JUCE 7.0.12 VST3 channel strip for Intel macOS. The project targets x86_64 and macOS 10.13+ and uses no external runtime assets or image dependencies.

## v0.2.8 goals

This revision is a hardware-skin, metering, and input-stage correction pass. The four-column editor remains fixed to the approved layout: INPUT / FILTERS / EQ, DYNAMICS, central meter bridge, and OUTPUT / CHANNEL MODE. The UI is drawn procedurally in C++/JUCE, now with deeper panel texture, machined knobs, recessed illuminated switches, brushed metal and meter wells while using only Channel Strip X / OpenWorkstation X branding.

### Dynamics

- Compressor detector defaults to a 10 ms RMS-style average; PEAK remains a real optional detector mode.
- Normal compressor attack is program-dependent, moving approximately from 30 ms toward 3 ms as requested reduction becomes more urgent. The user ATTACK parameter remains active as a multiplier; FAST selects the faster base behaviour rather than making the visible ATTACK control decorative.
- Compressor attack remains a 20 dB-per-attack-time dB slew, with a 6 dB soft knee and threshold/ratio-derived automatic make-up retained.
- Gate and compressor now read the same pre-reduction detector signal and their gain reductions are combined before one gain application.
- Gate/expander uses fixed 3 dB hysteresis, real HOLD, 1:2 downward expansion, program-dependent normal opening attack, ~1 ms FAST opening, and RANGE-limited attenuation.

### EQ and filters

- HPF range is now 16–350 Hz. This changes the normalised value of old saved HPF automation/state in 0.2.x sessions.
- LMF range is now 200 Hz–2.5 kHz. This likewise changes normalised values in old 0.2.x sessions.
- Brown uses a gentler first-order HPF path; Black cascades first- and second-order sections for the tighter approximately 18 dB/oct path. LPF remains a 12 dB/oct filter in both models.
- Mid bands use the user Q directly in both E-style models instead of changing Q between Brown and Black.
- LF/HF shelf modes add a broad opposite-sign transition dip/overshoot component; BELL mode bypasses that extra component.
- Brown keeps a very small always-in-path electronics signature; Black can be clean when EQ IN is off.

### Console stages and automation

- INPUT DRIVE is now a real -20..+20 dB preamp control: negative values attenuate cleanly, 0 dB in LINE is a true clean/null point, and positive values feed progressively more level into an asymmetric transformer-style saturation stage. MIC retains a subtle baseline preamp colour.
- Output VCA colour is zero at a 0 dB VCA setting and increases progressively only when the VCA is pushed above unity.
- Input trim, VCA gain, output trim, mix, and output VCA colour use 20 ms sample-rate-based smoothing.
- Filter coefficients are cached and glide toward new targets rather than being rebuilt every audio block.
- MUTE is applied after dry/wet mixing, so no dry signal can leak through at MIX below 100%.
- The dry buffer has a real Release-build bounds safeguard instead of relying only on assertions.
- Host bypass is mapped to the APVTS `bypass` parameter through `getBypassParameter()`.

## GUI reliability

- Fixed editor size: 1536 × 942, matching the locked reference composition.
- Every APVTS parameter has exactly one interactive component with the same component ID.
- No raw JUCE numeric text boxes are shown; values are formatted for tooltips.
- Static textured panels, brushed metal, screws and legends are cached to an image once per editor size; 15 Hz timer repaints only live meter/display areas.
- Compressor and gate GR indicators read the actual DSP reduction values, use a 0 to -24 dB downward scale, and apply visual attack/release ballistics only for readability.
- CI recursively audits the complete component tree for missing/duplicate IDs, zero-sized or out-of-bounds controls, overlaps, and real parameter changes.
- CI renders `gui-preview-v0.2.8.png` directly from the real C++ editor before building the VST3, so the actual JUCE result can be inspected before installation.
- JUCE splash/badge is disabled on the plugin and both test targets.

## Automated checks

`ConsoleChannelStripXSmokeTests` checks mute at several mix settings, clean-path level/distortion, a clean 0 dB INPUT DRIVE point plus audible positive drive, 1:2 expansion, gate HOLD timing, program-dependent compression attack, shelf transition character, automatic make-up, Brown/Black HPF behaviour, block-size invariance, and finite output at extreme legal settings.

`ConsoleChannelStripXGuiSmokeTests` checks editor construction time, exact APVTS/GUI ID equality, visibility/bounds, parameter wiring, non-overlap, host-facing bypass/power behaviour, INIT, and generates the actual GUI preview PNG.

## Build

The supplied GitHub Actions workflow builds on an Intel macOS runner, verifies an x86_64 Mach-O VST3 with a minimum target no newer than macOS 10.13, runs both C++ test executables, and packages the VST3, logs, deployment information, and real GUI preview.
