#include "DspEngine.h"

namespace
{
    inline float dbToGain (float db) { return juce::Decibels::decibelsToGain (db); }

    void runFilter (DspEngine::IIR& filter, juce::AudioBuffer<float>& buffer)
    {
        juce::dsp::AudioBlock<float> block (buffer);
        juce::dsp::ProcessContextReplacing<float> context (block);
        filter.process (context);
    }
}

void DspEngine::prepare (double sampleRate, int maximumBlockSize, int numChannels)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate,
                                  static_cast<juce::uint32> (juce::jmax (1, maximumBlockSize)),
                                  static_cast<juce::uint32> (juce::jmax (1, numChannels)) };

    hp1.prepare (spec); hp2.prepare (spec); lp.prepare (spec);
    lf.prepare (spec); lfDip.prepare (spec); lmf.prepare (spec); hmf.prepare (spec); hf.prepare (spec); hfDip.prepare (spec);

    globalDryBuffer.setSize (juce::jmax (1, numChannels), juce::jmax (1, maximumBlockSize), false, false, true);

    inputTrimGain.reset (sr, 0.020);
    inputDriveGain.reset (sr, 0.020);
    vcaGain.reset (sr, 0.020);
    outputTrimGain.reset (sr, 0.020);
    mixSmoother.reset (sr, 0.020);
    vcaSaturationSmoother.reset (sr, 0.020);

    reset();
}

void DspEngine::reset()
{
    hp1.reset(); hp2.reset(); lp.reset();
    lf.reset(); lfDip.reset(); lmf.reset(); hmf.reset(); hf.reset(); hfDip.reset();

    compGainDb = 0.0f;
    rmsSquare = 0.0f;
    peakEnvelope = 0.0f;
    compUrgency = 0.0f;
    gateReductionDb = 0.0f;
    gateOpen = true;
    gateHoldSamplesRemaining = 0;

    inputTrimGain.setCurrentAndTargetValue (1.0f);
    inputDriveGain.setCurrentAndTargetValue (1.0f);
    vcaGain.setCurrentAndTargetValue (1.0f);
    outputTrimGain.setCurrentAndTargetValue (1.0f);
    mixSmoother.setCurrentAndTargetValue (1.0f);
    vcaSaturationSmoother.setCurrentAndTargetValue (0.0f);

    compMeterDb.store (0.0f);
    gateMeterDb.store (0.0f);
    inputPeakDb.store (-100.0f);
    outputPeakDb.store (-100.0f);

    filterCacheValid = false;
    filterStatesInitialised = false;
    gainSmoothersInitialised = false;
    hp1Target = nullptr; hp2Target = nullptr; lpTarget = nullptr;
    lfTarget = nullptr; lfDipTarget = nullptr; lmfTarget = nullptr; hmfTarget = nullptr; hfTarget = nullptr; hfDipTarget = nullptr;
}

float DspEngine::transformerSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Deliberately audible console-input nonlinearity. DRIVE itself is applied as
    // real pre-gain before this function; this stage then adds asymmetric soft
    // saturation instead of cancelling that gain back out. At 0 dB LINE mode the
    // whole input stage remains mathematically clean.
    const float hardness = 1.0f + 1.9f * a;
    const float bias = 0.010f + 0.026f * a;
    const float positive = std::tanh (hardness * (x + bias));
    const float negative = std::tanh ((hardness * (0.92f + 0.18f * a)) * (x - bias * 0.55f));
    const float asymmetric = 0.54f * positive + 0.46f * negative;

    // Keep the centre close to zero while preserving the asymmetry that produces
    // even harmonics. The dry blend is only a safety rail at low drive.
    const float dc = 0.54f * std::tanh (hardness * bias)
                   + 0.46f * std::tanh (-(hardness * (0.92f + 0.18f * a)) * bias * 0.55f);
    const float shaped = asymmetric - dc;
    const float blend = 0.30f + 0.70f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::vcaSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Output VCA colour is separate from the input transformer model and is zero
    // at a 0 dB fader setting. It becomes progressively firmer only above unity.
    const float drive = 1.0f + 2.2f * a;
    const float shaped = std::tanh (drive * x) / drive;
    const float blend = 0.08f + 0.52f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::eqPathSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Very light always-in-path colour for the 02/Brown model. This is deliberately
    // much subtler than INPUT DRIVE and does not add a hidden gain step.
    const float cubic = x * x * x;
    const float asymmetric = x * x * (x >= 0.0f ? 1.0f : -0.75f);
    return x - cubic * (0.020f * a) + asymmetric * (0.004f * a);
}

float DspEngine::bufferPeakDb (const juce::AudioBuffer<float>& buffer)
{
    float peak = 0.0f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        peak = juce::jmax (peak, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
    return juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -100.0f);
}

void DspEngine::processInputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    inputTrimGain.setTargetValue (dbToGain (p.inputTrimDb));
    inputDriveGain.setTargetValue (dbToGain (juce::jlimit (-20.0f, 20.0f, p.inputDrive)));
    const float polarityGain = p.polarity ? -1.0f : 1.0f;

    // INPUT DRIVE is a real -20..+20 dB preamp drive. Negative settings are clean
    // attenuation, 0 dB LINE is a true clean/null point, and positive settings
    // feed progressively more level into the transformer-style stage. MIC keeps a
    // subtle baseline colour even at 0 dB.
    const float positiveDrive = juce::jmax (0.0f, p.inputDrive);
    const float modeBias = p.inputMode == 1 ? 0.12f : 0.0f;
    const float saturationAmount = juce::jlimit (0.0f, 1.0f, positiveDrive / 20.0f + modeBias);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float trim = inputTrimGain.getNextValue() * polarityGain;
        const float drive = inputDriveGain.getNextValue();

        for (int ch = 0; ch < channels; ++ch)
        {
            float v = buffer.getSample (ch, i) * trim * drive;
            if (saturationAmount > 0.0001f)
                v = transformerSaturate (v, saturationAmount);
            buffer.setSample (ch, i, v);
        }
    }
}

bool DspEngine::filterParametersChanged (const Params& p) const noexcept
{
    if (! filterCacheValid)
        return true;

    return p.hpFreq != lastFilterParams.hpFreq
        || p.lpFreq != lastFilterParams.lpFreq
        || p.blackEq != lastFilterParams.blackEq
        || p.lfBell != lastFilterParams.lfBell
        || p.lfFreq != lastFilterParams.lfFreq
        || p.lfGain != lastFilterParams.lfGain
        || p.lmfFreq != lastFilterParams.lmfFreq
        || p.lmfGain != lastFilterParams.lmfGain
        || p.lmfQ != lastFilterParams.lmfQ
        || p.hmfFreq != lastFilterParams.hmfFreq
        || p.hmfGain != lastFilterParams.hmfGain
        || p.hmfQ != lastFilterParams.hmfQ
        || p.hfBell != lastFilterParams.hfBell
        || p.hfFreq != lastFilterParams.hfFreq
        || p.hfGain != lastFilterParams.hfGain;
}

void DspEngine::setFilterTargets (const Params& p)
{
    const auto nyquistSafe = static_cast<float> (0.45 * sr);
    const auto hpHz = juce::jlimit (16.0f, juce::jmin (350.0f, nyquistSafe), p.hpFreq);
    const auto lpHz = juce::jlimit (3000.0f, nyquistSafe, p.lpFreq);
    const float shelfSlope = p.blackEq ? 0.96f : 0.58f;

    hp1Target = Coefficients::makeFirstOrderHighPass (sr, hpHz);
    hp2Target = Coefficients::makeHighPass (sr, hpHz, 0.70710678f);
    lpTarget = Coefficients::makeLowPass (sr, lpHz, 0.70710678f);

    lfTarget = p.lfBell
        ? Coefficients::makePeakFilter (sr, p.lfFreq, 0.78f, dbToGain (p.lfGain))
        : Coefficients::makeLowShelf (sr, p.lfFreq, shelfSlope, dbToGain (p.lfGain));

    // E-series mids remain constant-Q in both 02/Brown and 242/Black models.
    lmfTarget = Coefficients::makePeakFilter (
        sr, p.lmfFreq, juce::jlimit (0.35f, 4.5f, p.lmfQ), dbToGain (p.lmfGain));
    hmfTarget = Coefficients::makePeakFilter (
        sr, p.hmfFreq, juce::jlimit (0.35f, 4.5f, p.hmfQ), dbToGain (p.hmfGain));

    hfTarget = p.hfBell
        ? Coefficients::makePeakFilter (sr, p.hfFreq, 0.78f, dbToGain (p.hfGain))
        : Coefficients::makeHighShelf (sr, p.hfFreq, shelfSlope, dbToGain (p.hfGain));

    const auto lfDipHz = juce::jmin (p.lfFreq * 2.2f, nyquistSafe);
    const auto hfDipHz = juce::jmax (p.hfFreq / 2.2f, 20.0f);
    lfDipTarget = Coefficients::makePeakFilter (sr, lfDipHz, 0.70f,
                                                p.lfBell ? 1.0f : dbToGain (-p.lfGain * 0.22f));
    hfDipTarget = Coefficients::makePeakFilter (sr, hfDipHz, 0.70f,
                                                p.hfBell ? 1.0f : dbToGain (-p.hfGain * 0.22f));

    lastFilterParams = p;
    filterCacheValid = true;
}

void DspEngine::moveCoefficientsTowards (IIR& filter, const CoeffPtr& target, float alpha)
{
    if (target == nullptr)
        return;

    auto& current = filter.state->coefficients;
    const auto& destination = target->coefficients;
    if (current.size() != destination.size())
    {
        *filter.state = *target;
        return;
    }

    for (int i = 0; i < current.size(); ++i)
        current.set (i, current[i] + (destination[i] - current[i]) * alpha);
}

void DspEngine::smoothFilterCoefficients (int blockSamples)
{
    if (! filterStatesInitialised)
    {
        if (hp1Target != nullptr) *hp1.state = *hp1Target;
        if (hp2Target != nullptr) *hp2.state = *hp2Target;
        if (lpTarget != nullptr) *lp.state = *lpTarget;
        if (lfTarget != nullptr) *lf.state = *lfTarget;
        if (lfDipTarget != nullptr) *lfDip.state = *lfDipTarget;
        if (lmfTarget != nullptr) *lmf.state = *lmfTarget;
        if (hmfTarget != nullptr) *hmf.state = *hmfTarget;
        if (hfTarget != nullptr) *hf.state = *hfTarget;
        if (hfDipTarget != nullptr) *hfDip.state = *hfDipTarget;
        filterStatesInitialised = true;
        return;
    }

    // 20 ms coefficient glide. The exponential is computed from elapsed samples,
    // not an arbitrary per-block constant, which keeps automation behaviour close
    // across different host block sizes.
    const float alpha = 1.0f - std::exp (-static_cast<float> (juce::jmax (1, blockSamples))
                                         / static_cast<float> (0.020 * sr));
    moveCoefficientsTowards (hp1, hp1Target, alpha);
    moveCoefficientsTowards (hp2, hp2Target, alpha);
    moveCoefficientsTowards (lp, lpTarget, alpha);
    moveCoefficientsTowards (lf, lfTarget, alpha);
    moveCoefficientsTowards (lfDip, lfDipTarget, alpha);
    moveCoefficientsTowards (lmf, lmfTarget, alpha);
    moveCoefficientsTowards (hmf, hmfTarget, alpha);
    moveCoefficientsTowards (hf, hfTarget, alpha);
    moveCoefficientsTowards (hfDip, hfDipTarget, alpha);
}

void DspEngine::updateFilters (const Params& p, int blockSamples)
{
    if (filterParametersChanged (p))
        setFilterTargets (p);
    smoothFilterCoefficients (blockSamples);
}

void DspEngine::processFilters (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.hpOn)
    {
        // 02/Brown uses the gentler first-order path; 242/Black cascades first +
        // second order sections for the tighter approximately 18 dB/oct response.
        if (p.blackEq)
        {
            runFilter (hp2, buffer);
            runFilter (hp1, buffer);
        }
        else
        {
            runFilter (hp1, buffer);
        }
    }

    if (p.lpOn)
        runFilter (lp, buffer);
}

void DspEngine::processEQ (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.eqOn)
    {
        runFilter (lf, buffer);
        if (! p.lfBell) runFilter (lfDip, buffer);
        runFilter (lmf, buffer);
        runFilter (hmf, buffer);
        runFilter (hf, buffer);
        if (! p.hfBell) runFilter (hfDip, buffer);
    }

    // The 02/Brown signal path retains a tiny electronics signature even at flat
    // settings. 242/Black can be completely clean when EQ IN is off.
    if (! p.blackEq)
    {
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            auto* data = buffer.getWritePointer (ch);
            for (int i = 0; i < buffer.getNumSamples(); ++i)
                data[i] = eqPathSaturate (data[i], 0.03f);
        }
    }
}

float DspEngine::softKneeGainReduction (float levelDb, float thresholdDb, float ratio, float kneeDb)
{
    if (ratio <= 1.0001f)
        return 0.0f;

    const float slope = 1.0f - 1.0f / ratio;
    const float x = levelDb - thresholdDb;
    if (kneeDb <= 0.0f)
        return x > 0.0f ? slope * x : 0.0f;

    const float half = 0.5f * kneeDb;
    if (x <= -half) return 0.0f;
    if (x >= half) return slope * x;
    const float t = x + half;
    return slope * t * t / (2.0f * kneeDb);
}

void DspEngine::processDynamics (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.dynOn)
    {
        compGainDb = 0.0f;
        gateReductionDb = 0.0f;
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    const float rmsWindowMs = 10.0f;
    const float rmsCoeff = std::exp (-1.0f / static_cast<float> (rmsWindowMs * 0.001 * sr));
    const float peakAttackCoeff = std::exp (-1.0f / static_cast<float> (0.00020 * sr));
    const float peakReleaseCoeff = std::exp (-1.0f / static_cast<float> (0.010 * sr));
    const float urgencyCoeff = std::exp (-1.0f / static_cast<float> (0.005 * sr));
    const float compReleaseCoeff = std::exp (-1.0f / static_cast<float> (
        juce::jmax (0.02, static_cast<double> (p.compReleaseSec)) * sr));
    const float gateReleaseCoeff = std::exp (-1.0f / static_cast<float> (
        juce::jmax (0.02, static_cast<double> (p.gateReleaseSec)) * sr));

    constexpr float hysteresisDb = 3.0f;
    const float gateCloseThresholdDb = p.gateThresholdDb - hysteresisDb;
    const int holdSamples = static_cast<int> (juce::jmax (0.0f, p.gateHoldSec) * static_cast<float> (sr));

    for (int i = 0; i < samples; ++i)
    {
        // Shared pre-gain-reduction detector source. Mean absolute channel sum is
        // stable for stereo image placement and does not favour whichever channel
        // happens to have the largest sample at this instant.
        float detectorInput = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            detectorInput += std::abs (buffer.getSample (ch, i));
        detectorInput /= static_cast<float> (channels);

        const float squared = detectorInput * detectorInput;
        rmsSquare = rmsCoeff * rmsSquare + (1.0f - rmsCoeff) * squared;
        const float rmsLevel = std::sqrt (juce::jmax (rmsSquare, 1.0e-18f));

        const float peakCoeff = detectorInput > peakEnvelope ? peakAttackCoeff : peakReleaseCoeff;
        peakEnvelope = peakCoeff * peakEnvelope + (1.0f - peakCoeff) * detectorInput;

        const float detectorLevel = p.compPeak ? peakEnvelope : rmsLevel;
        const float detectorDb = juce::Decibels::gainToDecibels (juce::jmax (detectorLevel, 1.0e-9f), -120.0f);

        // ---------------- Gate / expander control voltage ----------------
        float targetGateReductionDb = 0.0f;
        if (p.gateOn && p.gateRangeDb > 0.01f)
        {
            if (detectorDb >= p.gateThresholdDb)
            {
                gateOpen = true;
                gateHoldSamplesRemaining = holdSamples;
            }
            else if (gateOpen)
            {
                if (detectorDb < gateCloseThresholdDb)
                {
                    if (gateHoldSamplesRemaining > 0)
                        --gateHoldSamplesRemaining;
                    else
                        gateOpen = false;
                }
                else
                {
                    // The signal is inside the 3 dB hysteresis window: keep the
                    // gate stable and recharge HOLD instead of chattering.
                    gateHoldSamplesRemaining = holdSamples;
                }
            }

            if (! gateOpen)
            {
                if (p.gateExpand)
                {
                    // Fixed 1:2 downward expansion: 10 dB below threshold adds
                    // another 10 dB of attenuation, limited by RANGE.
                    targetGateReductionDb = juce::jmin (
                        p.gateRangeDb, juce::jmax (0.0f, p.gateThresholdDb - detectorDb));
                }
                else
                {
                    targetGateReductionDb = p.gateRangeDb;
                }
            }

            if (targetGateReductionDb < gateReductionDb)
            {
                // Opening attack. Normal mode is program dependent ~1.5..15 ms;
                // FAST is a fixed ~1 ms. RANGE, not a hard-coded 40 dB, defines
                // the amount traversed during the attack interval.
                const float openingDemand = juce::jmax (0.0f, detectorDb - p.gateThresholdDb);
                const float urgency = juce::jlimit (0.0f, 1.0f, openingDemand / 12.0f);
                const float classicAttackMs = juce::jmap (urgency, 15.0f, 1.5f);
                const float userScale = juce::jlimit (0.10f, 3.0f, p.gateAttackMs / 1.5f);
                const float attackMs = p.gateFast ? 1.0f : juce::jmax (0.05f, classicAttackMs * userScale);
                const float stepDb = juce::jmax (0.001f, p.gateRangeDb)
                                   / juce::jmax (1.0f, attackMs * 0.001f * static_cast<float> (sr));
                gateReductionDb = juce::jmax (targetGateReductionDb, gateReductionDb - stepDb);
            }
            else
            {
                gateReductionDb = gateReleaseCoeff * gateReductionDb
                                + (1.0f - gateReleaseCoeff) * targetGateReductionDb;
            }
        }
        else
        {
            gateReductionDb = 0.0f;
            gateOpen = true;
            gateHoldSamplesRemaining = 0;
        }

        // ---------------- Compressor control voltage ----------------
        float makeupDb = 0.0f;
        if (p.compOn)
        {
            const float ratio = p.compRatio >= 19.95f ? 1000.0f : juce::jmax (1.0f, p.compRatio);
            const float targetGrDb = softKneeGainReduction (detectorDb, p.compThresholdDb, ratio, 6.0f);
            const float targetGainDb = -targetGrDb;

            if (targetGainDb < compGainDb)
            {
                const float demandDb = juce::jmax (0.0f, compGainDb - targetGainDb);
                const float urgencyTarget = juce::jlimit (0.0f, 1.0f, demandDb / 12.0f);
                compUrgency = urgencyCoeff * compUrgency + (1.0f - urgencyCoeff) * urgencyTarget;

                float attackMs = p.compFast ? 3.0f : juce::jmap (compUrgency, 30.0f, 3.0f);
                // Keep the user's ATTACK knob active in both normal and FAST modes.
                attackMs *= juce::jlimit (0.1f, 3.0f, p.compAttackMs / 10.0f);
                attackMs = juce::jmax (0.05f, attackMs);

                // The E-series attack is commonly specified as the time to reach
                // about 20 dB of reduction, so use a dB-per-sample slew, not a
                // generic one-pole attack coefficient.
                const float stepDb = 20.0f / juce::jmax (
                    1.0f, attackMs * 0.001f * static_cast<float> (sr));
                compGainDb = juce::jmax (targetGainDb, compGainDb - stepDb);
            }
            else
            {
                compUrgency = urgencyCoeff * compUrgency;
                const float depth = juce::jlimit (0.0f, 1.0f, -compGainDb / 20.0f);
                const float releaseShape = 0.80f + 0.40f * depth;
                const float shapedReleaseCoeff = std::pow (compReleaseCoeff, 1.0f / releaseShape);
                compGainDb = shapedReleaseCoeff * compGainDb
                           + (1.0f - shapedReleaseCoeff) * targetGainDb;
            }

            // Automatic make-up remains threshold/ratio based by design.
            makeupDb = (-juce::jmin (0.0f, p.compThresholdDb))
                     * (1.0f - 1.0f / ratio) * 0.46f;
        }
        else
        {
            compGainDb = 0.0f;
            compUrgency = 0.0f;
        }

        // Both dynamics control voltages act on one gain element. Importantly, the
        // compressor detector never reads the already-gated signal.
        const float totalGainDb = compGainDb - gateReductionDb + makeupDb;
        const float dynamicsGain = dbToGain (totalGainDb);
        for (int ch = 0; ch < channels; ++ch)
            buffer.setSample (ch, i, buffer.getSample (ch, i) * dynamicsGain);
    }

    compMeterDb.store (p.compOn ? juce::jmax (0.0f, -compGainDb) : 0.0f);
    gateMeterDb.store (p.gateOn ? juce::jmax (0.0f, gateReductionDb) : 0.0f);
}

void DspEngine::encodeMidSide (juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() != 2)
        return;

    constexpr float k = 0.7071067811865476f;
    auto* left = buffer.getWritePointer (0);
    auto* right = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float l = left[i];
        const float r = right[i];
        left[i] = (l + r) * k;
        right[i] = (l - r) * k;
    }
}

void DspEngine::decodeMidSide (juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() != 2)
        return;

    constexpr float k = 0.7071067811865476f;
    auto* mid = buffer.getWritePointer (0);
    auto* side = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float m = mid[i];
        const float s = side[i];
        mid[i] = (m + s) * k;
        side[i] = (m - s) * k;
    }
}

void DspEngine::processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    vcaGain.setTargetValue (dbToGain (p.vcaFaderDb));
    outputTrimGain.setTargetValue (dbToGain (p.outputTrimDb));

    const float push = juce::jlimit (0.0f, 1.0f, p.vcaFaderDb / 10.0f);
    const float targetSaturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
    vcaSaturationSmoother.setTargetValue (targetSaturation);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float fader = vcaGain.getNextValue();
        const float trim = outputTrimGain.getNextValue();
        const float saturation = vcaSaturationSmoother.getNextValue();
        for (int ch = 0; ch < channels; ++ch)
        {
            float v = buffer.getSample (ch, i) * fader;
            if (saturation > 0.0001f)
                v = vcaSaturate (v, saturation);
            buffer.setSample (ch, i, v * trim);
        }
    }
}

void DspEngine::process (juce::AudioBuffer<float>& buffer, const Params& p)
{
    inputPeakDb.store (bufferPeakDb (buffer));

    if (p.bypass)
    {
        outputPeakDb.store (inputPeakDb.load());
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    // On the first active block, initialise the smoothers from the restored/current
    // parameter values instead of ramping from factory defaults. Subsequent changes
    // use the normal 20 ms ramps. This keeps session recall and MIX=0 null-safe.
    if (! gainSmoothersInitialised)
    {
        inputTrimGain.setCurrentAndTargetValue (dbToGain (p.inputTrimDb));
        inputDriveGain.setCurrentAndTargetValue (dbToGain (juce::jlimit (-20.0f, 20.0f, p.inputDrive)));
        vcaGain.setCurrentAndTargetValue (dbToGain (p.vcaFaderDb));
        outputTrimGain.setCurrentAndTargetValue (dbToGain (p.outputTrimDb));
        mixSmoother.setCurrentAndTargetValue (juce::jlimit (0.0f, 1.0f, p.mix));
        const float push = juce::jlimit (0.0f, 1.0f, p.vcaFaderDb / 10.0f);
        const float saturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
        vcaSaturationSmoother.setCurrentAndTargetValue (saturation);
        gainSmoothersInitialised = true;
    }

    // Hosts normally respect prepareToPlay's maximum block size, but Release builds
    // must never rely on jassert for buffer safety. Grow only on an unexpected host
    // violation instead of risking an out-of-bounds dry-path copy.
    if (channels > globalDryBuffer.getNumChannels() || samples > globalDryBuffer.getNumSamples())
        globalDryBuffer.setSize (juce::jmax (channels, globalDryBuffer.getNumChannels()),
                                 juce::jmax (samples, globalDryBuffer.getNumSamples()),
                                 false, false, true);

    for (int ch = 0; ch < channels; ++ch)
        globalDryBuffer.copyFrom (ch, 0, buffer, ch, 0, samples);

    if (p.channelMode == 1 && channels == 2)
        encodeMidSide (buffer);

    processInputStage (buffer, p);
    updateFilters (p, samples);

    switch (p.routing)
    {
        case 1: // FILTER -> DYN -> EQ
            processFilters (buffer, p); processDynamics (buffer, p); processEQ (buffer, p); break;
        case 2: // DYN -> FILTER -> EQ
            processDynamics (buffer, p); processFilters (buffer, p); processEQ (buffer, p); break;
        default: // FILTER -> EQ -> DYN
            processFilters (buffer, p); processEQ (buffer, p); processDynamics (buffer, p); break;
    }

    // TODO: a future sidechain-routing revision can feed HPF/LPF into the shared
    // dynamics detector without changing the main audio routing.
    processOutputStage (buffer, p);

    if (p.channelMode == 1 && channels == 2)
        decodeMidSide (buffer);

    mixSmoother.setTargetValue (juce::jlimit (0.0f, 1.0f, p.mix));
    for (int i = 0; i < samples; ++i)
    {
        const float mix = mixSmoother.getNextValue();
        if (mix >= 0.999999f)
            continue;

        const float dryGain = 1.0f - mix;
        for (int ch = 0; ch < channels; ++ch)
        {
            const float dry = globalDryBuffer.getSample (ch, i);
            const float wet = buffer.getSample (ch, i);
            buffer.setSample (ch, i, dry * dryGain + wet * mix);
        }
    }

    // MUTE is deliberately last so no dry/wet setting can leak signal around it.
    if (p.mute)
        buffer.clear();

    outputPeakDb.store (bufferPeakDb (buffer));
}
