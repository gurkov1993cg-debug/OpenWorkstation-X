#include "PluginEditor.h"
#include <cmath>

namespace ColoursX
{
    const juce::Colour bg       { 0xff080a0b };
    const juce::Colour top      { 0xff0d1012 };
    const juce::Colour panel    { 0xff171a1c };
    const juce::Colour panelHi  { 0xff24282b };
    const juce::Colour border   { 0xff4b5053 };
    const juce::Colour text     { 0xffe3ded4 };
    const juce::Colour muted    { 0xff9ba0a2 };
    const juce::Colour gold     { 0xffd69832 };
    const juce::Colour red      { 0xffc3342d };
    const juce::Colour orange   { 0xffdd7b21 };
    const juce::Colour green    { 0xff138146 };
    const juce::Colour blue     { 0xff0e6fb3 };
    const juce::Colour purple   { 0xff2d3f91 };
    const juce::Colour silver   { 0xffa8a7a3 };
}

ConsoleLookAndFeel::ConsoleLookAndFeel()
{
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff121516));
    setColour (juce::PopupMenu::textColourId, ColoursX::text);
    setColour (juce::TextButton::textColourOffId, ColoursX::text);
    setColour (juce::TextButton::textColourOnId, ColoursX::text);
}

void ConsoleLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                            float pos, float start, float end, juce::Slider& slider)
{
    auto full = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (1.0f);
    const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);
    const auto label = slider.getName();
    const auto leftScale = slider.getProperties().getWithDefault ("leftScale", "").toString();
    const auto rightScale = slider.getProperties().getWithDefault ("rightScale", "").toString();

    auto labelArea = full.removeFromBottom (18.0f);
    auto knobZone = full.reduced (3.0f, 1.0f);
    const float d = juce::jmax (22.0f, juce::jmin (knobZone.getWidth(), knobZone.getHeight()) - 22.0f);
    auto knob = knobZone.withSizeKeepingCentre (d, d);
    const float radius = d * 0.5f;
    const auto c = knob.getCentre();
    const float angle = start + pos * (end - start);

    g.setColour (juce::Colours::black.withAlpha (0.55f));
    g.fillEllipse (knob.translated (2.0f, 4.0f).expanded (7.0f));
    juce::ColourGradient socket (juce::Colour (0xff020304), c.x, knob.getY() - 6.0f,
                                 juce::Colour (0xff15191b), c.x, knob.getBottom() + 8.0f, false);
    g.setGradientFill (socket);
    g.fillEllipse (knob.expanded (7.0f));
    g.setColour (juce::Colour (0xff666b6f).withAlpha (0.55f));
    g.drawEllipse (knob.expanded (6.0f), 1.0f);

    for (int i = 0; i <= 10; ++i)
    {
        const float a = start + (end - start) * (float) i / 10.0f;
        const float ro = radius + 12.0f;
        const float ri = radius + (i == 0 || i == 5 || i == 10 ? 7.5f : 9.0f);
        const float dotR = (i == 0 || i == 5 || i == 10) ? 1.8f : 1.25f;
        const float px = c.x + std::sin (a) * ro;
        const float py = c.y - std::cos (a) * ro;
        g.setColour (juce::Colours::white.withAlpha (i == 0 || i == 5 || i == 10 ? 0.95f : 0.72f));
        g.fillEllipse (px - dotR, py - dotR, dotR * 2.0f, dotR * 2.0f);
        if (i == 0 || i == 10)
        {
            g.setColour (juce::Colours::white.withAlpha (0.42f));
            g.drawLine (c.x + std::sin (a) * ri, c.y - std::cos (a) * ri,
                        c.x + std::sin (a) * (ro - 2.0f), c.y - std::cos (a) * (ro - 2.0f), 0.8f);
        }
    }

    juce::ColourGradient rim (juce::Colour (0xffc4c6c6), knob.getX(), knob.getY(),
                              juce::Colour (0xff333638), knob.getRight(), knob.getBottom(), false);
    g.setGradientFill (rim);
    g.fillEllipse (knob);
    g.setColour (juce::Colour (0xff0c0d0e));
    g.drawEllipse (knob, 1.4f);

    auto cap = knob.reduced (5.5f);
    const bool neutral = accent == ColoursX::silver || accent.getSaturation() < 0.08f;
    const juce::Colour capTop = neutral ? juce::Colour (0xffaeb0b0) : accent.brighter (0.26f);
    const juce::Colour capBottom = neutral ? juce::Colour (0xff4c4f50) : accent.darker (0.56f);
    juce::ColourGradient capGrad (capTop, cap.getX() + cap.getWidth() * 0.22f, cap.getY(),
                                  capBottom, cap.getRight(), cap.getBottom(), false);
    g.setGradientFill (capGrad);
    g.fillEllipse (cap);

    g.setColour (juce::Colours::black.withAlpha (0.14f));
    for (int i = 0; i < 18; ++i)
    {
        const float a = juce::MathConstants<float>::twoPi * (float) i / 18.0f;
        const float r1 = radius * 0.70f;
        const float r2 = radius * 0.84f;
        g.drawLine (c.x + std::sin (a) * r1, c.y - std::cos (a) * r1,
                    c.x + std::sin (a) * r2, c.y - std::cos (a) * r2, 0.65f);
    }

    g.setColour (juce::Colours::white.withAlpha (0.14f));
    g.drawEllipse (cap.reduced (1.5f), 1.2f);

    juce::Path pointer;
    pointer.startNewSubPath (0.0f, -radius * 0.18f);
    pointer.lineTo (0.0f, -radius * 0.73f);
    g.setColour (juce::Colours::white.withAlpha (0.96f));
    g.strokePath (pointer, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded),
                  juce::AffineTransform::rotation (angle).translated (c.x, c.y));

    g.setFont (juce::Font (10.0f, juce::Font::plain));
    g.setColour (ColoursX::text.withAlpha (0.92f));
    const int scaleY = (int) (knob.getBottom() - 3.0f);
    g.drawText (leftScale, (int) knobZone.getX(), scaleY, (int) knobZone.getWidth() / 2, 15,
                juce::Justification::centredLeft);
    g.drawText (rightScale, (int) knobZone.getCentreX(), scaleY, (int) knobZone.getWidth() / 2, 15,
                juce::Justification::centredRight);

    g.setColour (ColoursX::text);
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    g.drawText (label, labelArea.toNearestInt(), juce::Justification::centred);
}

void ConsoleLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool hi, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.0f);
    const auto accent = b.findColour (juce::ToggleButton::tickColourId);
    const float lampSide = juce::jmin (29.0f, r.getHeight() - 2.0f);
    auto lamp = juce::Rectangle<float> (r.getX() + 2.0f, r.getCentreY() - lampSide * 0.5f,
                                        lampSide, lampSide);
    auto textArea = r.withTrimmedLeft (lampSide + 10.0f);

    g.setColour (juce::Colours::black.withAlpha (0.72f));
    g.fillRoundedRectangle (lamp.expanded (3.0f).translated (1.5f, 2.0f), 3.0f);
    juce::ColourGradient bezel (juce::Colour (0xff5f6263), lamp.getX(), lamp.getY(),
                                juce::Colour (0xff121415), lamp.getRight(), lamp.getBottom(), false);
    g.setGradientFill (bezel);
    g.fillRoundedRectangle (lamp.expanded (2.0f), 2.5f);
    g.setColour (juce::Colour (0xff030404));
    g.fillRoundedRectangle (lamp, 1.8f);

    if (b.getToggleState())
    {
        g.setColour (accent.withAlpha (0.17f));
        g.fillRoundedRectangle (lamp.expanded (8.0f), 6.0f);
        g.setColour (accent.withAlpha (0.35f));
        g.fillRoundedRectangle (lamp.expanded (4.0f), 4.0f);
        juce::ColourGradient glow (juce::Colour (0xfffff0b8), lamp.getCentreX(), lamp.getY() + 2.0f,
                                   accent.darker (0.12f), lamp.getCentreX(), lamp.getBottom(), false);
        g.setGradientFill (glow);
        g.fillRoundedRectangle (lamp.reduced (3.0f), 1.5f);
        g.setColour (juce::Colour (0xffffe3a0));
        g.drawRoundedRectangle (lamp.reduced (2.0f), 1.5f, 1.0f);
    }
    else
    {
        juce::ColourGradient off (juce::Colour (0xff55595b), lamp.getX(), lamp.getY(),
                                  juce::Colour (0xff202224), lamp.getRight(), lamp.getBottom(), false);
        g.setGradientFill (off);
        g.fillRoundedRectangle (lamp.reduced (3.0f), 1.5f);
        g.setColour (juce::Colour (0xff7a7e80).withAlpha (0.52f));
        g.drawRoundedRectangle (lamp.reduced (2.0f), 1.5f, 0.9f);
    }

    g.setColour (down ? ColoursX::text.darker (0.18f)
                      : (hi ? ColoursX::text.brighter (0.08f) : ColoursX::text));
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    g.drawText (b.getButtonText(), textArea.toNearestInt(), juce::Justification::centredLeft);
}

void ConsoleLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&, bool hi, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.0f);
    const bool on = b.getToggleState();

    g.setColour (juce::Colours::black.withAlpha (0.65f));
    g.fillRoundedRectangle (r.translated (1.0f, 2.0f), 3.0f);

    const juce::Colour top = on ? juce::Colour (0xff75401f) : juce::Colour (0xff25282a);
    const juce::Colour bottom = on ? juce::Colour (0xff24140d) : juce::Colour (0xff0b0d0e);
    juce::ColourGradient grad (hi ? top.brighter (0.08f) : top, r.getX(), r.getY(),
                               down ? bottom.darker (0.14f) : bottom, r.getX(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r, 3.0f);

    g.setColour (on ? ColoursX::orange.brighter (0.18f) : juce::Colour (0xff62676a));
    g.drawRoundedRectangle (r, 3.0f, on ? 1.35f : 0.9f);
    g.setColour (juce::Colours::white.withAlpha (on ? 0.12f : 0.05f));
    g.drawHorizontalLine ((int) r.getY() + 2, r.getX() + 3.0f, r.getRight() - 3.0f);

    if (on)
    {
        g.setColour (ColoursX::orange.withAlpha (0.11f));
        g.fillRoundedRectangle (r.expanded (3.0f), 5.0f);
    }
}

void ConsoleLookAndFeel::drawButtonText (juce::Graphics& g, juce::TextButton& b, bool, bool)
{
    const auto id = b.getName();
    auto r = b.getLocalBounds().toFloat().reduced (5.0f);
    g.setColour (ColoursX::text);

    if (id == "ui_power")
    {
        const auto c = r.getCentre();
        const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.27f;
        g.drawEllipse ({ c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f }, 2.2f);
        g.drawLine (c.x, c.y - rad - 2.0f, c.x, c.y + 1.0f, 2.6f);
        return;
    }
    if (id == "ui_undo" || id == "ui_redo")
    {
        const bool redo = id == "ui_redo";
        juce::Path p;
        const float cy = r.getCentreY();
        if (! redo)
        {
            p.startNewSubPath (r.getRight() - 5.0f, cy + 7.0f);
            p.cubicTo (r.getCentreX() + 7.0f, cy - 10.0f, r.getX() + 8.0f, cy - 8.0f, r.getX() + 7.0f, cy + 2.0f);
            p.startNewSubPath (r.getX() + 7.0f, cy + 2.0f); p.lineTo (r.getX() + 2.0f, cy - 3.0f); p.lineTo (r.getX() + 9.0f, cy - 5.0f);
        }
        else
        {
            p.startNewSubPath (r.getX() + 5.0f, cy + 7.0f);
            p.cubicTo (r.getCentreX() - 7.0f, cy - 10.0f, r.getRight() - 8.0f, cy - 8.0f, r.getRight() - 7.0f, cy + 2.0f);
            p.startNewSubPath (r.getRight() - 7.0f, cy + 2.0f); p.lineTo (r.getRight() - 2.0f, cy - 3.0f); p.lineTo (r.getRight() - 9.0f, cy - 5.0f);
        }
        g.strokePath (p, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }

    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (b.getButtonText(), r.toNearestInt(), juce::Justification::centred);
    if (id == "ui_init")
    {
        juce::Path a;
        const float cx = r.getRight() - 10.0f, cy = r.getCentreY();
        a.startNewSubPath (cx - 4.0f, cy - 2.0f); a.lineTo (cx, cy + 2.0f); a.lineTo (cx + 4.0f, cy - 2.0f);
        g.strokePath (a, juce::PathStrokeType (1.4f));
    }
}

TwoStateChoiceControl::TwoStateChoiceControl (juce::String id, juce::String a, juce::String b, bool firstMapsToOne)
    : first (std::move (a)), second (std::move (b)), reverse (firstMapsToOne)
{
    setComponentID (std::move (id));
    first.setClickingTogglesState (false);
    second.setClickingTogglesState (false);
    first.onClick = [this] { choose (0); };
    second.onClick = [this] { choose (1); };
    addAndMakeVisible (first);
    addAndMakeVisible (second);
}

void TwoStateChoiceControl::attach (juce::RangedAudioParameter* p) { parameter = p; syncFromParameter(); }
void TwoStateChoiceControl::choose (int index)
{
    if (parameter == nullptr) return;
    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost (reverse ? (index == 0 ? 1.0f : 0.0f) : (index == 0 ? 0.0f : 1.0f));
    parameter->endChangeGesture();
    syncFromParameter();
}
void TwoStateChoiceControl::syncFromParameter()
{
    if (parameter == nullptr) return;
    const bool valueOne = parameter->getValue() >= 0.5f;
    const bool firstOn = reverse ? valueOne : ! valueOne;
    first.setToggleState (firstOn, juce::dontSendNotification);
    second.setToggleState (! firstOn, juce::dontSendNotification);
}
void TwoStateChoiceControl::resized()
{
    auto r = getLocalBounds(); const int gap = 8; const int w = (r.getWidth() - gap) / 2;
    first.setBounds (r.removeFromLeft (w)); r.removeFromLeft (gap); second.setBounds (r);
}

CyclingChoiceControl::CyclingChoiceControl (juce::String id, juce::StringArray labels)
    : choices (std::move (labels))
{
    setComponentID (std::move (id));
    button.setClickingTogglesState (false);
    button.onClick = [this] { advance(); };
    addAndMakeVisible (button);
}

void CyclingChoiceControl::attach (juce::RangedAudioParameter* p)
{
    parameter = p;
    syncFromParameter();
}

void CyclingChoiceControl::advance()
{
    if (parameter == nullptr || choices.isEmpty())
        return;

    const int current = juce::jlimit (0, choices.size() - 1,
        (int) std::round (parameter->convertFrom0to1 (parameter->getValue())));
    const int next = (current + 1) % choices.size();
    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost (parameter->convertTo0to1 ((float) next));
    parameter->endChangeGesture();
    syncFromParameter();
}

void CyclingChoiceControl::advanceForTest() { advance(); }

void CyclingChoiceControl::syncFromParameter()
{
    if (parameter == nullptr || choices.isEmpty())
        return;

    const int index = juce::jlimit (0, choices.size() - 1,
        (int) std::round (parameter->convertFrom0to1 (parameter->getValue())));
    button.setButtonText (choices[index]);
}

void CyclingChoiceControl::resized()
{
    button.setBounds (getLocalBounds());
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&consoleLook);
    setOpaque (true);

    addKnob ("inputDrive", "INPUT DRIVE", ColoursX::silver, ValueStyle::drive, "-20", "+20");
    addKnob ("inputTrim", "INPUT", ColoursX::red, ValueStyle::dB, "-20", "+20");
    addButton ("polarity", "PHASE", ColoursX::gold);

    addButton ("hpOn", "HP IN", ColoursX::gold);
    addKnob ("hpFreq", "HPF", ColoursX::silver, ValueStyle::frequency, "16", "350");
    addButton ("lpOn", "LP IN", ColoursX::gold);
    addKnob ("lpFreq", "LPF", ColoursX::silver, ValueStyle::frequency, "3k", "22k");

    addButton ("eqOn", "EQ IN", ColoursX::gold);
    addButton ("hfBell", "BELL", ColoursX::red);
    addKnob ("hfGain", "HF", ColoursX::red, ValueStyle::dB, "-15", "+15");
    addKnob ("hfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "1.5k", "16k");
    addKnob ("hmfGain", "HMF", ColoursX::green, ValueStyle::dB, "-15", "+15");
    addKnob ("hmfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "0.6k", "7k");
    addKnob ("hmfQ", "Q", ColoursX::green.darker (0.2f), ValueStyle::q, "0.4", "4");
    addKnob ("lmfGain", "LMF", ColoursX::blue, ValueStyle::dB, "-15", "+15");
    addKnob ("lmfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "0.2k", "2.5k");
    addKnob ("lmfQ", "Q", ColoursX::blue.darker (0.2f), ValueStyle::q, "0.4", "4");
    addButton ("lfBell", "BELL", ColoursX::blue);
    addKnob ("lfGain", "LF", ColoursX::blue, ValueStyle::dB, "-15", "+15");
    addKnob ("lfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "30", "450");

    addButton ("dynOn", "DYN IN", ColoursX::gold);
    addButton ("compOn", "COMP", ColoursX::gold);
    addButton ("compFast", "FAST ATTACK", ColoursX::gold);
    addButton ("compPeak", "PEAK", ColoursX::gold);
    addKnob ("compThreshold", "THRESHOLD", ColoursX::red, ValueStyle::dB, "-20", "+10");
    addKnob ("compRatio", "RATIO", ColoursX::silver, ValueStyle::ratio, "1:1", "INF");
    addKnob ("compAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs, "0.1", "100");
    addKnob ("compRelease", "RELEASE", ColoursX::silver, ValueStyle::release, "0.1", "4.0");

    addButton ("gateOn", "GATE", ColoursX::gold);
    addButton ("gateExpand", "EXPAND", ColoursX::purple);
    addButton ("gateFast", "FAST ATTACK", ColoursX::gold);
    addKnob ("gateRange", "RANGE", ColoursX::purple, ValueStyle::dB, "0", "40");
    addKnob ("gateThreshold", "THRESHOLD", ColoursX::silver, ValueStyle::dB, "-30", "+10");
    addKnob ("gateHold", "HOLD", juce::Colour (0xff1b1d1f), ValueStyle::hold, "0", "4.0");
    addKnob ("gateAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs, "0.05", "50");
    addKnob ("gateRelease", "RELEASE", ColoursX::silver, ValueStyle::release, "0.1", "4.0");

    addKnob ("vcaFader", "OUTPUT", ColoursX::silver, ValueStyle::dB, "-20", "+10");
    addKnob ("outputTrim", "OUTPUT TRIM", ColoursX::silver, ValueStyle::dB, "-20", "+20");
    addKnob ("mix", "MIX", ColoursX::silver, ValueStyle::percent, "0", "100");
    addButton ("mute", "MUTE", ColoursX::red);
    addButton ("bypass", "BYPASS", ColoursX::gold);

    inputModeControl.attach (audioProcessor.parameters().getParameter ("inputMode"));
    eqModelControl.attach (audioProcessor.parameters().getParameter ("eqModel"));
    channelModeControl.attach (audioProcessor.parameters().getParameter ("channelMode"));
    routingControl.attach (audioProcessor.parameters().getParameter ("routing"));
    addAndMakeVisible (inputModeControl);
    addAndMakeVisible (eqModelControl);
    addAndMakeVisible (channelModeControl);
    addAndMakeVisible (routingControl);

    // Utility controls deliberately have no componentID: the GUI audit reserves
    // component IDs for the one-to-one APVTS control map.
    powerButton.setName ("ui_power");
    undoButton.setName ("ui_undo");
    redoButton.setName ("ui_redo");
    initButton.setName ("ui_init");
    powerButton.setClickingTogglesState (true);
    powerButton.onClick = [this]
    {
        if (auto* pBypass = audioProcessor.parameters().getParameter ("bypass"))
        {
            pBypass->beginChangeGesture();
            pBypass->setValueNotifyingHost (powerButton.getToggleState() ? 0.0f : 1.0f);
            pBypass->endChangeGesture();
        }
    };
    undoButton.onClick = [this] { audioProcessor.undo(); };
    redoButton.onClick = [this] { audioProcessor.redo(); };
    initButton.onClick = [this] { resetToInit(); };
    addAndMakeVisible (powerButton); addAndMakeVisible (undoButton); addAndMakeVisible (redoButton); addAndMakeVisible (initButton);

    setResizable (false, false);
    // setSize() invokes resized() after every interactive component already exists.
    // That single resized() builds the cached static layer once; do not rebuild it
    // again here, which was adding unnecessary editor-open latency.
    setSize (1536, 942);
    syncUtilityControls();
    startTimerHz (15);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer(); setLookAndFeel (nullptr);
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double v, ValueStyle s)
{
    switch (s)
    {
        case ValueStyle::dB:        return juce::String (v, 1) + " dB";
        case ValueStyle::drive:     return juce::String (v > 0.0 ? "+" : "") + juce::String (v, 1) + " dB";
        case ValueStyle::frequency: return v >= 1000.0 ? juce::String (v / 1000.0, v >= 10000.0 ? 1 : 2) + " kHz" : juce::String (v, 0) + " Hz";
        case ValueStyle::q:         return juce::String (v, 2);
        case ValueStyle::ratio:     return v >= 19.95 ? juce::String ("INF:1") : juce::String (v, 1) + ":1";
        case ValueStyle::attackMs:  return v < 1.0 ? juce::String (v, 2) + " ms" : juce::String (v, 1) + " ms";
        case ValueStyle::release:   return v < 1.0 ? juce::String (v * 1000.0, 0) + " ms" : juce::String (v, 2) + " s";
        case ValueStyle::percent:   return juce::String (v, 0) + "%";
        case ValueStyle::hold:      return juce::String (v, 2) + " s";
        case ValueStyle::plain:     return juce::String (v, 2);
    }
    return {};
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label,
                                                         juce::Colour accent, ValueStyle style,
                                                         const juce::String& leftScale, const juce::String& rightScale)
{
    auto s = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::NoTextBox);
    s->setName (label); s->setComponentID (id);
    s->setColour (juce::Slider::rotarySliderFillColourId, accent);
    s->getProperties().set ("leftScale", leftScale); s->getProperties().set ("rightScale", rightScale);
    s->setPopupDisplayEnabled (true, false, this);
    addAndMakeVisible (*s);
    sliderAttachments.push_back (std::make_unique<SliderAttachment> (audioProcessor.parameters(), id, *s));
    // SliderParameterAttachment can install its own text conversion; put our
    // engineering-unit formatter back afterwards so popup values are readable.
    s->textFromValueFunction = [style] (double v) { return formatValue (v, style); };
    s->updateText();
    knobs[id] = std::move (s);
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const juce::String& id, const juce::String& label, juce::Colour accent)
{
    auto b = std::make_unique<juce::ToggleButton> (label);
    b->setComponentID (id); b->setColour (juce::ToggleButton::tickColourId, accent); b->setClickingTogglesState (true);
    addAndMakeVisible (*b);
    buttonAttachments.push_back (std::make_unique<ButtonAttachment> (audioProcessor.parameters(), id, *b));
    buttons[id] = std::move (b);
}

void ConsoleChannelStripXAudioProcessorEditor::drawScrew (juce::Graphics& g, float x, float y, float angle)
{
    g.setColour (juce::Colour (0xff07090a));
    g.fillEllipse (x - 6.0f, y - 6.0f, 12.0f, 12.0f);
    g.setColour (juce::Colour (0xff73787b));
    g.drawEllipse (x - 5.0f, y - 5.0f, 10.0f, 10.0f, 1.0f);

    juce::Path slot;
    slot.startNewSubPath (-3.2f, 0.0f);
    slot.lineTo (3.2f, 0.0f);
    slot.startNewSubPath (0.0f, -3.2f);
    slot.lineTo (0.0f, 3.2f);
    g.setColour (juce::Colour (0xff282b2d));
    g.strokePath (slot, juce::PathStrokeType (1.1f), juce::AffineTransform::rotation (angle).translated (x, y));
}

void ConsoleChannelStripXAudioProcessorEditor::drawHardwarePanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    auto rf = r.toFloat();

    g.setColour (juce::Colours::black.withAlpha (0.75f));
    g.fillRoundedRectangle (rf.translated (2.0f, 3.0f), 5.0f);

    juce::ColourGradient grad (juce::Colour (0xff20272a), rf.getX(), rf.getY(),
                               juce::Colour (0xff0d1113), rf.getRight(), rf.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (rf, 5.0f);

    g.saveState();
    g.reduceClipRegion (r.reduced (3));
    for (int y = r.getY() + 5; y < r.getBottom() - 4; y += 5)
    {
        for (int x = r.getX() + 5; x < r.getRight() - 4; x += 5)
        {
            const unsigned hash = (unsigned) (x * 73856093u) ^ (unsigned) (y * 19349663u);
            const float a = 0.014f + 0.022f * (float) (hash & 7u) / 7.0f;
            g.setColour (((hash >> 3) & 1u) != 0u
                         ? juce::Colours::white.withAlpha (a)
                         : juce::Colours::black.withAlpha (a * 1.6f));
            g.fillRect (x, y, 1 + (int) ((hash >> 6) & 1u), 1);
        }
    }
    g.restoreState();

    g.setColour (juce::Colours::white.withAlpha (0.10f));
    g.drawRoundedRectangle (rf.reduced (1.0f), 5.0f, 1.0f);
    g.setColour (juce::Colours::black.withAlpha (0.88f));
    g.drawRoundedRectangle (rf, 5.0f, 1.6f);
    g.setColour (juce::Colour (0xff4a5053).withAlpha (0.55f));
    g.drawRoundedRectangle (rf.reduced (3.0f), 4.0f, 0.8f);

    drawScrew (g, (float) r.getX() + 24.0f, (float) r.getY() + 28.0f, 0.4f);
    drawScrew (g, (float) r.getRight() - 24.0f, (float) r.getY() + 28.0f, -0.7f);
    drawScrew (g, (float) r.getX() + 24.0f, (float) r.getBottom() - 28.0f, 0.8f);
    drawScrew (g, (float) r.getRight() - 24.0f, (float) r.getBottom() - 28.0f, -0.3f);

    if (title.isNotEmpty())
    {
        g.setColour (ColoursX::text);
        g.setFont (juce::Font (18.0f, juce::Font::plain));
        g.drawText (title, r.getX() + 46, r.getY() + 12, r.getWidth() - 92, 28,
                    juce::Justification::centredLeft);
        g.setColour (juce::Colours::white.withAlpha (0.10f));
        g.drawHorizontalLine (r.getY() + 47, (float) r.getX() + 36.0f, (float) r.getRight() - 36.0f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawLedColumn (juce::Graphics& g, juce::Rectangle<int> r, float db, bool outputStyle)
{
    static const float inputMarksDbfs[] = { 0.0f, -6.0f, -12.0f, -18.0f, -24.0f, -30.0f, -36.0f };
    static const char* inputLabels[] = { "+18", "+12", "+6", "0", "-6", "-12", "-18" };
    static const float outputMarksDbfs[] = { 0.0f, -3.0f, -6.0f, -12.0f, -18.0f, -24.0f };
    static const char* outputLabels[] = { "PK", "-3", "-6", "-12", "-18", "-24" };

    const int count = outputStyle ? 6 : 7;
    const int step = r.getHeight() / count;
    for (int i = 0; i < count; ++i)
    {
        const float mark = outputStyle ? outputMarksDbfs[i] : inputMarksDbfs[i];
        const char* label = outputStyle ? outputLabels[i] : inputLabels[i];
        const int cy = r.getY() + i * step + step / 2;

        juce::Colour c;
        if (i < 2)      c = juce::Colour (0xffe63329);
        else if (i < 4) c = juce::Colour (0xffffd21e);
        else            c = juce::Colour (0xff4caf50);

        const bool lit = db >= mark;
        g.setColour (lit ? c.withAlpha (0.22f) : c.withAlpha (0.06f));
        g.fillEllipse ((float) r.getX() - 3.0f, (float) cy - 8.0f, 16.0f, 16.0f);
        g.setColour (lit ? c : c.withAlpha (0.13f));
        g.fillEllipse ((float) r.getX(), (float) cy - 5.0f, 10.0f, 10.0f);
        g.setColour (juce::Colours::white.withAlpha (lit ? 0.50f : 0.10f));
        g.drawEllipse ((float) r.getX(), (float) cy - 5.0f, 10.0f, 10.0f, 0.8f);

        g.setColour (ColoursX::text.withAlpha (0.92f));
        g.setFont (juce::Font (10.5f, juce::Font::bold));
        g.drawText (label, r.getX() + 17, cy - 8, 48, 16, juce::Justification::centredLeft);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawMainMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                               float db, float peakHoldDb, bool scaleOnLeft)
{
    g.setColour (juce::Colour (0xff030506));
    g.fillRoundedRectangle (r.toFloat(), 3.0f);
    g.setColour (juce::Colour (0xff25292c));
    g.drawRoundedRectangle (r.toFloat(), 3.0f, 1.0f);

    constexpr int segments = 28;
    const int gap = 3;
    const int pad = 6;
    const int segH = juce::jmax (4, (r.getHeight() - 2 * pad - (segments - 1) * gap) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
    const int lit = (int) std::round (norm * segments);

    for (int i = 0; i < segments; ++i)
    {
        const float p = (float) i / (float) (segments - 1);
        juce::Colour c = p > 0.86f ? juce::Colour (0xffff3b20)
                         : (p > 0.52f ? juce::Colour (0xffffb52b) : juce::Colour (0xff62c54a));
        const int yy = r.getBottom() - pad - (i + 1) * segH - i * gap;
        const auto seg = juce::Rectangle<int> (r.getX() + 9, yy, r.getWidth() - 18, segH);
        g.setColour (i < lit ? c : c.withAlpha (0.12f));
        g.fillRect (seg);
    }

    const float holdNorm = juce::jlimit (0.0f, 1.0f, (peakHoldDb + 60.0f) / 60.0f);
    const int holdY = r.getBottom() - pad - (int) std::round (holdNorm * (r.getHeight() - 2 * pad));
    g.setColour (juce::Colour (0xffff9d2e).withAlpha (0.92f));
    g.fillRect (r.getX() + 5, holdY, r.getWidth() - 10, 2);

    static const int marks[] = { 0, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60 };
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.setColour (juce::Colour (0xffffa726));
    for (const int mark : marks)
    {
        const float t = (float) mark / 60.0f;
        const int y = r.getY() + (int) std::round (t * r.getHeight()) - 7;
        const int x = scaleOnLeft ? r.getX() - 28 : r.getRight() + 4;
        g.drawText (juce::String (mark), x, y, 24, 14,
                    scaleOnLeft ? juce::Justification::centredRight : juce::Justification::centredLeft);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawGRMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                             float reduction, const juce::String& title)
{
    constexpr float maxReductionDb = 24.0f;
    constexpr int segments = 13;
    const int gap = 2;
    const int pad = 5;
    const int segH = juce::jmax (4, (r.getHeight() - 2 * pad - (segments - 1) * gap) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, reduction / maxReductionDb);
    const int lit = (int) std::round (norm * segments);

    g.setColour (juce::Colours::black.withAlpha (0.72f));
    g.fillRoundedRectangle (r.toFloat().expanded (4.0f).translated (1.0f, 2.0f), 3.0f);
    juce::ColourGradient well (juce::Colour (0xff111618), (float) r.getX(), (float) r.getY(),
                               juce::Colour (0xff020303), (float) r.getRight(), (float) r.getBottom(), false);
    g.setGradientFill (well);
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    g.setColour (juce::Colour (0xff565b5e).withAlpha (0.48f));
    g.drawRoundedRectangle (r.toFloat(), 2.0f, 0.8f);

    for (int i = 0; i < segments; ++i)
    {
        const float p = (float) i / (float) (segments - 1);
        const juce::Colour c = p < 0.28f ? juce::Colour (0xffef4b20)
                               : (p < 0.58f ? juce::Colour (0xffffad20)
                                            : juce::Colour (0xff56b83f));
        const int yy = r.getY() + pad + i * (segH + gap);
        const auto seg = juce::Rectangle<int> (r.getX() + 4, yy, r.getWidth() - 8, segH);
        g.setColour (i < lit ? c : c.withAlpha (0.12f));
        g.fillRect (seg);
        if (i < lit)
        {
            g.setColour (c.withAlpha (0.15f));
            g.fillRect (seg.expanded (2, 1));
        }
    }

    g.setFont (juce::Font (9.0f, juce::Font::plain));
    g.setColour (ColoursX::text.withAlpha (0.88f));
    for (int mark = 0; mark <= 24; mark += 4)
    {
        const float t = (float) mark / maxReductionDb;
        const int y = r.getY() + (int) std::round (t * (float) r.getHeight()) - 6;
        g.drawText (mark == 0 ? "0" : "-" + juce::String (mark),
                    r.getRight() + 5, y, 22, 12, juce::Justification::centredLeft);
    }

    g.setColour (ColoursX::orange);
    g.setFont (juce::Font (10.0f, juce::Font::bold));
    g.drawText (title, r.getX() - 10, r.getY() - 22, r.getWidth() + 48, 16,
                juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawSevenSegmentNumber (juce::Graphics& g,
                                                                        juce::Rectangle<int> r,
                                                                        int value)
{
    value = juce::jlimit (0, 999, value);
    const juce::String digits = juce::String (value).paddedLeft ('0', 3);
    static constexpr int map[10] =
    {
        0b1111110, 0b0110000, 0b1101101, 0b1111001, 0b0110011,
        0b1011011, 0b1011111, 0b1110000, 0b1111111, 0b1111011
    };

    const int gap = 5;
    const int digitW = (r.getWidth() - 2 * gap) / 3;
    for (int d = 0; d < 3; ++d)
    {
        const int n = digits.substring (d, d + 1).getIntValue();
        const int bits = map[n];
        auto dr = juce::Rectangle<int> (r.getX() + d * (digitW + gap), r.getY(), digitW, r.getHeight()).toFloat();
        const float t = juce::jmax (3.0f, dr.getWidth() * 0.12f);
        const auto on = juce::Colour (0xffff2c2c);
        const auto off = juce::Colour (0xff351010);

        auto hseg = [&] (float y) { return juce::Rectangle<float> (dr.getX() + t, y, dr.getWidth() - 2 * t, t); };
        auto vsegL = [&] (float y) { return juce::Rectangle<float> (dr.getX(), y, t, dr.getHeight() * 0.34f); };
        auto vsegR = [&] (float y) { return juce::Rectangle<float> (dr.getRight() - t, y, t, dr.getHeight() * 0.34f); };
        const float top = dr.getY();
        const float mid = dr.getCentreY() - t * 0.5f;
        const float bottom = dr.getBottom() - t;
        const float upperY = dr.getY() + t;
        const float lowerY = dr.getCentreY() + t * 0.25f;

        const juce::Rectangle<float> segs[] =
        {
            hseg (top), vsegR (upperY), vsegR (lowerY), hseg (bottom),
            vsegL (lowerY), vsegL (upperY), hseg (mid)
        };

        for (int s = 0; s < 7; ++s)
        {
            const bool lit = (bits & (1 << (6 - s))) != 0;
            g.setColour (lit ? on.withAlpha (0.22f) : off.withAlpha (0.18f));
            g.fillRoundedRectangle (segs[s].expanded (2.0f), 2.0f);
            g.setColour (lit ? on : off);
            g.fillRoundedRectangle (segs[s], 1.5f);
        }
    }
}

void ConsoleChannelStripXAudioProcessorEditor::paintStatic (juce::Graphics& g)
{
    g.fillAll (ColoursX::bg);

    juce::ColourGradient topGrad (juce::Colour (0xff151b1f), 0.0f, 0.0f,
                                  juce::Colour (0xff050708), 0.0f, 64.0f, false);
    g.setGradientFill (topGrad);
    g.fillRect (0, 0, getWidth(), 64);
    g.setColour (juce::Colours::white.withAlpha (0.08f));
    g.drawHorizontalLine (1, 0.0f, (float) getWidth());
    g.setColour (juce::Colour (0xff343a3d));
    g.drawHorizontalLine (63, 0.0f, (float) getWidth());

    g.setColour (ColoursX::text);
    g.setFont (juce::Font (18.0f, juce::Font::plain));
    g.drawText ("Console Channel Strip X v0.2.8", 0, 8, getWidth(), 28, juce::Justification::centred);

    drawHardwarePanel (g, { 10, 70, 418, 858 }, "INPUT");
    drawHardwarePanel (g, { 435, 70, 360, 858 }, "DYNAMICS");
    drawHardwarePanel (g, { 803, 70, 380, 858 }, "");
    drawHardwarePanel (g, { 1191, 70, 335, 858 }, "OUTPUT");

    g.setColour (juce::Colours::white.withAlpha (0.10f));
    for (int y : { 325, 475, 520, 612, 704, 796, 888 })
        g.drawHorizontalLine (y, 42.0f, 396.0f);

    g.setColour (ColoursX::text.withAlpha (0.86f));
    g.setFont (juce::Font (13.0f, juce::Font::plain));
    g.drawText ("HPF", 48, 330, 60, 18, juce::Justification::centredLeft);
    g.drawText ("EQ", 48, 482, 40, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::red.brighter (0.22f)); g.drawText ("HF", 48, 528, 38, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::green.brighter (0.22f)); g.drawText ("HMF", 48, 620, 45, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue.brighter (0.25f)); g.drawText ("LMF", 48, 712, 45, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue.brighter (0.25f)); g.drawText ("LF", 48, 804, 38, 18, juce::Justification::centredLeft);

    g.setColour (juce::Colour (0xffffe2b0));
    g.setFont (juce::Font (14.0f, juce::Font::plain));
    g.drawText ("COMPRESSOR / LIMITER", 462, 112, 220, 20, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xff9faeea));
    g.drawText ("GATE / EXPANDER", 462, 455, 180, 20, juce::Justification::centredLeft);
    g.setColour (juce::Colours::white.withAlpha (0.10f));
    g.drawHorizontalLine (440, 460.0f, 770.0f);

    auto plateRect = juce::Rectangle<float> (816.0f, 80.0f, 354.0f, 80.0f);
    juce::ColourGradient plate (juce::Colour (0xffc0c2c2), plateRect.getX(), plateRect.getY(),
                                juce::Colour (0xff5d6264), plateRect.getX(), plateRect.getBottom(), false);
    g.setGradientFill (plate);
    g.fillRoundedRectangle (plateRect, 4.0f);
    g.setColour (juce::Colours::white.withAlpha (0.13f));
    for (int y = 84; y < 157; y += 3)
        g.drawHorizontalLine (y, 821.0f, 1165.0f);
    g.setColour (juce::Colours::black.withAlpha (0.76f));
    g.drawRoundedRectangle (plateRect, 4.0f, 1.2f);
    drawScrew (g, 824.0f, 88.0f, 0.3f);
    drawScrew (g, 1162.0f, 88.0f, -0.7f);
    drawScrew (g, 824.0f, 150.0f, 0.7f);
    drawScrew (g, 1162.0f, 150.0f, -0.2f);

    g.setColour (juce::Colour (0xff0c0d0e));
    g.setFont (juce::Font (28.0f, juce::Font::bold));
    g.drawText ("Channel Strip X", 850, 92, 285, 32, juce::Justification::centred);
    g.setFont (juce::Font (12.0f, juce::Font::plain));
    g.drawText ("CONSOLE CHANNEL STRIP", 850, 126, 285, 18, juce::Justification::centred);

    g.setColour (juce::Colours::black.withAlpha (0.70f));
    g.fillRoundedRectangle (juce::Rectangle<float> (818.0f, 166.0f, 350.0f, 576.0f).translated (2.0f, 3.0f), 3.0f);
    juce::ColourGradient bridge (juce::Colour (0xff101416), 820.0f, 168.0f,
                                 juce::Colour (0xff020304), 1166.0f, 740.0f, false);
    g.setGradientFill (bridge);
    g.fillRoundedRectangle (juce::Rectangle<float> (820.0f, 168.0f, 346.0f, 572.0f), 3.0f);
    g.setColour (juce::Colour (0xff464b4d).withAlpha (0.50f));
    g.drawRoundedRectangle (juce::Rectangle<float> (820.0f, 168.0f, 346.0f, 572.0f), 3.0f, 0.9f);

    g.setColour (ColoursX::orange.withAlpha (0.82f));
    g.fillRoundedRectangle (juce::Rectangle<float> (965.0f, 190.0f, 3.0f, 330.0f), 1.5f);
    g.fillRoundedRectangle (juce::Rectangle<float> (1017.0f, 190.0f, 3.0f, 330.0f), 1.5f);

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (10.5f, juce::Font::plain));
    g.drawText ("MIX", 842, 618, 72, 18, juce::Justification::centred);
    g.drawText ("ROUTING", 930, 618, 216, 18, juce::Justification::centredLeft);

    juce::ColourGradient lowerPlate (juce::Colour (0xff181c1e), 820.0f, 752.0f,
                                     juce::Colour (0xff050708), 1166.0f, 910.0f, false);
    g.setGradientFill (lowerPlate);
    g.fillRoundedRectangle (juce::Rectangle<float> (820.0f, 752.0f, 346.0f, 158.0f), 3.0f);
    g.setColour (juce::Colour (0xff565b5d).withAlpha (0.45f));
    g.drawRoundedRectangle (juce::Rectangle<float> (820.0f, 752.0f, 346.0f, 158.0f), 3.0f, 0.8f);
    drawScrew (g, 832.0f, 768.0f, 0.5f);
    drawScrew (g, 1154.0f, 768.0f, -0.6f);
    drawScrew (g, 832.0f, 894.0f, -0.2f);
    drawScrew (g, 1154.0f, 894.0f, 0.8f);

    g.setColour (ColoursX::text.withAlpha (0.80f));
    g.setFont (juce::Font (20.0f, juce::Font::plain));
    g.drawText ("OPENWORKSTATION X", 835, 793, 316, 28, juce::Justification::centred);
    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (13.0f, juce::Font::plain));
    g.drawText ("CONSOLE DSP", 835, 824, 316, 20, juce::Justification::centred);

    g.setColour (juce::Colours::white.withAlpha (0.10f));
    g.drawHorizontalLine (548, 1220.0f, 1498.0f);
    g.drawHorizontalLine (728, 1220.0f, 1498.0f);
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (14.0f, juce::Font::plain));
    g.drawText ("CHANNEL MODE", 1230, 575, 260, 20, juce::Justification::centred);
    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (12.0f, juce::Font::plain));
    g.drawText ("OPENWORKSTATION X", 1230, 790, 260, 18, juce::Justification::centred);
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    g.drawText ("CCS X v0.2.8", 1230, 814, 260, 18, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::rebuildStaticLayer()
{
    staticLayer = juce::Image (juce::Image::RGB, getWidth(), getHeight(), true);
    juce::Graphics g (staticLayer); paintStatic (g);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.drawImageAt (staticLayer, 0, 0);
    drawLedColumn (g, { 300, 105, 66, 180 }, audioProcessor.inputMeter(), false);
    drawMainMeter (g, { 885, 190, 64, 330 }, audioProcessor.inputMeter(), inputPeakHoldDb, true);
    drawMainMeter (g, { 1035, 190, 64, 330 }, audioProcessor.outputMeter(), outputPeakHoldDb, false);
    drawGRMeter (g, { 750, 190, 20, 200 }, compGrDisplayDb, "GR");
    drawGRMeter (g, { 750, 670, 20, 150 }, gateGrDisplayDb, "GATE GR");
    drawLedColumn (g, { 1430, 128, 70, 180 }, audioProcessor.outputMeter(), true);

    if (auto* mixValue = audioProcessor.parameters().getRawParameterValue ("mix"))
        drawSevenSegmentNumber (g, { 842, 640, 78, 42 }, (int) std::round (mixValue->load()));
}

void ConsoleChannelStripXAudioProcessorEditor::syncUtilityControls()
{
    inputModeControl.syncFromParameter(); eqModelControl.syncFromParameter(); channelModeControl.syncFromParameter(); routingControl.syncFromParameter();
    if (auto* p = audioProcessor.parameters().getParameter ("bypass"))
        powerButton.setToggleState (p->getValue() < 0.5f, juce::dontSendNotification);
}

void ConsoleChannelStripXAudioProcessorEditor::resetToInit()
{
    audioProcessor.resetParametersToDefaults();
    syncUtilityControls();
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    syncUtilityControls();

    constexpr float fallPerTickDb = 12.0f / 15.0f;
    const float in = audioProcessor.inputMeter();
    const float out = audioProcessor.outputMeter();
    inputPeakHoldDb = in >= inputPeakHoldDb ? in : juce::jmax (-60.0f, inputPeakHoldDb - fallPerTickDb);
    outputPeakHoldDb = out >= outputPeakHoldDb ? out : juce::jmax (-60.0f, outputPeakHoldDb - fallPerTickDb);

    auto followReduction = [] (float current, float target)
    {
        target = juce::jlimit (0.0f, 24.0f, target);
        const float coeff = target > current ? 0.62f : 0.16f;
        const float next = current + (target - current) * coeff;
        return std::abs (next - target) < 0.02f ? target : next;
    };

    compGrDisplayDb = followReduction (compGrDisplayDb, audioProcessor.compressorMeter());
    gateGrDisplayDb = followReduction (gateGrDisplayDb, audioProcessor.gateMeter());

    repaint (290, 95, 85, 205);
    repaint (700, 160, 470, 675);
    repaint (1420, 115, 95, 205);
    repaint (835, 610, 315, 90);
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = knobs.find (id); it != knobs.end()) it->second->setBounds (x, y, w, h);
}
void ConsoleChannelStripXAudioProcessorEditor::placeButton (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = buttons.find (id); it != buttons.end()) it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    powerButton.setBounds (16, 13, 46, 38); undoButton.setBounds (74, 13, 36, 38); redoButton.setBounds (112, 13, 36, 38); initButton.setBounds (166, 13, 230, 38);

    // INPUT / FILTERS / EQ
    placeKnob ("inputDrive", 58, 105, 155, 155);
    inputModeControl.setBounds (72, 274, 206, 36); placeButton ("polarity", 316, 276, 86, 32);
    placeButton ("hpOn", 72, 334, 88, 28); placeButton ("lpOn", 236, 334, 88, 28);
    placeKnob ("hpFreq", 56, 368, 126, 96); placeKnob ("lpFreq", 220, 368, 126, 96);
    eqModelControl.setBounds (214, 482, 178, 32);

    placeKnob ("hfGain", 76, 530, 88, 78); placeKnob ("hfFreq", 178, 530, 88, 78); placeButton ("hfBell", 298, 550, 88, 28);
    placeKnob ("hmfGain", 66, 622, 82, 78); placeKnob ("hmfFreq", 158, 622, 82, 78); placeKnob ("hmfQ", 250, 622, 82, 78);
    placeKnob ("lmfGain", 66, 714, 82, 78); placeKnob ("lmfFreq", 158, 714, 82, 78); placeKnob ("lmfQ", 250, 714, 82, 78);
    placeKnob ("lfGain", 76, 806, 88, 78); placeKnob ("lfFreq", 178, 806, 88, 78); placeButton ("lfBell", 298, 826, 88, 28);
    placeButton ("eqOn", 88, 890, 116, 30);

    // DYNAMICS
    placeButton ("dynOn", 680, 86, 92, 30); placeButton ("compOn", 462, 132, 92, 28);
    placeKnob ("compThreshold", 455, 165, 118, 118); placeButton ("compFast", 610, 166, 150, 30); placeButton ("compPeak", 610, 210, 110, 30);
    placeKnob ("compRatio", 455, 290, 94, 104); placeKnob ("compAttack", 555, 290, 94, 104); placeKnob ("compRelease", 655, 290, 94, 104);

    placeKnob ("gateRange", 455, 485, 94, 104); placeKnob ("gateThreshold", 555, 485, 94, 104); placeKnob ("gateHold", 655, 485, 94, 104);
    placeButton ("gateOn", 464, 600, 88, 30); placeButton ("gateExpand", 562, 600, 92, 30); placeButton ("gateFast", 664, 600, 108, 30);
    placeKnob ("gateAttack", 495, 650, 108, 112); placeKnob ("gateRelease", 620, 650, 108, 112);

    // CENTRE
    placeKnob ("inputTrim", 835, 520, 126, 112); placeKnob ("vcaFader", 1025, 520, 126, 112);
    routingControl.setBounds (930, 646, 216, 38);

    // OUTPUT
    placeKnob ("outputTrim", 1234, 120, 150, 150); placeKnob ("mix", 1234, 330, 150, 150);
    placeButton ("mute", 1405, 366, 96, 34); placeButton ("bypass", 1405, 454, 96, 34);
    channelModeControl.setBounds (1246, 615, 244, 48);

    if (staticLayer.isNull() || staticLayer.getWidth() != getWidth() || staticLayer.getHeight() != getHeight()) rebuildStaticLayer();
}
