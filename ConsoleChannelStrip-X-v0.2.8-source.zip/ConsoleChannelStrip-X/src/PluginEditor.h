#pragma once
#include <JuceHeader.h>
#include <map>
#include <memory>
#include "PluginProcessor.h"

class ConsoleLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    ConsoleLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int, int, int, int, float, float, float, juce::Slider&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool, bool) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&, bool, bool) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool, bool) override;
};

class TwoStateChoiceControl final : public juce::Component
{
public:
    TwoStateChoiceControl (juce::String componentId, juce::String firstText, juce::String secondText, bool firstMapsToOne = false);
    void attach (juce::RangedAudioParameter*);
    void syncFromParameter();
    void resized() override;
    void chooseForTest (int index) { choose (index); }

private:
    void choose (int);
    juce::RangedAudioParameter* parameter = nullptr;
    juce::TextButton first;
    juce::TextButton second;
    bool reverse = false;
};

class CyclingChoiceControl final : public juce::Component
{
public:
    CyclingChoiceControl (juce::String componentId, juce::StringArray labels);
    void attach (juce::RangedAudioParameter*);
    void syncFromParameter();
    void resized() override;
    void advanceForTest();

private:
    void advance();
    juce::RangedAudioParameter* parameter = nullptr;
    juce::StringArray choices;
    juce::TextButton button;
};

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;

    enum class ValueStyle { dB, drive, frequency, q, ratio, attackMs, release, percent, hold, plain };

    void addKnob (const juce::String&, const juce::String&, juce::Colour, ValueStyle,
                  const juce::String& leftScale = {}, const juce::String& rightScale = {});
    void addButton (const juce::String&, const juce::String&, juce::Colour);
    void placeKnob (const juce::String&, int, int, int = 96, int = 104);
    void placeButton (const juce::String&, int, int, int = 92, int = 30);
    void timerCallback() override;

    static juce::String formatValue (double, ValueStyle);
    static void drawHardwarePanel (juce::Graphics&, juce::Rectangle<int>, const juce::String&);
    static void drawScrew (juce::Graphics&, float, float, float angle = 0.0f);
    static void drawLedColumn (juce::Graphics&, juce::Rectangle<int>, float, bool outputStyle);
    static void drawMainMeter (juce::Graphics&, juce::Rectangle<int>, float, float peakHoldDb, bool scaleOnLeft);
    static void drawGRMeter (juce::Graphics&, juce::Rectangle<int>, float, const juce::String& title);
    static void drawSevenSegmentNumber (juce::Graphics&, juce::Rectangle<int>, int value);
    void rebuildStaticLayer();
    void paintStatic (juce::Graphics&);
    void syncUtilityControls();
    void resetToInit();

    ConsoleChannelStripXAudioProcessor& audioProcessor;
    ConsoleLookAndFeel consoleLook;

    std::map<juce::String, std::unique_ptr<juce::Slider>> knobs;
    std::map<juce::String, std::unique_ptr<juce::ToggleButton>> buttons;
    std::vector<std::unique_ptr<SliderAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<ButtonAttachment>> buttonAttachments;

    TwoStateChoiceControl inputModeControl { "inputMode", "LINE", "MIC" };
    TwoStateChoiceControl eqModelControl { "eqModel", "BLACK", "BROWN", true };
    TwoStateChoiceControl channelModeControl { "channelMode", "STEREO", "MID/SIDE" };
    CyclingChoiceControl routingControl { "routing", { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" } };

    juce::TextButton powerButton;
    juce::TextButton undoButton;
    juce::TextButton redoButton;
    juce::TextButton initButton { "INIT" };

    juce::Image staticLayer;
    float inputPeakHoldDb = -60.0f;
    float outputPeakHoldDb = -60.0f;
    float compGrDisplayDb = 0.0f;
    float gateGrDisplayDb = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
