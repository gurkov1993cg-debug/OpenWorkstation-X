#include "PluginEditor.h"
#include <cmath>

namespace ColoursX
{
    const auto bg       = juce::Colour (0xff0b0d0e);
    const auto panel    = juce::Colour (0xff1a1d1f);
    const auto panel2   = juce::Colour (0xff151819);
    const auto border   = juce::Colour (0xff4a4d4f);
    const auto text     = juce::Colour (0xffe7e2d7);
    const auto muted    = juce::Colour (0xff969a9b);
    const auto gold     = juce::Colour (0xffd49a37);
    const auto red      = juce::Colour (0xffb53228);
    const auto orange   = juce::Colour (0xffc87935);
    const auto blue     = juce::Colour (0xff2479b8);
    const auto green    = juce::Colour (0xff258448);
    const auto purple   = juce::Colour (0xff4350a3);
    const auto cream    = juce::Colour (0xffc7b99b);
    const auto silver   = juce::Colour (0xffaeadab);
}

ConsoleLookAndFeel::ConsoleLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, ColoursX::text);
    setColour (juce::Slider::textBoxBackgroundColourId, juce::Colour (0xff101213));
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colour (0xff4c5052));
    setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff101213));
    setColour (juce::ComboBox::textColourId, ColoursX::text);
    setColour (juce::ComboBox::outlineColourId, juce::Colour (0xff55595b));
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff151819));
    setColour (juce::PopupMenu::textColourId, ColoursX::text);
}

void ConsoleLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPosProportional, float rotaryStartAngle,
                                            float rotaryEndAngle, juce::Slider& slider)
{
    auto area = juce::Rectangle<float> (static_cast<float> (x), static_cast<float> (y),
                                        static_cast<float> (width), static_cast<float> (height));

    g.setColour (ColoursX::text.withAlpha (0.90f));
    g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawText (slider.getName(), area.removeFromTop (14.0f), juce::Justification::centred);

    auto knobArea = area;
    if (slider.getTextBoxPosition() != juce::Slider::NoTextBox)
        knobArea.removeFromBottom (22.0f);

    const float diameter = juce::jmin (knobArea.getWidth(), knobArea.getHeight()) - 12.0f;
    auto knob = knobArea.withSizeKeepingCentre (diameter, diameter).translated (0.0f, -1.0f);
    const float radius = diameter * 0.5f;
    const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);
    const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);

    g.setColour (juce::Colour (0xff08090a));
    g.fillEllipse (knob.expanded (3.0f));
    g.setColour (juce::Colour (0xff55595b));
    g.drawEllipse (knob.expanded (2.0f), 1.1f);

    juce::ColourGradient face (accent.brighter (0.15f), knob.getCentreX(), knob.getY(),
                               accent.darker (0.55f), knob.getCentreX(), knob.getBottom(), false);
    g.setGradientFill (face);
    g.fillEllipse (knob);
    g.setColour (juce::Colour (0xff6b6f71).withAlpha (0.65f));
    g.drawEllipse (knob.reduced (2.0f), 1.0f);

    g.setColour (juce::Colour (0xffb9b9b4));
    for (int i = 0; i <= 10; ++i)
    {
        const float a = rotaryStartAngle + (rotaryEndAngle - rotaryStartAngle) * static_cast<float> (i) / 10.0f;
        const auto c = knob.getCentre();
        const float r1 = radius + 1.0f;
        const float r2 = radius + 4.5f;
        g.drawLine (c.x + std::sin (a) * r1, c.y - std::cos (a) * r1,
                    c.x + std::sin (a) * r2, c.y - std::cos (a) * r2, 0.9f);
    }

    juce::Path pointer;
    const float pointerLength = radius * 0.72f;
    pointer.addRoundedRectangle (-1.4f, -radius + 5.0f, 2.8f, pointerLength, 1.2f);
    g.setColour (juce::Colours::white.withAlpha (0.92f));
    g.fillPath (pointer, juce::AffineTransform::rotation (angle).translated (knob.getCentreX(), knob.getCentreY()));
}

void ConsoleLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                                            bool highlighted, bool down)
{
    auto r = button.getLocalBounds().toFloat().reduced (1.0f);
    const auto accent = button.findColour (juce::ToggleButton::tickColourId);
    auto fill = juce::Colour (0xff111314);
    if (button.getToggleState()) fill = accent.withAlpha (0.24f);
    if (highlighted) fill = fill.brighter (0.08f);
    if (down) fill = fill.darker (0.10f);

    g.setColour (fill);
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (button.getToggleState() ? accent.brighter (0.1f) : juce::Colour (0xff5a5e60));
    g.drawRoundedRectangle (r, 3.0f, button.getToggleState() ? 1.8f : 1.0f);

    auto led = r.removeFromLeft (18.0f).reduced (5.0f, 4.0f);
    g.setColour (button.getToggleState() ? accent : juce::Colour (0xff2b2e30));
    g.fillRoundedRectangle (led, 1.5f);
    if (button.getToggleState())
    {
        g.setColour (accent.withAlpha (0.25f));
        g.fillRoundedRectangle (led.expanded (3.0f), 3.0f);
    }

    g.setColour (ColoursX::text);
    g.setFont (juce::Font (10.2f, juce::Font::bold));
    g.drawText (button.getButtonText(), r.reduced (2.0f, 0.0f), juce::Justification::centred);
}

void ConsoleLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool,
                                        int, int, int, int, juce::ComboBox& box)
{
    auto r = juce::Rectangle<float> (0.0f, 0.0f, static_cast<float> (width), static_cast<float> (height)).reduced (0.5f);
    g.setColour (box.findColour (juce::ComboBox::backgroundColourId));
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (box.findColour (juce::ComboBox::outlineColourId));
    g.drawRoundedRectangle (r, 3.0f, 1.0f);

    juce::Path arrow;
    const float cx = width - 12.0f;
    const float cy = height * 0.5f;
    arrow.startNewSubPath (cx - 3.5f, cy - 2.0f);
    arrow.lineTo (cx, cy + 2.0f);
    arrow.lineTo (cx + 3.5f, cy - 2.0f);
    g.setColour (ColoursX::gold);
    g.strokePath (arrow, juce::PathStrokeType (1.4f));
}

ChannelModeControl::ChannelModeControl()
{
    setComponentID ("channelMode");
    stereo.setClickingTogglesState (false);
    midSide.setClickingTogglesState (false);
    stereo.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff161819));
    midSide.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff161819));
    stereo.setColour (juce::TextButton::buttonOnColourId, ColoursX::gold.darker (0.38f));
    midSide.setColour (juce::TextButton::buttonOnColourId, ColoursX::gold.darker (0.38f));
    stereo.setColour (juce::TextButton::textColourOffId, ColoursX::text);
    midSide.setColour (juce::TextButton::textColourOffId, ColoursX::text);
    stereo.setColour (juce::TextButton::textColourOnId, ColoursX::text);
    midSide.setColour (juce::TextButton::textColourOnId, ColoursX::text);
    stereo.onClick = [this] { choose (0); };
    midSide.onClick = [this] { choose (1); };
    addAndMakeVisible (stereo);
    addAndMakeVisible (midSide);
}

void ChannelModeControl::attach (juce::RangedAudioParameter* p)
{
    parameter = p;
    syncFromParameter();
}

void ChannelModeControl::choose (int index)
{
    if (parameter == nullptr)
        return;
    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost (index == 0 ? 0.0f : 1.0f);
    parameter->endChangeGesture();
    syncFromParameter();
}

void ChannelModeControl::syncFromParameter()
{
    if (parameter == nullptr)
        return;
    const bool ms = parameter->getValue() >= 0.5f;
    stereo.setToggleState (! ms, juce::dontSendNotification);
    midSide.setToggleState (ms, juce::dontSendNotification);
}

void ChannelModeControl::resized()
{
    auto r = getLocalBounds();
    const int gap = 8;
    const int w = (r.getWidth() - gap) / 2;
    stereo.setBounds (r.removeFromLeft (w));
    r.removeFromLeft (gap);
    midSide.setBounds (r);
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&consoleLook);
    setOpaque (true);

    addKnob ("inputTrim", "INPUT", ColoursX::silver, ValueStyle::dB);
    addKnob ("inputDrive", "DRIVE", ColoursX::silver, ValueStyle::percent);
    addButton ("polarity", "PHASE Ø", ColoursX::cream);

    addButton ("hpOn", "HPF IN", ColoursX::gold);
    addKnob ("hpFreq", "HPF", ColoursX::silver, ValueStyle::frequency);
    addButton ("lpOn", "LPF IN", ColoursX::gold);
    addKnob ("lpFreq", "LPF", ColoursX::silver, ValueStyle::frequency);

    addButton ("eqOn", "EQ IN", ColoursX::gold);
    eqModelBox.setComponentID ("eqModel");
    eqModelBox.addItemList ({ "02 BROWN", "242 BLACK" }, 1);
    eqModelBox.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (eqModelBox);
    eqModelAttachment = std::make_unique<ComboAttachment> (audioProcessor.parameters(), "eqModel", eqModelBox);

    addButton ("hfBell", "HF BELL", ColoursX::red);
    addKnob ("hfGain", "HF GAIN", ColoursX::red, ValueStyle::dB);
    addKnob ("hfFreq", "HF FREQ", ColoursX::red, ValueStyle::frequency);

    addKnob ("hmfGain", "HMF GAIN", ColoursX::green, ValueStyle::dB);
    addKnob ("hmfFreq", "HMF FREQ", ColoursX::green, ValueStyle::frequency);
    addKnob ("hmfQ", "HMF Q", ColoursX::green, ValueStyle::q);

    addKnob ("lmfGain", "LMF GAIN", ColoursX::blue, ValueStyle::dB);
    addKnob ("lmfFreq", "LMF FREQ", ColoursX::blue, ValueStyle::frequency);
    addKnob ("lmfQ", "LMF Q", ColoursX::blue, ValueStyle::q);

    addButton ("lfBell", "LF BELL", ColoursX::blue);
    addKnob ("lfGain", "LF GAIN", ColoursX::blue, ValueStyle::dB);
    addKnob ("lfFreq", "LF FREQ", ColoursX::blue, ValueStyle::frequency);

    addButton ("dynOn", "DYN IN", ColoursX::gold);
    addButton ("compOn", "COMP IN", ColoursX::gold);
    addButton ("compFast", "FAST ATTACK", ColoursX::cream);
    addKnob ("compThreshold", "THRESHOLD", ColoursX::red, ValueStyle::dB);
    addKnob ("compRatio", "RATIO", ColoursX::silver, ValueStyle::ratio);
    addKnob ("compAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs);
    addKnob ("compRelease", "RELEASE", ColoursX::silver, ValueStyle::release);

    addButton ("gateOn", "GATE", ColoursX::gold);
    addButton ("gateExpand", "EXPAND", ColoursX::purple);
    addButton ("gateFast", "FAST ATTACK", ColoursX::purple);
    addKnob ("gateThreshold", "THRESHOLD", ColoursX::silver, ValueStyle::dB);
    addKnob ("gateRange", "RANGE", ColoursX::purple, ValueStyle::dB);
    addKnob ("gateAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs);
    addKnob ("gateRelease", "RELEASE", ColoursX::silver, ValueStyle::release);

    addKnob ("vcaFader", "VCA FADER", ColoursX::silver, ValueStyle::dB);
    addKnob ("outputTrim", "OUTPUT TRIM", ColoursX::silver, ValueStyle::dB);
    addKnob ("mix", "MIX", ColoursX::silver, ValueStyle::percent);
    addButton ("mute", "MUTE", ColoursX::red);
    addButton ("bypass", "BYPASS", ColoursX::gold);

    routingBox.setComponentID ("routing");
    routingBox.addItemList ({ "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" }, 1);
    routingBox.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (routingBox);
    routingAttachment = std::make_unique<ComboAttachment> (audioProcessor.parameters(), "routing", routingBox);

    channelModeControl.attach (audioProcessor.parameters().getParameter ("channelMode"));
    addAndMakeVisible (channelModeControl);

    // Reliability rule: every child exists before layout is triggered.
    setResizable (false, false);
    setSize (1320, 780);
    resized(); // explicit second layout pass prevents 0x0 controls on older JUCE/macOS hosts.

    // 15 Hz is ample for meters and substantially lighter on old Intel Macs.
    startTimerHz (15);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double value, ValueStyle style)
{
    switch (style)
    {
        case ValueStyle::dB:        return juce::String (value, 1) + " dB";
        case ValueStyle::frequency: return value >= 1000.0 ? juce::String (value / 1000.0, value >= 10000.0 ? 1 : 2) + " kHz"
                                                            : juce::String (value, 0) + " Hz";
        case ValueStyle::q:         return juce::String (value, 2);
        case ValueStyle::ratio:     return value >= 19.95 ? juce::String ("∞:1") : juce::String (value, 1) + ":1";
        case ValueStyle::attackMs:  return value < 1.0 ? juce::String (value, 2) + " ms" : juce::String (value, 1) + " ms";
        case ValueStyle::release:   return value < 1.0 ? juce::String (value * 1000.0, 0) + " ms" : juce::String (value, 2) + " s";
        case ValueStyle::percent:   return juce::String (value, 0) + "%";
        case ValueStyle::plain:     return juce::String (value, 2);
    }
    return {};
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label,
                                                         juce::Colour accent, ValueStyle style)
{
    auto s = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::TextBoxBelow);
    s->setName (label);
    s->setComponentID (id);
    s->setTextBoxStyle (juce::Slider::TextBoxBelow, false, 74, 18);
    s->setColour (juce::Slider::rotarySliderFillColourId, accent);
    s->setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff26292b));
    s->setColour (juce::Slider::thumbColourId, ColoursX::text);
    s->textFromValueFunction = [style] (double v) { return formatValue (v, style); };
    addAndMakeVisible (*s);
    sliderAttachments.push_back (std::make_unique<SliderAttachment> (audioProcessor.parameters(), id, *s));
    knobs[id] = std::move (s);
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const juce::String& id, const juce::String& label,
                                                           juce::Colour accent)
{
    auto b = std::make_unique<juce::ToggleButton> (label);
    b->setComponentID (id);
    b->setColour (juce::ToggleButton::textColourId, ColoursX::text);
    b->setColour (juce::ToggleButton::tickColourId, accent);
    b->setClickingTogglesState (true);
    addAndMakeVisible (*b);
    buttonAttachments.push_back (std::make_unique<ButtonAttachment> (audioProcessor.parameters(), id, *b));
    buttons[id] = std::move (b);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    g.setColour (ColoursX::panel);
    g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (ColoursX::border);
    g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.0f);
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (15.0f, juce::Font::bold));
    g.drawText (title, r.removeFromTop (30).reduced (10, 0), juce::Justification::centredLeft);
}

void ConsoleChannelStripXAudioProcessorEditor::drawMeter (juce::Graphics& g, juce::Rectangle<int> r, float levelDb,
                                                           const juce::String& title, float minDb, float maxDb)
{
    g.setColour (juce::Colour (0xff07090a));
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    g.setColour (juce::Colour (0xff45494b));
    g.drawRoundedRectangle (r.toFloat(), 2.0f, 1.0f);

    constexpr int segments = 24;
    constexpr int gap = 2;
    const int segH = juce::jmax (2, (r.getHeight() - (segments - 1) * gap - 6) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, (levelDb - minDb) / (maxDb - minDb));
    const int lit = static_cast<int> (std::round (norm * segments));

    for (int i = 0; i < segments; ++i)
    {
        auto seg = juce::Rectangle<int> (r.getX() + 4,
                                         r.getBottom() - 4 - (i + 1) * segH - i * gap,
                                         r.getWidth() - 8, segH);
        const float p = static_cast<float> (i) / static_cast<float> (segments - 1);
        juce::Colour c = p > 0.86f ? juce::Colour (0xffef4d2f)
                         : p > 0.64f ? juce::Colour (0xffffb62c)
                                     : juce::Colour (0xff63ad55);
        g.setColour (i < lit ? c : c.withAlpha (0.13f));
        g.fillRoundedRectangle (seg.toFloat(), 1.0f);
    }

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawText (title, r.getX() - 8, r.getY() - 20, r.getWidth() + 16, 16, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawGRMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                             float reductionDb, const juce::String& title,
                                                             float maxReductionDb)
{
    g.setColour (juce::Colour (0xff080a0b));
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    g.setColour (juce::Colour (0xff45494b));
    g.drawRoundedRectangle (r.toFloat(), 2.0f, 1.0f);

    const float norm = juce::jlimit (0.0f, 1.0f, reductionDb / maxReductionDb);
    const int h = static_cast<int> (std::round (norm * (r.getHeight() - 6)));
    auto fill = juce::Rectangle<int> (r.getX() + 3, r.getY() + 3, r.getWidth() - 6, h);
    g.setColour (ColoursX::gold);
    g.fillRoundedRectangle (fill.toFloat(), 1.0f);

    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText (title, r.getX() - 12, r.getY() - 18, r.getWidth() + 24, 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (ColoursX::bg);

    g.setColour (juce::Colour (0xff111416));
    g.fillRect (0, 0, getWidth(), 52);
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (21.0f, juce::Font::bold));
    g.drawText ("Console Channel Strip X", 0, 6, getWidth(), 26, juce::Justification::centred);
    g.setColour (ColoursX::gold);
    g.setFont (juce::Font (9.8f, juce::Font::bold));
    g.drawText ("E-SERIES CONSOLE  •  02 BROWN / 242 BLACK", 0, 32, getWidth(), 13, juce::Justification::centred);

    drawPanel (g, { 12, 60, 350, 708 }, "INPUT / FILTERS / EQ");
    drawPanel (g, { 370, 60, 330, 708 }, "DYNAMICS");
    drawPanel (g, { 708, 60, 300, 708 }, "CHANNEL STRIP X");
    drawPanel (g, { 1016, 60, 292, 708 }, "OUTPUT");

    // Left channel-strip hierarchy.
    const int x1 = 28, x2 = 346;
    const int separators[] = { 196, 318, 356, 445, 534, 623 };
    g.setColour (juce::Colour (0xff3b3f41));
    for (auto y : separators) g.drawHorizontalLine (y, static_cast<float> (x1), static_cast<float> (x2));
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.setColour (ColoursX::muted);
    g.drawText ("FILTERS", 30, 200, 90, 16, juce::Justification::centredLeft);
    g.drawText ("4-BAND EQ", 30, 322, 90, 16, juce::Justification::centredLeft);
    g.setColour (ColoursX::red);   g.drawText ("HF", 30, 360, 30, 16, juce::Justification::centredLeft);
    g.setColour (ColoursX::green); g.drawText ("HMF", 30, 449, 35, 16, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue);  g.drawText ("LMF", 30, 538, 35, 16, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue);  g.drawText ("LF", 30, 627, 30, 16, juce::Justification::centredLeft);

    // Dynamics split and meters.
    g.setColour (juce::Colour (0xff3b3f41));
    g.drawHorizontalLine (390, 388.0f, 682.0f);
    g.setColour (ColoursX::cream);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("COMPRESSOR / LIMITER", 390, 92, 180, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::purple);
    g.drawText ("GATE / EXPANDER", 390, 397, 160, 18, juce::Justification::centredLeft);
    drawGRMeter (g, { 663, 150, 18, 178 }, audioProcessor.compressorMeter(), "GR", 24.0f);
    drawGRMeter (g, { 663, 500, 18, 150 }, audioProcessor.gateMeter(), "GATE", 40.0f);

    // Central meter bridge.
    g.setColour (juce::Colour (0xff0a0c0d));
    g.fillRoundedRectangle (juce::Rectangle<float> (730.0f, 108.0f, 256.0f, 548.0f), 4.0f);
    drawMeter (g, { 772, 154, 52, 360 }, audioProcessor.inputMeter(), "INPUT");
    drawMeter (g, { 892, 154, 52, 360 }, audioProcessor.outputMeter(), "OUTPUT");
    g.setColour (ColoursX::text);
    g.setFont (juce::Font (17.0f, juce::Font::bold));
    g.drawText ("CHANNEL STRIP X", 740, 545, 236, 24, juce::Justification::centred);
    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (11.0f));
    g.drawText ("CONSOLE SIGNAL PATH", 740, 570, 236, 18, juce::Justification::centred);

    // Output hierarchy.
    g.setColour (juce::Colour (0xff3b3f41));
    g.drawHorizontalLine (350, 1036.0f, 1288.0f);
    g.drawHorizontalLine (510, 1036.0f, 1288.0f);
    g.setColour (ColoursX::muted);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("ROUTING", 1040, 362, 80, 16, juce::Justification::centredLeft);
    g.drawText ("CHANNEL MODE", 1040, 525, 120, 16, juce::Justification::centredLeft);
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    channelModeControl.syncFromParameter();
    // Repaint only dynamic meter regions; avoid redrawing the entire editor 30 times/sec.
    repaint (754, 128, 210, 410);
    repaint (650, 128, 45, 545);
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = knobs.find (id); it != knobs.end())
        it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::placeButton (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = buttons.find (id); it != buttons.end())
        it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    // INPUT / FILTERS
    placeKnob ("inputTrim", 36, 88, 92, 102);
    placeKnob ("inputDrive", 138, 88, 92, 102);
    placeButton ("polarity", 246, 125, 96, 27);

    placeButton ("hpOn", 32, 222, 78, 25);
    placeKnob ("hpFreq", 26, 244, 100, 70);
    placeButton ("lpOn", 145, 222, 78, 25);
    placeKnob ("lpFreq", 139, 244, 100, 70);

    // EQ selector.
    placeButton ("eqOn", 32, 326, 76, 25);
    eqModelBox.setBounds (172, 326, 168, 25);

    // HF
    placeKnob ("hfGain", 68, 365, 78, 77);
    placeKnob ("hfFreq", 156, 365, 78, 77);
    placeButton ("hfBell", 248, 390, 92, 24);

    // HMF
    placeKnob ("hmfGain", 58, 454, 78, 77);
    placeKnob ("hmfFreq", 146, 454, 78, 77);
    placeKnob ("hmfQ", 234, 454, 78, 77);

    // LMF
    placeKnob ("lmfGain", 58, 543, 78, 77);
    placeKnob ("lmfFreq", 146, 543, 78, 77);
    placeKnob ("lmfQ", 234, 543, 78, 77);

    // LF
    placeKnob ("lfGain", 68, 632, 78, 77);
    placeKnob ("lfFreq", 156, 632, 78, 77);
    placeButton ("lfBell", 248, 657, 92, 24);

    // DYNAMICS
    placeButton ("dynOn", 584, 86, 94, 25);
    placeButton ("compOn", 390, 116, 88, 25);
    placeButton ("compFast", 486, 116, 112, 25);
    placeKnob ("compThreshold", 395, 150, 108, 105);
    placeKnob ("compRatio", 510, 150, 108, 105);
    placeKnob ("compAttack", 395, 266, 108, 105);
    placeKnob ("compRelease", 510, 266, 108, 105);

    placeButton ("gateOn", 390, 420, 82, 25);
    placeButton ("gateExpand", 480, 420, 88, 25);
    placeButton ("gateFast", 576, 420, 102, 25);
    placeKnob ("gateThreshold", 395, 455, 108, 105);
    placeKnob ("gateRange", 510, 455, 108, 105);
    placeKnob ("gateAttack", 395, 575, 108, 105);
    placeKnob ("gateRelease", 510, 575, 108, 105);

    // OUTPUT
    placeKnob ("vcaFader", 1042, 100, 112, 112);
    placeKnob ("outputTrim", 1166, 100, 112, 112);
    placeKnob ("mix", 1042, 225, 112, 112);
    placeButton ("mute", 1174, 248, 100, 28);
    placeButton ("bypass", 1174, 292, 100, 28);

    routingBox.setBounds (1042, 392, 236, 32);
    channelModeControl.setBounds (1042, 555, 236, 38);
}
