#include "DspEngine.h"

namespace
{
    inline float dbToGain (float db) { return juce::Decibels::decibelsToGain (db); }

    void runFilter (DspEngine::IIR& filter, juce::AudioBuffer<float>& buffer)
    {
        juce::dsp::AudioBlock<float> block (buffer);
        juce::dsp::ProcessContextReplacing<float> context (block);
        filter.process (context);
    }
}

void DspEngine::prepare (double sampleRate, int maximumBlockSize, int numChannels)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, static_cast<juce::uint32> (maximumBlockSize), static_cast<juce::uint32> (numChannels) };
    hp1.prepare (spec); hp2.prepare (spec); lp.prepare (spec);
    lf.prepare (spec); lmf.prepare (spec); hmf.prepare (spec); hf.prepare (spec);
    globalDryBuffer.setSize (numChannels, maximumBlockSize, false, false, true);
    filterCacheValid = false;
    reset();
}

void DspEngine::reset()
{
    hp1.reset(); hp2.reset(); lp.reset(); lf.reset(); lmf.reset(); hmf.reset(); hf.reset();
    compGainDb = 0.0f;
    rmsSquare = 0.0f;
    gateGainDb = 0.0f;
    gateOpen = true;
    compMeterDb.store (0.0f);
    gateMeterDb.store (0.0f);
    inputPeakDb.store (-100.0f);
    outputPeakDb.store (-100.0f);
    filterCacheValid = false;
}

float DspEngine::consoleSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Clean-room console stage: slightly asymmetric, unity-slope around zero and
    // progressively denser with drive. The small asymmetry adds a restrained
    // second-harmonic component while the soft limiting supplies the familiar
    // VCA/transformer-style density without a large level jump.
    const float drive = 1.0f + 3.5f * a;
    const float bias = 0.018f * a;
    const float t0 = std::tanh (drive * bias);
    const float slope0 = juce::jmax (0.05f, drive * (1.0f - t0 * t0));
    const float shaped = (std::tanh (drive * (x + bias)) - t0) / slope0;
    const float blend = 0.16f + 0.62f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::bufferPeakDb (const juce::AudioBuffer<float>& buffer)
{
    float peak = 0.0f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        peak = juce::jmax (peak, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
    return juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -100.0f);
}

void DspEngine::processInputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    const float trim = dbToGain (p.inputTrimDb) * (p.polarity ? -1.0f : 1.0f);
    buffer.applyGain (trim);

    const float driveAmount = juce::jlimit (0.0f, 1.0f, p.inputDrive / 100.0f);
    if (driveAmount > 0.0001f)
    {
        for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        {
            auto* data = buffer.getWritePointer (ch);
            for (int i = 0; i < buffer.getNumSamples(); ++i)
                data[i] = consoleSaturate (data[i], driveAmount);
        }
    }
}

bool DspEngine::filterParametersChanged (const Params& p) const noexcept
{
    if (! filterCacheValid)
        return true;

    return p.hpFreq != lastFilterParams.hpFreq
        || p.lpFreq != lastFilterParams.lpFreq
        || p.blackEq != lastFilterParams.blackEq
        || p.lfBell != lastFilterParams.lfBell
        || p.lfFreq != lastFilterParams.lfFreq
        || p.lfGain != lastFilterParams.lfGain
        || p.lmfFreq != lastFilterParams.lmfFreq
        || p.lmfGain != lastFilterParams.lmfGain
        || p.lmfQ != lastFilterParams.lmfQ
        || p.hmfFreq != lastFilterParams.hmfFreq
        || p.hmfGain != lastFilterParams.hmfGain
        || p.hmfQ != lastFilterParams.hmfQ
        || p.hfBell != lastFilterParams.hfBell
        || p.hfFreq != lastFilterParams.hfFreq
        || p.hfGain != lastFilterParams.hfGain;
}

void DspEngine::updateFilters (const Params& p)
{
    if (! filterParametersChanged (p))
        return;
    const auto nyquistSafe = static_cast<float> (0.45 * sr);
    const auto hpHz = juce::jlimit (20.0f, juce::jmin (500.0f, nyquistSafe), p.hpFreq);
    const auto lpHz = juce::jlimit (3000.0f, nyquistSafe, p.lpFreq);

    *hp1.state = *juce::dsp::IIR::Coefficients<float>::makeFirstOrderHighPass (sr, hpHz);
    *hp2.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass (sr, hpHz, 0.70710678f);
    *lp.state  = *juce::dsp::IIR::Coefficients<float>::makeLowPass (sr, lpHz, 0.70710678f);

    // 02 Brown is intentionally rounder; 242 Black is tighter and more assertive.
    const float modelQ = p.blackEq ? 1.12f : 0.82f;
    const float shelfSlope = p.blackEq ? 0.96f : 0.58f;

    auto lfCoeffs = p.lfBell
        ? juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.lfFreq, 0.78f * modelQ, dbToGain (p.lfGain))
        : juce::dsp::IIR::Coefficients<float>::makeLowShelf (sr, p.lfFreq, shelfSlope, dbToGain (p.lfGain));
    *lf.state = *lfCoeffs;

    *lmf.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter (
        sr, p.lmfFreq, juce::jlimit (0.35f, 4.5f, p.lmfQ * modelQ), dbToGain (p.lmfGain));

    *hmf.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter (
        sr, p.hmfFreq, juce::jlimit (0.35f, 4.5f, p.hmfQ * modelQ), dbToGain (p.hmfGain));

    auto hfCoeffs = p.hfBell
        ? juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.hfFreq, 0.78f * modelQ, dbToGain (p.hfGain))
        : juce::dsp::IIR::Coefficients<float>::makeHighShelf (sr, p.hfFreq, shelfSlope, dbToGain (p.hfGain));
    *hf.state = *hfCoeffs;

    lastFilterParams = p;
    filterCacheValid = true;
}

void DspEngine::processFilters (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.hpOn)
    {
        // 02 Brown: ~12 dB/oct; 242 Black: ~18 dB/oct.
        runFilter (hp2, buffer);
        if (p.blackEq)
            runFilter (hp1, buffer);
    }
    if (p.lpOn)
        runFilter (lp, buffer);
}

void DspEngine::processEQ (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.eqOn)
        return;

    runFilter (lf, buffer);
    runFilter (lmf, buffer);
    runFilter (hmf, buffer);
    runFilter (hf, buffer);
}

float DspEngine::softKneeGainReduction (float levelDb, float thresholdDb, float ratio, float kneeDb)
{
    if (ratio <= 1.0001f)
        return 0.0f;

    const float slope = 1.0f - 1.0f / ratio;
    const float x = levelDb - thresholdDb;
    if (kneeDb <= 0.0f)
        return x > 0.0f ? slope * x : 0.0f;

    const float half = 0.5f * kneeDb;
    if (x <= -half) return 0.0f;
    if (x >= half)  return slope * x;
    const float t = x + half;
    return slope * t * t / (2.0f * kneeDb);
}

void DspEngine::processDynamics (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.dynOn)
    {
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();

    // Attack controls are intentionally extended beyond the original hardware so
    // the user can tune them freely. FAST keeps the same control active and makes
    // the chosen time ten times quicker, placing 30 ms at the classic ~3 ms point.
    const float compAttackMs = juce::jmax (0.05f, p.compAttackMs * (p.compFast ? 0.10f : 1.0f));
    const float compAttackStepDb = 20.0f / juce::jmax (1.0f, compAttackMs * 0.001f * static_cast<float> (sr));
    const float compReleaseCoeff = std::exp (-1.0f / static_cast<float> (
        juce::jmax (0.02, static_cast<double> (p.compReleaseSec)) * sr));

    const float gateAttackMs = juce::jmax (0.05f, p.gateAttackMs * (p.gateFast ? (0.10f / 1.5f) : 1.0f));
    const float gateAttackStepDb = 40.0f / juce::jmax (1.0f, gateAttackMs * 0.001f * static_cast<float> (sr));
    const float gateReleaseCoeff = std::exp (-1.0f / static_cast<float> (
        juce::jmax (0.02, static_cast<double> (p.gateReleaseSec)) * sr));

    // E-series gates use threshold-dependent hysteresis. Lower thresholds receive
    // a little more separation between open and close points for a musical decay.
    const float hysteresisDb = 2.5f + 0.10f * juce::jlimit (0.0f, 40.0f, -p.gateThresholdDb);
    const float gateCloseThreshold = p.gateThresholdDb - hysteresisDb;

    // Fast peak detector feeding a slower memory gives a feed-forward, transient-
    // conscious response rather than a generic long RMS compressor detector.
    const float detectorAttack = std::exp (-1.0f / static_cast<float> (0.00020 * sr));
    const float detectorRelease = std::exp (-1.0f / static_cast<float> (0.010 * sr));

    for (int i = 0; i < samples; ++i)
    {
        float peak = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            peak = juce::jmax (peak, std::abs (buffer.getSample (ch, i)));

        const float levelDb = juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -120.0f);

        if (p.gateOn && p.gateRangeDb > 0.01f)
        {
            if (! gateOpen && levelDb >= p.gateThresholdDb)
                gateOpen = true;
            else if (gateOpen && levelDb < gateCloseThreshold)
                gateOpen = false;

            float targetGateDb = 0.0f;
            if (! gateOpen)
            {
                if (p.gateExpand)
                    targetGateDb = -juce::jmin (p.gateRangeDb,
                                                juce::jmax (0.0f, (p.gateThresholdDb - levelDb) * 0.5f));
                else
                    targetGateDb = -p.gateRangeDb;
            }

            if (targetGateDb > gateGainDb)
                gateGainDb = juce::jmin (targetGateDb, gateGainDb + gateAttackStepDb);
            else
                gateGainDb = gateReleaseCoeff * gateGainDb + (1.0f - gateReleaseCoeff) * targetGateDb;

            const float g = dbToGain (gateGainDb);
            for (int ch = 0; ch < channels; ++ch)
                buffer.setSample (ch, i, buffer.getSample (ch, i) * g);
        }
        else
        {
            gateGainDb = 0.0f;
            gateOpen = true;
        }

        if (p.compOn)
        {
            peak = 0.0f;
            for (int ch = 0; ch < channels; ++ch)
                peak = juce::jmax (peak, std::abs (buffer.getSample (ch, i)));

            const float squared = peak * peak;
            const float detectorCoeff = squared > rmsSquare ? detectorAttack : detectorRelease;
            rmsSquare = detectorCoeff * rmsSquare + (1.0f - detectorCoeff) * squared;
            const float detectorDb = juce::Decibels::gainToDecibels (
                std::sqrt (juce::jmax (rmsSquare, 1.0e-18f)), -120.0f);

            const float ratio = p.compRatio >= 19.95f ? 1000.0f : juce::jmax (1.0f, p.compRatio);
            const float targetGr = softKneeGainReduction (detectorDb, p.compThresholdDb, ratio, 6.0f);
            const float targetGainDb = -targetGr;

            if (targetGainDb < compGainDb)
                compGainDb = juce::jmax (targetGainDb, compGainDb - compAttackStepDb);
            else
                compGainDb = compReleaseCoeff * compGainDb + (1.0f - compReleaseCoeff) * targetGainDb;

            // Threshold-linked make-up mirrors the fast SSL workflow while avoiding
            // the exaggerated loudness jump of a simplistic 1:1 compensation law.
            const float makeupDb = (-juce::jmin (0.0f, p.compThresholdDb))
                                 * (1.0f - 1.0f / ratio) * 0.46f;
            const float wetGain = dbToGain (compGainDb + makeupDb);
            for (int ch = 0; ch < channels; ++ch)
                buffer.setSample (ch, i, buffer.getSample (ch, i) * wetGain);
        }
        else
        {
            compGainDb = 0.0f;
            rmsSquare = 0.0f;
        }
    }

    compMeterDb.store (juce::jmax (0.0f, -compGainDb));
    gateMeterDb.store (juce::jmax (0.0f, -gateGainDb));
}

void DspEngine::encodeMidSide (juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() != 2)
        return;

    constexpr float k = 0.7071067811865476f;
    auto* left = buffer.getWritePointer (0);
    auto* right = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float l = left[i];
        const float r = right[i];
        left[i] = (l + r) * k;
        right[i] = (l - r) * k;
    }
}

void DspEngine::decodeMidSide (juce::AudioBuffer<float>& buffer)
{
    if (buffer.getNumChannels() != 2)
        return;

    constexpr float k = 0.7071067811865476f;
    auto* mid = buffer.getWritePointer (0);
    auto* side = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float m = mid[i];
        const float s = side[i];
        mid[i] = (m + s) * k;
        side[i] = (m - s) * k;
    }
}

void DspEngine::processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    buffer.applyGain (dbToGain (p.vcaFaderDb));

    // Subtle VCA-like density at unity, increasing as the fader is pushed above 0 dB.
    const float base = 0.055f;
    const float push = juce::jlimit (0.0f, 1.0f, p.vcaFaderDb / 10.0f);
    const float amount = base + 0.28f * push;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
    {
        auto* data = buffer.getWritePointer (ch);
        for (int i = 0; i < buffer.getNumSamples(); ++i)
            data[i] = consoleSaturate (data[i], amount);
    }

    buffer.applyGain (dbToGain (p.outputTrimDb));
    if (p.mute)
        buffer.clear();
}

void DspEngine::process (juce::AudioBuffer<float>& buffer, const Params& p)
{
    inputPeakDb.store (bufferPeakDb (buffer));

    if (p.bypass)
    {
        outputPeakDb.store (inputPeakDb.load());
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    jassert (samples <= globalDryBuffer.getNumSamples());
    jassert (channels <= globalDryBuffer.getNumChannels());
    for (int ch = 0; ch < channels; ++ch)
        globalDryBuffer.copyFrom (ch, 0, buffer, ch, 0, samples);

    if (p.channelMode == 1 && channels == 2)
        encodeMidSide (buffer);

    processInputStage (buffer, p);
    updateFilters (p);

    switch (p.routing)
    {
        case 1: // FILTER -> DYN -> EQ
            processFilters (buffer, p); processDynamics (buffer, p); processEQ (buffer, p); break;
        case 2: // DYN -> FILTER -> EQ
            processDynamics (buffer, p); processFilters (buffer, p); processEQ (buffer, p); break;
        default: // FILTER -> EQ -> DYN
            processFilters (buffer, p); processEQ (buffer, p); processDynamics (buffer, p); break;
    }

    processOutputStage (buffer, p);

    if (p.channelMode == 1 && channels == 2)
        decodeMidSide (buffer);

    const float mix = juce::jlimit (0.0f, 1.0f, p.mix);
    if (mix < 0.9999f)
    {
        for (int ch = 0; ch < channels; ++ch)
        {
            auto* wet = buffer.getWritePointer (ch);
            const auto* dry = globalDryBuffer.getReadPointer (ch);
            for (int i = 0; i < samples; ++i)
                wet[i] = dry[i] * (1.0f - mix) + wet[i] * mix;
        }
    }

    outputPeakDb.store (bufferPeakDb (buffer));
}
