# Console Channel Strip X v0.2.3

C++17 / JUCE 7 VST3 channel strip with an original E-series-inspired workflow.

v0.2.3 fixes the editor layout ordering bug that could leave controls at 0x0 bounds in Cubase. The production GUI no longer shows build architecture, deployment-target, or internal audit text.

All 41 visible controls are APVTS-backed. DSP smoke tests cover every audible control, and a separate C++/JUCE GUI smoke test rejects builds with hidden, zero-size, duplicate-ID, or parameterless top-level controls.


## v0.2.3 SSL-behaviour pass
- E-series control ranges aligned to documented 4K E ranges.
- Feed-forward transient-conscious compressor detector with dB-slew attack and logarithmic release.
- Threshold-dependent gate hysteresis and dB-slew attack.
- Refined asymmetric input/VCA console non-linearity.
- Brown/Black EQ voicing remains clean-room and independently implemented.
