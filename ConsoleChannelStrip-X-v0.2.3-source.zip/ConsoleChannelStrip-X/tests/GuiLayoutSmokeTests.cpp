#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <chrono>
#include <iostream>
#include <set>

int main()
{
    juce::ScopedJuceInitialiser_GUI juceGui;
    ConsoleChannelStripXAudioProcessor processor;

    const auto start = std::chrono::steady_clock::now();
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds> (
        std::chrono::steady_clock::now() - start).count();

    if (editor == nullptr)
    {
        std::cerr << "FAIL: editor was not created\n";
        return 1;
    }

    if (editor->getWidth() != 1320 || editor->getHeight() != 780)
    {
        std::cerr << "FAIL: unexpected editor size " << editor->getWidth() << "x" << editor->getHeight() << "\n";
        return 1;
    }

    if (elapsedMs > 5000)
    {
        std::cerr << "FAIL: editor construction is unexpectedly slow: " << elapsedMs << " ms\n";
        return 1;
    }

    constexpr int expectedControls = 42;
    if (editor->getNumChildComponents() != expectedControls)
    {
        std::cerr << "FAIL: expected " << expectedControls << " top-level controls, got "
                  << editor->getNumChildComponents() << "\n";
        return 1;
    }

    std::set<std::string> ids;
    for (int i = 0; i < editor->getNumChildComponents(); ++i)
    {
        auto* child = editor->getChildComponent (i);
        if (child == nullptr)
        {
            std::cerr << "FAIL: null child component at index " << i << "\n";
            return 1;
        }

        const auto id = child->getComponentID();
        if (id.isEmpty())
        {
            std::cerr << "FAIL: visible control without component ID at index " << i << "\n";
            return 1;
        }

        if (! ids.insert (id.toStdString()).second)
        {
            std::cerr << "FAIL: duplicate visible control ID: " << id << "\n";
            return 1;
        }

        if (! child->isVisible() || child->getBounds().isEmpty())
        {
            std::cerr << "FAIL: invisible or 0x0 control: " << id << "\n";
            return 1;
        }

        if (! editor->getLocalBounds().contains (child->getBounds()))
        {
            std::cerr << "FAIL: control lies outside editor bounds: " << id << "\n";
            return 1;
        }

        auto* parameter = processor.parameters().getParameter (id);
        if (parameter == nullptr)
        {
            std::cerr << "FAIL: visible control has no APVTS parameter: " << id << "\n";
            return 1;
        }

        const float before = parameter->getValue();

        if (auto* button = dynamic_cast<juce::ToggleButton*> (child))
        {
            button->setToggleState (! button->getToggleState(), juce::dontSendNotification);
            if (button->onClick) button->onClick();
            if (std::abs (parameter->getValue() - before) < 1.0e-6f)
            {
                std::cerr << "FAIL: button is visible but not connected to DSP parameter: " << id << "\n";
                return 1;
            }
        }
        else if (auto* slider = dynamic_cast<juce::Slider*> (child))
        {
            const auto lo = slider->getMinimum();
            const auto hi = slider->getMaximum();
            const auto target = std::abs (slider->getValue() - lo) < std::abs (slider->getValue() - hi) ? hi : lo;
            slider->setValue (target, juce::sendNotificationSync);
            if (std::abs (parameter->getValue() - before) < 1.0e-6f)
            {
                std::cerr << "FAIL: knob is visible but not connected to DSP parameter: " << id << "\n";
                return 1;
            }
        }
        else if (auto* combo = dynamic_cast<juce::ComboBox*> (child))
        {
            const int current = combo->getSelectedItemIndex();
            const int next = (current + 1) % combo->getNumItems();
            combo->setSelectedItemIndex (next, juce::sendNotificationSync);
            if (std::abs (parameter->getValue() - before) < 1.0e-6f)
            {
                std::cerr << "FAIL: selector is visible but not connected to DSP parameter: " << id << "\n";
                return 1;
            }
        }
        else if (id == "channelMode")
        {
            auto* first = child->getChildComponent (0);
            auto* second = child->getChildComponent (1);
            auto* target = dynamic_cast<juce::Button*> (before < 0.5f ? second : first);
            if (target == nullptr)
            {
                std::cerr << "FAIL: channel mode buttons missing\n";
                return 1;
            }
            if (target->onClick) target->onClick();
            if (std::abs (parameter->getValue() - before) < 1.0e-6f)
            {
                std::cerr << "FAIL: Channel Mode buttons are not connected\n";
                return 1;
            }
        }
    }

    if (static_cast<int> (processor.getParameters().size()) != expectedControls)
    {
        std::cerr << "FAIL: processor exposes " << processor.getParameters().size()
                  << " parameters but GUI exposes " << expectedControls << " controls\n";
        return 1;
    }

    std::cout << "PASS: all 42 GUI controls are visible, in-bounds and connected. Editor created in "
              << elapsedMs << " ms.\n";
    return 0;
}
