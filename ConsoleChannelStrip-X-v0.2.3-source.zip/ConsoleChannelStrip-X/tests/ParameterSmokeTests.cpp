#include "DspEngine.h"
#include <cmath>
#include <functional>
#include <iostream>
#include <string>

namespace
{
    constexpr double sampleRate = 48000.0;
    constexpr int numSamples = 48000;
    constexpr float pi = 3.14159265358979323846f;

    using Generator = std::function<float (int)>;

    std::vector<float> render (const DspEngine::Params& params, const Generator& generator)
    {
        DspEngine engine;
        engine.prepare (sampleRate, numSamples, 1);
        juce::AudioBuffer<float> buffer (1, numSamples);
        for (int i = 0; i < numSamples; ++i)
            buffer.setSample (0, i, generator (i));
        engine.process (buffer, params);
        return std::vector<float> (buffer.getReadPointer (0), buffer.getReadPointer (0) + numSamples);
    }

    float difference (const std::vector<float>& a, const std::vector<float>& b)
    {
        double sum = 0.0;
        for (size_t i = 0; i < a.size(); ++i)
            sum += std::abs (static_cast<double> (a[i] - b[i]));
        return static_cast<float> (sum / static_cast<double> (a.size()));
    }

    float rms (const std::vector<float>& a)
    {
        double sum = 0.0;
        for (auto v : a) sum += static_cast<double> (v) * v;
        return static_cast<float> (std::sqrt (sum / static_cast<double> (a.size())));
    }

    Generator sine (float hz, float amp = 0.5f)
    {
        return [=] (int i) { return amp * std::sin (2.0f * pi * hz * static_cast<float> (i) / static_cast<float> (sampleRate)); };
    }

    Generator twoTone (float f1, float f2, float amp = 0.35f)
    {
        return [=] (int i)
        {
            const float t = static_cast<float> (i) / static_cast<float> (sampleRate);
            return amp * std::sin (2.0f * pi * f1 * t) + amp * std::sin (2.0f * pi * f2 * t);
        };
    }

    Generator burst()
    {
        return [] (int i)
        {
            const float t = static_cast<float> (i) / static_cast<float> (sampleRate);
            const float amp = (i < 8000) ? 0.05f : (i < 24000 ? 0.95f : 0.08f);
            return amp * std::sin (2.0f * pi * 180.0f * t);
        };
    }

    Generator gateSignal()
    {
        return [] (int i)
        {
            const float t = static_cast<float> (i) / static_cast<float> (sampleRate);
            const float amp = (i < 9000) ? 0.02f : (i < 22000 ? 0.40f : 0.015f);
            return amp * std::sin (2.0f * pi * 220.0f * t);
        };
    }

    bool expectDifferent (const std::string& name, DspEngine::Params a, DspEngine::Params b,
                          const Generator& gen, float minimum = 1.0e-5f)
    {
        const auto ra = render (a, gen);
        const auto rb = render (b, gen);
        const auto d = difference (ra, rb);
        if (d <= minimum)
        {
            std::cerr << "FAIL: " << name << " produced no meaningful DSP change (diff=" << d << ")\n";
            return false;
        }
        std::cout << "PASS: " << name << " diff=" << d << "\n";
        return true;
    }
}

int main()
{
    bool ok = true;
    DspEngine::Params base;
    base.dynOn = false;
    base.eqOn = false;

    {
        auto a = base, b = base; a.inputTrimDb = -6.0f; b.inputTrimDb = 6.0f;
        ok &= expectDifferent ("Input Trim", a, b, sine (1000.0f));
    }
    {
        auto a = base, b = base; a.inputDrive = 0.0f; b.inputDrive = 100.0f;
        ok &= expectDifferent ("Input Drive", a, b, sine (1000.0f, 0.95f));
    }
    {
        auto a = base, b = base; a.polarity = false; b.polarity = true;
        ok &= expectDifferent ("Polarity", a, b, sine (1000.0f));
    }
    {
        auto a = base, b = base; a.hpOn = b.hpOn = true; a.hpFreq = 30.0f; b.hpFreq = 300.0f;
        ok &= expectDifferent ("HP Frequency", a, b, sine (70.0f));
    }
    {
        auto a = base, b = base; a.lpOn = b.lpOn = true; a.lpFreq = 22000.0f; b.lpFreq = 4000.0f;
        ok &= expectDifferent ("LP Frequency", a, b, sine (12000.0f));
    }
    {
        auto a = base, b = base; a.hpOn = b.hpOn = true; a.hpFreq = b.hpFreq = 200.0f; a.blackEq = false; b.blackEq = true;
        ok &= expectDifferent ("02 Brown / 242 Black model", a, b, sine (80.0f));
    }

    DspEngine::Params eq;
    eq.dynOn = false;
    eq.eqOn = true;
    {
        auto a = eq, b = eq; a.eqOn = false; b.hfGain = 12.0f;
        ok &= expectDifferent ("EQ IN", a, b, sine (10000.0f));
    }
    {
        auto a = eq, b = eq; a.hfGain = -12.0f; b.hfGain = 12.0f;
        ok &= expectDifferent ("HF Gain", a, b, sine (10000.0f));
    }
    {
        auto a = eq, b = eq; a.hfGain = b.hfGain = 12.0f; a.hfFreq = 3000.0f; b.hfFreq = 16000.0f;
        ok &= expectDifferent ("HF Frequency", a, b, sine (7000.0f));
    }
    {
        auto a = eq, b = eq; a.hfGain = b.hfGain = 12.0f; a.hfBell = false; b.hfBell = true;
        ok &= expectDifferent ("HF Bell", a, b, twoTone (5000.0f, 16000.0f));
    }
    {
        auto a = eq, b = eq; a.hmfGain = -12.0f; b.hmfGain = 12.0f;
        ok &= expectDifferent ("HMF Gain", a, b, sine (2500.0f));
    }
    {
        auto a = eq, b = eq; a.hmfGain = b.hmfGain = 12.0f; a.hmfFreq = 900.0f; b.hmfFreq = 5000.0f;
        ok &= expectDifferent ("HMF Frequency", a, b, sine (2500.0f));
    }
    {
        auto a = eq, b = eq; a.hmfGain = b.hmfGain = 12.0f; a.hmfFreq = b.hmfFreq = 2500.0f; a.hmfQ = 0.4f; b.hmfQ = 4.0f;
        ok &= expectDifferent ("HMF Q", a, b, sine (1800.0f));
    }
    {
        auto a = eq, b = eq; a.lmfGain = -12.0f; b.lmfGain = 12.0f;
        ok &= expectDifferent ("LMF Gain", a, b, sine (500.0f));
    }
    {
        auto a = eq, b = eq; a.lmfGain = b.lmfGain = 12.0f; a.lmfFreq = 200.0f; b.lmfFreq = 1800.0f;
        ok &= expectDifferent ("LMF Frequency", a, b, sine (700.0f));
    }
    {
        auto a = eq, b = eq; a.lmfGain = b.lmfGain = 12.0f; a.lmfFreq = b.lmfFreq = 700.0f; a.lmfQ = 0.4f; b.lmfQ = 4.0f;
        ok &= expectDifferent ("LMF Q", a, b, sine (450.0f));
    }
    {
        auto a = eq, b = eq; a.lfGain = -12.0f; b.lfGain = 12.0f;
        ok &= expectDifferent ("LF Gain", a, b, sine (80.0f));
    }
    {
        auto a = eq, b = eq; a.lfGain = b.lfGain = 12.0f; a.lfFreq = 40.0f; b.lfFreq = 400.0f;
        ok &= expectDifferent ("LF Frequency", a, b, sine (120.0f));
    }
    {
        auto a = eq, b = eq; a.lfGain = b.lfGain = 12.0f; a.lfBell = false; b.lfBell = true;
        ok &= expectDifferent ("LF Bell", a, b, twoTone (60.0f, 400.0f));
    }

    DspEngine::Params dyn;
    dyn.eqOn = false;
    dyn.dynOn = true;
    dyn.compOn = true;
    dyn.compThresholdDb = -24.0f;
    dyn.compRatio = 10.0f;
    {
        auto a = dyn, b = dyn; a.dynOn = false;
        ok &= expectDifferent ("Dynamics IN", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compOn = false;
        ok &= expectDifferent ("Compressor IN", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compThresholdDb = -5.0f; b.compThresholdDb = -30.0f;
        ok &= expectDifferent ("Compressor Threshold", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compRatio = 1.2f; b.compRatio = 20.0f;
        ok &= expectDifferent ("Compressor Ratio", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compAttackMs = 0.1f; b.compAttackMs = 100.0f;
        ok &= expectDifferent ("Compressor Attack", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compReleaseSec = 0.05f; b.compReleaseSec = 4.0f;
        ok &= expectDifferent ("Compressor Release", a, b, burst());
    }
    {
        auto a = dyn, b = dyn; a.compAttackMs = b.compAttackMs = 40.0f; a.compFast = false; b.compFast = true;
        ok &= expectDifferent ("Compressor FAST", a, b, burst());
    }

    DspEngine::Params gate;
    gate.eqOn = false;
    gate.dynOn = true;
    gate.compOn = false;
    gate.gateOn = true;
    gate.gateThresholdDb = -20.0f;
    gate.gateRangeDb = 35.0f;
    {
        auto a = gate, b = gate; a.gateOn = false;
        ok &= expectDifferent ("Gate IN", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateThresholdDb = -45.0f; b.gateThresholdDb = -10.0f;
        ok &= expectDifferent ("Gate Threshold", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateRangeDb = 3.0f; b.gateRangeDb = 40.0f;
        ok &= expectDifferent ("Gate Range", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateAttackMs = 0.05f; b.gateAttackMs = 50.0f;
        ok &= expectDifferent ("Gate Attack", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateReleaseSec = 0.05f; b.gateReleaseSec = 4.0f;
        ok &= expectDifferent ("Gate Release", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateAttackMs = b.gateAttackMs = 30.0f; a.gateFast = false; b.gateFast = true;
        ok &= expectDifferent ("Gate FAST", a, b, gateSignal());
    }
    {
        auto a = gate, b = gate; a.gateExpand = false; b.gateExpand = true;
        ok &= expectDifferent ("Gate / Expand mode", a, b, gateSignal());
    }

    {
        DspEngine::Params a, b;
        a.eqOn = b.eqOn = true;
        a.hpOn = b.hpOn = true;
        a.hpFreq = b.hpFreq = 180.0f;
        a.lmfGain = b.lmfGain = 10.0f;
        a.lmfFreq = b.lmfFreq = 700.0f;
        a.dynOn = b.dynOn = true;
        a.compOn = b.compOn = true;
        a.compThresholdDb = b.compThresholdDb = -22.0f;
        a.compRatio = b.compRatio = 8.0f;
        a.routing = 0; b.routing = 2;
        ok &= expectDifferent ("Routing / Order", a, b, twoTone (90.0f, 700.0f));
    }
    {
        auto a = base, b = base; a.vcaFaderDb = -12.0f; b.vcaFaderDb = 8.0f;
        ok &= expectDifferent ("VCA Fader", a, b, sine (1000.0f, 0.8f));
    }
    {
        auto a = base, b = base; a.outputTrimDb = -12.0f; b.outputTrimDb = 12.0f;
        ok &= expectDifferent ("Output Trim", a, b, sine (1000.0f));
    }
    {
        auto a = dyn, b = dyn; a.mix = 0.0f; b.mix = 1.0f;
        ok &= expectDifferent ("Global Mix", a, b, burst());
    }
    {
        auto p = base; p.mute = true;
        const auto r = render (p, sine (1000.0f));
        if (rms (r) > 1.0e-7f) { std::cerr << "FAIL: Mute is not silent\n"; ok = false; }
        else std::cout << "PASS: Mute\n";
    }
    {
        auto a = dyn, b = dyn; a.bypass = true;
        ok &= expectDifferent ("Bypass", a, b, burst());
    }


    {
        DspEngine engineA, engineB;
        engineA.prepare (sampleRate, 4096, 2);
        engineB.prepare (sampleRate, 4096, 2);
        juce::AudioBuffer<float> aBuf (2, 4096), bBuf (2, 4096);
        for (int i = 0; i < 4096; ++i)
        {
            const float t = static_cast<float> (i) / static_cast<float> (sampleRate);
            const float l = 0.85f * std::sin (2.0f * pi * 220.0f * t);
            const float r = 0.35f * std::sin (2.0f * pi * 880.0f * t + 0.4f);
            aBuf.setSample (0, i, l); aBuf.setSample (1, i, r);
            bBuf.setSample (0, i, l); bBuf.setSample (1, i, r);
        }
        DspEngine::Params pa, pb;
        pa.eqOn = pb.eqOn = false;
        pa.dynOn = pb.dynOn = false;
        pa.inputDrive = pb.inputDrive = 85.0f;
        pa.channelMode = 0; pb.channelMode = 1;
        engineA.process (aBuf, pa);
        engineB.process (bBuf, pb);
        double d = 0.0;
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < 4096; ++i)
                d += std::abs (aBuf.getSample (ch, i) - bBuf.getSample (ch, i));
        d /= 8192.0;
        if (d <= 1.0e-5) { std::cerr << "FAIL: Channel Mode produced no DSP change\n"; ok = false; }
        else std::cout << "PASS: Channel Mode diff=" << d << "\n";
    }


    // Behavioural assertions: these catch parameters that move but act in the wrong direction.
    {
        DspEngine::Params brown, black;
        brown.eqOn = black.eqOn = false;
        brown.dynOn = black.dynOn = false;
        brown.hpOn = black.hpOn = true;
        brown.hpFreq = black.hpFreq = 160.0f;
        brown.blackEq = false; black.blackEq = true;
        const auto rb = render (brown, sine (50.0f));
        const auto rk = render (black, sine (50.0f));
        if (! (rms (rk) < rms (rb))) { std::cerr << "FAIL: Black HPF should be steeper than Brown HPF\n"; ok = false; }
        else std::cout << "PASS: Black/Brown HPF slope direction\n";
    }
    {
        DspEngine::Params clean, driven;
        clean.eqOn = driven.eqOn = false;
        clean.dynOn = driven.dynOn = false;
        clean.inputDrive = 0.0f; driven.inputDrive = 100.0f;
        const auto rc = render (clean, sine (1000.0f, 0.05f));
        const auto rd = render (driven, sine (1000.0f, 0.05f));
        const float ratio = rms (rd) / juce::jmax (1.0e-9f, rms (rc));
        if (ratio < 0.85f || ratio > 1.15f) { std::cerr << "FAIL: Input Drive is not sensibly gain compensated, ratio=" << ratio << "\n"; ok = false; }
        else std::cout << "PASS: Input Drive small-signal gain compensation ratio=" << ratio << "\n";
    }
    {
        DspEngine engineLow, engineHigh;
        engineLow.prepare (sampleRate, numSamples, 1);
        engineHigh.prepare (sampleRate, numSamples, 1);
        juce::AudioBuffer<float> a (1, numSamples), b (1, numSamples);
        for (int i = 0; i < numSamples; ++i)
        {
            const float v = sine (1000.0f, 0.9f) (i);
            a.setSample (0, i, v); b.setSample (0, i, v);
        }
        DspEngine::Params low, high;
        low.eqOn = high.eqOn = false;
        low.dynOn = high.dynOn = true;
        low.compOn = high.compOn = true;
        low.compThresholdDb = high.compThresholdDb = -18.0f;
        low.compRatio = 2.0f; high.compRatio = 10.0f;
        engineLow.process (a, low); engineHigh.process (b, high);
        if (! (engineHigh.getCompressorGainReductionDb() > engineLow.getCompressorGainReductionDb()))
        { std::cerr << "FAIL: Higher compressor ratio did not increase GR\n"; ok = false; }
        else std::cout << "PASS: Compressor ratio direction\n";
    }
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.inputDrive = 80.0f; p.vcaFaderDb = 5.0f;
        p.mix = 0.0f;
        const auto dry = render (p, twoTone (440.0f, 2200.0f));
        DspEngine::Params ref; ref.eqOn = false; ref.dynOn = false;
        const auto original = render (ref, twoTone (440.0f, 2200.0f));
        if (difference (dry, original) > 1.0e-6f) { std::cerr << "FAIL: Mix 0 is not dry/null-safe\n"; ok = false; }
        else std::cout << "PASS: Mix 0 dry path\n";
    }

    if (! ok)
        return 1;

    std::cout << "All visible v0.2.3 controls passed DSP smoke tests.\n";
    return 0;
}
