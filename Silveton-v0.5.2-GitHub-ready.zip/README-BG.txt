SILVETON CHANNEL STRIP v0.5.2 — FIXED APPROVED GUI

ЗАКЛЮЧЕНИ ПРАВИЛА:
- Одобрената 1536x1024 визия е точната bitmap основа.
- JUCE е wrapper/GUI/parameter/state слой; DSP остава собствен C++.
- Не се променят заключените v0.4.1 core DSP файлове.
- Всеки видим бутон, врътка, селектор и фейдър е реален JUCE/APVTS контрол.
- Live hit-region на всеки физически контрол е върху точното място от одобрената визия.
- GATE / EXPAND е реален двупозиционен режим; Gate power е отделен реален бутон.
- Compressor power и видимият IN бутон управляват реално compOn.
- HF/LF curve иконите са реалните shelf/bell бутони.
- HP/LP сините точки са реални on/off контроли.
- Output L/R meter измерва реалния обработен peak в dBFS.
- Gate/Compressor GR meter се задвижват от реалната gain reduction, включително extension корекцията.
- Meter refresh: 60 Hz.
- Workflow-ът fail-ва при липсващ контрол, грешен hit-region, счупена връзка, грешен meter calibration или променен approved skin.

Target: macOS 10.13+, Intel x86_64, VST3.

Качване в GitHub:
1) Silveton-v0.5.2-GitHub-ready.zip -> root на repo-то
2) build-silveton-v052-macos-intel.yml -> .github/workflows/
