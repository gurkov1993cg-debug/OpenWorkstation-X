SILVETON CHANNEL STRIP v0.5.2 — APPROVED SKIN BUILD

Тази версия използва буквално одобрената 1536x1024 визия като заключена bitmap основа.
Видимите контроли остават реално свързани с APVTS/DSP; не са фалшиви изображения.
Работещият v0.4.1 core DSP остава защитен; разширенията от успешния v0.5.1 са запазени.
Target: macOS 10.13+, Intel x86_64, VST3.

Качване в GitHub:
1) Silveton-v0.5.2-GitHub-ready.zip -> root на repo-то
2) build-silveton-v052-macos-intel.yml -> .github/workflows/
