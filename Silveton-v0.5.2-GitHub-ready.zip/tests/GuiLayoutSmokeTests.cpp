#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <iostream>
#include <vector>
#include <functional>

namespace
{
    struct Failure
    {
        int count = 0;
        void require (bool ok, const juce::String& message)
        {
            if (! ok)
            {
                ++count;
                std::cerr << "FAIL: " << message << "\n";
            }
        }
    };

    juce::Component* findByIdRecursive (juce::Component& parent, const juce::String& id)
    {
        if (parent.getComponentID() == id)
            return &parent;
        for (int i = 0; i < parent.getNumChildComponents(); ++i)
            if (auto* c = parent.getChildComponent (i))
                if (auto* found = findByIdRecursive (*c, id))
                    return found;
        return nullptr;
    }

    void collectPrefixRecursive (juce::Component& parent, const juce::String& prefix,
                                 std::vector<juce::Component*>& out)
    {
        if (parent.getComponentID().startsWith (prefix))
            out.push_back (&parent);
        for (int i = 0; i < parent.getNumChildComponents(); ++i)
            if (auto* c = parent.getChildComponent (i))
                collectPrefixRecursive (*c, prefix, out);
    }

    bool hitResolvesTo (juce::Component& editor, const juce::String& componentId, juce::Point<int> point)
    {
        auto* target = findByIdRecursive (editor, componentId);
        if (target == nullptr)
            return false;
        auto* hit = editor.getComponentAt (point);
        for (auto* c = hit; c != nullptr; c = c->getParentComponent())
            if (c == target)
                return true;
        return false;
    }

    bool exerciseParameterControl (juce::AudioProcessorEditor& editor,
                                   juce::AudioProcessorValueTreeState& apvts,
                                   const juce::String& id)
    {
        auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (apvts.getParameter (id));
        if (parameter == nullptr)
            return false;

        const float before = parameter->getValue();

        if (auto* c = findByIdRecursive (editor, id))
        {
            if (auto* slider = dynamic_cast<juce::Slider*> (c))
            {
                const double lo = slider->getMinimum();
                const double hi = slider->getMaximum();
                const double mid = (lo + hi) * 0.5;
                double target = slider->getValue() <= mid ? hi : lo;
                if (std::abs (target - slider->getValue()) < 1.0e-9)
                    target = mid;
                slider->setValue (target, juce::sendNotificationSync);
            }
            else if (auto* button = dynamic_cast<juce::TextButton*> (c))
            {
                button->setToggleState (! button->getToggleState(), juce::sendNotificationSync);
            }
            else
            {
                return false;
            }
        }
        else
        {
            std::vector<juce::Component*> choices;
            collectPrefixRecursive (editor, id + "__", choices);
            if (choices.size() < 2)
                return false;

            const int raw = (int) std::lround (apvts.getRawParameterValue (id)->load());
            int targetVisual = 0;
            if (id == "compPeak")
                targetVisual = raw == 1 ? 1 : 0;
            else
                targetVisual = raw == 0 ? 1 : 0;

            const juce::String targetId = id + "__" + juce::String (targetVisual);
            auto* target = findByIdRecursive (editor, targetId);
            auto* button = dynamic_cast<juce::TextButton*> (target);
            if (button == nullptr)
                return false;
            if (button->onClick) button->onClick();
        }

        const float after = parameter->getValue();
        parameter->setValueNotifyingHost (before);
        return std::abs (after - before) > 1.0e-6f;
    }
    void setActual (ConsoleChannelStripXAudioProcessor& p, const char* id, float actual)
    {
        if (auto* rp = dynamic_cast<juce::RangedAudioParameter*> (p.parameters().getParameter (id)))
            rp->setValueNotifyingHost (rp->convertTo0to1 (actual));
    }

    void neutralise (ConsoleChannelStripXAudioProcessor& p)
    {
        setActual (p, "inputOn", 1.0f); setActual (p, "inputDrive", 0.0f); setActual (p, "inputTrim", 0.0f);
        setActual (p, "inputMode", 0.0f); setActual (p, "inputPad", 0.0f); setActual (p, "polarity", 0.0f);

        setActual (p, "filtersOn", 0.0f); setActual (p, "hpOn", 0.0f); setActual (p, "lpOn", 0.0f);
        setActual (p, "hpSlope", 1.0f); setActual (p, "lpSlope", 1.0f);

        setActual (p, "eqOn", 0.0f); setActual (p, "hfGain", 0.0f); setActual (p, "hmfGain", 0.0f);
        setActual (p, "lmfGain", 0.0f); setActual (p, "lfGain", 0.0f); setActual (p, "hfBell", 0.0f); setActual (p, "lfBell", 0.0f);

        setActual (p, "dynOn", 0.0f); setActual (p, "compOn", 0.0f); setActual (p, "gateOn", 0.0f);
        setActual (p, "compFast", 0.0f); setActual (p, "gateFast", 0.0f); setActual (p, "gateExpand", 0.0f); setActual (p, "compMakeup", 0.0f);

        setActual (p, "saturationOn", 0.0f); setActual (p, "satTone", 0.0f); setActual (p, "satOutputTrim", 0.0f);
        setActual (p, "stereoOn", 0.0f); setActual (p, "stereoWidth", 0.0f); setActual (p, "pan", 0.0f);
        setActual (p, "stereoFocus", 120.0f); setActual (p, "stereoBalance", 0.0f); setActual (p, "stereoDetune", 0.0f);
        setActual (p, "stereoDelay", 0.0f); setActual (p, "bassMono", 0.0f); setActual (p, "stereoMode", 0.0f);

        setActual (p, "outputOn", 1.0f); setActual (p, "vcaFader", 0.0f); setActual (p, "outputTrim", 0.0f);
        setActual (p, "autoLevel", 0.0f); setActual (p, "mix", 100.0f); setActual (p, "mute", 0.0f); setActual (p, "bypass", 0.0f);
    }

    struct Rendered
    {
        std::vector<float> l, r;
    };

    Rendered render (const std::function<void(ConsoleChannelStripXAudioProcessor&)>& setup,
                     const std::function<void(juce::AudioBuffer<float>&, double)>& fill)
    {
        constexpr int n = 2048;
        constexpr double fs = 48000.0;
        ConsoleChannelStripXAudioProcessor p;
        neutralise (p);
        setup (p);
        p.prepareToPlay (fs, n);
        juce::AudioBuffer<float> b (2, n);
        b.clear();
        fill (b, fs);
        juce::MidiBuffer midi;
        p.processBlock (b, midi);
        Rendered out;
        out.l.assign (b.getReadPointer (0), b.getReadPointer (0) + n);
        out.r.assign (b.getReadPointer (1), b.getReadPointer (1) + n);
        return out;
    }

    void fillSine (juce::AudioBuffer<float>& b, double fs, float hz, float amp,
                   bool antiPhase = false)
    {
        for (int n = 0; n < b.getNumSamples(); ++n)
        {
            const float x = amp * std::sin (2.0 * juce::MathConstants<double>::pi * (double) hz * (double) n / fs);
            b.setSample (0, n, x);
            b.setSample (1, n, antiPhase ? -x : x);
        }
    }

    float meanAbsDiff (const std::vector<float>& a, const std::vector<float>& b, int start = 96)
    {
        const int n = (int) juce::jmin (a.size(), b.size());
        if (n <= start) return 0.0f;
        double sum = 0.0;
        for (int i = start; i < n; ++i) sum += std::abs ((double) a[(size_t) i] - (double) b[(size_t) i]);
        return (float) (sum / (double) (n - start));
    }

    float rms (const std::vector<float>& a, int start = 96, int end = -1)
    {
        if (end < 0 || end > (int) a.size()) end = (int) a.size();
        if (end <= start) return 0.0f;
        double sum = 0.0;
        for (int i = start; i < end; ++i) sum += (double) a[(size_t) i] * (double) a[(size_t) i];
        return (float) std::sqrt (sum / (double) (end - start));
    }

}

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;
    Failure f;
    ConsoleChannelStripXAudioProcessor processor;
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());

    f.require (editor != nullptr, "editor was not created");
    if (editor == nullptr) return 1;

    // JUCE components default to non-visible. A host makes AudioProcessorEditor
    // visible before real mouse hit-testing, so mirror that state in this test.
    editor->setVisible (true);

    f.require (editor->getWidth() == 1536 && editor->getHeight() == 1024,
               "approved Silveton design surface must be exactly 1536x1024");

    const std::vector<juce::String> visibleParameterIds {
        "mix",
        "inputOn", "inputDrive", "inputMode", "polarity", "inputPad", "inputTrim",
        "filtersOn", "hpOn", "hpFreq", "hpSlope", "lpOn", "lpFreq", "lpSlope",
        "eqOn", "hfFreq", "hfGain", "hfQ", "hmfFreq", "hmfGain", "hmfQ",
        "lmfFreq", "lmfGain", "lmfQ", "lfFreq", "lfGain", "lfQ", "hfBell", "lfBell",
        "dynOn", "gateOn", "gateExpand", "gateFast", "gateThreshold", "gateRange", "gateAttack", "gateRelease",
        "compOn", "compPeak", "compFast", "compThreshold", "compRatio", "compAttack", "compRelease", "compKnee", "compMakeup",
        "saturationOn", "satType", "satGain", "saturation", "satTone", "satMix", "satCharacter", "satOutputTrim",
        "stereoOn", "stereoMode", "stereoWidth", "pan", "stereoFocus", "stereoBalance", "stereoDetune", "stereoDelay", "bassMono",
        "outputOn", "vcaFader", "autoLevel"
    };

    f.require ((int) visibleParameterIds.size() == 66, "expected 66 approved visible parameter controls");

    for (const auto& id : visibleParameterIds)
    {
        auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter (id));
        f.require (parameter != nullptr, "missing APVTS parameter: " + id);

        auto* direct = findByIdRecursive (*editor, id);
        std::vector<juce::Component*> choices;
        collectPrefixRecursive (*editor, id + "__", choices);
        const bool exists = direct != nullptr || ! choices.empty();
        f.require (exists, "missing visible GUI control: " + id);

        if (direct != nullptr)
            f.require (direct->getWidth() > 0 && direct->getHeight() > 0, "control has zero bounds: " + id);
        else
            for (auto* c : choices)
                f.require (c->getWidth() > 0 && c->getHeight() > 0, "choice control has zero bounds: " + c->getComponentID());

        if (exists && parameter != nullptr)
            f.require (exerciseParameterControl (*editor, processor.parameters(), id),
                       "control is not functionally attached: " + id);
    }

    // Approved-face hit map. A control is not accepted merely because it exists:
    // the live JUCE hit region must sit exactly under the visible control in the 1536x1024 skin.
    struct HitTarget { const char* id; int x; int y; };
    const HitTarget approvedHits[] {
        { "actionPrevPreset", 565, 42 }, { "presetBox", 748, 42 }, { "actionNextPreset", 924, 42 },
        { "actionAB", 1011, 44 }, { "actionUndo", 1093, 44 }, { "actionRedo", 1169, 44 },
        { "actionMenu", 1232, 44 }, { "mix", 1419, 45 }, { "actionSettings", 1490, 42 },

        { "inputOn", 25, 116 }, { "inputDrive", 83, 250 },
        { "inputMode__0", 52, 394 }, { "inputMode__1", 119, 394 },
        { "polarity", 51, 447 }, { "inputPad", 119, 447 }, { "inputTrim", 86, 670 },

        { "filtersOn", 190, 116 }, { "hpOn", 193, 174 }, { "hpFreq", 249, 300 },
        { "hpSlope__0", 202, 414 }, { "hpSlope__1", 249, 414 }, { "hpSlope__2", 296, 414 },
        { "lpOn", 193, 502 }, { "lpFreq", 249, 630 },
        { "lpSlope__0", 202, 745 }, { "lpSlope__1", 249, 745 }, { "lpSlope__2", 296, 745 },

        { "eqOn", 353, 116 }, { "hfBell", 357, 223 },
        { "hfFreq", 415, 250 }, { "hfGain", 500, 250 }, { "hfQ", 580, 250 },
        { "hmfFreq", 415, 435 }, { "hmfGain", 500, 435 }, { "hmfQ", 580, 435 },
        { "lmfFreq", 415, 622 }, { "lmfGain", 500, 622 }, { "lmfQ", 580, 622 },
        { "lfBell", 357, 783 }, { "lfFreq", 415, 805 }, { "lfGain", 500, 805 }, { "lfQ", 580, 805 },

        { "dynOn", 650, 116 }, { "gateOn", 650, 163 },
        { "gateExpand__0", 678, 203 }, { "gateExpand__1", 750, 203 }, { "gateFast", 822, 203 },
        { "gateThreshold", 685, 305 }, { "gateRange", 798, 305 }, { "gateAttack", 685, 444 }, { "gateRelease", 798, 444 },
        { "compOn", 650, 533 }, { "compOn__in", 677, 572 },
        { "compPeak__0", 746, 572 }, { "compPeak__1", 819, 572 }, { "compFast", 888, 572 },
        { "compThreshold", 678, 664 }, { "compRatio", 744, 664 }, { "compAttack", 816, 664 }, { "compRelease", 886, 664 },
        { "compKnee", 684, 814 }, { "compMakeup", 787, 814 },

        { "saturationOn", 954, 116 },
        { "satType__0", 974, 181 }, { "satType__1", 1039, 181 }, { "satType__2", 1104, 181 },
        { "satGain", 986, 307 }, { "saturation", 1090, 307 }, { "satTone", 986, 481 }, { "satMix", 1090, 481 },
        { "satCharacter__0", 975, 646 }, { "satCharacter__1", 1040, 646 }, { "satCharacter__2", 1105, 646 },
        { "satOutputTrim", 1039, 792 },

        { "stereoOn", 1168, 116 }, { "stereoMode__0", 1215, 204 }, { "stereoMode__1", 1314, 204 },
        { "stereoWidth", 1206, 352 }, { "pan", 1317, 352 }, { "stereoFocus", 1206, 559 }, { "stereoBalance", 1317, 559 },
        { "stereoDetune", 1206, 742 }, { "stereoDelay", 1317, 742 },
        { "bassMono__0", 1184, 888 }, { "bassMono__1", 1236, 888 }, { "bassMono__2", 1289, 888 }, { "bassMono__3", 1341, 888 },

        { "outputOn", 1404, 116 }, { "vcaFader", 1456, 257 }, { "autoLevel", 1456, 800 }
    };
    for (const auto& h : approvedHits)
        f.require (hitResolvesTo (*editor, h.id, { h.x, h.y }),
                   "approved visible control has wrong hit region: " + juce::String (h.id));

    // The approved compressor has both a power icon and an IN key. Both must control compOn.
    if (auto* compIn = dynamic_cast<juce::TextButton*> (findByIdRecursive (*editor, "compOn__in")))
    {
        auto* compOn = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter ("compOn"));
        f.require (compOn != nullptr, "compOn parameter missing for IN mirror");
        if (compOn != nullptr)
        {
            const float before = compOn->getValue();
            compIn->setToggleState (! compIn->getToggleState(), juce::sendNotificationSync);
            const float after = compOn->getValue();
            f.require (std::abs (after - before) > 1.0e-6f, "Compressor IN key is not attached to compOn");
            compOn->setValueNotifyingHost (before);
        }
    }
    else
    {
        f.require (false, "approved Compressor IN key is missing");
    }

    // Legacy parameters intentionally hidden from the approved face remain available to hosts/menu actions.
    for (const auto& id : { "eqModel", "routing", "mute", "bypass", "gateHold", "outputTrim" })
        f.require (processor.parameters().getParameter (id) != nullptr, "legacy parameter was removed: " + juce::String (id));

    for (const auto& action : { "actionPrevPreset", "actionNextPreset", "actionAB", "actionUndo", "actionRedo", "actionMenu", "actionSettings", "presetBox" })
    {
        auto* c = findByIdRecursive (*editor, action);
        f.require (c != nullptr, "missing header action: " + juce::String (action));
        if (c != nullptr)
            f.require (c->getWidth() > 0 && c->getHeight() > 0, "header action has zero bounds: " + juce::String (action));
    }

    // Preset action must change a real parameter.
    if (auto* box = dynamic_cast<juce::ComboBox*> (findByIdRecursive (*editor, "presetBox")))
    {
        auto* threshold = processor.parameters().getRawParameterValue ("compThreshold");
        box->setSelectedId (1, juce::sendNotificationSync);
        const float before = threshold != nullptr ? threshold->load() : 0.0f;
        box->setSelectedId (2, juce::sendNotificationSync);
        const float after = threshold != nullptr ? threshold->load() : 0.0f;
        f.require (std::abs (after - before) > 1.0e-5f, "Vocal preset did not drive APVTS parameters");
    }

    // A/B action must store the active slot and recall the other slot.
    if (auto* ab = dynamic_cast<juce::TextButton*> (findByIdRecursive (*editor, "actionAB")))
    {
        auto* drive = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter ("inputDrive"));
        if (drive != nullptr)
        {
            drive->setValueNotifyingHost (drive->convertTo0to1 (12.0f));
            if (ab->onClick) ab->onClick();
            const float recalled = processor.parameters().getRawParameterValue ("inputDrive")->load();
            f.require (std::abs (recalled - 12.0f) > 0.5f, "A/B did not recall alternate state");
        }
    }


    // Audio-level extension tests: every new approved control family must alter the signal, not only APVTS state.
    {
        const auto hp6 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "hpOn", 1); setActual (p, "hpFreq", 120); setActual (p, "hpSlope", 0); },
                                 [] (auto& b, double fs) { fillSine (b, fs, 45.0f, 0.2f); });
        const auto hp24 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "hpOn", 1); setActual (p, "hpFreq", 120); setActual (p, "hpSlope", 2); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 45.0f, 0.2f); });
        f.require (std::abs (rms (hp6.l) - rms (hp24.l)) > 1.0e-4f, "HP 6/12/24 slope selector has no audio effect");

        const auto lp6 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "lpOn", 1); setActual (p, "lpFreq", 6000); setActual (p, "lpSlope", 0); },
                                 [] (auto& b, double fs) { fillSine (b, fs, 15000.0f, 0.2f); });
        const auto lp24 = render ([] (auto& p) { setActual (p, "filtersOn", 1); setActual (p, "lpOn", 1); setActual (p, "lpFreq", 6000); setActual (p, "lpSlope", 2); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 15000.0f, 0.2f); });
        f.require (std::abs (rms (lp6.l) - rms (lp24.l)) > 1.0e-4f, "LP 6/12/24 slope selector has no audio effect");

        const auto hfQlo = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "hfBell", 1); setActual (p, "hfFreq", 8000); setActual (p, "hfGain", 8); setActual (p, "hfQ", 0.4f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 8000.0f, 0.08f); });
        const auto hfQhi = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "hfBell", 1); setActual (p, "hfFreq", 8000); setActual (p, "hfGain", 8); setActual (p, "hfQ", 2.8f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 8000.0f, 0.08f); });
        f.require (meanAbsDiff (hfQlo.l, hfQhi.l) > 1.0e-5f, "HF Q has no audio effect");

        const auto lfQlo = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "lfBell", 1); setActual (p, "lfFreq", 100); setActual (p, "lfGain", 8); setActual (p, "lfQ", 0.4f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 100.0f, 0.08f); });
        const auto lfQhi = render ([] (auto& p) { setActual (p, "eqOn", 1); setActual (p, "lfBell", 1); setActual (p, "lfFreq", 100); setActual (p, "lfGain", 8); setActual (p, "lfQ", 2.8f); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 100.0f, 0.08f); });
        f.require (meanAbsDiff (lfQlo.l, lfQhi.l) > 1.0e-5f, "LF Q has no audio effect");

        const auto attackFast = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -24); setActual (p, "compRatio", 10); setActual (p, "compAttack", 1); setActual (p, "compKnee", 0); },
                                        [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<300?0.0f:0.35f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        const auto attackSlow = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -24); setActual (p, "compRatio", 10); setActual (p, "compAttack", 80); setActual (p, "compKnee", 0); },
                                        [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<300?0.0f:0.35f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        f.require (meanAbsDiff (attackFast.l, attackSlow.l, 350) > 1.0e-5f, "Compressor ATTACK knob has no audio effect");

        const auto kneeHard = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -18); setActual (p, "compRatio", 4); setActual (p, "compAttack", 10); setActual (p, "compKnee", 0); },
                                       [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.14f); });
        const auto kneeSoft = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compThreshold", -18); setActual (p, "compRatio", 4); setActual (p, "compAttack", 10); setActual (p, "compKnee", 100); },
                                       [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.14f); });
        f.require (meanAbsDiff (kneeHard.l, kneeSoft.l) > 1.0e-6f, "Compressor KNEE knob has no audio effect");

        const auto makeup0 = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compMakeup", 0); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.08f); });
        const auto makeup6 = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "compOn", 1); setActual (p, "compMakeup", 6); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.08f); });
        f.require (rms (makeup6.l) > rms (makeup0.l) * 1.3f, "Compressor MAKEUP knob has no audio effect");

        const auto gateFast = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "gateOn", 1); setActual (p, "gateThreshold", -30); setActual (p, "gateRange", 40); setActual (p, "gateAttack", 0.2f); },
                                      [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<400?0.0f:0.2f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        const auto gateSlow = render ([] (auto& p) { setActual (p, "dynOn", 1); setActual (p, "gateOn", 1); setActual (p, "gateThreshold", -30); setActual (p, "gateRange", 40); setActual (p, "gateAttack", 200.0f); },
                                      [] (auto& b, double) { for (int n=0;n<b.getNumSamples();++n) { float x=n<400?0.0f:0.2f; b.setSample(0,n,x); b.setSample(1,n,x); } });
        f.require (meanAbsDiff (gateFast.l, gateSlow.l, 460) > 1.0e-5f, "Gate ATTACK knob has no audio effect");

        const auto tube = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satType", 0); setActual (p, "satGain", 8); setActual (p, "saturation", 70); setActual (p, "satMix", 100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto tape = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satType", 1); setActual (p, "satGain", 8); setActual (p, "saturation", 70); setActual (p, "satMix", 100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (tube.l, tape.l) > 1.0e-5f, "Saturation TYPE selector has no audio effect");

        const auto dark = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "saturation", 40); setActual (p, "satTone", -100); },
                                  [] (auto& b, double fs) { fillSine (b, fs, 9000.0f, 0.08f); });
        const auto bright = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "saturation", 40); setActual (p, "satTone", 100); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 9000.0f, 0.08f); });
        f.require (meanAbsDiff (dark.l, bright.l) > 1.0e-5f, "Saturation TONE knob has no audio effect");

        const auto satDry = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satGain", 10); setActual (p, "saturation", 80); setActual (p, "satMix", 0); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto satWet = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satGain", 10); setActual (p, "saturation", 80); setActual (p, "satMix", 100); },
                                    [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (satDry.l, satWet.l) > 1.0e-5f, "Saturation MIX knob has no audio effect");

        const auto clean = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satCharacter", 0); setActual (p, "saturation", 70); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        const auto aggressive = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satCharacter", 2); setActual (p, "saturation", 70); },
                                        [] (auto& b, double fs) { fillSine (b, fs, 997.0f, 0.25f); });
        f.require (meanAbsDiff (clean.l, aggressive.l) > 1.0e-5f, "Saturation CHARACTER selector has no audio effect");

        const auto trim0 = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satOutputTrim", 0); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.05f); });
        const auto trim6 = render ([] (auto& p) { setActual (p, "saturationOn", 1); setActual (p, "satOutputTrim", 6); },
                                   [] (auto& b, double fs) { fillSine (b, fs, 1000.0f, 0.05f); });
        f.require (rms (trim6.l) > rms (trim0.l) * 1.3f, "Saturation OUTPUT TRIM has no audio effect");

        const auto stereoMode = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "stereoMode", 0); setActual (p, "stereoBalance", 0.75f); },
                                        [] (auto& b, double fs) { for(int n=0;n<b.getNumSamples();++n){ float l=0.12f*std::sin(2.0*juce::MathConstants<double>::pi*700*n/fs); float r=0.08f*std::cos(2.0*juce::MathConstants<double>::pi*1100*n/fs); b.setSample(0,n,l); b.setSample(1,n,r);} });
        const auto midSideMode = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "stereoMode", 1); setActual (p, "stereoBalance", 0.75f); },
                                         [] (auto& b, double fs) { for(int n=0;n<b.getNumSamples();++n){ float l=0.12f*std::sin(2.0*juce::MathConstants<double>::pi*700*n/fs); float r=0.08f*std::cos(2.0*juce::MathConstants<double>::pi*1100*n/fs); b.setSample(0,n,l); b.setSample(1,n,r);} });
        f.require (meanAbsDiff (stereoMode.l, midSideMode.l) > 1.0e-5f, "STEREO / MID-SIDE mode selector has no audio effect");

        const auto bassOff = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "bassMono", 0); },
                                     [] (auto& b, double fs) { fillSine (b, fs, 70.0f, 0.12f, true); });
        const auto bassMono = render ([] (auto& p) { setActual (p, "stereoOn", 1); setActual (p, "bassMono", 3); },
                                      [] (auto& b, double fs) { fillSine (b, fs, 70.0f, 0.12f, true); });
        f.require (rms (bassMono.l) < rms (bassOff.l) * 0.8f, "BASS MONO selector does not collapse low-frequency side energy");
    }

    // Exhaustive audio audit for every approved EFFECT control family.
    // Each test compares two real processBlock renders with all required parent sections enabled.
    {
        auto audible = [&f] (const char* name,
                             const std::function<void(ConsoleChannelStripXAudioProcessor&)>& a,
                             const std::function<void(ConsoleChannelStripXAudioProcessor&)>& b,
                             const std::function<void(juce::AudioBuffer<float>&, double)>& fill,
                             float eps = 1.0e-7f)
        {
            const auto ra = render (a, fill);
            const auto rb = render (b, fill);
            const float d = meanAbsDiff (ra.l, rb.l) + meanAbsDiff (ra.r, rb.r);
            f.require (std::isfinite (d) && d > eps, juce::String (name) + " does not alter processed audio");
        };

        const auto sine1k = [] (auto& x, double fs) { fillSine (x, fs, 1000.0f, 0.12f); };
        const auto sine50 = [] (auto& x, double fs) { fillSine (x, fs, 50.0f, 0.12f); };
        const auto sine100 = [] (auto& x, double fs) { fillSine (x, fs, 100.0f, 0.12f); };
        const auto sine500 = [] (auto& x, double fs) { fillSine (x, fs, 500.0f, 0.12f); };
        const auto sine2500 = [] (auto& x, double fs) { fillSine (x, fs, 2500.0f, 0.12f); };
        const auto sine8k = [] (auto& x, double fs) { fillSine (x, fs, 8000.0f, 0.12f); };
        const auto sine15k = [] (auto& x, double fs) { fillSine (x, fs, 15000.0f, 0.12f); };
        const auto stereoSignal = [] (juce::AudioBuffer<float>& x, double fs) {
            for (int n = 0; n < x.getNumSamples(); ++n) {
                const float l = 0.12f * std::sin (2.0 * juce::MathConstants<double>::pi * 700.0 * n / fs);
                const float r = 0.08f * std::cos (2.0 * juce::MathConstants<double>::pi * 1300.0 * n / fs);
                x.setSample (0, n, l); x.setSample (1, n, r);
            }
        };
        const auto transient = [] (auto& x, double) {
            for (int n = 0; n < x.getNumSamples(); ++n) {
                const float v = (n % 256) < 24 ? 0.45f : 0.025f;
                x.setSample (0, n, v); x.setSample (1, n, v * 0.83f);
            }
        };
        const auto gateReleaseSignal = [] (juce::AudioBuffer<float>& x, double fs) {
            for (int n = 0; n < x.getNumSamples(); ++n) {
                const float amp = n < 160 ? 0.20f : 0.002f;
                const float v = amp * (float) std::sin (2.0 * juce::MathConstants<double>::pi * 1000.0 * (double) n / fs);
                x.setSample (0, n, v); x.setSample (1, n, v);
            }
        };

        // INPUT
        audible ("inputOn", [] (auto& p){ setActual(p,"inputOn",0); setActual(p,"inputTrim",12); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputTrim",12); }, sine1k);
        audible ("inputDrive", [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputDrive",-12); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputDrive",18); }, sine1k);
        audible ("inputMode", [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputMode",0); setActual(p,"inputDrive",8); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputMode",1); setActual(p,"inputDrive",8); }, sine1k);
        audible ("polarity", [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"polarity",0); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"polarity",1); }, sine1k);
        audible ("inputPad", [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputPad",0); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputPad",1); }, sine1k);
        audible ("inputTrim", [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputTrim",-12); }, [] (auto& p){ setActual(p,"inputOn",1); setActual(p,"inputTrim",12); }, sine1k);

        // FILTERS
        audible ("filtersOn", [] (auto& p){ setActual(p,"filtersOn",0); setActual(p,"hpOn",1); setActual(p,"hpFreq",180); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",180); }, sine50);
        audible ("hpOn", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",0); setActual(p,"hpFreq",180); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",180); }, sine50);
        audible ("hpFreq", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",30); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",250); }, sine50);
        audible ("hpSlope", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",120); setActual(p,"hpSlope",0); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"hpOn",1); setActual(p,"hpFreq",120); setActual(p,"hpSlope",2); }, sine50);
        audible ("lpOn", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",0); setActual(p,"lpFreq",5000); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",1); setActual(p,"lpFreq",5000); }, sine15k);
        audible ("lpFreq", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",1); setActual(p,"lpFreq",4000); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",1); setActual(p,"lpFreq",18000); }, sine15k);
        audible ("lpSlope", [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",1); setActual(p,"lpFreq",6000); setActual(p,"lpSlope",0); }, [] (auto& p){ setActual(p,"filtersOn",1); setActual(p,"lpOn",1); setActual(p,"lpFreq",6000); setActual(p,"lpSlope",2); }, sine15k);

        // EQ outer and mid bands
        audible ("eqOn", [] (auto& p){ setActual(p,"eqOn",0); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",12); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",12); }, sine2500);
        audible ("hfFreq", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfGain",12); setActual(p,"hfFreq",3000); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfGain",12); setActual(p,"hfFreq",10000); }, sine8k);
        audible ("hfGain", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",-12); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",12); }, sine8k);
        audible ("hfQ", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",10); setActual(p,"hfQ",0.3f); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfBell",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",10); setActual(p,"hfQ",3.0f); }, sine8k);
        audible ("hfBell", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",10); setActual(p,"hfBell",0); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hfFreq",8000); setActual(p,"hfGain",10); setActual(p,"hfBell",1); }, sine8k);
        audible ("hmfFreq", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfGain",12); setActual(p,"hmfFreq",900); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfGain",12); setActual(p,"hmfFreq",2500); }, sine2500);
        audible ("hmfGain", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",-12); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",12); }, sine2500);
        audible ("hmfQ", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",10); setActual(p,"hmfQ",0.2f); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"hmfFreq",2500); setActual(p,"hmfGain",10); setActual(p,"hmfQ",3.2f); }, sine2500);
        audible ("lmfFreq", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfGain",12); setActual(p,"lmfFreq",250); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfGain",12); setActual(p,"lmfFreq",1200); }, sine500);
        audible ("lmfGain", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfFreq",500); setActual(p,"lmfGain",-12); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfFreq",500); setActual(p,"lmfGain",12); }, sine500);
        audible ("lmfQ", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfFreq",500); setActual(p,"lmfGain",10); setActual(p,"lmfQ",0.2f); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lmfFreq",500); setActual(p,"lmfGain",10); setActual(p,"lmfQ",3.2f); }, sine500);
        audible ("lfFreq", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfGain",12); setActual(p,"lfFreq",50); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfGain",12); setActual(p,"lfFreq",250); }, sine100);
        audible ("lfGain", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",-12); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",12); }, sine100);
        audible ("lfQ", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",10); setActual(p,"lfQ",0.3f); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfBell",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",10); setActual(p,"lfQ",3.0f); }, sine100);
        audible ("lfBell", [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",10); setActual(p,"lfBell",0); }, [] (auto& p){ setActual(p,"eqOn",1); setActual(p,"lfFreq",100); setActual(p,"lfGain",10); setActual(p,"lfBell",1); }, sine100);

        // DYNAMICS
        audible ("dynOn", [] (auto& p){ setActual(p,"dynOn",0); setActual(p,"compOn",1); setActual(p,"compThreshold",-30); setActual(p,"compRatio",10); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-30); setActual(p,"compRatio",10); }, sine1k);
        audible ("compOn", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",0); setActual(p,"compThreshold",-30); setActual(p,"compRatio",10); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-30); setActual(p,"compRatio",10); }, sine1k);
        audible ("compThreshold", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-6); setActual(p,"compRatio",10); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-30); setActual(p,"compRatio",10); }, sine1k);
        audible ("compRatio", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",1); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",20); }, sine1k);
        audible ("compAttack", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compAttack",0.2f); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compAttack",100); }, transient);
        audible ("compRelease", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compRelease",0.1f); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compRelease",4.0f); }, transient);
        audible ("compKnee", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-18); setActual(p,"compRatio",4); setActual(p,"compKnee",0); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-18); setActual(p,"compRatio",4); setActual(p,"compKnee",100); }, sine1k);
        audible ("compMakeup", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compMakeup",-6); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compMakeup",6); }, sine1k);
        audible ("compFast", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compFast",0); setActual(p,"compAttack",80); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compFast",1); setActual(p,"compAttack",80); }, transient);
        audible ("compPeak", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compPeak",0); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"compOn",1); setActual(p,"compThreshold",-24); setActual(p,"compRatio",10); setActual(p,"compPeak",1); }, transient);
        audible ("gateOn", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",0); setActual(p,"gateHold",0); setActual(p,"gateRelease",0.01f); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateHold",0); setActual(p,"gateRelease",0.01f); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); }, [] (auto& x,double fs){ fillSine(x,fs,1000,0.005f); });
        audible ("gateThreshold", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-60); setActual(p,"gateRange",50); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-20); setActual(p,"gateRange",50); }, [] (auto& x,double fs){ fillSine(x,fs,1000,0.02f); });
        audible ("gateRange", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-20); setActual(p,"gateRange",0); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-20); setActual(p,"gateRange",60); }, [] (auto& x,double fs){ fillSine(x,fs,1000,0.005f); });
        audible ("gateAttack", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateAttack",0.1f); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateAttack",1000); }, transient);
        audible ("gateRelease", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateHold",0); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateRelease",0.01f); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateHold",0); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateRelease",5.0f); }, gateReleaseSignal);
        audible ("gateFast", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateFast",0); setActual(p,"gateAttack",200); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-30); setActual(p,"gateRange",50); setActual(p,"gateFast",1); setActual(p,"gateAttack",200); }, transient);
        audible ("gateExpand", [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-20); setActual(p,"gateRange",50); setActual(p,"gateExpand",0); }, [] (auto& p){ setActual(p,"dynOn",1); setActual(p,"gateOn",1); setActual(p,"gateThreshold",-20); setActual(p,"gateRange",50); setActual(p,"gateExpand",1); }, [] (auto& x,double fs){ fillSine(x,fs,1000,0.005f); });

        // SATURATION
        audible ("saturationOn", [] (auto& p){ setActual(p,"saturationOn",0); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",12); setActual(p,"saturation",90); }, sine1k);
        audible ("satType", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satType",0); setActual(p,"satGain",10); setActual(p,"saturation",80); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satType",2); setActual(p,"satGain",10); setActual(p,"saturation",80); }, sine1k);
        audible ("satGain", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",-12); setActual(p,"saturation",80); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",18); setActual(p,"saturation",80); }, sine1k);
        audible ("saturation", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"saturation",0); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"saturation",100); setActual(p,"satGain",12); }, sine1k);
        audible ("satTone", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"saturation",60); setActual(p,"satTone",-100); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"saturation",60); setActual(p,"satTone",100); }, sine8k);
        audible ("satMix", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",12); setActual(p,"saturation",90); setActual(p,"satMix",0); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",12); setActual(p,"saturation",90); setActual(p,"satMix",100); }, sine1k);
        audible ("satCharacter", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satCharacter",0); setActual(p,"saturation",80); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satCharacter",2); setActual(p,"saturation",80); }, sine1k);
        audible ("satOutputTrim", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satOutputTrim",-12); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satOutputTrim",12); }, sine1k);

        // STEREO
        audible ("stereoOn", [] (auto& p){ setActual(p,"stereoOn",0); setActual(p,"pan",0.8f); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"pan",0.8f); }, stereoSignal);
        audible ("stereoMode", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoMode",0); setActual(p,"stereoBalance",0.7f); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoMode",1); setActual(p,"stereoBalance",0.7f); }, stereoSignal);
        audible ("stereoWidth", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",0); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",100); }, stereoSignal);
        audible ("pan", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"pan",-1); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"pan",1); }, stereoSignal);
        audible ("stereoFocus", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",80); setActual(p,"stereoFocus",40); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",80); setActual(p,"stereoFocus",5000); }, stereoSignal);
        audible ("stereoBalance", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoBalance",-1); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoBalance",1); }, stereoSignal);
        audible ("stereoDetune", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",100); setActual(p,"stereoDetune",0); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",100); setActual(p,"stereoDetune",20); }, sine1k);
        audible ("stereoDelay", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",100); setActual(p,"stereoDelay",0); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"stereoWidth",100); setActual(p,"stereoDelay",25); }, sine1k);
        audible ("bassMono", [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"bassMono",0); }, [] (auto& p){ setActual(p,"stereoOn",1); setActual(p,"bassMono",3); }, [] (auto& x,double fs){ fillSine(x,fs,70,0.12f,true); });

        // OUTPUT and global MIX
        audible ("outputOn", [] (auto& p){ setActual(p,"outputOn",0); setActual(p,"vcaFader",-15); }, [] (auto& p){ setActual(p,"outputOn",1); setActual(p,"vcaFader",-15); }, sine1k);
        audible ("vcaFader", [] (auto& p){ setActual(p,"outputOn",1); setActual(p,"vcaFader",-20); }, [] (auto& p){ setActual(p,"outputOn",1); setActual(p,"vcaFader",10); }, sine1k);
        audible ("autoLevel", [] (auto& p){ setActual(p,"outputOn",1); setActual(p,"autoLevel",0); setActual(p,"inputOn",1); setActual(p,"inputDrive",16); }, [] (auto& p){ setActual(p,"outputOn",1); setActual(p,"autoLevel",1); setActual(p,"inputOn",1); setActual(p,"inputDrive",16); }, sine1k);
        audible ("mix", [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",12); setActual(p,"saturation",90); setActual(p,"mix",0); }, [] (auto& p){ setActual(p,"saturationOn",1); setActual(p,"satGain",12); setActual(p,"saturation",90); setActual(p,"mix",100); }, sine1k);
    }

    // Meter calibration: the GUI meters must report the real audio peaks, not decorative values.
    {
        constexpr int n = 1024;
        constexpr double fs = 48000.0;
        ConsoleChannelStripXAudioProcessor p;
        neutralise (p);
        p.prepareToPlay (fs, n);
        juce::MidiBuffer midi;
        juce::AudioBuffer<float> b (2, n);

        const auto db = [] (float x) { return 20.0f * std::log10 (juce::jmax (1.0e-9f, x)); };

        b.clear();
        for (int i = 0; i < n; ++i) { b.setSample (0, i, 0.5f); b.setSample (1, i, 0.25f); }
        p.processBlock (b, midi);
        const float outPeak1L = b.getMagnitude (0, 0, n);
        const float outPeak1R = b.getMagnitude (1, 0, n);

        b.clear();
        for (int i = 0; i < n; ++i) { b.setSample (0, i, 0.1f); b.setSample (1, i, 0.05f); }
        p.processBlock (b, midi);
        const float outPeak2L = b.getMagnitude (0, 0, n);
        const float outPeak2R = b.getMagnitude (1, 0, n);

        const float inMeterL = p.inputMeterL();
        const float inMeterR = p.inputMeterR();
        const float outMeterL = p.outputMeterL();
        const float outMeterR = p.outputMeterR();
        f.require (std::abs (inMeterL - db (0.5f)) < 0.20f, "Input L meter is not calibrated to real dBFS peak");
        f.require (std::abs (inMeterR - db (0.25f)) < 0.20f, "Input R meter is not calibrated to real dBFS peak");
        f.require (std::abs (outMeterL - db (juce::jmax (outPeak1L, outPeak2L))) < 0.20f,
                   "Output L meter does not equal the actual processed peak");
        f.require (std::abs (outMeterR - db (juce::jmax (outPeak1R, outPeak2R))) < 0.20f,
                   "Output R meter does not equal the actual processed peak");
    }

    // GR meters must move only from real dynamics processing.
    {
        constexpr int n = 4096;
        constexpr double fs = 48000.0;
        juce::MidiBuffer midi;

        ConsoleChannelStripXAudioProcessor comp;
        neutralise (comp);
        setActual (comp, "dynOn", 1); setActual (comp, "compOn", 1); setActual (comp, "gateOn", 0);
        setActual (comp, "compThreshold", -30); setActual (comp, "compRatio", 10); setActual (comp, "compAttack", 1);
        comp.prepareToPlay (fs, n);
        juce::AudioBuffer<float> cb (2, n);
        fillSine (cb, fs, 997.0f, 0.5f);
        comp.processBlock (cb, midi);
        const float compMeter = comp.compressorPeakReductionMeter();
        f.require (std::isfinite (compMeter) && compMeter > 0.25f && compMeter <= 60.0f,
                   "Compressor GR meter is not driven by real gain reduction");

        ConsoleChannelStripXAudioProcessor gate;
        neutralise (gate);
        setActual (gate, "dynOn", 1); setActual (gate, "compOn", 0); setActual (gate, "gateOn", 1);
        setActual (gate, "gateThreshold", -30); setActual (gate, "gateRange", 40); setActual (gate, "gateAttack", 1);
        gate.prepareToPlay (fs, n);
        juce::AudioBuffer<float> gb (2, n);
        fillSine (gb, fs, 997.0f, 0.005f);
        gate.processBlock (gb, midi);
        const float gateMeter = gate.gatePeakReductionMeter();
        f.require (std::isfinite (gateMeter) && gateMeter > 0.25f && gateMeter <= 60.0f,
                   "Gate GR meter is not driven by real gain reduction");
    }

    juce::Image image (juce::Image::RGB, editor->getWidth(), editor->getHeight(), true);
    juce::Graphics graphics (image);
    editor->paintEntireComponent (graphics, true);
    juce::File out = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-silveton-v0.5.2.png");
    juce::FileOutputStream stream (out);
    juce::PNGImageFormat png;
    f.require (stream.openedOk() && png.writeImageToStream (image, stream), "approved GUI preview PNG was not written");

    if (f.count != 0)
    {
        std::cerr << f.count << " Silveton approved-GUI smoke test(s) failed\n";
        return 1;
    }

    std::cout << "PASS: Silveton v0.5.2 approved GUI; all 66 visible parameters, all physical hit regions, Compressor IN mirror and real meters are live.\n";
    return 0;
}
