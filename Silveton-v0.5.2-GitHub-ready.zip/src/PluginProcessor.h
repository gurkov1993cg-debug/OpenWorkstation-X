#pragma once
#include <JuceHeader.h>
#include "DspEngine.h"
#include <array>
#include <atomic>
#include <vector>

class ConsoleChannelStripXAudioProcessor final : public juce::AudioProcessor
{
public:
    ConsoleChannelStripXAudioProcessor();
    ~ConsoleChannelStripXAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.10; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;
    juce::AudioProcessorParameter* getBypassParameter() const override;

    juce::AudioProcessorValueTreeState& parameters() noexcept { return apvts; }
    void undo() { undoManager.undo(); }
    void redo() { undoManager.redo(); }
    void resetParametersToDefaults();

    float compressorMeter() const noexcept { return engine.getCompressorGainReductionDb(); }
    float gateMeter() const noexcept { return engine.getGateGainReductionDb(); }
    float compressorPeakReductionMeter() noexcept;
    float gatePeakReductionMeter() noexcept;
    float inputMeter() const noexcept { return inputPeakDb.load(); }
    float outputMeter() const noexcept { return outputPeakDb.load(); }
    float inputMeterL() noexcept { return consumeMeter (inputPeakLDb); }
    float inputMeterR() noexcept { return consumeMeter (inputPeakRDb); }
    float outputMeterL() noexcept { return consumeMeter (outputPeakLDb); }
    float outputMeterR() noexcept { return consumeMeter (outputPeakRDb); }
    float preSaturationMeter() noexcept { return engine.consumePreSaturationPeakDb(); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    DspEngine::Params readParams() const;
    float param (const char* id) const noexcept;

    void resetExtensionState() noexcept;
    void processSlopeExtensions (juce::AudioBuffer<float>& buffer, int hpStages, int lpStages,
                                 float hpFreq, float lpFreq) noexcept;
    void processDynamicsControlExtensions (juce::AudioBuffer<float>& buffer,
                                           const juce::AudioBuffer<float>& alignedDetector) noexcept;
    void processOuterBandQCorrection (juce::AudioBuffer<float>& buffer, float lfFreq, float lfGain, float lfQ,
                                     float hfFreq, float hfGain, float hfQ) noexcept;
    void processSaturationTone (juce::AudioBuffer<float>& buffer, float tone) noexcept;
    void processStereoExtensions (juce::AudioBuffer<float>& buffer, int mode, float balance,
                                  int bassMonoChoice) noexcept;
    void captureAlignedDry (const juce::AudioBuffer<float>& input, juce::AudioBuffer<float>& alignedDry);
    void updateInputMeters (const juce::AudioBuffer<float>& buffer) noexcept;
    void updateOutputMeters (const juce::AudioBuffer<float>& buffer) noexcept;

    static float toDb (float linear) noexcept;
    static float consumeMeter (std::atomic<float>& meter) noexcept;
    static void storePeakMax (std::atomic<float>& meter, float value) noexcept;

    juce::UndoManager undoManager;
    juce::AudioProcessorValueTreeState apvts;
    DspEngine engine;

    double currentSampleRate = 44100.0;

    std::array<std::array<float, 2>, 2> hpPrevIn {{ { 0.0f, 0.0f }, { 0.0f, 0.0f } }};
    std::array<std::array<float, 2>, 2> hpPrevOut {{ { 0.0f, 0.0f }, { 0.0f, 0.0f } }};
    std::array<std::array<float, 2>, 2> lpState {{ { 0.0f, 0.0f }, { 0.0f, 0.0f } }};
    struct BiquadState { float x1 = 0.0f, x2 = 0.0f, y1 = 0.0f, y2 = 0.0f; };
    std::array<BiquadState, 2> lfQState;
    std::array<BiquadState, 2> hfQState;
    std::array<float, 2> satToneLow {{ 0.0f, 0.0f }};
    float bassMonoSideLow = 0.0f;
    std::array<float, 2> compEnvChosen {{ 0.0f, 0.0f }};
    std::array<float, 2> compEnvReference {{ 0.0f, 0.0f }};
    float gateGainChosen = 1.0f;
    float gateGainReference = 1.0f;
    std::array<std::vector<float>, 2> dryDelay;
    int dryDelayPos = 0;
    juce::AudioBuffer<float> alignedDry;

    std::atomic<float> inputPeakLDb { -72.0f };
    std::atomic<float> inputPeakRDb { -72.0f };
    std::atomic<float> outputPeakLDb { -72.0f };
    std::atomic<float> outputPeakRDb { -72.0f };
    std::atomic<float> inputPeakDb { -72.0f };
    std::atomic<float> outputPeakDb { -72.0f };
    std::atomic<float> compExtensionPeakReductionDb { 0.0f };
    std::atomic<float> gateExtensionPeakReductionDb { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessor)
};
