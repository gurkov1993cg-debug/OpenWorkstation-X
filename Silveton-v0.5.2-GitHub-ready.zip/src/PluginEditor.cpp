#include "PluginEditor.h"
#include <BinaryData.h>
#include <algorithm>
#include <cmath>

namespace
{
    constexpr int kDesignWidth = 1536;
    constexpr int kDesignHeight = 1024;

    const auto cBg = juce::Colour::fromRGB (9, 15, 19);
    const auto cHeader = juce::Colour::fromRGB (13, 23, 29);
    const auto cPanelTop = juce::Colour::fromRGB (23, 35, 42);
    const auto cPanelBottom = juce::Colour::fromRGB (12, 21, 27);
    const auto cEdge = juce::Colour::fromRGB (53, 75, 87);
    const auto cField = juce::Colour::fromRGB (10, 18, 23);
    const auto cText = juce::Colour::fromRGB (225, 234, 240);
    const auto cMuted = juce::Colour::fromRGB (138, 157, 170);
    const auto cBlue = juce::Colour::fromRGB (56, 181, 245);
    const auto cBlue2 = juce::Colour::fromRGB (26, 109, 159);
    const auto cGreen = juce::Colour::fromRGB (80, 210, 125);
    const auto cYellow = juce::Colour::fromRGB (231, 197, 73);
    const auto cRed = juce::Colour::fromRGB (238, 87, 78);

    struct Layout
    {
        static juce::Rectangle<int> input()      { return { 6, 90, 160, 830 }; }
        static juce::Rectangle<int> filters()    { return { 170, 90, 160, 830 }; }
        static juce::Rectangle<int> eq()         { return { 334, 90, 292, 830 }; }
        static juce::Rectangle<int> dynamics()   { return { 630, 90, 300, 830 }; }
        static juce::Rectangle<int> saturation() { return { 934, 90, 210, 830 }; }
        static juce::Rectangle<int> stereo()     { return { 1148, 90, 232, 830 }; }
        static juce::Rectangle<int> output()     { return { 1384, 90, 146, 830 }; }
    };

    bool containsIgnoreCase (const juce::String& s, const char* token)
    {
        return s.containsIgnoreCase (token);
    }
}

class SilvetonLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    SilvetonLookAndFeel()
    {
        setColour (juce::Slider::textBoxTextColourId, cText);
        setColour (juce::Slider::textBoxBackgroundColourId, cField);
        setColour (juce::Slider::textBoxOutlineColourId, cEdge);
        setColour (juce::Label::textColourId, cMuted);
        setColour (juce::ComboBox::backgroundColourId, cField);
        setColour (juce::ComboBox::outlineColourId, cEdge);
        setColour (juce::ComboBox::textColourId, cText);
        setColour (juce::PopupMenu::backgroundColourId, cPanelBottom);
        setColour (juce::PopupMenu::textColourId, cText);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, cBlue2);
        setColour (juce::PopupMenu::highlightedTextColourId, juce::Colours::white);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float pos, float startAngle, float endAngle, juce::Slider& slider) override
    {
        // The approved PNG supplies the labels, tick ring and panel artwork.
        // We repaint only the live knob face + pointer, so the GUI keeps the
        // approved look while the control itself remains a real JUCE Slider.
        auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height);
        const float minSide = juce::jmin (area.getWidth(), area.getHeight());
        const float radius = minSide * 0.34f;
        const auto centre = area.getCentre();
        const float angle = startAngle + pos * (endAngle - startAngle);

        auto dial = juce::Rectangle<float> (centre.x - radius, centre.y - radius,
                                            radius * 2.0f, radius * 2.0f);
        juce::ColourGradient face (juce::Colour::fromRGB (54, 68, 77), dial.getX(), dial.getY(),
                                   juce::Colour::fromRGB (7, 13, 17), dial.getRight(), dial.getBottom(), false);
        face.addColour (0.45, juce::Colour::fromRGB (26, 36, 42));
        g.setGradientFill (face);
        g.fillEllipse (dial);
        g.setColour (juce::Colour::fromRGB (3, 8, 11));
        g.drawEllipse (dial, 2.0f);
        g.setColour (cEdge.withAlpha (0.82f));
        g.drawEllipse (dial.reduced (3.0f), 1.0f);

        // Clear the baked position arc first, then draw exactly one live arc.
        // This prevents the approved reference position and the current value
        // from appearing simultaneously.
        juce::Path clearArc;
        clearArc.addCentredArc (centre.x, centre.y, radius + 4.0f, radius + 4.0f, 0.0f,
                                startAngle, endAngle, true);
        g.setColour (juce::Colour::fromRGB (18, 29, 35));
        g.strokePath (clearArc, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved,
                                                       juce::PathStrokeType::rounded));

        juce::Path arc;
        arc.addCentredArc (centre.x, centre.y, radius + 4.0f, radius + 4.0f, 0.0f,
                           startAngle, angle, true);
        g.setColour (cBlue.withAlpha (0.95f));
        g.strokePath (arc, juce::PathStrokeType (2.2f, juce::PathStrokeType::curved,
                                                  juce::PathStrokeType::rounded));

        juce::Path pointer;
        pointer.addRoundedRectangle (-1.25f, -radius * 0.72f, 2.5f, radius * 0.50f, 1.0f);
        pointer.applyTransform (juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
        g.setColour (juce::Colours::white.withAlpha (0.96f));
        g.fillPath (pointer);

        // A tiny centre cap keeps the pointer visually clean on the small MIX knob.
        g.setColour (juce::Colour::fromRGB (15, 23, 28));
        g.fillEllipse (centre.x - 2.0f, centre.y - 2.0f, 4.0f, 4.0f);
        juce::ignoreUnused (slider);
    }

    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float, float, const juce::Slider::SliderStyle style,
                           juce::Slider& slider) override
    {
        if (style != juce::Slider::LinearVertical)
        {
            juce::LookAndFeel_V4::drawLinearSlider (g, x, y, width, height, sliderPos, 0, 0, style, slider);
            return;
        }

        const float cx = (float) x + width * 0.5f;
        // Cover the static reference handle/track before drawing the live one.
        g.setColour (juce::Colour::fromRGB (12, 22, 27));
        g.fillRect (cx - 20.0f, (float) y + 2.0f, 40.0f, (float) height - 4.0f);

        g.setColour (juce::Colour::fromRGB (3, 8, 11));
        g.fillRoundedRectangle (cx - 5.0f, (float) y + 6.0f, 10.0f, (float) height - 12.0f, 4.0f);
        g.setColour (cEdge.withAlpha (0.9f));
        g.drawRoundedRectangle (cx - 5.0f, (float) y + 6.0f, 10.0f, (float) height - 12.0f, 4.0f, 1.0f);

        auto thumb = juce::Rectangle<float> (cx - 15.0f, sliderPos - 10.0f, 30.0f, 20.0f);
        juce::ColourGradient grad (juce::Colour::fromRGB (205, 214, 220), thumb.getX(), thumb.getY(),
                                   juce::Colour::fromRGB (65, 78, 86), thumb.getX(), thumb.getBottom(), false);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (thumb, 2.0f);
        g.setColour (juce::Colour::fromRGB (25, 34, 39));
        g.drawRoundedRectangle (thumb, 2.0f, 1.0f);
        g.setColour (juce::Colours::white.withAlpha (0.45f));
        g.drawHorizontalLine ((int) thumb.getCentreY(), thumb.getX() + 4.0f, thumb.getRight() - 4.0f);
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                               bool highlighted, bool down) override
    {
        const auto id = button.getComponentID();
        const bool on = button.getToggleState();
        auto r = button.getLocalBounds().toFloat().reduced (0.5f);

        // Section/subsection power controls are the circular blue power lamps from the approved panel.
        if (button.getButtonText() == "POWER")
        {
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.43f;
            g.setColour (juce::Colour::fromRGB (12, 25, 32));
            g.fillEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f);
            g.setColour ((on ? cBlue : cEdge).withAlpha (0.95f));
            g.drawEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f, 1.2f);
            if (on)
            {
                g.setColour (cBlue.withAlpha (0.16f));
                g.fillEllipse (c.x - rad - 3.0f, c.y - rad - 3.0f, rad * 2.0f + 6.0f, rad * 2.0f + 6.0f);
            }
            return;
        }

        // HP/LP enable controls are the small illuminated dots from the approved panel.
        if (id == "hpOn" || id == "lpOn")
        {
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.34f;
            g.setColour ((on ? cBlue : cMuted.darker (0.65f)).withAlpha (0.98f));
            g.fillEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f);
            if (on)
            {
                g.setColour (cBlue.withAlpha (0.20f));
                g.fillEllipse (c.x - rad - 4.0f, c.y - rad - 4.0f, rad * 2.0f + 8.0f, rad * 2.0f + 8.0f);
            }
            return;
        }

        // HF/LF shelf-vs-bell controls live on the small response-curve icon itself.
        if (id == "hfBell" || id == "lfBell")
        {
            g.setColour (juce::Colour::fromRGB (17, 28, 34));
            g.fillRoundedRectangle (r, 2.0f);
            juce::Path p;
            if (on)
            {
                p.startNewSubPath (r.getX() + 2.0f, r.getCentreY());
                p.cubicTo (r.getX() + r.getWidth() * 0.28f, r.getCentreY(),
                           r.getX() + r.getWidth() * 0.28f, r.getY() + 3.0f,
                           r.getCentreX(), r.getY() + 3.0f);
                p.cubicTo (r.getX() + r.getWidth() * 0.72f, r.getY() + 3.0f,
                           r.getX() + r.getWidth() * 0.72f, r.getCentreY(),
                           r.getRight() - 2.0f, r.getCentreY());
            }
            else
            {
                p.startNewSubPath (r.getX() + 2.0f, r.getBottom() - 4.0f);
                p.cubicTo (r.getX() + r.getWidth() * 0.35f, r.getBottom() - 4.0f,
                           r.getX() + r.getWidth() * 0.35f, r.getY() + 4.0f,
                           r.getRight() - 2.0f, r.getY() + 4.0f);
            }
            g.setColour (on ? cBlue : cText.withAlpha (0.95f));
            g.strokePath (p, juce::PathStrokeType (1.35f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            return;
        }

        auto fill = on ? cBlue2 : cField;
        if (highlighted) fill = fill.brighter (0.08f);
        if (down) fill = fill.darker (0.15f);

        g.setColour (fill);
        g.fillRoundedRectangle (r, 3.0f);
        g.setColour ((on ? cBlue : cEdge).withAlpha (0.95f));
        g.drawRoundedRectangle (r, 3.0f, on ? 1.4f : 1.0f);
        if (on)
        {
            g.setColour (cBlue.withAlpha (0.13f));
            g.drawRoundedRectangle (r.expanded (1.0f), 4.0f, 2.0f);
        }
    }

    void drawButtonText (juce::Graphics& g, juce::TextButton& button,
                         bool, bool) override
    {
        g.setColour (button.getToggleState() ? juce::Colours::white : cText);
        if (button.getComponentID() == "hpOn" || button.getComponentID() == "lpOn" ||
            button.getComponentID() == "hfBell" || button.getComponentID() == "lfBell")
            return;
        if (button.getButtonText() == "POWER")
        {
            const auto r = button.getLocalBounds().toFloat();
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.27f;
            g.drawEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f, 1.5f);
            g.drawLine (c.x, c.y - rad - 2.0f, c.x, c.y + 1.0f, 1.8f);
            return;
        }
        if (button.getButtonText() == "PHASEICON")
        {
            const auto r = button.getLocalBounds().toFloat();
            const auto c = r.getCentre();
            const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.24f;
            g.drawEllipse (c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f, 1.4f);
            g.drawLine (c.x - rad * 0.72f, c.y + rad * 0.92f, c.x + rad * 0.72f, c.y - rad * 0.92f, 1.5f);
            return;
        }
        if (button.getButtonText() == "MENU")
        {
            const auto c = button.getLocalBounds().toFloat().getCentre();
            for (int dy : { -7, 0, 7 }) g.fillEllipse (c.x - 1.5f, c.y + (float) dy - 1.5f, 3.0f, 3.0f);
            return;
        }
        if (button.getButtonText() == "SETTINGS")
        {
            const auto c = button.getLocalBounds().toFloat().getCentre();
            g.drawEllipse (c.x - 7.0f, c.y - 7.0f, 14.0f, 14.0f, 1.5f);
            g.drawEllipse (c.x - 2.0f, c.y - 2.0f, 4.0f, 4.0f, 1.2f);
            g.drawLine (c.x - 10.0f, c.y, c.x - 7.0f, c.y, 1.5f);
            g.drawLine (c.x + 7.0f, c.y, c.x + 10.0f, c.y, 1.5f);
            g.drawLine (c.x, c.y - 10.0f, c.x, c.y - 7.0f, 1.5f);
            g.drawLine (c.x, c.y + 7.0f, c.x, c.y + 10.0f, 1.5f);
            return;
        }
        g.setFont (juce::Font (button.getHeight() <= 24 ? 9.5f : 10.5f, juce::Font::bold));
        g.drawFittedText (button.getButtonText(), button.getLocalBounds().reduced (4, 1),
                          juce::Justification::centred, 1);
    }

    void drawLabel (juce::Graphics& g, juce::Label& label) override
    {
        // The approved skin already contains the default numeric readouts.
        // Slider text boxes must therefore erase that baked value completely
        // before drawing the live value, otherwise two texts are visible.
        auto r = label.getLocalBounds().toFloat();
        const auto* parent = label.getParentComponent();
        const bool isMix = parent != nullptr && parent->getComponentID() == "mix";

        if (isMix)
        {
            g.setColour (cHeader);
            g.fillRect (label.getLocalBounds());
            g.setColour (cText);
            g.setFont (juce::Font (12.0f));
            g.drawFittedText (label.getText(), label.getLocalBounds().reduced (1, 0),
                              juce::Justification::centred, 1);
            return;
        }

        g.setColour (cField);
        g.fillRoundedRectangle (r, 2.0f);
        g.setColour (cEdge.withAlpha (0.95f));
        g.drawRoundedRectangle (r.reduced (0.5f), 2.0f, 1.0f);
        g.setColour (cText);
        g.setFont (juce::Font (label.getHeight() <= 20 ? 10.5f : 11.0f));
        g.drawFittedText (label.getText(), label.getLocalBounds().reduced (3, 1),
                          juce::Justification::centred, 1);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool,
                       int, int, int, int, juce::ComboBox&) override
    {
        auto r = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
        g.setColour (cField);
        g.fillRoundedRectangle (r, 4.0f);
        g.setColour (cEdge);
        g.drawRoundedRectangle (r, 4.0f, 1.0f);

        juce::Path p;
        const float cx = width - 16.0f, cy = height * 0.5f;
        p.addTriangle (cx - 4.0f, cy - 2.0f, cx + 4.0f, cy - 2.0f, cx, cy + 3.0f);
        g.setColour (cMuted);
        g.fillPath (p);
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return juce::Font (11.0f); }
};

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), silvetonLookAndFeel (std::make_unique<SilvetonLookAndFeel>())
{
    setOpaque (true);
    setLookAndFeel (silvetonLookAndFeel.get());

    approvedSkin = juce::ImageCache::getFromMemory (BinaryData::approved_visual_reference_png,
                                                    BinaryData::approved_visual_reference_pngSize);

    for (auto* b : { &prevPresetButton, &nextPresetButton, &abButton, &undoButton, &redoButton, &menuButton, &settingsButton })
        addAndMakeVisible (*b);

    prevPresetButton.setComponentID ("actionPrevPreset");
    nextPresetButton.setComponentID ("actionNextPreset");
    abButton.setComponentID ("actionAB");
    undoButton.setComponentID ("actionUndo");
    redoButton.setComponentID ("actionRedo");
    menuButton.setComponentID ("actionMenu");
    settingsButton.setComponentID ("actionSettings");

    addAndMakeVisible (presetBox);
    presetBox.setComponentID ("presetBox");
    presetBox.addItem ("INIT", 1);
    presetBox.addItem ("Vocal - Modern Clarity", 2);
    presetBox.addItem ("Drum - Punch", 3);
    presetBox.addItem ("Mix Bus - Glue", 4);
    presetBox.setSelectedId (2, juce::dontSendNotification);

    prevPresetButton.onClick = [this] { cyclePreset (-1); };
    nextPresetButton.onClick = [this] { cyclePreset (1); };
    presetBox.onChange = [this] { applyPreset (presetBox.getSelectedId()); };
    abButton.onClick = [this] { toggleAB(); };
    undoButton.onClick = [this] { audioProcessor.undo(); };
    redoButton.onClick = [this] { audioProcessor.redo(); };
    menuButton.onClick = [this] { showMainMenu(); };
    settingsButton.onClick = [this] { showSettingsMenu(); };

    // Global bypass remains available to the host through the dedicated bypass parameter.
    // The approved front panel has no separate bypass button, so no fake GUI control is added.
    addSlider ("mix", "MIX");
    if (auto* mixSlider = dynamic_cast<juce::Slider*> (control ("mix")))
    {
        // Live numeric MIX readout occupies the exact header percentage area and remains editable.
        mixSlider->setTextBoxStyle (juce::Slider::TextBoxLeft, false, 52, 24);
        mixSlider->setColour (juce::Slider::textBoxTextColourId, cText);
    }

    addToggle ("inputOn", "POWER");
    addSlider ("inputDrive", "GAIN");
    addChoice ("inputMode", { "LINE", "MIC" });
    addToggle ("polarity", "PHASEICON");
    addToggle ("inputPad", "-20 dB");
    addSlider ("inputTrim", "INPUT TRIM", true);

    addToggle ("filtersOn", "POWER");
    addToggle ("hpOn", "LED");
    addSlider ("hpFreq", "");
    addChoice ("hpSlope", { "6 dB", "12 dB", "24 dB" });
    addToggle ("lpOn", "LED");
    addSlider ("lpFreq", "");
    addChoice ("lpSlope", { "6 dB", "12 dB", "24 dB" });

    addToggle ("eqOn", "POWER");
    addSlider ("hfFreq", "FREQ");
    addSlider ("hfGain", "GAIN");
    addSlider ("hfQ", "Q");
    addSlider ("hmfFreq", "FREQ");
    addSlider ("hmfGain", "GAIN");
    addSlider ("hmfQ", "Q");
    addSlider ("lmfFreq", "FREQ");
    addSlider ("lmfGain", "GAIN");
    addSlider ("lmfQ", "Q");
    addSlider ("lfFreq", "FREQ");
    addSlider ("lfGain", "GAIN");
    addSlider ("lfQ", "Q");
    addToggle ("hfBell", "CURVE");
    addToggle ("lfBell", "CURVE");

    addToggle ("dynOn", "POWER");
    addToggle ("gateOn", "POWER");
    addChoice ("gateExpand", { "GATE", "EXPAND" });
    addToggle ("gateFast", "FAST");
    addSlider ("gateThreshold", "THRESHOLD");
    addSlider ("gateRange", "RANGE");
    addSlider ("gateAttack", "ATTACK");
    addSlider ("gateRelease", "RELEASE");

    addToggle ("compOn", "POWER");
    addChoice ("compPeak", { "PEAK", "RMS" });
    addToggle ("compFast", "FAST");
    addSlider ("compThreshold", "THRESHOLD");
    addSlider ("compRatio", "RATIO");
    addSlider ("compAttack", "ATTACK");
    addSlider ("compRelease", "RELEASE");
    addSlider ("compKnee", "KNEE");
    addSlider ("compMakeup", "MAKEUP");

    // The approved panel shows both the compressor power icon and an IN key.
    // Both are real controls for the same compressor enable parameter.
    compInButton.setComponentID ("compOn__in");
    compInButton.setClickingTogglesState (true);
    addAndMakeVisible (compInButton);
    compInAttachment = std::make_unique<ButtonAttachment> (audioProcessor.parameters(), "compOn", compInButton);

    addToggle ("saturationOn", "POWER");
    addChoice ("satType", { "TUBE", "TAPE", "SOLID STATE" });
    addSlider ("satGain", "DRIVE");
    addSlider ("saturation", "AMOUNT");
    addSlider ("satTone", "TONE");
    addSlider ("satMix", "MIX");
    addChoice ("satCharacter", { "CLEAN", "WARM", "AGGRESSIVE" });
    addSlider ("satOutputTrim", "OUTPUT TRIM");

    addToggle ("stereoOn", "POWER");
    addChoice ("stereoMode", { "STEREO", "MID / SIDE" });
    addSlider ("stereoWidth", "WIDTH");
    addSlider ("pan", "PAN");
    addSlider ("stereoFocus", "FOCUS");
    addSlider ("stereoBalance", "BALANCE");
    addSlider ("stereoDetune", "DETUNE");
    addSlider ("stereoDelay", "DELAY");
    addChoice ("bassMono", { "OFF", "80 Hz", "120 Hz", "200 Hz" });
    // BASS MONO: live JUCE choice control, functionally attached to the bassMono DSP parameter.

    addToggle ("outputOn", "POWER");
    addSlider ("vcaFader", "LEVEL");
    addToggle ("autoLevel", "AUTO LEVEL");

    slotA = audioProcessor.parameters().copyState();
    slotB = slotA.createCopy();

    setSize (kDesignWidth, kDesignHeight);
    setResizable (false, false);
    startTimerHz (60);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void ConsoleChannelStripXAudioProcessorEditor::addSlider (const char* parameterId, const char* labelText, bool vertical)
{
    auto slot = std::make_unique<SliderControl>();
    slot->label = std::make_unique<juce::Label>();
    slot->slider = std::make_unique<juce::Slider>();

    slot->label->setText (labelText, juce::dontSendNotification);
    slot->label->setJustificationType (juce::Justification::centred);
    slot->label->setColour (juce::Label::textColourId, cMuted);
    slot->label->setFont (juce::Font (9.5f, juce::Font::bold));

    slot->slider->setComponentID (parameterId);
    slot->slider->setSliderStyle (vertical ? juce::Slider::LinearVertical : juce::Slider::RotaryHorizontalVerticalDrag);
    slot->slider->setTextBoxStyle (juce::Slider::TextBoxBelow, false, vertical ? 68 : 74, 20);
    slot->slider->setScrollWheelEnabled (true);
    slot->slider->setDoubleClickReturnValue (true, 0.0);

    if (auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (parameterId)))
    {
        const auto r = parameter->getNormalisableRange();
        juce::NormalisableRange<double> dr ((double) r.start, (double) r.end, (double) r.interval,
                                            (double) r.skew, r.symmetricSkew);
        slot->slider->setNormalisableRange (dr);
        const double def = (double) r.convertFrom0to1 (parameter->getDefaultValue());
        slot->slider->setDoubleClickReturnValue (true, def);
    }

    const juce::String id (parameterId);
    slot->slider->textFromValueFunction = [id] (double v) { return formatParameterValue (id, v); };
    slot->slider->valueFromTextFunction = [id] (const juce::String& s) { return parseParameterValue (id, s); };

    addAndMakeVisible (*slot->label);
    slot->label->setVisible (false); // Labels are baked into the approved 1:1 skin.
    addAndMakeVisible (*slot->slider);
    slot->attachment = std::make_unique<SliderAttachment> (audioProcessor.parameters(), parameterId, *slot->slider);

    controlsById[parameterId] = slot->slider.get();
    labelsById[parameterId] = slot->label.get();
    sliderControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addToggle (const char* parameterId, const char* buttonText)
{
    auto slot = std::make_unique<ToggleControl>();
    slot->button = std::make_unique<juce::TextButton> (buttonText);
    slot->button->setComponentID (parameterId);
    slot->button->setClickingTogglesState (true);
    addAndMakeVisible (*slot->button);
    slot->attachment = std::make_unique<ButtonAttachment> (audioProcessor.parameters(), parameterId, *slot->button);
    controlsById[parameterId] = slot->button.get();
    toggleControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addChoice (const char* parameterId, std::initializer_list<const char*> labels)
{
    auto group = std::make_unique<ChoiceControl>();
    group->parameterId = parameterId;
    int index = 0;
    for (const auto* text : labels)
    {
        auto b = std::make_unique<juce::TextButton> (text);
        b->setComponentID (juce::String (parameterId) + "__" + juce::String (index));
        const int thisIndex = index;
        const std::string id = parameterId;
        b->onClick = [this, id, thisIndex]
        {
            if (auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (juce::String (id))))
            {
                const float actual = (id == "compPeak") ? (float) (1 - thisIndex) : (float) thisIndex;
                parameter->beginChangeGesture();
                parameter->setValueNotifyingHost (parameter->convertTo0to1 (actual));
                parameter->endChangeGesture();
            }
            syncChoiceButtons();
        };
        addAndMakeVisible (*b);
        group->buttons.push_back (std::move (b));
        ++index;
    }
    if (! group->buttons.empty())
        controlsById[parameterId] = group->buttons.front().get();
    choiceControls.push_back (std::move (group));
}

juce::Component* ConsoleChannelStripXAudioProcessorEditor::control (const char* id) const
{
    const auto it = controlsById.find (id);
    return it == controlsById.end() ? nullptr : it->second;
}

juce::Label* ConsoleChannelStripXAudioProcessorEditor::label (const char* id) const
{
    const auto it = labelsById.find (id);
    return it == labelsById.end() ? nullptr : it->second;
}

void ConsoleChannelStripXAudioProcessorEditor::placeSlider (const char* id, juce::Rectangle<int> bounds)
{
    auto* c = control (id);
    auto* l = label (id);
    if (c == nullptr || l == nullptr) return;
    // The approved artwork already contains every printed label. The live control
    // occupies the exact knob/fader/value-box rectangle with no hidden 15 px offset.
    l->setBounds (0, 0, 0, 0);
    c->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeToggle (const char* id, juce::Rectangle<int> bounds)
{
    if (auto* c = control (id)) c->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeChoice (const char* id, juce::Rectangle<int> bounds, int gap)
{
    for (auto& group : choiceControls)
    {
        if (group->parameterId != id) continue;
        const int count = (int) group->buttons.size();
        if (count <= 0) return;
        const int totalGap = gap * (count - 1);
        const int each = juce::jmax (1, (bounds.getWidth() - totalGap) / count);
        for (int i = 0; i < count; ++i)
        {
            group->buttons[(size_t) i]->setBounds (bounds.removeFromLeft (each));
            if (i + 1 < count) bounds.removeFromLeft (gap);
        }
        return;
    }
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    // Header — coordinates are taken from the approved 1536x1024 production reference.
    prevPresetButton.setBounds (548, 23, 34, 38);
    presetBox.setBounds (590, 23, 316, 38);
    nextPresetButton.setBounds (907, 23, 34, 38);
    abButton.setBounds (972, 27, 78, 34);
    undoButton.setBounds (1058, 27, 70, 34);
    redoButton.setBounds (1134, 27, 71, 34);
    menuButton.setBounds (1211, 27, 42, 34);
    placeSlider ("mix", { 1330, 16, 119, 58 });
    settingsButton.setBounds (1462, 23, 57, 38);

    // INPUT
    placeToggle ("inputOn", { 13, 104, 24, 24 });
    placeSlider ("inputDrive", { 23, 176, 120, 166 });
    placeChoice ("inputMode", { 21, 377, 129, 34 });
    placeToggle ("polarity", { 21, 430, 61, 34 });
    placeToggle ("inputPad", { 88, 430, 62, 34 });
    placeSlider ("inputTrim", { 50, 529, 72, 340 });

    // FILTERS
    placeToggle ("filtersOn", { 178, 104, 24, 24 });
    placeToggle ("hpOn", { 184, 165, 19, 19 });
    placeSlider ("hpFreq", { 189, 235, 120, 136 });
    placeChoice ("hpSlope", { 180, 399, 138, 31 }, 4);
    placeToggle ("lpOn", { 184, 493, 19, 19 });
    placeSlider ("lpFreq", { 189, 565, 120, 136 });
    placeChoice ("lpSlope", { 180, 730, 138, 31 }, 4);

    // EQUALISER
    placeToggle ("eqOn", { 341, 104, 24, 24 });
    placeToggle ("hfBell", { 342, 211, 31, 24 });
    placeSlider ("hfFreq", { 380, 194, 70, 112 });
    placeSlider ("hfGain", { 465, 194, 70, 112 });
    placeSlider ("hfQ", { 545, 194, 70, 112 });
    placeSlider ("hmfFreq", { 380, 379, 70, 112 });
    placeSlider ("hmfGain", { 465, 379, 70, 112 });
    placeSlider ("hmfQ", { 545, 379, 70, 112 });
    placeSlider ("lmfFreq", { 380, 566, 70, 112 });
    placeSlider ("lmfGain", { 465, 566, 70, 112 });
    placeSlider ("lmfQ", { 545, 566, 70, 112 });
    placeToggle ("lfBell", { 342, 771, 31, 24 });
    placeSlider ("lfFreq", { 380, 749, 70, 112 });
    placeSlider ("lfGain", { 465, 749, 70, 112 });
    placeSlider ("lfQ", { 545, 749, 70, 112 });

    // DYNAMICS — both subsection power icons are live. GATE/EXPAND is a real mode choice.
    placeToggle ("dynOn", { 638, 104, 24, 24 });
    placeToggle ("gateOn", { 638, 151, 24, 24 });
    placeChoice ("gateExpand", { 644, 188, 139, 31 }, 4);
    placeToggle ("gateFast", { 789, 188, 66, 31 });
    placeSlider ("gateThreshold", { 651, 249, 68, 112 });
    placeSlider ("gateRange", { 764, 249, 68, 112 });
    placeSlider ("gateAttack", { 651, 388, 68, 112 });
    placeSlider ("gateRelease", { 764, 388, 68, 112 });

    placeToggle ("compOn", { 638, 521, 24, 24 });
    compInButton.setBounds (645, 557, 64, 31);
    placeChoice ("compPeak", { 713, 557, 139, 31 }, 4);
    placeToggle ("compFast", { 856, 557, 64, 31 });
    placeSlider ("compThreshold", { 647, 611, 62, 106 });
    placeSlider ("compRatio", { 713, 611, 62, 106 });
    placeSlider ("compAttack", { 785, 611, 62, 106 });
    placeSlider ("compRelease", { 855, 611, 62, 106 });
    placeSlider ("compKnee", { 647, 758, 74, 112 });
    placeSlider ("compMakeup", { 750, 758, 74, 112 });

    // SATURATION
    placeToggle ("saturationOn", { 942, 104, 24, 24 });
    placeChoice ("satType", { 943, 164, 193, 34 }, 4);
    placeSlider ("satGain", { 947, 246, 78, 122 });
    placeSlider ("saturation", { 1051, 246, 78, 122 });
    placeSlider ("satTone", { 947, 420, 78, 122 });
    placeSlider ("satMix", { 1051, 420, 78, 122 });
    placeChoice ("satCharacter", { 943, 630, 193, 32 }, 4);
    placeSlider ("satOutputTrim", { 997, 731, 84, 132 });

    // STEREO
    placeToggle ("stereoOn", { 1156, 104, 24, 24 });
    placeChoice ("stereoMode", { 1168, 188, 193, 32 }, 4);
    placeSlider ("stereoWidth", { 1164, 286, 84, 133 });
    placeSlider ("pan", { 1275, 286, 84, 133 });
    placeSlider ("stereoFocus", { 1164, 493, 84, 133 });
    placeSlider ("stereoBalance", { 1275, 493, 84, 133 });
    placeSlider ("stereoDetune", { 1164, 681, 84, 123 });
    placeSlider ("stereoDelay", { 1275, 681, 84, 123 });
    placeChoice ("bassMono", { 1160, 873, 206, 31 }, 4);

    // OUTPUT
    placeToggle ("outputOn", { 1392, 104, 24, 24 });
    placeSlider ("vcaFader", { 1406, 172, 100, 170 });
    placeToggle ("autoLevel", { 1401, 783, 111, 34 });
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    // The approved production mockup is the literal visual base.  We do not
    // reinterpret or redraw the shell: this guarantees the shipped editor has
    // the same composition, typography, spacing and surface treatment 1:1.
    if (approvedSkin.isValid())
        g.drawImage (approvedSkin, getLocalBounds().toFloat(), juce::RectanglePlacement::stretchToFit);
    else
        g.fillAll (cBg);

    // Live overlays are restricted to the exact moving parts of the approved skin.
    // The scale artwork stays untouched; the bars below are driven by real DSP values.
    drawReductionMeter (g, { 895, 226, 11, 142 }, gateGr);
    drawReductionMeter (g, { 895, 692, 11, 104 }, compGr);
    drawStereoMeter (g, { 1432, 412, 67, 350 }, outL, outR, outHoldL, outHoldR);

}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, juce::Rectangle<int> r,
                                                           const juce::String& title) const
{
    juce::ColourGradient grad (cPanelTop, (float) r.getX(), (float) r.getY(),
                               cPanelBottom, (float) r.getRight(), (float) r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (cEdge.withAlpha (0.95f));
    g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.0f);
    g.setColour (cText);
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText (title, r.getX() + 54, r.getY() + 13, r.getWidth() - 66, 22, juce::Justification::centredLeft);
    g.setColour (cEdge.withAlpha (0.85f));
    g.drawHorizontalLine (r.getY() + 51, (float) r.getX() + 12.0f, (float) r.getRight() - 12.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawLogo (juce::Graphics& g, juce::Rectangle<float> r) const
{
    juce::Path p;
    p.startNewSubPath (r.getX() + r.getWidth() * 0.72f, r.getY());
    p.cubicTo (r.getX() + r.getWidth() * 0.35f, r.getY() + r.getHeight() * 0.16f,
               r.getX() + r.getWidth() * 0.10f, r.getY() + r.getHeight() * 0.28f,
               r.getX() + r.getWidth() * 0.17f, r.getY() + r.getHeight() * 0.45f);
    p.cubicTo (r.getX() + r.getWidth() * 0.28f, r.getY() + r.getHeight() * 0.64f,
               r.getX() + r.getWidth() * 0.70f, r.getY() + r.getHeight() * 0.56f,
               r.getX() + r.getWidth() * 0.72f, r.getY() + r.getHeight() * 0.74f);
    p.cubicTo (r.getX() + r.getWidth() * 0.72f, r.getY() + r.getHeight() * 0.86f,
               r.getX() + r.getWidth() * 0.42f, r.getY() + r.getHeight(),
               r.getX() + r.getWidth() * 0.24f, r.getBottom());
    juce::ColourGradient grad (juce::Colour::fromRGB (185, 225, 244), r.getX(), r.getY(),
                               cBlue2, r.getRight(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.strokePath (p, juce::PathStrokeType (8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}

void ConsoleChannelStripXAudioProcessorEditor::drawStereoMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                 float leftDb, float rightDb,
                                                                 float holdLeftDb, float holdRightDb) const
{
    // r spans only the two moving bar wells in the approved OUTPUT meter.
    const int barW = 11;
    const int gap = 22;
    const auto left = juce::Rectangle<int> (r.getX(), r.getY(), barW, r.getHeight());
    const auto right = juce::Rectangle<int> (r.getX() + barW + gap, r.getY(), barW, r.getHeight());
    const auto dbToNorm = [] (float db)
    {
        return juce::jmap (juce::jlimit (-60.0f, 0.0f, db), -60.0f, 0.0f, 0.0f, 1.0f);
    };

    const auto drawBar = [&] (juce::Rectangle<int> bar, float db, float hold)
    {
        g.setColour (juce::Colour::fromRGB (5, 12, 16));
        g.fillRect (bar);
        const int fillH = juce::roundToInt ((float) bar.getHeight() * dbToNorm (db));
        auto fill = bar.withTop (bar.getBottom() - fillH);
        juce::ColourGradient meter (juce::Colour::fromRGB (45, 176, 242), 0.0f, (float) bar.getBottom(),
                                    juce::Colour::fromRGB (69, 206, 255), 0.0f, (float) bar.getY(), false);
        g.setGradientFill (meter);
        g.fillRect (fill);
        const int holdY = bar.getBottom() - juce::roundToInt ((float) bar.getHeight() * dbToNorm (hold));
        g.setColour (juce::Colours::white.withAlpha (0.95f));
        g.fillRect (bar.getX(), juce::jlimit (bar.getY(), bar.getBottom() - 1, holdY), bar.getWidth(), 1);
    };

    drawBar (left, leftDb, holdLeftDb);
    drawBar (right, rightDb, holdRightDb);
}

void ConsoleChannelStripXAudioProcessorEditor::drawReductionMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                    float reductionDb) const
{
    // Approved GR scale: 0 dB at the top, -60 dB at the bottom. The live blue
    // column therefore shrinks downward as actual gain reduction increases.
    const float reduction = juce::jlimit (0.0f, 60.0f, std::abs (reductionDb));
    const float visible = 1.0f - reduction / 60.0f;
    g.setColour (juce::Colour::fromRGB (5, 12, 16));
    g.fillRect (r);
    const int fillH = juce::roundToInt ((float) r.getHeight() * visible);
    auto fill = r.withTop (r.getBottom() - fillH);
    juce::ColourGradient meter (juce::Colour::fromRGB (43, 168, 232), 0.0f, (float) r.getBottom(),
                                juce::Colour::fromRGB (67, 211, 255), 0.0f, (float) r.getY(), false);
    g.setGradientFill (meter);
    g.fillRect (fill);
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    inL = smoothMeter (inL, audioProcessor.inputMeterL());
    inR = smoothMeter (inR, audioProcessor.inputMeterR());
    outL = smoothMeter (outL, audioProcessor.outputMeterL());
    outR = smoothMeter (outR, audioProcessor.outputMeterR());
    compGr = smoothMeter (compGr, audioProcessor.compressorPeakReductionMeter());
    gateGr = smoothMeter (gateGr, audioProcessor.gatePeakReductionMeter());
    updatePeakHold (inL, inHoldL, inHoldTicksL);
    updatePeakHold (inR, inHoldR, inHoldTicksR);
    updatePeakHold (outL, outHoldL, outHoldTicksL);
    updatePeakHold (outR, outHoldR, outHoldTicksR);
    syncChoiceButtons();
    repaint();
}

void ConsoleChannelStripXAudioProcessorEditor::syncChoiceButtons()
{
    for (auto& group : choiceControls)
    {
        auto* raw = audioProcessor.parameters().getRawParameterValue (juce::String (group->parameterId));
        if (raw == nullptr) continue;
        const int rawSelected = (int) std::lround (raw->load());
        const int selected = group->parameterId == "compPeak" ? 1 - rawSelected : rawSelected;
        for (int i = 0; i < (int) group->buttons.size(); ++i)
            group->buttons[(size_t) i]->setToggleState (i == selected, juce::dontSendNotification);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::cyclePreset (int delta)
{
    int id = presetBox.getSelectedId();
    if (id < 1 || id > 4) id = 1;
    id += delta;
    if (id < 1) id = 4;
    if (id > 4) id = 1;
    presetBox.setSelectedId (id, juce::sendNotificationSync);
}

void ConsoleChannelStripXAudioProcessorEditor::setParameterActual (const char* id, float actual)
{
    if (auto* p = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (juce::String (id))))
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost (p->convertTo0to1 (actual));
        p->endChangeGesture();
    }
}

void ConsoleChannelStripXAudioProcessorEditor::applyPreset (int presetId)
{
    if (presetId == 1)
    {
        // True neutral INIT, independent of the approved Vocal factory presentation.
        setParameterActual ("inputOn", 1.0f); setParameterActual ("inputDrive", 0.0f); setParameterActual ("inputTrim", 0.0f);
        setParameterActual ("inputMode", 0.0f); setParameterActual ("inputPad", 0.0f); setParameterActual ("polarity", 0.0f);
        setParameterActual ("filtersOn", 1.0f); setParameterActual ("hpOn", 0.0f); setParameterActual ("lpOn", 0.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("hfGain", 0.0f); setParameterActual ("hmfGain", 0.0f);
        setParameterActual ("lmfGain", 0.0f); setParameterActual ("lfGain", 0.0f);
        setParameterActual ("dynOn", 0.0f); setParameterActual ("gateOn", 0.0f); setParameterActual ("compOn", 0.0f);
        setParameterActual ("compMakeup", 0.0f); setParameterActual ("saturationOn", 0.0f); setParameterActual ("saturation", 0.0f);
        setParameterActual ("stereoOn", 1.0f); setParameterActual ("stereoWidth", 0.0f); setParameterActual ("pan", 0.0f);
        setParameterActual ("stereoBalance", 0.0f); setParameterActual ("stereoDetune", 0.0f); setParameterActual ("stereoDelay", 0.0f);
        setParameterActual ("bassMono", 0.0f); setParameterActual ("outputOn", 1.0f); setParameterActual ("vcaFader", 0.0f);
        setParameterActual ("outputTrim", 0.0f); setParameterActual ("autoLevel", 0.0f); setParameterActual ("mix", 100.0f);
        setParameterActual ("mute", 0.0f); setParameterActual ("bypass", 0.0f);
        return;
    }

    if (presetId == 2)
    {
        setParameterActual ("hpOn", 1.0f); setParameterActual ("hpFreq", 80.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("hmfFreq", 2800.0f); setParameterActual ("hmfGain", 1.8f);
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 3.0f);
        setParameterActual ("compThreshold", -16.0f); setParameterActual ("saturationOn", 1.0f); setParameterActual ("saturation", 38.0f);
    }
    else if (presetId == 3)
    {
        setParameterActual ("hpOn", 1.0f); setParameterActual ("hpFreq", 35.0f);
        setParameterActual ("eqOn", 1.0f); setParameterActual ("lfGain", 2.5f); setParameterActual ("hmfGain", 2.0f);
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 4.0f);
        setParameterActual ("compAttack", 18.0f); setParameterActual ("saturation", 48.0f);
    }
    else if (presetId == 4)
    {
        setParameterActual ("compOn", 1.0f); setParameterActual ("dynOn", 1.0f); setParameterActual ("compRatio", 2.0f);
        setParameterActual ("compThreshold", -10.0f); setParameterActual ("compAttack", 30.0f); setParameterActual ("compRelease", 0.35f);
        setParameterActual ("saturationOn", 1.0f); setParameterActual ("saturation", 22.0f); setParameterActual ("satCharacter", 0.0f);
        setParameterActual ("stereoWidth", 10.0f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::toggleAB()
{
    if (usingA)
    {
        slotA = audioProcessor.parameters().copyState();
        audioProcessor.parameters().replaceState (slotB.createCopy());
        usingA = false;
    }
    else
    {
        slotB = audioProcessor.parameters().copyState();
        audioProcessor.parameters().replaceState (slotA.createCopy());
        usingA = true;
    }
    abButton.setTooltip (usingA ? "A active" : "B active");
}

void ConsoleChannelStripXAudioProcessorEditor::showMainMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("EQ MODEL");
    m.addItem (1, "02 Brown");
    m.addItem (2, "242 Black");
    m.addSeparator();
    m.addSectionHeader ("ROUTING");
    m.addItem (10, "FLT > EQ > DYN");
    m.addItem (11, "FLT > DYN > EQ");
    m.addItem (12, "DYN > FLT > EQ");
    m.addSeparator();
    m.addItem (20, "Mute / Unmute");

    auto safe = juce::Component::SafePointer<ConsoleChannelStripXAudioProcessorEditor> (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&menuButton), [safe] (int result)
    {
        if (safe == nullptr || result == 0) return;
        if (result == 1) safe->setParameterActual ("eqModel", 0.0f);
        else if (result == 2) safe->setParameterActual ("eqModel", 1.0f);
        else if (result >= 10 && result <= 12) safe->setParameterActual ("routing", (float) (result - 10));
        else if (result == 20)
        {
            const float current = safe->audioProcessor.parameters().getRawParameterValue ("mute")->load();
            safe->setParameterActual ("mute", current > 0.5f ? 0.0f : 1.0f);
        }
    });
}

void ConsoleChannelStripXAudioProcessorEditor::showSettingsMenu()
{
    juce::PopupMenu m;
    m.addItem (1, "Reset approved 1536 x 1024 view");
    m.addItem (2, "INIT all parameters");
    m.addSeparator();
    m.addItem (3, "Silveton Channel Strip v0.5.2", false, false);
    auto safe = juce::Component::SafePointer<ConsoleChannelStripXAudioProcessorEditor> (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&settingsButton), [safe] (int result)
    {
        if (safe == nullptr) return;
        if (result == 1) safe->setSize (kDesignWidth, kDesignHeight);
        else if (result == 2) safe->presetBox.setSelectedId (1, juce::sendNotificationSync);
    });
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatParameterValue (const juce::String& id, double value)
{
    if (containsIgnoreCase (id, "freq") || id == "stereoFocus")
    {
        if (value >= 1000.0)
            return juce::String (value / 1000.0, value >= 10000.0 ? 1 : 2) + " kHz";
        return juce::String (value, value < 100.0 ? 1 : 0) + " Hz";
    }
    if (id == "gateAttack" || id == "compAttack" || id == "stereoDelay")
        return juce::String (value, value < 10.0 ? 1 : 0) + " ms";
    if (id == "gateRelease" || id == "gateHold" || id == "compRelease")
        return value < 1.0 ? juce::String (value * 1000.0, 0) + " ms" : juce::String (value, 2) + " s";
    if (id == "stereoDetune")
        return juce::String (value, 1) + " ct";
    if (id == "mix")
        return juce::String (value, 0) + "%";
    if (id == "saturation" || id == "satMix" || id == "compKnee")
        return juce::String (value, 0) + " %";
    if (id == "stereoWidth")
        return juce::String (100.0 + value, 0) + " %";
    if (id == "satTone")
        return juce::String (value, 0) + " %";
    if (id == "pan" || id == "stereoBalance")
    {
        if (std::abs (value) < 0.005) return "C";
        return value < 0.0 ? "L " + juce::String (std::abs (value) * 100.0, 0)
                           : "R " + juce::String (value * 100.0, 0);
    }
    if (containsIgnoreCase (id, "q"))
        return juce::String (value, 2);
    if (id == "compRatio")
        return juce::String (value, 1) + ":1";
    return juce::String (value, 1) + " dB";
}

double ConsoleChannelStripXAudioProcessorEditor::parseParameterValue (const juce::String& id, const juce::String& raw)
{
    auto s = raw.trim().toLowerCase();
    double value = s.getDoubleValue();
    if ((containsIgnoreCase (id, "freq") || id == "stereoFocus") && s.containsChar ('k')) value *= 1000.0;
    if ((id == "gateRelease" || id == "gateHold" || id == "compRelease") && s.contains ("ms")) value *= 0.001;
    if (id == "stereoWidth" && s.containsChar ('%')) value -= 100.0;
    if (id == "pan" || id == "stereoBalance")
    {
        if (s.startsWithChar ('l')) return -std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('r')) return std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('c')) return 0.0;
    }
    return value;
}

float ConsoleChannelStripXAudioProcessorEditor::smoothMeter (float current, float target) noexcept
{
    if (target > current) return target;
    return current + (target - current) * 0.18f;
}

void ConsoleChannelStripXAudioProcessorEditor::updatePeakHold (float value, float& hold, int& ticks) noexcept
{
    if (value >= hold) { hold = value; ticks = 28; }
    else if (ticks > 0) --ticks;
    else hold = juce::jmax (value, hold - 1.25f);
}
