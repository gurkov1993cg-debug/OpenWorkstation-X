#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "DynamicsCircuitFactory.h"
#include <algorithm>
#include <cmath>

namespace
{
    using Range = juce::NormalisableRange<float>;

    std::unique_ptr<juce::RangedAudioParameter> makeFloat (const char* id, const char* name,
                                                            float min, float max, float def,
                                                            float centre = 0.0f)
    {
        Range r (min, max);
        if (centre > min && centre < max)
            r.setSkewForCentre (centre);
        return std::make_unique<juce::AudioParameterFloat> (id, name, r, def);
    }

    std::unique_ptr<juce::RangedAudioParameter> makeBool (const char* id, const char* name, bool def)
    {
        return std::make_unique<juce::AudioParameterBool> (id, name, def);
    }

    std::unique_ptr<juce::RangedAudioParameter> makeChoice (const char* id, const char* name,
                                                             juce::StringArray items, int def)
    {
        return std::make_unique<juce::AudioParameterChoice> (id, name, std::move (items), def);
    }

    constexpr float kPi = 3.14159265358979323846f;
}

ConsoleChannelStripXAudioProcessor::ConsoleChannelStripXAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, &undoManager, "PARAMETERS", createParameterLayout())
{
}

void ConsoleChannelStripXAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate > 1.0 ? sampleRate : 44100.0;
    engine.prepare (currentSampleRate, samplesPerBlock, getTotalNumOutputChannels());
    resetExtensionState();
    const int latency = juce::jmax (0, DspEngine::latencySamples());
    for (auto& line : dryDelay) line.assign ((size_t) juce::jmax (1, latency), 0.0f);
    dryDelayPos = 0;
    alignedDry.setSize (juce::jmax (2, getTotalNumOutputChannels()), juce::jmax (1, samplesPerBlock), false, true, false);
    setLatencySamples (latency);
}

void ConsoleChannelStripXAudioProcessor::releaseResources() {}

bool ConsoleChannelStripXAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (out == juce::AudioChannelSet::mono())
        return in == juce::AudioChannelSet::mono();
    if (out == juce::AudioChannelSet::stereo())
        return in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
    return false;
}

float ConsoleChannelStripXAudioProcessor::param (const char* id) const noexcept
{
    if (auto* p = apvts.getRawParameterValue (id))
        return p->load();
    return 0.0f;
}

DspEngine::Params ConsoleChannelStripXAudioProcessor::readParams() const
{
    DspEngine::Params p;
    const auto v = [this] (const char* id) { return param (id); };

    const bool inputOn = v ("inputOn") > 0.5f;
    p.inputTrimDb = inputOn ? v ("inputTrim") : 0.0f;
    p.inputDrive = inputOn ? v ("inputDrive") : 0.0f;
    p.inputMode = inputOn ? static_cast<int> (v ("inputMode")) : 0;
    p.inputPad = inputOn && v ("inputPad") > 0.5f;
    p.polarity = inputOn && v ("polarity") > 0.5f;

    const bool filtersOn = v ("filtersOn") > 0.5f;
    const int hpSlope = static_cast<int> (std::lround (v ("hpSlope")));
    const int lpSlope = static_cast<int> (std::lround (v ("lpSlope")));
    p.hpOn = filtersOn && v ("hpOn") > 0.5f && hpSlope != 0; // 6 dB is supplied by the extension stage.
    p.hpFreq = v ("hpFreq");
    p.lpOn = filtersOn && v ("lpOn") > 0.5f && lpSlope != 0;
    p.lpFreq = v ("lpFreq");

    p.eqOn = v ("eqOn") > 0.5f;
    p.blackEq = v ("eqModel") > 0.5f;
    p.lfBell = v ("lfBell") > 0.5f;
    p.lfFreq = v ("lfFreq");
    p.lfGain = v ("lfGain");
    p.lmfFreq = v ("lmfFreq");
    p.lmfGain = v ("lmfGain");
    p.lmfQ = v ("lmfQ");
    p.hmfFreq = v ("hmfFreq");
    p.hmfGain = v ("hmfGain");
    p.hmfQ = v ("hmfQ");
    p.hfBell = v ("hfBell") > 0.5f;
    p.hfFreq = v ("hfFreq");
    p.hfGain = v ("hfGain");

    const bool dynOn = v ("dynOn") > 0.5f;
    const bool compFast = v ("compFast") > 0.5f;
    const bool gateFast = v ("gateFast") > 0.5f;

    p.dynOn = dynOn;
    p.dynamicsCircuit = DynamicsCircuitFactory::fromPanel (
        v ("compThreshold"), v ("compRatio"), v ("compRelease"),
        compFast, v ("compPeak") > 0.5f, v ("compOn") > 0.5f,
        v ("gateThreshold"), v ("gateRange"), v ("gateHold"), v ("gateRelease"),
        gateFast, v ("gateExpand") > 0.5f, v ("gateOn") > 0.5f);

    p.routing = static_cast<int> (v ("routing"));

    const bool outputOn = v ("outputOn") > 0.5f;
    const float makeup = dynOn && v ("compOn") > 0.5f ? v ("compMakeup") : 0.0f;
    p.vcaFaderDb = (outputOn ? v ("vcaFader") : 0.0f) + makeup;
    p.outputTrimDb = outputOn ? v ("outputTrim") : 0.0f;
    p.autoLevelMatch = outputOn && v ("autoLevel") > 0.5f;

    const bool stereoOn = v ("stereoOn") > 0.5f;
    p.pan = stereoOn ? v ("pan") : 0.0f;
    p.mix = v ("mix") * 0.01f;
    p.mute = v ("mute") > 0.5f;
    p.bypass = v ("bypass") > 0.5f;

    const bool satOn = v ("saturationOn") > 0.5f;
    const int satType = static_cast<int> (std::lround (v ("satType")));
    const int satCharacter = static_cast<int> (std::lround (v ("satCharacter")));
    const float satMix = juce::jlimit (0.0f, 100.0f, v ("satMix")) * 0.01f;

    float typeDrive = 0.0f;
    float typeAmount = 1.0f;
    if (satType == 0) { typeDrive = 2.0f; typeAmount = 0.85f; }       // Tube: denser drive, softer amount.
    else if (satType == 1) { typeDrive = -1.0f; typeAmount = 0.72f; } // Tape: gentler drive.

    float characterDrive = 0.0f;
    float characterAmount = 1.0f;
    if (satCharacter == 0) { characterDrive = -1.0f; characterAmount = 0.70f; }
    else if (satCharacter == 2) { characterDrive = 3.0f; characterAmount = 1.25f; }

    p.saturationOn = satOn && satMix > 0.0001f;
    p.saturation = juce::jlimit (0.0f, 100.0f, v ("saturation") * typeAmount * characterAmount * satMix);
    p.saturationGainDb = juce::jlimit (-12.0f, 18.0f,
                                       (v ("satGain") + typeDrive + characterDrive) * satMix);

    p.stereoWidth = stereoOn ? v ("stereoWidth") : 0.0f;
    p.stereoDetune = stereoOn ? v ("stereoDetune") : 0.0f;
    p.stereoDelayMs = stereoOn ? v ("stereoDelay") : 0.0f;
    p.stereoFocusHz = stereoOn ? v ("stereoFocus") : 120.0f;
    return p;
}

void ConsoleChannelStripXAudioProcessor::resetExtensionState() noexcept
{
    for (auto& stage : hpPrevIn) stage.fill (0.0f);
    for (auto& stage : hpPrevOut) stage.fill (0.0f);
    for (auto& stage : lpState) stage.fill (0.0f);
    for (auto& st : lfQState) st = {};
    for (auto& st : hfQState) st = {};
    satToneLow.fill (0.0f);
    bassMonoSideLow = 0.0f;
    compEnvChosen.fill (0.0f);
    compEnvReference.fill (0.0f);
    gateGainChosen = 1.0f;
    gateGainReference = 1.0f;
}

void ConsoleChannelStripXAudioProcessor::processSlopeExtensions (juce::AudioBuffer<float>& buffer,
                                                                  int hpStages, int lpStages,
                                                                  float hpFreq, float lpFreq) noexcept
{
    hpStages = juce::jlimit (0, 2, hpStages);
    lpStages = juce::jlimit (0, 2, lpStages);
    if (hpStages == 0)
    {
        for (auto& stage : hpPrevIn) stage.fill (0.0f);
        for (auto& stage : hpPrevOut) stage.fill (0.0f);
    }
    if (lpStages == 0)
        for (auto& stage : lpState) stage.fill (0.0f);
    if (hpStages == 0 && lpStages == 0)
        return;

    const float fs = static_cast<float> (juce::jmax (8000.0, currentSampleRate));
    const float hpA = std::exp (-2.0f * kPi * juce::jlimit (5.0f, 0.45f * fs, hpFreq) / fs);
    const float lpAlpha = 1.0f - std::exp (-2.0f * kPi * juce::jlimit (20.0f, 0.45f * fs, lpFreq) / fs);
    const int channels = juce::jmin (2, buffer.getNumChannels());

    for (int ch = 0; ch < channels; ++ch)
    {
        auto* data = buffer.getWritePointer (ch);
        for (int n = 0; n < buffer.getNumSamples(); ++n)
        {
            float x = data[n];
            for (int stage = 0; stage < hpStages; ++stage)
            {
                const float y = hpA * (hpPrevOut[(size_t) stage][(size_t) ch]
                                      + x - hpPrevIn[(size_t) stage][(size_t) ch]);
                hpPrevIn[(size_t) stage][(size_t) ch] = x;
                hpPrevOut[(size_t) stage][(size_t) ch] = y;
                x = y;
            }
            for (int stage = 0; stage < lpStages; ++stage)
            {
                auto& z = lpState[(size_t) stage][(size_t) ch];
                z += lpAlpha * (x - z);
                x = z;
            }
            data[n] = x;
        }
    }
}

void ConsoleChannelStripXAudioProcessor::processDynamicsControlExtensions (juce::AudioBuffer<float>& buffer,
                                                                              const juce::AudioBuffer<float>& detector) noexcept
{
    if (param ("dynOn") <= 0.5f)
    {
        compEnvChosen.fill (0.0f);
        compEnvReference.fill (0.0f);
        gateGainChosen = gateGainReference = 1.0f;
        return;
    }

    const float fs = static_cast<float> (juce::jmax (8000.0, currentSampleRate));
    const int channels = juce::jmin (2, buffer.getNumChannels());
    const int samples = buffer.getNumSamples();

    const auto coeff = [fs] (float ms)
    {
        ms = juce::jmax (0.05f, ms);
        return 1.0f - std::exp (-1.0f / (0.001f * ms * fs));
    };

    if (param ("compOn") > 0.5f)
    {
        const float threshold = param ("compThreshold");
        const float ratio = juce::jmax (1.0f, param ("compRatio"));
        const float attackMs = param ("compFast") > 0.5f ? 1.0f : param ("compAttack");
        const float releaseMs = juce::jmax (1.0f, param ("compRelease") * 1000.0f);
        const float kneeDb = juce::jlimit (0.0f, 12.0f, param ("compKnee") * 0.12f);
        const float attackA = coeff (attackMs);
        const float referenceAttackA = coeff (10.0f);
        const float releaseA = coeff (releaseMs);

        const auto staticGr = [threshold, ratio] (float env, float knee)
        {
            const float levelDb = 20.0f * std::log10 (juce::jmax (1.0e-9f, env));
            const float slope = 1.0f - 1.0f / ratio;
            if (knee <= 1.0e-4f)
                return levelDb > threshold ? (levelDb - threshold) * slope : 0.0f;

            const float lo = threshold - 0.5f * knee;
            const float hi = threshold + 0.5f * knee;
            if (levelDb <= lo) return 0.0f;
            if (levelDb >= hi) return (levelDb - threshold) * slope;
            const float x = levelDb - lo;
            return slope * x * x / (2.0f * knee);
        };

        // Detect from the pre-core aligned signal so KNEE and ATTACK remain real,
        // independently audible controls after the locked v0.4.1 compressor stage.
        for (int ch = 0; ch < channels; ++ch)
        {
            auto* data = buffer.getWritePointer (ch);
            auto& chosen = compEnvChosen[(size_t) ch];
            auto& reference = compEnvReference[(size_t) ch];
            for (int n = 0; n < samples; ++n)
            {
                const int detectorCh = juce::jmin (ch, juce::jmax (0, detector.getNumChannels() - 1));
                const float x = detector.getNumChannels() > 0
                                  ? std::abs (detector.getSample (detectorCh, n))
                                  : std::abs (data[n]);
                const float aChosen = x > chosen ? attackA : releaseA;
                const float aReference = x > reference ? referenceAttackA : releaseA;
                chosen += aChosen * (x - chosen);
                reference += aReference * (x - reference);

                const float chosenGr = staticGr (chosen, kneeDb);
                const float referenceGr = staticGr (reference, 0.0f);
                const float correctionDb = juce::jlimit (-6.0f, 6.0f, chosenGr - referenceGr);
                if (correctionDb > 0.0f)
                    storePeakMax (compExtensionPeakReductionDb, correctionDb);
                data[n] *= std::pow (10.0f, -correctionDb / 20.0f);
            }
        }
    }

    if (param ("gateOn") > 0.5f && detector.getNumChannels() > 0)
    {
        const float threshold = param ("gateThreshold");
        const float rangeDb = juce::jlimit (0.0f, 60.0f, param ("gateRange"));
        const float attackMs = param ("gateFast") > 0.5f ? 0.1f : param ("gateAttack");
        const float releaseMs = juce::jmax (1.0f, param ("gateRelease") * 1000.0f);
        const float attackA = coeff (attackMs);
        const float referenceAttackA = coeff (1.0f);
        const float releaseA = coeff (releaseMs);
        float closedGain = std::pow (10.0f, -rangeDb / 20.0f);
        if (param ("gateExpand") > 0.5f)
            closedGain = std::sqrt (closedGain);

        for (int n = 0; n < samples; ++n)
        {
            float peak = std::abs (detector.getSample (0, n));
            if (detector.getNumChannels() > 1)
                peak = juce::jmax (peak, std::abs (detector.getSample (1, n)));
            const float levelDb = 20.0f * std::log10 (juce::jmax (1.0e-9f, peak));
            const float target = levelDb >= threshold ? 1.0f : closedGain;

            const float cA = target > gateGainChosen ? attackA : releaseA;
            const float rA = target > gateGainReference ? referenceAttackA : releaseA;
            gateGainChosen += cA * (target - gateGainChosen);
            gateGainReference += rA * (target - gateGainReference);
            const float correction = juce::jlimit (0.25f, 4.0f,
                                                   gateGainChosen / juce::jmax (0.0001f, gateGainReference));
            if (correction < 1.0f)
                storePeakMax (gateExtensionPeakReductionDb, -20.0f * std::log10 (juce::jmax (1.0e-6f, correction)));
            for (int ch = 0; ch < channels; ++ch)
                buffer.setSample (ch, n, buffer.getSample (ch, n) * correction);
        }
    }
}

void ConsoleChannelStripXAudioProcessor::processOuterBandQCorrection (juce::AudioBuffer<float>& buffer,
                                                                          float lfFreq, float lfGain, float lfQ,
                                                                          float hfFreq, float hfGain, float hfQ) noexcept
{
    const float fs = static_cast<float> (juce::jmax (8000.0, currentSampleRate));
    const int channels = juce::jmin (2, buffer.getNumChannels());

    auto processBand = [fs, channels, &buffer] (float freq, float originalGain, float q, float referenceQ,
                                                std::array<BiquadState, 2>& states)
    {
        if (std::abs (originalGain) < 0.001f || std::abs (q - referenceQ) < 0.001f)
        {
            for (auto& st : states) st = {};
            return;
        }

        const float ratio = juce::jlimit (0.25f, 4.0f, q / referenceQ);
        const float correctionDb = juce::jlimit (-6.0f, 6.0f, originalGain * std::log2 (ratio) * 0.35f);
        if (std::abs (correctionDb) < 0.001f)
            return;

        freq = juce::jlimit (20.0f, 0.45f * fs, freq);
        q = juce::jlimit (0.20f, 4.0f, q);
        const float A = std::pow (10.0f, correctionDb / 40.0f);
        const float w0 = 2.0f * kPi * freq / fs;
        const float alpha = std::sin (w0) / (2.0f * q);
        const float cw = std::cos (w0);
        const float a0 = 1.0f + alpha / A;
        const float b0 = (1.0f + alpha * A) / a0;
        const float b1 = (-2.0f * cw) / a0;
        const float b2 = (1.0f - alpha * A) / a0;
        const float a1 = (-2.0f * cw) / a0;
        const float a2 = (1.0f - alpha / A) / a0;

        for (int ch = 0; ch < channels; ++ch)
        {
            auto* data = buffer.getWritePointer (ch);
            auto& st = states[(size_t) ch];
            for (int n = 0; n < buffer.getNumSamples(); ++n)
            {
                const float x = data[n];
                const float y = b0 * x + b1 * st.x1 + b2 * st.x2 - a1 * st.y1 - a2 * st.y2;
                st.x2 = st.x1; st.x1 = x; st.y2 = st.y1; st.y1 = y;
                data[n] = y;
            }
        }
    };

    processBand (lfFreq, lfGain, lfQ, 1.0f, lfQState);
    processBand (hfFreq, hfGain, hfQ, 1.7f, hfQState);
}

void ConsoleChannelStripXAudioProcessor::processSaturationTone (juce::AudioBuffer<float>& buffer, float tone) noexcept
{
    tone = juce::jlimit (-100.0f, 100.0f, tone) * 0.01f;
    if (std::abs (tone) < 0.0001f)
        return;

    const float fs = static_cast<float> (juce::jmax (8000.0, currentSampleRate));
    const float alpha = 1.0f - std::exp (-2.0f * kPi * 1800.0f / fs);
    const int channels = juce::jmin (2, buffer.getNumChannels());
    for (int ch = 0; ch < channels; ++ch)
    {
        auto* data = buffer.getWritePointer (ch);
        auto& low = satToneLow[(size_t) ch];
        for (int n = 0; n < buffer.getNumSamples(); ++n)
        {
            const float x = data[n];
            low += alpha * (x - low);
            const float high = x - low;
            data[n] = x + high * tone * 0.60f;
        }
    }
}

void ConsoleChannelStripXAudioProcessor::processStereoExtensions (juce::AudioBuffer<float>& buffer,
                                                                   int mode, float balance,
                                                                   int bassMonoChoice) noexcept
{
    if (buffer.getNumChannels() < 2)
        return;

    balance = juce::jlimit (-1.0f, 1.0f, balance);
    const float cutoff = bassMonoChoice == 1 ? 80.0f : bassMonoChoice == 2 ? 120.0f : bassMonoChoice == 3 ? 200.0f : 0.0f;
    const float fs = static_cast<float> (juce::jmax (8000.0, currentSampleRate));
    const float bassAlpha = cutoff > 0.0f ? 1.0f - std::exp (-2.0f * kPi * cutoff / fs) : 0.0f;
    if (cutoff <= 0.0f) bassMonoSideLow = 0.0f;

    auto* l = buffer.getWritePointer (0);
    auto* r = buffer.getWritePointer (1);
    for (int n = 0; n < buffer.getNumSamples(); ++n)
    {
        float left = l[n];
        float right = r[n];

        if (mode == 0)
        {
            if (balance > 0.0f) left *= 1.0f - balance;
            else if (balance < 0.0f) right *= 1.0f + balance;
        }
        else
        {
            float mid = 0.5f * (left + right);
            float side = 0.5f * (left - right);
            if (balance > 0.0f) mid *= 1.0f - balance;
            else if (balance < 0.0f) side *= 1.0f + balance;
            left = mid + side;
            right = mid - side;
        }

        if (cutoff > 0.0f)
        {
            const float mid = 0.5f * (left + right);
            float side = 0.5f * (left - right);
            bassMonoSideLow += bassAlpha * (side - bassMonoSideLow);
            side -= bassMonoSideLow;
            left = mid + side;
            right = mid - side;
        }

        l[n] = left;
        r[n] = right;
    }
}

void ConsoleChannelStripXAudioProcessor::captureAlignedDry (const juce::AudioBuffer<float>& input,
                                                                  juce::AudioBuffer<float>& dry)
{
    const int channels = juce::jmin (2, input.getNumChannels());
    const int samples = input.getNumSamples();
    if (dry.getNumChannels() < channels || dry.getNumSamples() < samples)
        dry.setSize (juce::jmax (2, channels), samples, false, false, true);

    const int latency = juce::jmax (0, DspEngine::latencySamples());
    if (latency <= 0)
    {
        for (int ch = 0; ch < channels; ++ch)
            dry.copyFrom (ch, 0, input, ch, 0, samples);
        return;
    }

    for (int n = 0; n < samples; ++n)
    {
        for (int ch = 0; ch < channels; ++ch)
        {
            auto& line = dryDelay[(size_t) ch];
            if ((int) line.size() != latency) line.assign ((size_t) latency, 0.0f);
            const float delayed = line[(size_t) dryDelayPos];
            line[(size_t) dryDelayPos] = input.getSample (ch, n);
            dry.setSample (ch, n, delayed);
        }
        dryDelayPos = (dryDelayPos + 1) % latency;
    }

    if (channels == 1 && dry.getNumChannels() > 1)
        dry.copyFrom (1, 0, dry, 0, 0, samples);
}

float ConsoleChannelStripXAudioProcessor::toDb (float linear) noexcept
{
    return 20.0f * std::log10 (juce::jmax (1.0e-9f, linear));
}

float ConsoleChannelStripXAudioProcessor::consumeMeter (std::atomic<float>& meter) noexcept
{
    return meter.exchange (-72.0f);
}

void ConsoleChannelStripXAudioProcessor::storePeakMax (std::atomic<float>& meter, float value) noexcept
{
    float old = meter.load (std::memory_order_relaxed);
    while (value > old && ! meter.compare_exchange_weak (old, value,
                                                          std::memory_order_release,
                                                          std::memory_order_relaxed)) {}
}

float ConsoleChannelStripXAudioProcessor::compressorPeakReductionMeter() noexcept
{
    const float core = std::abs (engine.consumeCompressorPeakReductionDb());
    const float extension = compExtensionPeakReductionDb.exchange (0.0f);
    return juce::jlimit (0.0f, 60.0f, core + extension);
}

float ConsoleChannelStripXAudioProcessor::gatePeakReductionMeter() noexcept
{
    const float core = std::abs (engine.consumeGatePeakReductionDb());
    const float extension = gateExtensionPeakReductionDb.exchange (0.0f);
    return juce::jlimit (0.0f, 60.0f, core + extension);
}

void ConsoleChannelStripXAudioProcessor::updateInputMeters (const juce::AudioBuffer<float>& buffer) noexcept
{
    const int channels = buffer.getNumChannels();
    const float l = channels > 0 ? buffer.getMagnitude (0, 0, buffer.getNumSamples()) : 0.0f;
    const float r = channels > 1 ? buffer.getMagnitude (1, 0, buffer.getNumSamples()) : l;
    const float lDb = toDb (l), rDb = toDb (r);
    storePeakMax (inputPeakLDb, lDb);
    storePeakMax (inputPeakRDb, rDb);
    inputPeakDb.store (juce::jmax (lDb, rDb));
}

void ConsoleChannelStripXAudioProcessor::updateOutputMeters (const juce::AudioBuffer<float>& buffer) noexcept
{
    const int channels = buffer.getNumChannels();
    const float l = channels > 0 ? buffer.getMagnitude (0, 0, buffer.getNumSamples()) : 0.0f;
    const float r = channels > 1 ? buffer.getMagnitude (1, 0, buffer.getNumSamples()) : l;
    const float lDb = toDb (l), rDb = toDb (r);
    storePeakMax (outputPeakLDb, lDb);
    storePeakMax (outputPeakRDb, rDb);
    outputPeakDb.store (juce::jmax (lDb, rDb));
}

void ConsoleChannelStripXAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int inputs = getTotalNumInputChannels();
    const int outputs = getTotalNumOutputChannels();

    if (inputs == 1 && outputs >= 2)
        buffer.copyFrom (1, 0, buffer, 0, 0, buffer.getNumSamples());
    else
        for (int ch = inputs; ch < outputs; ++ch)
            buffer.clear (ch, 0, buffer.getNumSamples());

    updateInputMeters (buffer);
    captureAlignedDry (buffer, alignedDry);

    const float globalMix = juce::jlimit (0.0f, 1.0f, param ("mix") * 0.01f);
    const bool bypass = param ("bypass") > 0.5f;
    const bool mute = param ("mute") > 0.5f;

    auto p = readParams();
    // Global mix/bypass/mute are handled after the complete Silveton extension chain,
    // using a latency-aligned dry path. The locked v0.4.1 core remains fully warm.
    p.mix = 1.0f;
    p.bypass = false;
    p.mute = false;

    const bool filtersOn = param ("filtersOn") > 0.5f;
    const int hpSlope = static_cast<int> (std::lround (param ("hpSlope")));
    const int lpSlope = static_cast<int> (std::lround (param ("lpSlope")));
    const int hpExtraStages = filtersOn && param ("hpOn") > 0.5f ? (hpSlope == 0 ? 1 : hpSlope == 2 ? 2 : 0) : 0;
    const int lpExtraStages = filtersOn && param ("lpOn") > 0.5f ? (lpSlope == 0 ? 1 : lpSlope == 2 ? 2 : 0) : 0;
    processSlopeExtensions (buffer, hpExtraStages, lpExtraStages, param ("hpFreq"), param ("lpFreq"));

    engine.process (buffer, p);

    processDynamicsControlExtensions (buffer, alignedDry);

    if (param ("eqOn") > 0.5f)
        processOuterBandQCorrection (buffer, param ("lfFreq"), param ("lfGain"), param ("lfQ"),
                                     param ("hfFreq"), param ("hfGain"), param ("hfQ"));

    if (param ("saturationOn") > 0.5f && param ("satMix") > 0.0f)
    {
        processSaturationTone (buffer, param ("satTone"));
        const float trim = std::pow (10.0f, param ("satOutputTrim") / 20.0f);
        buffer.applyGain (trim);
    }

    if (param ("stereoOn") > 0.5f)
        processStereoExtensions (buffer,
                                 static_cast<int> (std::lround (param ("stereoMode"))),
                                 param ("stereoBalance"),
                                 static_cast<int> (std::lround (param ("bassMono"))));

    const float wetMix = bypass ? 0.0f : globalMix;
    const int channels = juce::jmin (buffer.getNumChannels(), alignedDry.getNumChannels());
    const int samples = buffer.getNumSamples();
    for (int ch = 0; ch < channels; ++ch)
    {
        auto* wet = buffer.getWritePointer (ch);
        const auto* dry = alignedDry.getReadPointer (ch);
        for (int n = 0; n < samples; ++n)
            wet[n] = dry[n] + (wet[n] - dry[n]) * wetMix;
    }

    if (mute)
        buffer.clear();

    updateOutputMeters (buffer);
}

juce::AudioProcessorEditor* ConsoleChannelStripXAudioProcessor::createEditor()
{
    return new ConsoleChannelStripXAudioProcessorEditor (*this);
}

void ConsoleChannelStripXAudioProcessor::resetParametersToDefaults()
{
    undoManager.beginNewTransaction ("INIT");
    for (auto* parameter : getParameters())
    {
        if (auto* ranged = dynamic_cast<juce::RangedAudioParameter*> (parameter))
        {
            ranged->beginChangeGesture();
            ranged->setValueNotifyingHost (ranged->getDefaultValue());
            ranged->endChangeGesture();
        }
    }
}

void ConsoleChannelStripXAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void ConsoleChannelStripXAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorParameter* ConsoleChannelStripXAudioProcessor::getBypassParameter() const
{
    return apvts.getParameter ("bypass");
}

juce::AudioProcessorValueTreeState::ParameterLayout ConsoleChannelStripXAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (makeBool ("inputOn", "Input Section", true));
    p.push_back (makeFloat ("inputTrim", "Input Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeFloat ("inputDrive", "Input Drive", -20.0f, 20.0f, 0.0f));
    p.push_back (makeChoice ("inputMode", "Input Mode", { "Line", "Mic" }, 0));
    p.push_back (makeBool ("inputPad", "Input Pad -20 dB", false));
    p.push_back (makeBool ("polarity", "Polarity", false));

    p.push_back (makeBool ("filtersOn", "Filters Section", true));
    p.push_back (makeBool ("hpOn", "High Pass On", true));
    p.push_back (makeFloat ("hpFreq", "High Pass Frequency", 16.0f, 350.0f, 80.0f, 100.0f));
    p.push_back (makeChoice ("hpSlope", "High Pass Slope", { "6 dB", "12 dB", "24 dB" }, 1));
    p.push_back (makeBool ("lpOn", "Low Pass On", true));
    p.push_back (makeFloat ("lpFreq", "Low Pass Frequency", 3000.0f, 22000.0f, 18000.0f, 10000.0f));
    p.push_back (makeChoice ("lpSlope", "Low Pass Slope", { "6 dB", "12 dB", "24 dB" }, 1));

    p.push_back (makeBool ("eqOn", "EQ On", true));
    p.push_back (makeChoice ("eqModel", "EQ Model", { "02 Brown", "242 Black" }, 1));
    p.push_back (makeBool ("hfBell", "HF Bell", false));
    p.push_back (makeFloat ("hfFreq", "HF Frequency", 1500.0f, 16000.0f, 10000.0f, 8000.0f));
    p.push_back (makeFloat ("hfGain", "HF Gain", -18.0f, 18.0f, 2.5f));
    p.push_back (makeFloat ("hfQ", "HF Q", 0.30f, 3.0f, 0.70f, 1.0f));
    p.push_back (makeFloat ("hmfFreq", "HMF Frequency", 600.0f, 7000.0f, 2500.0f, 2500.0f));
    p.push_back (makeFloat ("hmfGain", "HMF Gain", -18.0f, 18.0f, -1.8f));
    p.push_back (makeFloat ("hmfQ", "HMF Q", 0.10f, 3.5f, 1.2f, 1.0f));
    p.push_back (makeFloat ("lmfFreq", "LMF Frequency", 200.0f, 2500.0f, 250.0f, 700.0f));
    p.push_back (makeFloat ("lmfGain", "LMF Gain", -18.0f, 18.0f, 3.0f));
    p.push_back (makeFloat ("lmfQ", "LMF Q", 0.10f, 3.5f, 1.0f, 1.0f));
    p.push_back (makeBool ("lfBell", "LF Bell", false));
    p.push_back (makeFloat ("lfFreq", "LF Frequency", 30.0f, 450.0f, 80.0f, 120.0f));
    p.push_back (makeFloat ("lfGain", "LF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("lfQ", "LF Q", 0.30f, 3.0f, 0.80f, 1.0f));

    p.push_back (makeBool ("dynOn", "Dynamics On", true));
    p.push_back (makeBool ("compOn", "Compressor On", true));
    p.push_back (makeFloat ("compThreshold", "Compressor Threshold", -30.0f, 10.0f, -18.0f));
    p.push_back (makeFloat ("compRatio", "Compressor Ratio", 1.0f, 20.0f, 4.0f, 4.0f));
    p.push_back (makeFloat ("compAttack", "Compressor Attack", 0.1f, 100.0f, 10.0f, 10.0f));
    p.push_back (makeFloat ("compRelease", "Compressor Release", 0.10f, 4.0f, 0.25f, 0.50f));
    p.push_back (makeFloat ("compKnee", "Compressor Knee", 0.0f, 100.0f, 25.0f));
    p.push_back (makeFloat ("compMakeup", "Compressor Makeup", -20.0f, 20.0f, 2.0f));
    p.push_back (makeBool ("compFast", "Compressor Fast", false));
    p.push_back (makeBool ("compPeak", "Compressor Peak", true));

    p.push_back (makeBool ("gateOn", "Gate On", true));
    p.push_back (makeFloat ("gateThreshold", "Gate Threshold", -60.0f, 0.0f, -32.0f));
    p.push_back (makeFloat ("gateRange", "Gate Range", 0.0f, 60.0f, 44.0f));
    p.push_back (makeFloat ("gateAttack", "Gate Attack", 0.1f, 1000.0f, 1.0f, 10.0f));
    p.push_back (makeFloat ("gateHold", "Gate Hold", 0.0f, 4.0f, 0.05f, 0.4f));
    p.push_back (makeFloat ("gateRelease", "Gate Release", 0.01f, 5.0f, 0.12f, 0.50f));
    p.push_back (makeBool ("gateFast", "Gate Fast", false));
    p.push_back (makeBool ("gateExpand", "Expander Mode", false));

    p.push_back (makeChoice ("routing", "Routing", { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" }, 0));

    p.push_back (makeBool ("saturationOn", "Saturation In", true));
    p.push_back (makeChoice ("satType", "Saturation Type", { "Tube", "Tape", "Solid State" }, 0));
    p.push_back (makeFloat ("satGain", "Saturation Drive", -12.0f, 18.0f, 6.0f));
    p.push_back (makeFloat ("saturation", "Saturation Amount", 0.0f, 100.0f, 70.0f));
    p.push_back (makeFloat ("satTone", "Saturation Tone", -100.0f, 100.0f, 10.0f));
    p.push_back (makeFloat ("satMix", "Saturation Mix", 0.0f, 100.0f, 100.0f));
    p.push_back (makeChoice ("satCharacter", "Saturation Character", { "Clean", "Warm", "Aggressive" }, 1));
    p.push_back (makeFloat ("satOutputTrim", "Saturation Output Trim", -12.0f, 12.0f, 0.0f));

    p.push_back (makeBool ("stereoOn", "Stereo Section", true));
    p.push_back (makeChoice ("stereoMode", "Stereo Mode", { "Stereo", "Mid / Side" }, 0));
    p.push_back (makeFloat ("stereoWidth", "Stereo Width", 0.0f, 100.0f, 20.0f));
    p.push_back (makeFloat ("pan", "Pan", -1.0f, 1.0f, 0.0f));
    p.push_back (makeFloat ("stereoFocus", "Stereo Focus", 20.0f, 10000.0f, 120.0f, 500.0f));
    p.push_back (makeFloat ("stereoBalance", "Stereo Balance", -1.0f, 1.0f, 0.0f));
    p.push_back (makeFloat ("stereoDetune", "Stereo Detune", 0.0f, 20.0f, 12.0f));
    p.push_back (makeFloat ("stereoDelay", "Stereo Delay", 0.0f, 25.0f, 8.0f));
    p.push_back (makeChoice ("bassMono", "Bass Mono", { "Off", "80 Hz", "120 Hz", "200 Hz" }, 1));

    p.push_back (makeBool ("outputOn", "Output Section", true));
    p.push_back (makeFloat ("vcaFader", "Output Level", -20.0f, 10.0f, 0.0f));
    p.push_back (makeFloat ("outputTrim", "Output Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeBool ("autoLevel", "Auto Level Match", true));

    p.push_back (makeFloat ("mix", "Mix", 0.0f, 100.0f, 100.0f));
    p.push_back (makeBool ("mute", "Mute", false));
    p.push_back (makeBool ("bypass", "Bypass", false));

    return { p.begin(), p.end() };
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ConsoleChannelStripXAudioProcessor();
}
