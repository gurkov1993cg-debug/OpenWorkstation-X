#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

class SilvetonLookAndFeel;

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using APVTS = juce::AudioProcessorValueTreeState;
    using SliderAttachment = APVTS::SliderAttachment;
    using ButtonAttachment = APVTS::ButtonAttachment;

    struct SliderControl
    {
        std::unique_ptr<juce::Label> label;
        std::unique_ptr<juce::Slider> slider;
        std::unique_ptr<SliderAttachment> attachment;
    };

    struct ToggleControl
    {
        std::unique_ptr<juce::TextButton> button;
        std::unique_ptr<ButtonAttachment> attachment;
    };

    struct ChoiceControl
    {
        std::string parameterId;
        std::vector<std::unique_ptr<juce::TextButton>> buttons;
    };

    ConsoleChannelStripXAudioProcessor& audioProcessor;
    std::unique_ptr<SilvetonLookAndFeel> silvetonLookAndFeel;
    juce::Image approvedSkin;

    std::vector<std::unique_ptr<SliderControl>> sliderControls;
    std::vector<std::unique_ptr<ToggleControl>> toggleControls;
    std::vector<std::unique_ptr<ChoiceControl>> choiceControls;
    std::unordered_map<std::string, juce::Component*> controlsById;
    std::unordered_map<std::string, juce::Label*> labelsById;

    juce::TextButton prevPresetButton { "<" };
    juce::TextButton nextPresetButton { ">" };
    juce::ComboBox presetBox;
    juce::TextButton abButton { "A / B" };
    juce::TextButton undoButton { "UNDO" };
    juce::TextButton redoButton { "REDO" };
    juce::TextButton menuButton { "MENU" };
    juce::TextButton settingsButton { "SETTINGS" };

    juce::ValueTree slotA, slotB;
    bool usingA = true;

    float inL = -72.0f, inR = -72.0f, outL = -72.0f, outR = -72.0f;
    float inHoldL = -72.0f, inHoldR = -72.0f, outHoldL = -72.0f, outHoldR = -72.0f;
    float compGr = 0.0f, gateGr = 0.0f;
    int inHoldTicksL = 0, inHoldTicksR = 0, outHoldTicksL = 0, outHoldTicksR = 0;

    void addSlider (const char* parameterId, const char* labelText, bool vertical = false);
    void addToggle (const char* parameterId, const char* buttonText);
    void addChoice (const char* parameterId, std::initializer_list<const char*> labels);

    void placeSlider (const char* parameterId, juce::Rectangle<int> bounds);
    void placeToggle (const char* parameterId, juce::Rectangle<int> bounds);
    void placeChoice (const char* parameterId, juce::Rectangle<int> bounds, int gap = 4);

    juce::Component* control (const char* parameterId) const;
    juce::Label* label (const char* parameterId) const;

    void timerCallback() override;
    void syncChoiceButtons();
    void cyclePreset (int delta);
    void applyPreset (int presetId);
    void toggleAB();
    void showMainMenu();
    void showSettingsMenu();
    void setParameterActual (const char* id, float actual);

    void drawPanel (juce::Graphics&, juce::Rectangle<int>, const juce::String& title) const;
    void drawStereoMeter (juce::Graphics&, juce::Rectangle<int>, float leftDb, float rightDb,
                          float holdLeftDb, float holdRightDb) const;
    void drawReductionMeter (juce::Graphics&, juce::Rectangle<int>, float reductionDb) const;
    void drawLogo (juce::Graphics&, juce::Rectangle<float>) const;

    static juce::String formatParameterValue (const juce::String& id, double value);
    static double parseParameterValue (const juce::String& id, const juce::String& text);
    static float smoothMeter (float current, float target) noexcept;
    static void updatePeakHold (float value, float& hold, int& ticks) noexcept;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
