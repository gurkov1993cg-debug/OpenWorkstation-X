#include "DspEngine.h"
#include <juce_audio_basics/juce_audio_basics.h>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <vector>

namespace
{
    constexpr double sampleRate = 48000.0;

    float dbGain (float db) { return juce::Decibels::decibelsToGain (db); }

    float rms (const std::vector<float>& v, size_t begin = 0)
    {
        if (begin >= v.size()) return 0.0f;
        double sum = 0.0;
        for (size_t i = begin; i < v.size(); ++i) sum += (double) v[i] * v[i];
        return (float) std::sqrt (sum / (double) (v.size() - begin));
    }

    float differenceRms (const std::vector<float>& a, const std::vector<float>& b)
    {
        const size_t n = juce::jmin (a.size(), b.size());
        if (n == 0) return 0.0f;
        double sum = 0.0;
        for (size_t i = 0; i < n; ++i)
        {
            const double d = (double) a[i] - b[i];
            sum += d * d;
        }
        return (float) std::sqrt (sum / (double) n);
    }

    std::vector<float> makeSine (float frequency, float amplitude, int samples)
    {
        std::vector<float> out ((size_t) samples);
        for (int i = 0; i < samples; ++i)
            out[(size_t) i] = amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                    * frequency * (float) i / (float) sampleRate);
        return out;
    }

    std::vector<float> render (const DspEngine::Params& params, const std::vector<float>& input,
                               int blockSize = 512)
    {
        DspEngine engine;
        engine.prepare (sampleRate, juce::jmax (1, blockSize), 1);
        std::vector<float> output (input.size());
        int offset = 0;
        while (offset < (int) input.size())
        {
            const int n = juce::jmin (blockSize, (int) input.size() - offset);
            juce::AudioBuffer<float> block (1, n);
            for (int i = 0; i < n; ++i) block.setSample (0, i, input[(size_t) (offset + i)]);
            engine.process (block, params);
            for (int i = 0; i < n; ++i) output[(size_t) (offset + i)] = block.getSample (0, i);
            offset += n;
        }
        return output;
    }

    float steadyGainDb (DspEngine::Params p, float frequency, float amplitude = 0.05f)
    {
        const int samples = (int) sampleRate;
        auto input = makeSine (frequency, amplitude, samples);
        auto output = render (p, input, 256);
        const size_t begin = output.size() / 2;
        const float inRms = rms (input, begin);
        const float outRms = rms (output, begin);
        return juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms), -120.0f);
    }

    bool finiteVector (const std::vector<float>& v)
    {
        for (float x : v) if (! std::isfinite (x)) return false;
        return true;
    }
}

int main()
{
    bool ok = true;

    // a) MUTE must remain absolute silence for all dry/wet positions.
    for (float mix : { 0.0f, 0.5f, 1.0f })
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.mix = mix; p.mute = true;
        const auto input = makeSine (1000.0f, 0.5f, 8192);
        const auto out = render (p, input);
        if (rms (out) > 1.0e-8f)
        {
            std::cerr << "FAIL: MUTE leaks at mix=" << mix << "\n";
            ok = false;
        }
    }
    if (ok) std::cout << "PASS: MUTE is post-mix silence\n";

    // b) Neutral Black path should be essentially transparent at nominal level.
    {
        DspEngine::Params p;
        p.eqOn = false; p.blackEq = true; p.dynOn = false;
        p.inputDrive = 0.0f; p.inputMode = 0; p.vcaFaderDb = 0.0f; p.outputTrimDb = 0.0f; p.mix = 1.0f;
        const auto input = makeSine (1000.0f, dbGain (-12.0f), 32768);
        const auto out = render (p, input);
        const float inRms = rms (input), outRms = rms (out);
        const float levelErrorDb = juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms));

        double dot = 0.0, energy = 0.0;
        for (size_t i = 0; i < input.size(); ++i)
        {
            dot += (double) out[i] * input[i];
            energy += (double) input[i] * input[i];
        }
        const float scale = energy > 0.0 ? (float) (dot / energy) : 1.0f;
        std::vector<float> scaled (input.size());
        for (size_t i = 0; i < input.size(); ++i) scaled[i] = input[i] * scale;
        const float residual = differenceRms (out, scaled);
        const float thdPercent = 100.0f * residual / juce::jmax (1.0e-12f, rms (scaled));

        if (std::abs (levelErrorDb) > 0.01f || thdPercent > 0.05f)
        {
            std::cerr << "FAIL: neutral path levelError=" << levelErrorDb << " dB, residual=" << thdPercent << "%\n";
            ok = false;
        }
        else std::cout << "PASS: neutral path level/THD\n";
    }

    // Mix=0 must be the generator itself, not a second processed reference render.
    {
        DspEngine::Params p;
        p.inputDrive = 100.0f; p.eqOn = true; p.lfGain = 12.0f; p.dynOn = true;
        p.compThresholdDb = -20.0f; p.vcaFaderDb = 10.0f; p.mix = 0.0f;
        const auto input = makeSine (777.0f, 0.2f, 16384);
        const auto out = render (p, input);
        if (differenceRms (out, input) > 1.0e-7f)
        {
            std::cerr << "FAIL: Mix 0 is not dry/null-safe\n";
            ok = false;
        }
        else std::cout << "PASS: Mix 0 returns raw input\n";
    }

    // c) EXPAND must be 1:2: 10 dB below threshold -> about 10 dB extra reduction.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.compOn = false; p.dynOn = true;
        p.gateOn = true; p.gateExpand = true; p.gateThresholdDb = -20.0f;
        p.gateRangeDb = 40.0f; p.gateHoldSec = 0.0f; p.gateReleaseSec = 0.1f;

        // Sine RMS is peak - 3.01 dB, so -27 dBFS peak is approximately -30 dBFS RMS.
        const auto input = makeSine (1000.0f, dbGain (-27.0f), (int) (sampleRate * 2.0));
        int offset = 0;
        while (offset < (int) input.size())
        {
            const int n = juce::jmin (512, (int) input.size() - offset);
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i) b.setSample (0, i, input[(size_t) (offset + i)]);
            engine.process (b, p);
            offset += n;
        }
        const float gr = engine.getGateGainReductionDb();
        if (gr < 9.0f || gr > 11.5f)
        {
            std::cerr << "FAIL: expander 1:2 reduction=" << gr << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: expander 1:2 reduction=" << gr << " dB\n";
    }

    // d) HOLD must keep the gate open, then allow release after the hold interval.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.compOn = false; p.dynOn = true;
        p.gateOn = true; p.gateExpand = false; p.gateThresholdDb = -20.0f;
        p.gateRangeDb = 40.0f; p.gateHoldSec = 0.5f; p.gateReleaseSec = 0.1f;

        auto processSignal = [&] (float amplitude, float seconds)
        {
            int remaining = (int) std::round (seconds * sampleRate);
            int phase = 0;
            while (remaining > 0)
            {
                const int n = juce::jmin (512, remaining);
                juce::AudioBuffer<float> b (1, n);
                for (int i = 0; i < n; ++i)
                    b.setSample (0, i, amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                             * 1000.0f * (float) (phase + i) / (float) sampleRate));
                engine.process (b, p);
                remaining -= n;
                phase += n;
            }
        };

        processSignal (dbGain (-6.0f), 0.20f);
        processSignal (dbGain (-37.0f), 0.40f);
        const float beforeHoldEnds = engine.getGateGainReductionDb();
        processSignal (dbGain (-37.0f), 0.70f);
        const float afterHoldEnds = engine.getGateGainReductionDb();
        if (beforeHoldEnds > 1.0f || afterHoldEnds < 20.0f)
        {
            std::cerr << "FAIL: gate HOLD before=" << beforeHoldEnds << " after=" << afterHoldEnds << "\n";
            ok = false;
        }
        else std::cout << "PASS: gate HOLD/release timing\n";
    }

    // e) Program-dependent compressor attack: an abrupt transient must pull more GR
    // in the first 5 ms than a ramp reaching the same final level.
    {
        const int n = (int) std::round (sampleRate * 0.005);
        auto measure = [&] (bool ramp)
        {
            DspEngine engine;
            engine.prepare (sampleRate, n, 1);
            DspEngine::Params p;
            p.eqOn = false; p.gateOn = false; p.dynOn = true; p.compOn = true;
            p.compPeak = false; p.compThresholdDb = -20.0f; p.compRatio = 10.0f;
            p.compAttackMs = 10.0f; p.compReleaseSec = 0.3f;
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i)
            {
                const float env = ramp ? (float) i / (float) juce::jmax (1, n - 1) : 1.0f;
                b.setSample (0, i, 0.9f * env * std::sin ((float) juce::MathConstants<double>::twoPi
                                                          * 1000.0f * (float) i / (float) sampleRate));
            }
            engine.process (b, p);
            return engine.getCompressorGainReductionDb();
        };

        const float abrupt = measure (false);
        const float ramped = measure (true);
        if (! (abrupt > ramped + 0.05f))
        {
            std::cerr << "FAIL: program attack abrupt=" << abrupt << " ramp=" << ramped << "\n";
            ok = false;
        }
        else std::cout << "PASS: program-dependent compressor attack\n";
    }

    // f) Shelf character: strong LF/HF boosts plus the opposite-sign broad dip
    // should create full shelf lift and a restrained shoulder around the transition.
    {
        DspEngine::Params lf;
        lf.dynOn = false; lf.blackEq = true; lf.eqOn = true; lf.lfBell = false;
        lf.lfGain = 12.0f; lf.lfFreq = 80.0f;
        const float low = steadyGainDb (lf, 35.0f);
        const float shoulder = steadyGainDb (lf, 200.0f);
        if (low < 8.0f || shoulder > 3.0f)
        {
            std::cerr << "FAIL: LF shelf shape low=" << low << " shoulder=" << shoulder << " dB\n";
            ok = false;
        }

        DspEngine::Params hf;
        hf.dynOn = false; hf.blackEq = true; hf.eqOn = true; hf.hfBell = false;
        hf.hfGain = 12.0f; hf.hfFreq = 10000.0f;
        const float high = steadyGainDb (hf, 17000.0f);
        const float highShoulder = steadyGainDb (hf, 4500.0f);
        if (high < 7.0f || highShoulder > 3.5f)
        {
            std::cerr << "FAIL: HF shelf shape high=" << high << " shoulder=" << highShoulder << " dB\n";
            ok = false;
        }
        if (low >= 8.0f && shoulder <= 3.0f && high >= 7.0f && highShoulder <= 3.5f)
            std::cout << "PASS: shelf shoulder/dip character\n";
    }

    // g) Automatic threshold/ratio make-up must remain present below threshold.
    {
        DspEngine::Params a, b;
        a.eqOn = b.eqOn = false; a.dynOn = b.dynOn = true; a.gateOn = b.gateOn = false;
        a.compOn = b.compOn = true; a.compRatio = b.compRatio = 4.0f;
        a.compThresholdDb = 0.0f; b.compThresholdDb = -20.0f;
        const auto input = makeSine (1000.0f, dbGain (-40.0f), 32768);
        const auto outA = render (a, input);
        const auto outB = render (b, input);
        if (! (rms (outB, outB.size() / 2) > rms (outA, outA.size() / 2) * 1.5f))
        {
            std::cerr << "FAIL: automatic compressor make-up disappeared\n";
            ok = false;
        }
        else std::cout << "PASS: automatic threshold/ratio make-up preserved\n";
    }

    // Brown/Black HPF direction and constant-Q mid behaviour sanity.
    {
        DspEngine::Params brown, black;
        brown.eqOn = black.eqOn = false; brown.dynOn = black.dynOn = false;
        brown.hpOn = black.hpOn = true; brown.hpFreq = black.hpFreq = 160.0f;
        brown.blackEq = false; black.blackEq = true;
        const auto input = makeSine (50.0f, 0.1f, 32768);
        const auto rb = render (brown, input);
        const auto rk = render (black, input);
        if (! (rms (rk, 16000) < rms (rb, 16000)))
        {
            std::cerr << "FAIL: Black HPF is not steeper than Brown HPF\n";
            ok = false;
        }
        else std::cout << "PASS: Black/Brown HPF slope direction\n";
    }

    // h) Static processing should be effectively block-size invariant.
    {
        DspEngine::Params p;
        p.blackEq = true; p.hpOn = true; p.hpFreq = 70.0f; p.eqOn = true;
        p.lmfGain = 3.0f; p.hmfGain = -2.0f; p.dynOn = true; p.compOn = true;
        p.compThresholdDb = -12.0f; p.compRatio = 3.0f; p.gateOn = false;
        const auto input = makeSine (440.0f, 0.25f, 16384);
        const auto reference = render (p, input, 16384);
        for (int block : { 32, 64, 512, 4096 })
        {
            const auto candidate = render (p, input, block);
            const float diff = differenceRms (reference, candidate);
            if (diff > 1.0e-5f)
            {
                std::cerr << "FAIL: block-size difference block=" << block << " rms=" << diff << "\n";
                ok = false;
            }
        }
        if (ok) std::cout << "PASS: block-size invariance\n";
    }

    // i) Extreme legal settings must never emit NaN/Inf.
    {
        DspEngine::Params p;
        p.inputTrimDb = 20.0f; p.inputDrive = 100.0f; p.inputMode = 1;
        p.hpOn = true; p.hpFreq = 350.0f; p.lpOn = true; p.lpFreq = 3000.0f;
        p.eqOn = true; p.blackEq = false; p.lfGain = 15.0f; p.lmfGain = 15.0f;
        p.hmfGain = 15.0f; p.hfGain = 15.0f; p.lmfQ = 4.0f; p.hmfQ = 4.0f;
        p.dynOn = true; p.compOn = true; p.compThresholdDb = -20.0f; p.compRatio = 20.0f;
        p.compAttackMs = 0.1f; p.compReleaseSec = 0.1f; p.compFast = true; p.compPeak = true;
        p.gateOn = true; p.gateThresholdDb = 10.0f; p.gateRangeDb = 40.0f;
        p.gateHoldSec = 4.0f; p.gateAttackMs = 0.05f; p.gateReleaseSec = 0.1f; p.gateFast = true;
        p.vcaFaderDb = 10.0f; p.outputTrimDb = 20.0f; p.mix = 1.0f;
        const auto input = makeSine (997.0f, 0.95f, 32768);
        const auto out = render (p, input);
        if (! finiteVector (out))
        {
            std::cerr << "FAIL: NaN/Inf at extreme settings\n";
            ok = false;
        }
        else std::cout << "PASS: finite output at extreme settings\n";
    }

    if (! ok)
        return 1;

    std::cout << "All v0.2.7 DSP behaviour tests passed.\n";
    return 0;
}
