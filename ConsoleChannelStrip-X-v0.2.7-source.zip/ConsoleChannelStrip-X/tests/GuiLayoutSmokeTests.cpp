#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <chrono>
#include <cmath>
#include <iostream>
#include <map>
#include <set>
#include <vector>

namespace
{
    void collectComponentsWithIds (juce::Component& root, std::vector<juce::Component*>& out)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
        {
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getComponentID().isNotEmpty())
                    out.push_back (child);
                collectComponentsWithIds (*child, out);
            }
        }
    }

    juce::Component* findByNameRecursive (juce::Component& root, const juce::String& name)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
        {
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getName() == name)
                    return child;
                if (auto* nested = findByNameRecursive (*child, name))
                    return nested;
            }
        }
        return nullptr;
    }
}

int main()
{
    juce::ScopedJuceInitialiser_GUI juceGui;
    ConsoleChannelStripXAudioProcessor processor;

    const auto start = std::chrono::steady_clock::now();
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds> (
        std::chrono::steady_clock::now() - start).count();

    if (editor == nullptr)
    {
        std::cerr << "FAIL: editor was not created\n";
        return 1;
    }

    if (editor->getWidth() != 1536 || editor->getHeight() != 942)
    {
        std::cerr << "FAIL: unexpected editor size " << editor->getWidth() << "x" << editor->getHeight() << "\n";
        return 1;
    }

    if (elapsedMs > 2000)
    {
        std::cerr << "FAIL: editor construction is too slow: " << elapsedMs << " ms\n";
        return 1;
    }

    std::set<std::string> expectedIds;
    for (auto* parameter : processor.getParameters())
    {
        if (auto* withId = dynamic_cast<juce::AudioProcessorParameterWithID*> (parameter))
            expectedIds.insert (withId->paramID.toStdString());
    }

    std::vector<juce::Component*> controls;
    collectComponentsWithIds (*editor, controls);

    std::map<std::string, juce::Component*> byId;
    for (auto* control : controls)
    {
        const auto id = control->getComponentID().toStdString();
        if (! byId.emplace (id, control).second)
        {
            std::cerr << "FAIL: duplicate component ID: " << id << "\n";
            return 1;
        }
    }

    std::set<std::string> actualIds;
    for (const auto& [id, component] : byId)
        actualIds.insert (id);

    if (actualIds != expectedIds)
    {
        std::cerr << "FAIL: GUI/APVTS ID sets differ\n";
        for (const auto& id : expectedIds)
            if (actualIds.count (id) == 0) std::cerr << "  missing GUI control: " << id << "\n";
        for (const auto& id : actualIds)
            if (expectedIds.count (id) == 0) std::cerr << "  extra GUI control: " << id << "\n";
        return 1;
    }

    // Bounds, visibility and real parameter wiring.
    std::vector<std::pair<std::string, juce::Rectangle<int>>> parameterBounds;
    for (const auto& id : expectedIds)
    {
        auto* control = byId[id];
        if (control == nullptr || ! control->isVisible() || control->getLocalBounds().isEmpty())
        {
            std::cerr << "FAIL: invisible/0x0 control: " << id << "\n";
            return 1;
        }

        const auto boundsInEditor = editor->getLocalArea (control, control->getLocalBounds());
        if (! editor->getLocalBounds().contains (boundsInEditor))
        {
            std::cerr << "FAIL: control outside editor: " << id << "\n";
            return 1;
        }
        parameterBounds.emplace_back (id, boundsInEditor);

        auto* parameter = processor.parameters().getParameter (id.c_str());
        if (parameter == nullptr)
        {
            std::cerr << "FAIL: APVTS parameter missing: " << id << "\n";
            return 1;
        }

        const float before = parameter->getValue();
        if (auto* slider = dynamic_cast<juce::Slider*> (control))
        {
            if (slider->getTextBoxPosition() != juce::Slider::NoTextBox)
            {
                std::cerr << "FAIL: raw numeric textbox visible: " << id << "\n";
                return 1;
            }
            const auto lo = slider->getMinimum();
            const auto hi = slider->getMaximum();
            const auto next = std::abs (slider->getValue() - lo) < std::abs (slider->getValue() - hi) ? hi : lo;
            slider->setValue (next, juce::sendNotificationSync);
        }
        else if (auto* toggle = dynamic_cast<juce::ToggleButton*> (control))
        {
            toggle->setToggleState (! toggle->getToggleState(), juce::sendNotificationSync);
        }
        else if (auto* two = dynamic_cast<TwoStateChoiceControl*> (control))
        {
            // Two-state controls can intentionally reverse their visual labels
            // relative to normalised 0/1 values (for example BLACK/BROWN).
            // Try one visual state and, if it was already selected, try the other.
            two->chooseForTest (0);
            if (std::abs (parameter->getValue() - before) < 1.0e-6f)
                two->chooseForTest (1);
        }
        else if (auto* cycling = dynamic_cast<CyclingChoiceControl*> (control))
        {
            cycling->advanceForTest();
        }
        else
        {
            std::cerr << "FAIL: unsupported parameter control type: " << id << "\n";
            return 1;
        }

        if (std::abs (parameter->getValue() - before) < 1.0e-6f)
        {
            std::cerr << "FAIL: control is not connected to parameter: " << id << "\n";
            return 1;
        }
    }

    for (size_t a = 0; a < parameterBounds.size(); ++a)
    {
        for (size_t b = a + 1; b < parameterBounds.size(); ++b)
        {
            if (parameterBounds[a].second.intersects (parameterBounds[b].second))
            {
                std::cerr << "FAIL: parameter controls overlap: "
                          << parameterBounds[a].first << " / " << parameterBounds[b].first << "\n";
                return 1;
            }
        }
    }

    // Top power is a second presentation of the bypass function. It is intentionally
    // not assigned a parameter componentID so the one-control-per-parameter audit
    // remains exact.
    auto* power = dynamic_cast<juce::TextButton*> (findByNameRecursive (*editor, "ui_power"));
    auto* bypass = processor.parameters().getParameter ("bypass");
    if (power == nullptr || bypass == nullptr)
    {
        std::cerr << "FAIL: top power/bypass missing\n";
        return 1;
    }
    // Earlier in this test the dedicated BYPASS parameter control is exercised,
    // so the APVTS bypass value may no longer match the utility power button's
    // cached visual state. Re-sync the utility button to the current parameter
    // before simulating its click; otherwise the test can falsely report a broken
    // Power -> Bypass connection when both already represent the same target state.
    const float bypassBefore = bypass->getValue();
    power->setToggleState (bypassBefore < 0.5f, juce::dontSendNotification);
    power->setToggleState (! power->getToggleState(), juce::dontSendNotification);
    if (power->onClick) power->onClick();
    if (std::abs (bypass->getValue() - bypassBefore) < 1.0e-6f)
    {
        std::cerr << "FAIL: top power does not control bypass\n";
        return 1;
    }

    auto* inputTrim = processor.parameters().getParameter ("inputTrim");
    auto* init = dynamic_cast<juce::TextButton*> (findByNameRecursive (*editor, "ui_init"));
    if (inputTrim == nullptr || init == nullptr)
    {
        std::cerr << "FAIL: INIT test controls missing\n";
        return 1;
    }
    inputTrim->setValueNotifyingHost (1.0f);
    if (init->onClick) init->onClick();
    if (std::abs (inputTrim->getValue() - inputTrim->getDefaultValue()) > 1.0e-6f)
    {
        std::cerr << "FAIL: INIT does not restore defaults\n";
        return 1;
    }

    const auto preview = editor->createComponentSnapshot (editor->getLocalBounds(), true, 1.0f);
    auto previewFile = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-v0.2.7.png");
    if (auto stream = previewFile.createOutputStream())
    {
        juce::PNGImageFormat png;
        if (! png.writeImageToStream (preview, *stream))
        {
            std::cerr << "FAIL: could not encode GUI preview PNG\n";
            return 1;
        }
    }
    else
    {
        std::cerr << "FAIL: could not create GUI preview PNG\n";
        return 1;
    }

    std::cout << "PASS: GUI has exactly " << expectedIds.size()
              << " APVTS controls, all visible/in-bounds/wired/non-overlapping; editor created in "
              << elapsedMs << " ms.\n";
    return 0;
}
