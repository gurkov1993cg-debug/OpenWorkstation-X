#include "PluginEditor.h"
#include <cmath>

namespace ColoursX
{
    const juce::Colour bg       { 0xff080a0b };
    const juce::Colour top      { 0xff0d1012 };
    const juce::Colour panel    { 0xff171a1c };
    const juce::Colour panelHi  { 0xff24282b };
    const juce::Colour border   { 0xff4b5053 };
    const juce::Colour text     { 0xffe3ded4 };
    const juce::Colour muted    { 0xff9ba0a2 };
    const juce::Colour gold     { 0xffd69832 };
    const juce::Colour red      { 0xffc3342d };
    const juce::Colour orange   { 0xffdd7b21 };
    const juce::Colour green    { 0xff138146 };
    const juce::Colour blue     { 0xff0e6fb3 };
    const juce::Colour purple   { 0xff2d3f91 };
    const juce::Colour silver   { 0xffa8a7a3 };
}

ConsoleLookAndFeel::ConsoleLookAndFeel()
{
    setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff121516));
    setColour (juce::PopupMenu::textColourId, ColoursX::text);
    setColour (juce::TextButton::textColourOffId, ColoursX::text);
    setColour (juce::TextButton::textColourOnId, ColoursX::text);
}

void ConsoleLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                            float pos, float start, float end, juce::Slider& slider)
{
    auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height);
    const auto accent = slider.findColour (juce::Slider::rotarySliderFillColourId);
    const auto label = slider.getName();
    const auto leftScale = slider.getProperties().getWithDefault ("leftScale", "").toString();
    const auto rightScale = slider.getProperties().getWithDefault ("rightScale", "").toString();

    g.setColour (ColoursX::text);
    g.setFont (juce::Font (11.5f, juce::Font::bold));
    g.drawText (label, area.removeFromTop (17.0f), juce::Justification::centred);

    auto knobZone = area.removeFromTop (juce::jmin (area.getHeight() - 16.0f, area.getWidth() * 0.78f));
    const float d = juce::jmin (knobZone.getWidth(), knobZone.getHeight()) - 16.0f;
    auto knob = knobZone.withSizeKeepingCentre (d, d);
    const float radius = d * 0.5f;
    const float angle = start + pos * (end - start);
    const auto c = knob.getCentre();

    for (int i = 0; i <= 10; ++i)
    {
        const float a = start + (end - start) * (float) i / 10.0f;
        const float r1 = radius + 4.0f;
        const float r2 = radius + (i % 5 == 0 ? 10.0f : 7.0f);
        g.setColour (juce::Colours::white.withAlpha (i % 5 == 0 ? 0.92f : 0.60f));
        g.drawLine (c.x + std::sin (a) * r1, c.y - std::cos (a) * r1,
                    c.x + std::sin (a) * r2, c.y - std::cos (a) * r2, i % 5 == 0 ? 1.4f : 0.9f);
    }

    g.setColour (juce::Colour (0xff050607));
    g.fillEllipse (knob.expanded (5.0f));
    g.setColour (juce::Colour (0xff5b6063));
    g.drawEllipse (knob.expanded (3.0f), 1.2f);

    juce::ColourGradient rim (juce::Colour (0xff707477), knob.getX(), knob.getY(),
                              juce::Colour (0xff1c1e20), knob.getRight(), knob.getBottom(), false);
    g.setGradientFill (rim);
    g.fillEllipse (knob);

    auto face = knob.reduced (5.0f);
    juce::ColourGradient faceGrad (accent.brighter (0.24f), face.getX(), face.getY(),
                                   accent.darker (0.58f), face.getRight(), face.getBottom(), false);
    g.setGradientFill (faceGrad);
    g.fillEllipse (face);
    g.setColour (juce::Colours::black.withAlpha (0.45f));
    g.drawEllipse (face, 1.0f);

    juce::Path highlight;
    highlight.addArc (face.getX() + 4.0f, face.getY() + 4.0f, face.getWidth() - 8.0f, face.getHeight() - 8.0f,
                      juce::MathConstants<float>::pi * 1.08f, juce::MathConstants<float>::pi * 1.82f, true);
    g.setColour (juce::Colours::white.withAlpha (0.18f));
    g.strokePath (highlight, juce::PathStrokeType (2.0f));

    juce::Path pointer;
    pointer.addRoundedRectangle (-1.7f, -radius + 9.0f, 3.4f, radius * 0.72f, 1.4f);
    g.setColour (juce::Colours::white.withAlpha (0.96f));
    g.fillPath (pointer, juce::AffineTransform::rotation (angle).translated (c.x, c.y));

    g.setFont (juce::Font (10.0f));
    g.setColour (ColoursX::text.withAlpha (0.92f));
    auto scaleArea = area.removeFromTop (16.0f);
    g.drawText (leftScale, scaleArea.removeFromLeft (scaleArea.getWidth() / 2), juce::Justification::centredLeft);
    g.drawText (rightScale, scaleArea, juce::Justification::centredRight);
}

void ConsoleLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool hi, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.0f);
    const auto accent = b.findColour (juce::ToggleButton::tickColourId);
    const float lampW = juce::jmin (30.0f, r.getHeight());
    auto lamp = r.removeFromLeft (lampW).reduced (4.0f);

    g.setColour (juce::Colour (0xff0d0f10));
    g.fillRoundedRectangle (lamp.expanded (2.0f), 3.0f);
    g.setColour (b.getToggleState() ? accent.darker (0.18f) : juce::Colour (0xff3c4042));
    g.fillRoundedRectangle (lamp, 2.0f);
    g.setColour (b.getToggleState() ? accent.brighter (0.55f) : juce::Colour (0xff707477));
    g.drawRoundedRectangle (lamp, 2.0f, 1.0f);
    if (b.getToggleState())
    {
        g.setColour (accent.withAlpha (0.18f));
        g.fillRoundedRectangle (lamp.expanded (6.0f), 5.0f);
    }

    g.setColour (hi ? ColoursX::text.brighter (0.1f) : ColoursX::text);
    if (down) g.setColour (ColoursX::text.darker (0.15f));
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText (b.getButtonText(), r.reduced (5.0f, 0.0f), juce::Justification::centredLeft);
}

void ConsoleLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&, bool hi, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (1.0f);
    const bool on = b.getToggleState();
    auto fill = on ? ColoursX::gold.darker (0.42f) : juce::Colour (0xff111416);
    if (hi) fill = fill.brighter (0.08f);
    if (down) fill = fill.darker (0.10f);
    g.setColour (fill);
    g.fillRoundedRectangle (r, 3.0f);
    g.setColour (on ? ColoursX::gold.brighter (0.2f) : juce::Colour (0xff555a5d));
    g.drawRoundedRectangle (r, 3.0f, on ? 1.5f : 1.0f);
    if (on)
    {
        g.setColour (ColoursX::gold.withAlpha (0.14f));
        g.fillRoundedRectangle (r.expanded (3.0f), 5.0f);
    }
}

void ConsoleLookAndFeel::drawButtonText (juce::Graphics& g, juce::TextButton& b, bool, bool)
{
    const auto id = b.getName();
    auto r = b.getLocalBounds().toFloat().reduced (5.0f);
    g.setColour (ColoursX::text);

    if (id == "ui_power")
    {
        const auto c = r.getCentre();
        const float rad = juce::jmin (r.getWidth(), r.getHeight()) * 0.27f;
        g.drawEllipse ({ c.x - rad, c.y - rad, rad * 2.0f, rad * 2.0f }, 2.2f);
        g.drawLine (c.x, c.y - rad - 2.0f, c.x, c.y + 1.0f, 2.6f);
        return;
    }
    if (id == "ui_undo" || id == "ui_redo")
    {
        const bool redo = id == "ui_redo";
        juce::Path p;
        const float cy = r.getCentreY();
        if (! redo)
        {
            p.startNewSubPath (r.getRight() - 5.0f, cy + 7.0f);
            p.cubicTo (r.getCentreX() + 7.0f, cy - 10.0f, r.getX() + 8.0f, cy - 8.0f, r.getX() + 7.0f, cy + 2.0f);
            p.startNewSubPath (r.getX() + 7.0f, cy + 2.0f); p.lineTo (r.getX() + 2.0f, cy - 3.0f); p.lineTo (r.getX() + 9.0f, cy - 5.0f);
        }
        else
        {
            p.startNewSubPath (r.getX() + 5.0f, cy + 7.0f);
            p.cubicTo (r.getCentreX() - 7.0f, cy - 10.0f, r.getRight() - 8.0f, cy - 8.0f, r.getRight() - 7.0f, cy + 2.0f);
            p.startNewSubPath (r.getRight() - 7.0f, cy + 2.0f); p.lineTo (r.getRight() - 2.0f, cy - 3.0f); p.lineTo (r.getRight() - 9.0f, cy - 5.0f);
        }
        g.strokePath (p, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }

    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (b.getButtonText(), r.toNearestInt(), juce::Justification::centred);
    if (id == "ui_init")
    {
        juce::Path a;
        const float cx = r.getRight() - 10.0f, cy = r.getCentreY();
        a.startNewSubPath (cx - 4.0f, cy - 2.0f); a.lineTo (cx, cy + 2.0f); a.lineTo (cx + 4.0f, cy - 2.0f);
        g.strokePath (a, juce::PathStrokeType (1.4f));
    }
}

TwoStateChoiceControl::TwoStateChoiceControl (juce::String id, juce::String a, juce::String b, bool firstMapsToOne)
    : first (std::move (a)), second (std::move (b)), reverse (firstMapsToOne)
{
    setComponentID (std::move (id));
    first.setClickingTogglesState (false);
    second.setClickingTogglesState (false);
    first.onClick = [this] { choose (0); };
    second.onClick = [this] { choose (1); };
    addAndMakeVisible (first);
    addAndMakeVisible (second);
}

void TwoStateChoiceControl::attach (juce::RangedAudioParameter* p) { parameter = p; syncFromParameter(); }
void TwoStateChoiceControl::choose (int index)
{
    if (parameter == nullptr) return;
    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost (reverse ? (index == 0 ? 1.0f : 0.0f) : (index == 0 ? 0.0f : 1.0f));
    parameter->endChangeGesture();
    syncFromParameter();
}
void TwoStateChoiceControl::syncFromParameter()
{
    if (parameter == nullptr) return;
    const bool valueOne = parameter->getValue() >= 0.5f;
    const bool firstOn = reverse ? valueOne : ! valueOne;
    first.setToggleState (firstOn, juce::dontSendNotification);
    second.setToggleState (! firstOn, juce::dontSendNotification);
}
void TwoStateChoiceControl::resized()
{
    auto r = getLocalBounds(); const int gap = 8; const int w = (r.getWidth() - gap) / 2;
    first.setBounds (r.removeFromLeft (w)); r.removeFromLeft (gap); second.setBounds (r);
}

CyclingChoiceControl::CyclingChoiceControl (juce::String id, juce::StringArray labels)
    : choices (std::move (labels))
{
    setComponentID (std::move (id));
    button.setClickingTogglesState (false);
    button.onClick = [this] { advance(); };
    addAndMakeVisible (button);
}

void CyclingChoiceControl::attach (juce::RangedAudioParameter* p)
{
    parameter = p;
    syncFromParameter();
}

void CyclingChoiceControl::advance()
{
    if (parameter == nullptr || choices.isEmpty())
        return;

    const int current = juce::jlimit (0, choices.size() - 1,
        (int) std::round (parameter->convertFrom0to1 (parameter->getValue())));
    const int next = (current + 1) % choices.size();
    parameter->beginChangeGesture();
    parameter->setValueNotifyingHost (parameter->convertTo0to1 ((float) next));
    parameter->endChangeGesture();
    syncFromParameter();
}

void CyclingChoiceControl::advanceForTest() { advance(); }

void CyclingChoiceControl::syncFromParameter()
{
    if (parameter == nullptr || choices.isEmpty())
        return;

    const int index = juce::jlimit (0, choices.size() - 1,
        (int) std::round (parameter->convertFrom0to1 (parameter->getValue())));
    button.setButtonText (choices[index]);
}

void CyclingChoiceControl::resized()
{
    button.setBounds (getLocalBounds());
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&consoleLook);
    setOpaque (true);

    addKnob ("inputDrive", "INPUT DRIVE", ColoursX::silver, ValueStyle::drive, "0", "100");
    addKnob ("inputTrim", "INPUT", ColoursX::red, ValueStyle::dB, "-20", "+20");
    addButton ("polarity", "PHASE", ColoursX::gold);

    addButton ("hpOn", "HP IN", ColoursX::gold);
    addKnob ("hpFreq", "HPF", ColoursX::silver, ValueStyle::frequency, "16", "350");
    addButton ("lpOn", "LP IN", ColoursX::gold);
    addKnob ("lpFreq", "LPF", ColoursX::silver, ValueStyle::frequency, "3k", "22k");

    addButton ("eqOn", "EQ IN", ColoursX::gold);
    addButton ("hfBell", "BELL", ColoursX::red);
    addKnob ("hfGain", "HF", ColoursX::red, ValueStyle::dB, "-15", "+15");
    addKnob ("hfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "1.5k", "16k");
    addKnob ("hmfGain", "HMF", ColoursX::green, ValueStyle::dB, "-15", "+15");
    addKnob ("hmfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "0.6k", "7k");
    addKnob ("hmfQ", "Q", ColoursX::green.darker (0.2f), ValueStyle::q, "0.4", "4");
    addKnob ("lmfGain", "LMF", ColoursX::blue, ValueStyle::dB, "-15", "+15");
    addKnob ("lmfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "0.2k", "2.5k");
    addKnob ("lmfQ", "Q", ColoursX::blue.darker (0.2f), ValueStyle::q, "0.4", "4");
    addButton ("lfBell", "BELL", ColoursX::blue);
    addKnob ("lfGain", "LF", ColoursX::blue, ValueStyle::dB, "-15", "+15");
    addKnob ("lfFreq", "FREQ", ColoursX::silver, ValueStyle::frequency, "30", "450");

    addButton ("dynOn", "DYN IN", ColoursX::gold);
    addButton ("compOn", "COMP", ColoursX::gold);
    addButton ("compFast", "FAST ATTACK", ColoursX::gold);
    addButton ("compPeak", "PEAK", ColoursX::gold);
    addKnob ("compThreshold", "THRESHOLD", ColoursX::red, ValueStyle::dB, "-20", "+10");
    addKnob ("compRatio", "RATIO", ColoursX::silver, ValueStyle::ratio, "1:1", "INF");
    addKnob ("compAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs, "0.1", "100");
    addKnob ("compRelease", "RELEASE", ColoursX::silver, ValueStyle::release, "0.1", "4.0");

    addButton ("gateOn", "GATE", ColoursX::gold);
    addButton ("gateExpand", "EXPAND", ColoursX::purple);
    addButton ("gateFast", "FAST ATTACK", ColoursX::gold);
    addKnob ("gateRange", "RANGE", ColoursX::purple, ValueStyle::dB, "0", "40");
    addKnob ("gateThreshold", "THRESHOLD", ColoursX::silver, ValueStyle::dB, "-30", "+10");
    addKnob ("gateHold", "HOLD", juce::Colour (0xff1b1d1f), ValueStyle::hold, "0", "4.0");
    addKnob ("gateAttack", "ATTACK", ColoursX::silver, ValueStyle::attackMs, "0.05", "50");
    addKnob ("gateRelease", "RELEASE", ColoursX::silver, ValueStyle::release, "0.1", "4.0");

    addKnob ("vcaFader", "OUTPUT", ColoursX::silver, ValueStyle::dB, "-20", "+10");
    addKnob ("outputTrim", "OUTPUT TRIM", ColoursX::silver, ValueStyle::dB, "-20", "+20");
    addKnob ("mix", "MIX", ColoursX::silver, ValueStyle::percent, "0", "100");
    addButton ("mute", "MUTE", ColoursX::red);
    addButton ("bypass", "BYPASS", ColoursX::gold);

    inputModeControl.attach (audioProcessor.parameters().getParameter ("inputMode"));
    eqModelControl.attach (audioProcessor.parameters().getParameter ("eqModel"));
    channelModeControl.attach (audioProcessor.parameters().getParameter ("channelMode"));
    routingControl.attach (audioProcessor.parameters().getParameter ("routing"));
    addAndMakeVisible (inputModeControl);
    addAndMakeVisible (eqModelControl);
    addAndMakeVisible (channelModeControl);
    addAndMakeVisible (routingControl);

    // Utility controls deliberately have no componentID: the GUI audit reserves
    // component IDs for the one-to-one APVTS control map.
    powerButton.setName ("ui_power");
    undoButton.setName ("ui_undo");
    redoButton.setName ("ui_redo");
    initButton.setName ("ui_init");
    powerButton.setClickingTogglesState (true);
    powerButton.onClick = [this]
    {
        if (auto* pBypass = audioProcessor.parameters().getParameter ("bypass"))
        {
            pBypass->beginChangeGesture();
            pBypass->setValueNotifyingHost (powerButton.getToggleState() ? 0.0f : 1.0f);
            pBypass->endChangeGesture();
        }
    };
    undoButton.onClick = [this] { audioProcessor.undo(); };
    redoButton.onClick = [this] { audioProcessor.redo(); };
    initButton.onClick = [this] { resetToInit(); };
    addAndMakeVisible (powerButton); addAndMakeVisible (undoButton); addAndMakeVisible (redoButton); addAndMakeVisible (initButton);

    setResizable (false, false);
    // setSize() invokes resized() after every interactive component already exists.
    // That single resized() builds the cached static layer once; do not rebuild it
    // again here, which was adding unnecessary editor-open latency.
    setSize (1536, 942);
    syncUtilityControls();
    startTimerHz (15);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer(); setLookAndFeel (nullptr);
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double v, ValueStyle s)
{
    switch (s)
    {
        case ValueStyle::dB:        return juce::String (v, 1) + " dB";
        case ValueStyle::drive:     return juce::String (v, 0) + "%";
        case ValueStyle::frequency: return v >= 1000.0 ? juce::String (v / 1000.0, v >= 10000.0 ? 1 : 2) + " kHz" : juce::String (v, 0) + " Hz";
        case ValueStyle::q:         return juce::String (v, 2);
        case ValueStyle::ratio:     return v >= 19.95 ? juce::String ("INF:1") : juce::String (v, 1) + ":1";
        case ValueStyle::attackMs:  return v < 1.0 ? juce::String (v, 2) + " ms" : juce::String (v, 1) + " ms";
        case ValueStyle::release:   return v < 1.0 ? juce::String (v * 1000.0, 0) + " ms" : juce::String (v, 2) + " s";
        case ValueStyle::percent:   return juce::String (v, 0) + "%";
        case ValueStyle::hold:      return juce::String (v, 2) + " s";
        case ValueStyle::plain:     return juce::String (v, 2);
    }
    return {};
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label,
                                                         juce::Colour accent, ValueStyle style,
                                                         const juce::String& leftScale, const juce::String& rightScale)
{
    auto s = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::NoTextBox);
    s->setName (label); s->setComponentID (id);
    s->setColour (juce::Slider::rotarySliderFillColourId, accent);
    s->getProperties().set ("leftScale", leftScale); s->getProperties().set ("rightScale", rightScale);
    s->setPopupDisplayEnabled (true, false, this);
    addAndMakeVisible (*s);
    sliderAttachments.push_back (std::make_unique<SliderAttachment> (audioProcessor.parameters(), id, *s));
    // SliderParameterAttachment can install its own text conversion; put our
    // engineering-unit formatter back afterwards so popup values are readable.
    s->textFromValueFunction = [style] (double v) { return formatValue (v, style); };
    s->updateText();
    knobs[id] = std::move (s);
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const juce::String& id, const juce::String& label, juce::Colour accent)
{
    auto b = std::make_unique<juce::ToggleButton> (label);
    b->setComponentID (id); b->setColour (juce::ToggleButton::tickColourId, accent); b->setClickingTogglesState (true);
    addAndMakeVisible (*b);
    buttonAttachments.push_back (std::make_unique<ButtonAttachment> (audioProcessor.parameters(), id, *b));
    buttons[id] = std::move (b);
}

void ConsoleChannelStripXAudioProcessorEditor::drawScrew (juce::Graphics& g, float x, float y, float angle)
{
    g.setColour (juce::Colour (0xff07090a));
    g.fillEllipse (x - 6.0f, y - 6.0f, 12.0f, 12.0f);
    g.setColour (juce::Colour (0xff73787b));
    g.drawEllipse (x - 5.0f, y - 5.0f, 10.0f, 10.0f, 1.0f);

    juce::Path slot;
    slot.startNewSubPath (-3.2f, 0.0f);
    slot.lineTo (3.2f, 0.0f);
    slot.startNewSubPath (0.0f, -3.2f);
    slot.lineTo (0.0f, 3.2f);
    g.setColour (juce::Colour (0xff282b2d));
    g.strokePath (slot, juce::PathStrokeType (1.1f), juce::AffineTransform::rotation (angle).translated (x, y));
}

void ConsoleChannelStripXAudioProcessorEditor::drawHardwarePanel (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& title)
{
    juce::ColourGradient grad (ColoursX::panelHi, (float) r.getX(), (float) r.getY(), ColoursX::panel, (float) r.getRight(), (float) r.getBottom(), false);
    g.setGradientFill (grad); g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (juce::Colours::white.withAlpha (0.07f)); g.drawRoundedRectangle (r.toFloat().reduced (1.0f), 5.0f, 1.0f);
    g.setColour (juce::Colours::black.withAlpha (0.75f)); g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.5f);
    g.setColour (ColoursX::text); g.setFont (juce::Font (17.0f, juce::Font::bold));
    g.drawText (title, r.getX() + 22, r.getY() + 10, r.getWidth() - 44, 24, juce::Justification::centredLeft);
    drawScrew (g, (float) r.getX() + 18.0f, (float) r.getY() + 18.0f); drawScrew (g, (float) r.getRight() - 18.0f, (float) r.getY() + 18.0f);
    drawScrew (g, (float) r.getX() + 18.0f, (float) r.getBottom() - 18.0f); drawScrew (g, (float) r.getRight() - 18.0f, (float) r.getBottom() - 18.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawLedColumn (juce::Graphics& g, juce::Rectangle<int> r, float db, bool outputStyle)
{
    static const float inputMarksDbfs[] = { 0.0f, -6.0f, -12.0f, -18.0f, -24.0f, -30.0f, -36.0f };
    static const char* inputLabels[] = { "+18", "+12", "+6", "0", "-6", "-12", "-18" };
    static const float outputMarksDbfs[] = { 0.0f, -3.0f, -6.0f, -12.0f, -18.0f, -24.0f };
    static const char* outputLabels[] = { "PK", "-3", "-6", "-12", "-18", "-24" };

    const int count = outputStyle ? 6 : 7;
    const int step = r.getHeight() / count;
    for (int i = 0; i < count; ++i)
    {
        const float mark = outputStyle ? outputMarksDbfs[i] : inputMarksDbfs[i];
        const char* label = outputStyle ? outputLabels[i] : inputLabels[i];
        const int cy = r.getY() + i * step + step / 2;

        juce::Colour c;
        if (i < 2)      c = juce::Colour (0xffe63329);
        else if (i < 4) c = juce::Colour (0xffffd21e);
        else            c = juce::Colour (0xff4caf50);

        const bool lit = db >= mark;
        g.setColour (lit ? c.withAlpha (0.22f) : c.withAlpha (0.06f));
        g.fillEllipse ((float) r.getX() - 3.0f, (float) cy - 8.0f, 16.0f, 16.0f);
        g.setColour (lit ? c : c.withAlpha (0.13f));
        g.fillEllipse ((float) r.getX(), (float) cy - 5.0f, 10.0f, 10.0f);
        g.setColour (juce::Colours::white.withAlpha (lit ? 0.50f : 0.10f));
        g.drawEllipse ((float) r.getX(), (float) cy - 5.0f, 10.0f, 10.0f, 0.8f);

        g.setColour (ColoursX::text.withAlpha (0.92f));
        g.setFont (juce::Font (10.5f, juce::Font::bold));
        g.drawText (label, r.getX() + 17, cy - 8, 48, 16, juce::Justification::centredLeft);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawMainMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                               float db, float peakHoldDb, bool scaleOnLeft)
{
    g.setColour (juce::Colour (0xff030506));
    g.fillRoundedRectangle (r.toFloat(), 3.0f);
    g.setColour (juce::Colour (0xff25292c));
    g.drawRoundedRectangle (r.toFloat(), 3.0f, 1.0f);

    constexpr int segments = 28;
    const int gap = 3;
    const int pad = 6;
    const int segH = juce::jmax (4, (r.getHeight() - 2 * pad - (segments - 1) * gap) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
    const int lit = (int) std::round (norm * segments);

    for (int i = 0; i < segments; ++i)
    {
        const float p = (float) i / (float) (segments - 1);
        juce::Colour c = p > 0.86f ? juce::Colour (0xffff3b20)
                         : (p > 0.52f ? juce::Colour (0xffffb52b) : juce::Colour (0xff62c54a));
        const int yy = r.getBottom() - pad - (i + 1) * segH - i * gap;
        const auto seg = juce::Rectangle<int> (r.getX() + 9, yy, r.getWidth() - 18, segH);
        g.setColour (i < lit ? c : c.withAlpha (0.12f));
        g.fillRect (seg);
    }

    const float holdNorm = juce::jlimit (0.0f, 1.0f, (peakHoldDb + 60.0f) / 60.0f);
    const int holdY = r.getBottom() - pad - (int) std::round (holdNorm * (r.getHeight() - 2 * pad));
    g.setColour (juce::Colour (0xffff9d2e).withAlpha (0.92f));
    g.fillRect (r.getX() + 5, holdY, r.getWidth() - 10, 2);

    static const int marks[] = { 0, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60 };
    g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.setColour (juce::Colour (0xffffa726));
    for (const int mark : marks)
    {
        const float t = (float) mark / 60.0f;
        const int y = r.getY() + (int) std::round (t * r.getHeight()) - 7;
        const int x = scaleOnLeft ? r.getX() - 28 : r.getRight() + 4;
        g.drawText (juce::String (mark), x, y, 24, 14,
                    scaleOnLeft ? juce::Justification::centredRight : juce::Justification::centredLeft);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawGRMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                             float reduction, const juce::String& title)
{
    g.setColour (juce::Colour (0xff060809));
    g.fillRoundedRectangle (r.toFloat(), 2.0f);
    constexpr int segments = 12;
    const int gap = 3;
    const int pad = 4;
    const int segH = juce::jmax (4, (r.getHeight() - 2 * pad - (segments - 1) * gap) / segments);
    const float norm = juce::jlimit (0.0f, 1.0f, reduction / 24.0f);
    const int lit = (int) std::round (norm * segments);

    for (int i = 0; i < segments; ++i)
    {
        const float p = (float) i / (float) (segments - 1);
        const auto c = p < 0.35f ? juce::Colour (0xff62c54a)
                     : (p < 0.70f ? juce::Colour (0xffffb52b) : juce::Colour (0xffff4a23));
        const int yy = r.getBottom() - pad - (i + 1) * segH - i * gap;
        g.setColour (i < lit ? c : c.withAlpha (0.14f));
        g.fillRect (r.getX() + 4, yy, r.getWidth() - 8, segH);
    }

    g.setColour (ColoursX::gold);
    g.setFont (juce::Font (10.0f, juce::Font::bold));
    g.drawText (title, r.getX() - 8, r.getY() - 20, r.getWidth() + 16, 16, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawSevenSegmentNumber (juce::Graphics& g,
                                                                        juce::Rectangle<int> r,
                                                                        int value)
{
    value = juce::jlimit (0, 999, value);
    const juce::String digits = juce::String (value).paddedLeft ('0', 3);
    static constexpr int map[10] =
    {
        0b1111110, 0b0110000, 0b1101101, 0b1111001, 0b0110011,
        0b1011011, 0b1011111, 0b1110000, 0b1111111, 0b1111011
    };

    const int gap = 5;
    const int digitW = (r.getWidth() - 2 * gap) / 3;
    for (int d = 0; d < 3; ++d)
    {
        const int n = digits.substring (d, d + 1).getIntValue();
        const int bits = map[n];
        auto dr = juce::Rectangle<int> (r.getX() + d * (digitW + gap), r.getY(), digitW, r.getHeight()).toFloat();
        const float t = juce::jmax (3.0f, dr.getWidth() * 0.12f);
        const auto on = juce::Colour (0xffff2c2c);
        const auto off = juce::Colour (0xff351010);

        auto hseg = [&] (float y) { return juce::Rectangle<float> (dr.getX() + t, y, dr.getWidth() - 2 * t, t); };
        auto vsegL = [&] (float y) { return juce::Rectangle<float> (dr.getX(), y, t, dr.getHeight() * 0.34f); };
        auto vsegR = [&] (float y) { return juce::Rectangle<float> (dr.getRight() - t, y, t, dr.getHeight() * 0.34f); };
        const float top = dr.getY();
        const float mid = dr.getCentreY() - t * 0.5f;
        const float bottom = dr.getBottom() - t;
        const float upperY = dr.getY() + t;
        const float lowerY = dr.getCentreY() + t * 0.25f;

        const juce::Rectangle<float> segs[] =
        {
            hseg (top), vsegR (upperY), vsegR (lowerY), hseg (bottom),
            vsegL (lowerY), vsegL (upperY), hseg (mid)
        };

        for (int s = 0; s < 7; ++s)
        {
            const bool lit = (bits & (1 << (6 - s))) != 0;
            g.setColour (lit ? on.withAlpha (0.22f) : off.withAlpha (0.18f));
            g.fillRoundedRectangle (segs[s].expanded (2.0f), 2.0f);
            g.setColour (lit ? on : off);
            g.fillRoundedRectangle (segs[s], 1.5f);
        }
    }
}

void ConsoleChannelStripXAudioProcessorEditor::paintStatic (juce::Graphics& g)
{
    g.fillAll (ColoursX::bg);
    juce::ColourGradient topGrad (juce::Colour (0xff192026), 0.0f, 0.0f, juce::Colour (0xff080a0c), 0.0f, 64.0f, false);
    g.setGradientFill (topGrad); g.fillRect (0, 0, getWidth(), 64);
    g.setColour (juce::Colour (0xff42474a)); g.drawHorizontalLine (63, 0.0f, (float) getWidth());

    g.setColour (ColoursX::text); g.setFont (juce::Font (19.0f, juce::Font::bold));
    g.drawText ("Console Channel Strip X  v0.2.7", 0, 10, getWidth(), 30, juce::Justification::centred);

    drawHardwarePanel (g, { 10, 70, 418, 858 }, "INPUT");
    drawHardwarePanel (g, { 435, 70, 360, 858 }, "DYNAMICS");
    drawHardwarePanel (g, { 803, 70, 380, 858 }, "");
    drawHardwarePanel (g, { 1191, 70, 335, 858 }, "OUTPUT");

    // Left panel separators and labels.
    g.setColour (juce::Colour (0xff4a4f51));
    for (int y : { 325, 475, 520, 612, 704, 796, 888 }) g.drawHorizontalLine (y, 42.0f, 396.0f);
    g.setColour (ColoursX::muted); g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("FILTERS", 48, 330, 90, 18, juce::Justification::centredLeft);
    g.drawText ("EQ", 48, 482, 40, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::red); g.drawText ("HF", 48, 528, 38, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::green); g.drawText ("HMF", 48, 620, 45, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue); g.drawText ("LMF", 48, 712, 45, 18, juce::Justification::centredLeft);
    g.setColour (ColoursX::blue); g.drawText ("LF", 48, 804, 38, 18, juce::Justification::centredLeft);

    // Dynamics hierarchy.
    g.setColour (ColoursX::text); g.setFont (juce::Font (14.0f, juce::Font::bold));
    g.drawText ("COMPRESSOR / LIMITER", 462, 112, 210, 20, juce::Justification::centredLeft);
    g.setColour (ColoursX::purple.brighter (0.4f)); g.drawText ("GATE / EXPANDER", 462, 455, 180, 20, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xff4a4f51)); g.drawHorizontalLine (440, 460.0f, 770.0f);

    // Centre plate and meter bridge.
    juce::ColourGradient plate (juce::Colour (0xffb8b9b7), 0, 80, juce::Colour (0xff5a5d5f), 0, 158, false);
    g.setGradientFill (plate); g.fillRoundedRectangle (juce::Rectangle<float> (816.0f, 80.0f, 354.0f, 80.0f), 4.0f);
    g.setColour (juce::Colours::black.withAlpha (0.85f)); g.setFont (juce::Font (27.0f, juce::Font::bold));
    g.drawText ("Channel Strip X", 850, 92, 285, 32, juce::Justification::centred);
    g.setFont (juce::Font (12.0f, juce::Font::bold)); g.drawText ("CONSOLE CHANNEL STRIP", 850, 126, 285, 18, juce::Justification::centred);

    g.setColour (juce::Colour (0xff050708)); g.fillRoundedRectangle (juce::Rectangle<float> (820.0f, 168.0f, 346.0f, 572.0f), 3.0f);
    g.setColour (ColoursX::muted); g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawText ("MIX", 842, 618, 72, 18, juce::Justification::centred);
    g.drawText ("ROUTING", 930, 618, 216, 18, juce::Justification::centredLeft);

    g.setColour (juce::Colour (0xff0a0c0d)); g.fillRoundedRectangle (juce::Rectangle<float> (820.0f, 752.0f, 346.0f, 158.0f), 3.0f);
    g.setColour (ColoursX::text.withAlpha (0.86f)); g.setFont (juce::Font (20.0f, juce::Font::bold));
    g.drawText ("OPENWORKSTATION X", 835, 793, 316, 28, juce::Justification::centred);
    g.setColour (ColoursX::muted); g.setFont (juce::Font (13.0f));
    g.drawText ("CONSOLE DSP", 835, 824, 316, 20, juce::Justification::centred);

    // Output hierarchy.
    g.setColour (juce::Colour (0xff4a4f51)); g.drawHorizontalLine (548, 1220.0f, 1498.0f); g.drawHorizontalLine (728, 1220.0f, 1498.0f);
    g.setColour (ColoursX::text); g.setFont (juce::Font (14.0f, juce::Font::bold));
    g.drawText ("CHANNEL MODE", 1230, 575, 260, 20, juce::Justification::centred);
    g.setColour (ColoursX::muted); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("CHANNEL STRIP X", 1230, 790, 260, 18, juce::Justification::centred);
    g.setFont (juce::Font (11.0f)); g.drawText ("CCS X v0.2.7", 1230, 814, 260, 18, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::rebuildStaticLayer()
{
    staticLayer = juce::Image (juce::Image::RGB, getWidth(), getHeight(), true);
    juce::Graphics g (staticLayer); paintStatic (g);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.drawImageAt (staticLayer, 0, 0);
    drawLedColumn (g, { 300, 105, 66, 180 }, audioProcessor.inputMeter(), false);
    drawMainMeter (g, { 885, 190, 64, 330 }, audioProcessor.inputMeter(), inputPeakHoldDb, true);
    drawMainMeter (g, { 1035, 190, 64, 330 }, audioProcessor.outputMeter(), outputPeakHoldDb, false);
    drawGRMeter (g, { 747, 190, 26, 200 }, audioProcessor.compressorMeter(), "GR");
    drawGRMeter (g, { 748, 670, 22, 150 }, audioProcessor.gateMeter(), "GATE");
    drawLedColumn (g, { 1430, 128, 70, 180 }, audioProcessor.outputMeter(), true);

    if (auto* mixValue = audioProcessor.parameters().getRawParameterValue ("mix"))
        drawSevenSegmentNumber (g, { 842, 640, 78, 42 }, (int) std::round (mixValue->load()));
}

void ConsoleChannelStripXAudioProcessorEditor::syncUtilityControls()
{
    inputModeControl.syncFromParameter(); eqModelControl.syncFromParameter(); channelModeControl.syncFromParameter(); routingControl.syncFromParameter();
    if (auto* p = audioProcessor.parameters().getParameter ("bypass"))
        powerButton.setToggleState (p->getValue() < 0.5f, juce::dontSendNotification);
}

void ConsoleChannelStripXAudioProcessorEditor::resetToInit()
{
    audioProcessor.resetParametersToDefaults();
    syncUtilityControls();
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    syncUtilityControls();

    constexpr float fallPerTickDb = 12.0f / 15.0f;
    const float in = audioProcessor.inputMeter();
    const float out = audioProcessor.outputMeter();
    inputPeakHoldDb = in >= inputPeakHoldDb ? in : juce::jmax (-60.0f, inputPeakHoldDb - fallPerTickDb);
    outputPeakHoldDb = out >= outputPeakHoldDb ? out : juce::jmax (-60.0f, outputPeakHoldDb - fallPerTickDb);

    repaint (290, 95, 85, 205);
    repaint (730, 165, 405, 665);
    repaint (1420, 115, 95, 205);
    repaint (835, 610, 315, 90);
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = knobs.find (id); it != knobs.end()) it->second->setBounds (x, y, w, h);
}
void ConsoleChannelStripXAudioProcessorEditor::placeButton (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = buttons.find (id); it != buttons.end()) it->second->setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    powerButton.setBounds (16, 13, 46, 38); undoButton.setBounds (74, 13, 36, 38); redoButton.setBounds (112, 13, 36, 38); initButton.setBounds (166, 13, 230, 38);

    // INPUT / FILTERS / EQ
    placeKnob ("inputDrive", 58, 105, 155, 155);
    inputModeControl.setBounds (72, 274, 206, 36); placeButton ("polarity", 316, 276, 86, 32);
    placeButton ("hpOn", 72, 334, 88, 28); placeButton ("lpOn", 236, 334, 88, 28);
    placeKnob ("hpFreq", 56, 368, 126, 96); placeKnob ("lpFreq", 220, 368, 126, 96);
    eqModelControl.setBounds (214, 482, 178, 32);

    placeKnob ("hfGain", 76, 530, 88, 78); placeKnob ("hfFreq", 178, 530, 88, 78); placeButton ("hfBell", 298, 550, 88, 28);
    placeKnob ("hmfGain", 66, 622, 82, 78); placeKnob ("hmfFreq", 158, 622, 82, 78); placeKnob ("hmfQ", 250, 622, 82, 78);
    placeKnob ("lmfGain", 66, 714, 82, 78); placeKnob ("lmfFreq", 158, 714, 82, 78); placeKnob ("lmfQ", 250, 714, 82, 78);
    placeKnob ("lfGain", 76, 806, 88, 78); placeKnob ("lfFreq", 178, 806, 88, 78); placeButton ("lfBell", 298, 826, 88, 28);
    placeButton ("eqOn", 88, 890, 116, 30);

    // DYNAMICS
    placeButton ("dynOn", 680, 86, 92, 30); placeButton ("compOn", 462, 132, 92, 28);
    placeKnob ("compThreshold", 455, 165, 118, 118); placeButton ("compFast", 610, 166, 150, 30); placeButton ("compPeak", 610, 210, 110, 30);
    placeKnob ("compRatio", 455, 290, 94, 104); placeKnob ("compAttack", 555, 290, 94, 104); placeKnob ("compRelease", 655, 290, 94, 104);

    placeKnob ("gateRange", 455, 485, 94, 104); placeKnob ("gateThreshold", 555, 485, 94, 104); placeKnob ("gateHold", 655, 485, 94, 104);
    placeButton ("gateOn", 464, 600, 88, 30); placeButton ("gateExpand", 562, 600, 92, 30); placeButton ("gateFast", 664, 600, 108, 30);
    placeKnob ("gateAttack", 495, 650, 108, 112); placeKnob ("gateRelease", 620, 650, 108, 112);

    // CENTRE
    placeKnob ("inputTrim", 835, 520, 126, 112); placeKnob ("vcaFader", 1025, 520, 126, 112);
    routingControl.setBounds (930, 646, 216, 38);

    // OUTPUT
    placeKnob ("outputTrim", 1234, 120, 150, 150); placeKnob ("mix", 1234, 330, 150, 150);
    placeButton ("mute", 1405, 366, 96, 34); placeButton ("bypass", 1405, 454, 96, 34);
    channelModeControl.setBounds (1246, 615, 244, 48);

    if (staticLayer.isNull() || staticLayer.getWidth() != getWidth() || staticLayer.getHeight() != getHeight()) rebuildStaticLayer();
}
