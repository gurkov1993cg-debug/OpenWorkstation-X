# GUI LOCK — v0.2.7

The approved composition is locked. Do not redesign, add utility/browser columns, move CHANNEL MODE out of OUTPUT, or reintroduce debug/build labels.

Fixed composition at 1536 × 942:

1. INPUT / FILTERS / EQ
2. DYNAMICS
3. central meter bridge / Channel Strip X plate
4. OUTPUT with CHANNEL MODE

Rules:

- No VST Instruments, VST Effects, browser, preset-browser, or empty fifth column.
- No architecture/OS/debug labels.
- No real third-party company names, logos, or trademark artwork; use Channel Strip X / OpenWorkstation X branding only.
- All APVTS parameters must remain accessible; compact controls rather than deleting them.
- No visible raw floating-point text boxes.
- All visible interactive controls must change a real APVTS/DSP parameter.
- The real C++ editor is rendered by CI to `gui-preview-v0.2.7.png`; review that output rather than relying on a generated mockup.
