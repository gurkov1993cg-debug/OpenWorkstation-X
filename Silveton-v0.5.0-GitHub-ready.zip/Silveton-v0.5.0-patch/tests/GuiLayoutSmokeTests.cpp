#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>
#include <iostream>
#include <vector>

namespace
{
    struct Failure
    {
        int count = 0;
        void require (bool ok, const juce::String& message)
        {
            if (! ok)
            {
                ++count;
                std::cerr << "FAIL: " << message << "\n";
            }
        }
    };

    juce::Component* findDirectChildById (juce::Component& parent, const juce::String& id)
    {
        for (int i = 0; i < parent.getNumChildComponents(); ++i)
            if (auto* c = parent.getChildComponent (i); c != nullptr && c->getComponentID() == id)
                return c;
        return nullptr;
    }

    bool exerciseControl (juce::Component& c, juce::RangedAudioParameter& parameter)
    {
        const float before = parameter.getValue();

        if (auto* s = dynamic_cast<juce::Slider*> (&c))
        {
            const double lo = s->getMinimum();
            const double hi = s->getMaximum();
            const double mid = (lo + hi) * 0.5;
            double target = s->getValue() <= mid ? hi : lo;
            if (std::abs (target - s->getValue()) < 1.0e-9)
                target = mid;
            s->setValue (target, juce::sendNotificationSync);
        }
        else if (auto* b = dynamic_cast<juce::ToggleButton*> (&c))
        {
            // Button::triggerClick() completes its simulated click asynchronously.
            // The smoke test reads APVTS immediately, so drive the actual toggle state
            // synchronously and let ButtonAttachment forward it to the parameter now.
            b->setToggleState (! b->getToggleState(), juce::sendNotificationSync);
        }
        else if (auto* box = dynamic_cast<juce::ComboBox*> (&c))
        {
            const int count = box->getNumItems();
            if (count < 2) return false;
            const int next = (box->getSelectedItemIndex() + 1) % count;
            box->setSelectedItemIndex (next, juce::sendNotificationSync);
        }
        else
        {
            return false;
        }

        const float after = parameter.getValue();
        parameter.setValueNotifyingHost (before);
        return std::abs (after - before) > 1.0e-6f;
    }
}

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;
    Failure f;
    ConsoleChannelStripXAudioProcessor processor;
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());

    f.require (editor != nullptr, "editor was not created");
    if (editor == nullptr) return 1;

    f.require (editor->getWidth() == 1500 && editor->getHeight() == 880,
               "Silveton design surface must be 1500x880");

    const std::vector<juce::String> visibleParameterIds {
        "bypass", "mix",
        "inputDrive", "inputTrim", "inputMode", "inputPad", "polarity",
        "hpOn", "hpFreq", "lpOn", "lpFreq",
        "eqOn", "eqModel", "hfGain", "hfFreq", "hfBell",
        "hmfGain", "hmfFreq", "hmfQ", "lmfGain", "lmfFreq", "lmfQ", "lfGain", "lfFreq", "lfBell",
        "dynOn", "routing", "gateOn", "gateExpand", "gateFast", "gateThreshold", "gateRange", "gateHold", "gateRelease",
        "compOn", "compPeak", "compFast", "compThreshold", "compRatio", "compRelease",
        "saturationOn", "satGain", "saturation",
        "stereoWidth", "pan", "stereoFocus", "stereoDetune", "stereoDelay",
        "vcaFader", "outputTrim", "autoLevel"
    };

    f.require ((int) visibleParameterIds.size() == 51, "expected 51 visible parameter controls");

    for (const auto& id : visibleParameterIds)
    {
        auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (processor.parameters().getParameter (id));
        f.require (parameter != nullptr, "missing APVTS parameter: " + id);
        auto* component = findDirectChildById (*editor, id);
        f.require (component != nullptr, "missing visible GUI control: " + id);
        if (component == nullptr || parameter == nullptr) continue;
        f.require (component->isVisible(), "control is hidden: " + id);
        f.require (component->getWidth() > 0 && component->getHeight() > 0, "control has zero bounds: " + id);
        f.require (exerciseControl (*component, *parameter), "control is not functionally attached: " + id);
    }

    f.require (processor.parameters().getParameter ("mute") != nullptr, "internal mute parameter was lost");
    f.require (findDirectChildById (*editor, "mute") == nullptr, "MUTE must remain hidden from Silveton GUI");

    for (const auto& action : { juce::String ("actionUndo"), juce::String ("actionRedo"), juce::String ("actionInit") })
    {
        auto* c = findDirectChildById (*editor, action);
        f.require (c != nullptr, "missing working action control: " + action);
        if (c != nullptr)
            f.require (c->getWidth() > 0 && c->getHeight() > 0, "action control has zero bounds: " + action);
    }

    juce::Image image (juce::Image::RGB, editor->getWidth(), editor->getHeight(), true);
    juce::Graphics graphics (image);
    editor->paintEntireComponent (graphics, true);
    juce::File out = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-silveton-v0.5.0.png");
    juce::FileOutputStream stream (out);
    juce::PNGImageFormat png;
    f.require (stream.openedOk() && png.writeImageToStream (image, stream), "GUI preview PNG was not written");

    if (f.count != 0)
    {
        std::cerr << f.count << " Silveton GUI smoke test(s) failed\n";
        return 1;
    }

    std::cout << "PASS: Silveton v0.5.0 modern lightweight GUI; all 51 visible APVTS controls are present, bounded and functionally attached; MUTE remains hidden.\n";
    return 0;
}
