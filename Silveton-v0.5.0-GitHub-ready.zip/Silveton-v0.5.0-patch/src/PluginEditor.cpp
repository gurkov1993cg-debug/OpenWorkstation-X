#include "PluginEditor.h"
#include <algorithm>
#include <cmath>

namespace
{
    constexpr int kDesignWidth  = 1500;
    constexpr int kDesignHeight = 880;

    const auto bg        = juce::Colour::fromRGB (15, 18, 22);
    const auto header    = juce::Colour::fromRGB (18, 23, 28);
    const auto panel     = juce::Colour::fromRGB (23, 29, 35);
    const auto panelEdge = juce::Colour::fromRGB (44, 54, 64);
    const auto field     = juce::Colour::fromRGB (17, 22, 27);
    const auto blue      = juce::Colour::fromRGB (65, 164, 224);
    const auto blueDim   = juce::Colour::fromRGB (42, 101, 137);
    const auto text      = juce::Colour::fromRGB (220, 230, 237);
    const auto muted     = juce::Colour::fromRGB (126, 141, 153);
    const auto meterG    = juce::Colour::fromRGB (83, 199, 118);
    const auto meterY    = juce::Colour::fromRGB (222, 190, 75);
    const auto meterR    = juce::Colour::fromRGB (224, 82, 76);

    struct Layout
    {
        static juce::Rectangle<int> headerRect()     { return { 0, 0, kDesignWidth, 66 }; }
        static juce::Rectangle<int> input()          { return { 18, 82, 188, 394 }; }
        static juce::Rectangle<int> filters()        { return { 216, 82, 214, 394 }; }
        static juce::Rectangle<int> eq()             { return { 440, 82, 540, 394 }; }
        static juce::Rectangle<int> dynamics()       { return { 990, 82, 492, 394 }; }
        static juce::Rectangle<int> saturation()     { return { 18, 492, 352, 370 }; }
        static juce::Rectangle<int> stereo()         { return { 380, 492, 592, 370 }; }
        static juce::Rectangle<int> output()         { return { 982, 492, 500, 370 }; }
    };

    class SilvetonLookAndFeel final : public juce::LookAndFeel_V4
    {
    public:
        SilvetonLookAndFeel()
        {
            setColour (juce::Label::textColourId, text);
            setColour (juce::Slider::textBoxTextColourId, text);
            setColour (juce::Slider::textBoxBackgroundColourId, field);
            setColour (juce::Slider::textBoxOutlineColourId, panelEdge);
            setColour (juce::ComboBox::backgroundColourId, field);
            setColour (juce::ComboBox::textColourId, text);
            setColour (juce::ComboBox::outlineColourId, panelEdge);
            setColour (juce::PopupMenu::backgroundColourId, juce::Colour::fromRGB (20, 25, 30));
            setColour (juce::PopupMenu::textColourId, text);
            setColour (juce::TextButton::buttonColourId, field);
            setColour (juce::TextButton::buttonOnColourId, blueDim);
            setColour (juce::TextButton::textColourOffId, text);
            setColour (juce::TextButton::textColourOnId, juce::Colours::white);
        }

        void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                               float sliderPosProportional, float rotaryStartAngle,
                               float rotaryEndAngle, juce::Slider&) override
        {
            auto area = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (7.0f);
            const float size = juce::jmin (area.getWidth(), area.getHeight());
            auto dial = juce::Rectangle<float> (0.0f, 0.0f, size, size).withCentre (area.getCentre());
            const auto centre = dial.getCentre();
            const float radius = dial.getWidth() * 0.5f;
            const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

            g.setColour (juce::Colour::fromRGB (10, 13, 16));
            g.fillEllipse (dial);
            g.setColour (panelEdge);
            g.drawEllipse (dial, 1.0f);

            juce::Path track;
            track.addCentredArc (centre.x, centre.y, radius - 3.0f, radius - 3.0f, 0.0f,
                                 rotaryStartAngle, rotaryEndAngle, true);
            g.setColour (juce::Colour::fromRGB (49, 60, 70));
            g.strokePath (track, juce::PathStrokeType (2.0f));

            juce::Path active;
            active.addCentredArc (centre.x, centre.y, radius - 3.0f, radius - 3.0f, 0.0f,
                                  rotaryStartAngle, angle, true);
            g.setColour (blue);
            g.strokePath (active, juce::PathStrokeType (2.0f));

            juce::Path pointer;
            pointer.addRoundedRectangle (-1.0f, -radius + 8.0f, 2.0f, radius * 0.42f, 1.0f);
            pointer.applyTransform (juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
            g.setColour (juce::Colours::white.withAlpha (0.94f));
            g.fillPath (pointer);
        }

        void drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                               bool shouldDrawButtonAsHighlighted, bool) override
        {
            auto r = button.getLocalBounds().toFloat().reduced (0.5f);
            auto c = button.getToggleState() ? blueDim : field;
            if (shouldDrawButtonAsHighlighted)
                c = c.brighter (0.10f);
            g.setColour (c);
            g.fillRoundedRectangle (r, 3.0f);
            g.setColour (button.getToggleState() ? blue : panelEdge);
            g.drawRoundedRectangle (r, 3.0f, 1.0f);
            g.setColour (button.getToggleState() ? juce::Colours::white : text);
            g.setFont (juce::Font (11.0f, juce::Font::bold));
            g.drawFittedText (button.getButtonText(), button.getLocalBounds().reduced (5, 1),
                              juce::Justification::centred, 1);
        }

        void drawButtonBackground (juce::Graphics& g, juce::Button& button,
                                   const juce::Colour&, bool highlighted, bool down) override
        {
            auto r = button.getLocalBounds().toFloat().reduced (0.5f);
            auto c = down ? blueDim : field;
            if (highlighted) c = c.brighter (0.08f);
            g.setColour (c);
            g.fillRoundedRectangle (r, 3.0f);
            g.setColour (panelEdge);
            g.drawRoundedRectangle (r, 3.0f, 1.0f);
        }

        void drawComboBox (juce::Graphics& g, int width, int height, bool,
                           int, int, int, int, juce::ComboBox&) override
        {
            auto r = juce::Rectangle<float> (0.5f, 0.5f, (float) width - 1.0f, (float) height - 1.0f);
            g.setColour (field);
            g.fillRoundedRectangle (r, 3.0f);
            g.setColour (panelEdge);
            g.drawRoundedRectangle (r, 3.0f, 1.0f);
            juce::Path p;
            const float cx = (float) width - 13.0f;
            const float cy = (float) height * 0.5f;
            p.addTriangle (cx - 4.0f, cy - 2.0f, cx + 4.0f, cy - 2.0f, cx, cy + 3.0f);
            g.setColour (muted);
            g.fillPath (p);
        }

        juce::Font getComboBoxFont (juce::ComboBox&) override
        {
            return juce::Font (11.0f, juce::Font::plain);
        }
    };

    juce::Rectangle<int> inner (juce::Rectangle<int> panelRect, int x, int y, int w, int h)
    {
        return { panelRect.getX() + x, panelRect.getY() + y, w, h };
    }

    bool containsIgnoreCase (const juce::String& s, const char* token)
    {
        return s.containsIgnoreCase (token);
    }
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), silvetonLookAndFeel (std::make_unique<SilvetonLookAndFeel>())
{
    setOpaque (true);
    setLookAndFeel (silvetonLookAndFeel.get());

    addAndMakeVisible (undoButton);
    addAndMakeVisible (redoButton);
    addAndMakeVisible (initButton);
    undoButton.setComponentID ("actionUndo");
    redoButton.setComponentID ("actionRedo");
    initButton.setComponentID ("actionInit");
    undoButton.onClick = [this] { audioProcessor.undo(); };
    redoButton.onClick = [this] { audioProcessor.redo(); };
    initButton.onClick = [this] { audioProcessor.resetParametersToDefaults(); };

    addButton ("bypass", "BYPASS");
    addSlider ("mix", "MIX");

    addSlider ("inputDrive", "GAIN");
    addSlider ("inputTrim", "TRIM");
    addChoice ("inputMode", "MODE", { "LINE", "MIC" });
    addButton ("inputPad", "-20 dB");
    addButton ("polarity", "PHASE");

    addButton ("hpOn", "HP IN");
    addSlider ("hpFreq", "HPF");
    addButton ("lpOn", "LP IN");
    addSlider ("lpFreq", "LPF");

    addButton ("eqOn", "EQ IN");
    addChoice ("eqModel", "MODEL", { "02 BROWN", "242 BLACK" });
    addSlider ("hfGain", "HF GAIN");
    addSlider ("hfFreq", "HF FREQ");
    addButton ("hfBell", "BELL");
    addSlider ("hmfGain", "HMF GAIN");
    addSlider ("hmfFreq", "HMF FREQ");
    addSlider ("hmfQ", "HMF Q");
    addSlider ("lmfGain", "LMF GAIN");
    addSlider ("lmfFreq", "LMF FREQ");
    addSlider ("lmfQ", "LMF Q");
    addSlider ("lfGain", "LF GAIN");
    addSlider ("lfFreq", "LF FREQ");
    addButton ("lfBell", "BELL");

    addButton ("dynOn", "DYN IN");
    addChoice ("routing", "ORDER", { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" });
    addButton ("gateOn", "GATE IN");
    addButton ("gateExpand", "EXPAND");
    addButton ("gateFast", "FAST");
    addSlider ("gateThreshold", "THRESHOLD");
    addSlider ("gateRange", "RANGE");
    addSlider ("gateHold", "HOLD");
    addSlider ("gateRelease", "RELEASE");
    addButton ("compOn", "COMP IN");
    addButton ("compPeak", "PEAK");
    addButton ("compFast", "FAST");
    addSlider ("compThreshold", "THRESHOLD");
    addSlider ("compRatio", "RATIO");
    addSlider ("compRelease", "RELEASE");

    addButton ("saturationOn", "SAT IN");
    addSlider ("satGain", "DRIVE");
    addSlider ("saturation", "AMOUNT");

    addSlider ("stereoWidth", "WIDTH");
    addSlider ("pan", "PAN / BAL");
    addSlider ("stereoFocus", "FOCUS");
    addSlider ("stereoDetune", "DETUNE");
    addSlider ("stereoDelay", "DELAY");

    addSlider ("vcaFader", "LEVEL");
    addSlider ("outputTrim", "OUT TRIM");
    addButton ("autoLevel", "AUTO LEVEL");

    setSize (kDesignWidth, kDesignHeight);
    setResizable (false, false);
    startTimerHz (30);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void ConsoleChannelStripXAudioProcessorEditor::addSlider (const char* parameterId, const char* labelText)
{
    auto slot = std::make_unique<SliderControl>();
    slot->label = std::make_unique<juce::Label>();
    slot->slider = std::make_unique<juce::Slider>();

    slot->label->setText (labelText, juce::dontSendNotification);
    slot->label->setJustificationType (juce::Justification::centred);
    slot->label->setColour (juce::Label::textColourId, muted);
    slot->label->setFont (juce::Font (10.0f, juce::Font::bold));

    slot->slider->setComponentID (parameterId);
    slot->slider->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slot->slider->setRotaryParameters (juce::MathConstants<float>::pi * 1.25f,
                                       juce::MathConstants<float>::pi * 2.75f, true);
    slot->slider->setTextBoxStyle (juce::Slider::TextBoxBelow, false, 74, 18);
    slot->slider->setScrollWheelEnabled (true);

    if (auto* parameter = dynamic_cast<juce::RangedAudioParameter*> (audioProcessor.parameters().getParameter (parameterId)))
    {
        const auto r = parameter->getNormalisableRange();
        juce::NormalisableRange<double> dr ((double) r.start, (double) r.end, (double) r.interval,
                                             (double) r.skew, r.symmetricSkew);
        slot->slider->setNormalisableRange (dr);
        slot->slider->setDoubleClickReturnValue (true, (double) r.convertFrom0to1 (parameter->getDefaultValue()));
    }

    addAndMakeVisible (*slot->label);
    addAndMakeVisible (*slot->slider);
    slot->attachment = std::make_unique<SliderAttachment> (audioProcessor.parameters(), parameterId, *slot->slider);

    const juce::String id (parameterId);
    slot->slider->textFromValueFunction = [id] (double v) { return formatParameterValue (id, v); };
    slot->slider->valueFromTextFunction = [id] (const juce::String& s) { return parseParameterValue (id, s); };
    slot->slider->updateText();

    controlsById[parameterId] = slot->slider.get();
    labelsById[parameterId] = slot->label.get();
    sliderControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const char* parameterId, const char* buttonText)
{
    auto slot = std::make_unique<ButtonControl>();
    slot->button = std::make_unique<juce::ToggleButton> (buttonText);
    slot->button->setComponentID (parameterId);
    slot->button->setClickingTogglesState (true);
    addAndMakeVisible (*slot->button);
    slot->attachment = std::make_unique<ButtonAttachment> (audioProcessor.parameters(), parameterId, *slot->button);
    controlsById[parameterId] = slot->button.get();
    buttonControls.push_back (std::move (slot));
}

void ConsoleChannelStripXAudioProcessorEditor::addChoice (const char* parameterId, const char* labelText,
                                                           const juce::StringArray& items)
{
    auto slot = std::make_unique<ChoiceControl>();
    slot->label = std::make_unique<juce::Label>();
    slot->choice = std::make_unique<juce::ComboBox>();
    slot->label->setText (labelText, juce::dontSendNotification);
    slot->label->setJustificationType (juce::Justification::centredLeft);
    slot->label->setColour (juce::Label::textColourId, muted);
    slot->label->setFont (juce::Font (10.0f, juce::Font::bold));
    slot->choice->setComponentID (parameterId);
    slot->choice->addItemList (items, 1);
    addAndMakeVisible (*slot->label);
    addAndMakeVisible (*slot->choice);
    slot->attachment = std::make_unique<ComboAttachment> (audioProcessor.parameters(), parameterId, *slot->choice);
    controlsById[parameterId] = slot->choice.get();
    labelsById[parameterId] = slot->label.get();
    choiceControls.push_back (std::move (slot));
}

juce::Component* ConsoleChannelStripXAudioProcessorEditor::control (const char* parameterId) const
{
    const auto it = controlsById.find (parameterId);
    return it == controlsById.end() ? nullptr : it->second;
}

void ConsoleChannelStripXAudioProcessorEditor::placeSlider (const char* id, juce::Rectangle<int> bounds)
{
    auto it = controlsById.find (id);
    auto lit = labelsById.find (id);
    if (it == controlsById.end() || lit == labelsById.end()) return;
    lit->second->setBounds (bounds.removeFromTop (15));
    it->second->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeButton (const char* id, juce::Rectangle<int> bounds)
{
    if (auto* c = control (id)) c->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::placeChoice (const char* id, juce::Rectangle<int> bounds)
{
    auto it = controlsById.find (id);
    auto lit = labelsById.find (id);
    if (it == controlsById.end() || lit == labelsById.end()) return;
    lit->second->setBounds (bounds.removeFromTop (15));
    it->second->setBounds (bounds);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    undoButton.setBounds (875, 18, 62, 30);
    redoButton.setBounds (943, 18, 62, 30);
    initButton.setBounds (1011, 18, 62, 30);
    placeButton ("bypass", { 1082, 18, 78, 30 });
    placeSlider ("mix", { 1180, 5, 92, 58 });

    const auto pIn = Layout::input();
    placeSlider ("inputDrive", inner (pIn, 12, 42, 82, 105));
    placeSlider ("inputTrim", inner (pIn, 94, 42, 82, 105));
    placeChoice ("inputMode", inner (pIn, 14, 158, 160, 49));
    placeButton ("inputPad", inner (pIn, 14, 222, 74, 28));
    placeButton ("polarity", inner (pIn, 100, 222, 74, 28));

    const auto pF = Layout::filters();
    placeSlider ("hpFreq", inner (pF, 14, 48, 86, 112));
    placeSlider ("lpFreq", inner (pF, 114, 48, 86, 112));
    placeButton ("hpOn", inner (pF, 18, 172, 78, 28));
    placeButton ("lpOn", inner (pF, 118, 172, 78, 28));

    const auto pEq = Layout::eq();
    placeButton ("eqOn", inner (pEq, 12, 38, 72, 28));
    placeChoice ("eqModel", inner (pEq, 95, 30, 154, 50));
    placeSlider ("hfGain", inner (pEq, 15, 94, 80, 108));
    placeSlider ("hfFreq", inner (pEq, 101, 94, 80, 108));
    placeButton ("hfBell", inner (pEq, 44, 215, 102, 26));
    placeSlider ("hmfGain", inner (pEq, 190, 94, 80, 108));
    placeSlider ("hmfFreq", inner (pEq, 276, 94, 80, 108));
    placeSlider ("hmfQ", inner (pEq, 362, 94, 80, 108));
    placeSlider ("lmfGain", inner (pEq, 15, 254, 80, 108));
    placeSlider ("lmfFreq", inner (pEq, 101, 254, 80, 108));
    placeSlider ("lmfQ", inner (pEq, 187, 254, 80, 108));
    placeSlider ("lfGain", inner (pEq, 286, 254, 80, 108));
    placeSlider ("lfFreq", inner (pEq, 372, 254, 80, 108));
    placeButton ("lfBell", inner (pEq, 454, 287, 70, 26));

    const auto pD = Layout::dynamics();
    placeButton ("dynOn", inner (pD, 12, 38, 70, 28));
    placeChoice ("routing", inner (pD, 92, 30, 205, 50));
    placeButton ("gateOn", inner (pD, 15, 89, 72, 27));
    placeButton ("gateExpand", inner (pD, 92, 89, 76, 27));
    placeButton ("gateFast", inner (pD, 173, 89, 62, 27));
    placeSlider ("gateThreshold", inner (pD, 10, 124, 76, 105));
    placeSlider ("gateRange", inner (pD, 86, 124, 76, 105));
    placeSlider ("gateHold", inner (pD, 162, 124, 76, 105));
    placeSlider ("gateRelease", inner (pD, 238, 124, 76, 105));
    placeButton ("compOn", inner (pD, 332, 89, 72, 27));
    placeButton ("compPeak", inner (pD, 410, 89, 62, 27));
    placeButton ("compFast", inner (pD, 410, 122, 62, 27));
    placeSlider ("compThreshold", inner (pD, 318, 155, 76, 105));
    placeSlider ("compRatio", inner (pD, 396, 155, 76, 105));
    placeSlider ("compRelease", inner (pD, 357, 270, 76, 105));

    const auto pS = Layout::saturation();
    placeButton ("saturationOn", inner (pS, 18, 42, 80, 29));
    placeSlider ("satGain", inner (pS, 40, 98, 112, 130));
    placeSlider ("saturation", inner (pS, 188, 98, 112, 130));

    const auto pSt = Layout::stereo();
    placeSlider ("stereoWidth", inner (pSt, 18, 58, 100, 122));
    placeSlider ("pan", inner (pSt, 128, 58, 100, 122));
    placeSlider ("stereoFocus", inner (pSt, 238, 58, 100, 122));
    placeSlider ("stereoDetune", inner (pSt, 348, 58, 100, 122));
    placeSlider ("stereoDelay", inner (pSt, 458, 58, 100, 122));

    const auto pO = Layout::output();
    placeSlider ("vcaFader", inner (pO, 28, 60, 112, 130));
    placeSlider ("outputTrim", inner (pO, 153, 60, 112, 130));
    placeButton ("autoLevel", inner (pO, 45, 220, 180, 30));
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (bg);
    g.setColour (header);
    g.fillRect (Layout::headerRect());
    g.setColour (panelEdge);
    g.drawHorizontalLine (65, 0.0f, (float) getWidth());

    g.setColour (text);
    g.setFont (juce::Font (24.0f, juce::Font::bold));
    g.drawText ("SILVETON", 22, 9, 170, 28, juce::Justification::centredLeft);
    g.setColour (blue);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("CHANNEL STRIP", 23, 36, 170, 18, juce::Justification::centredLeft);

    g.setColour (muted);
    g.setFont (juce::Font (10.0f));
    g.drawText ("v0.5.0  •  49 REAL CONTROLS", 210, 24, 230, 18, juce::Justification::centredLeft);

    drawPanel (g, Layout::input(), "INPUT");
    drawPanel (g, Layout::filters(), "FILTERS");
    drawPanel (g, Layout::eq(), "EQUALISER");
    drawPanel (g, Layout::dynamics(), "DYNAMICS");
    drawPanel (g, Layout::saturation(), "SATURATION");
    drawPanel (g, Layout::stereo(), "STEREO");
    drawPanel (g, Layout::output(), "OUTPUT");

    drawStereoMeter (g, inner (Layout::input(), 24, 277, 140, 92), inL, inR, inHoldL, inHoldR, "INPUT METER");
    drawReductionMeter (g, inner (Layout::dynamics(), 324, 315, 150, 47), compGr, "COMP GR");
    drawReductionMeter (g, inner (Layout::dynamics(), 12, 315, 150, 47), gateGr, "GATE GR");
    drawReductionMeter (g, inner (Layout::saturation(), 52, 274, 246, 48), juce::jlimit (0.0f, 24.0f, preSat + 24.0f), "PRE-SAT LEVEL");
    drawStereoMeter (g, inner (Layout::output(), 286, 58, 184, 255), outL, outR, outHoldL, outHoldR, "OUTPUT L / R");

    g.setColour (muted);
    g.setFont (juce::Font (9.0f));
    g.drawText ("Lightweight 2D GUI • meters 30 Hz • DSP unchanged from locked v0.4.1 base",
                22, 855, 900, 16, juce::Justification::centredLeft);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, juce::Rectangle<int> r,
                                                           const juce::String& title) const
{
    g.setColour (panel);
    g.fillRoundedRectangle (r.toFloat(), 5.0f);
    g.setColour (panelEdge);
    g.drawRoundedRectangle (r.toFloat(), 5.0f, 1.0f);
    g.setColour (blue.withAlpha (0.85f));
    g.fillRect (r.getX() + 10, r.getY() + 28, juce::jmin (76, r.getWidth() - 20), 2);
    g.setColour (text);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (title, r.getX() + 12, r.getY() + 7, r.getWidth() - 24, 18, juce::Justification::centredLeft);
}

void ConsoleChannelStripXAudioProcessorEditor::drawStereoMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                 float leftDb, float rightDb,
                                                                 float holdLeftDb, float holdRightDb,
                                                                 const juce::String& caption) const
{
    g.setColour (muted);
    g.setFont (juce::Font (9.0f, juce::Font::bold));
    g.drawText (caption, r.removeFromTop (14), juce::Justification::centred);

    const int scaleW = 28;
    auto scale = r.removeFromLeft (scaleW);
    auto meterArea = r.reduced (4, 2);
    auto l = meterArea.removeFromLeft (meterArea.getWidth() / 2 - 3);
    meterArea.removeFromLeft (6);
    auto rr = meterArea;

    const auto dbToNorm = [] (float db)
    {
        return juce::jmap (juce::jlimit (-60.0f, 6.0f, db), -60.0f, 6.0f, 0.0f, 1.0f);
    };

    for (int db : { 6, 0, -12, -24, -36, -48, -60 })
    {
        const int y = r.getBottom() - juce::roundToInt ((float) r.getHeight() * dbToNorm ((float) db));
        g.setColour (muted.withAlpha (0.75f));
        g.setFont (juce::Font (8.0f));
        g.drawText (juce::String (db), scale.getX(), y - 5, scale.getWidth() - 2, 10, juce::Justification::centredRight);
    }

    auto drawOne = [&] (juce::Rectangle<int> bar, float db, float holdDb)
    {
        g.setColour (field);
        g.fillRoundedRectangle (bar.toFloat(), 2.0f);
        const int fillH = juce::roundToInt ((float) bar.getHeight() * dbToNorm (db));
        auto fill = bar.withTop (bar.getBottom() - fillH);
        juce::ColourGradient grad (meterG, 0.0f, (float) bar.getBottom(), meterR, 0.0f, (float) bar.getY(), false);
        grad.addColour (0.70, meterY);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (fill.toFloat(), 2.0f);

        const int holdY = bar.getBottom() - juce::roundToInt ((float) bar.getHeight() * dbToNorm (holdDb));
        g.setColour (juce::Colours::white.withAlpha (0.90f));
        g.fillRect (bar.getX(), juce::jlimit (bar.getY(), bar.getBottom() - 1, holdY), bar.getWidth(), 1);
    };

    drawOne (l, leftDb, holdLeftDb);
    drawOne (rr, rightDb, holdRightDb);
}

void ConsoleChannelStripXAudioProcessorEditor::drawReductionMeter (juce::Graphics& g, juce::Rectangle<int> r,
                                                                    float reductionDb, const juce::String& caption) const
{
    g.setColour (muted);
    g.setFont (juce::Font (9.0f, juce::Font::bold));
    g.drawText (caption, r.removeFromTop (13), juce::Justification::centredLeft);
    auto bar = r.reduced (2, 4);
    g.setColour (field);
    g.fillRoundedRectangle (bar.toFloat(), 2.0f);
    const float n = juce::jlimit (0.0f, 1.0f, std::abs (reductionDb) / 24.0f);
    auto fill = bar.withWidth (juce::roundToInt ((float) bar.getWidth() * n));
    g.setColour (blue);
    g.fillRoundedRectangle (fill.toFloat(), 2.0f);
}

float ConsoleChannelStripXAudioProcessorEditor::smoothMeter (float current, float target)
{
    if (target > current) return target;
    return current + (target - current) * 0.18f;
}

void ConsoleChannelStripXAudioProcessorEditor::updatePeakHold (float value, float& hold, int& ticks)
{
    if (value >= hold)
    {
        hold = value;
        ticks = 28;
    }
    else if (ticks > 0)
    {
        --ticks;
    }
    else
    {
        hold = juce::jmax (value, hold - 1.25f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    inL = smoothMeter (inL, audioProcessor.inputMeterL());
    inR = smoothMeter (inR, audioProcessor.inputMeterR());
    outL = smoothMeter (outL, audioProcessor.outputMeterL());
    outR = smoothMeter (outR, audioProcessor.outputMeterR());
    compGr = smoothMeter (compGr, audioProcessor.compressorPeakReductionMeter());
    gateGr = smoothMeter (gateGr, audioProcessor.gatePeakReductionMeter());
    preSat = smoothMeter (preSat, audioProcessor.preSaturationMeter());

    updatePeakHold (inL, inHoldL, inHoldTicksL);
    updatePeakHold (inR, inHoldR, inHoldTicksR);
    updatePeakHold (outL, outHoldL, outHoldTicksL);
    updatePeakHold (outR, outHoldR, outHoldTicksR);

    repaint (Layout::input());
    repaint (Layout::dynamics());
    repaint (Layout::saturation());
    repaint (Layout::output());
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatParameterValue (const juce::String& id, double value)
{
    if (containsIgnoreCase (id, "freq") || id == "stereoFocus")
    {
        if (value >= 1000.0)
            return juce::String (value / 1000.0, value >= 10000.0 ? 1 : 2) + " kHz";
        return juce::String (value, value < 100.0 ? 1 : 0) + " Hz";
    }
    if (id == "gateHold" || id == "gateRelease" || id == "compRelease")
        return juce::String (value, 2) + " s";
    if (id == "stereoDelay")
        return juce::String (value, 1) + " ms";
    if (id == "stereoDetune")
        return juce::String (value, 1) + " ct";
    if (id == "mix" || id == "saturation" || id == "stereoWidth")
        return juce::String (value, 0) + " %";
    if (id == "pan")
    {
        if (std::abs (value) < 0.005) return "C";
        return value < 0.0 ? "L " + juce::String (std::abs (value) * 100.0, 0)
                           : "R " + juce::String (value * 100.0, 0);
    }
    if (containsIgnoreCase (id, "q") || id == "compRatio")
        return juce::String (value, 2);
    return juce::String (value, 1) + " dB";
}

double ConsoleChannelStripXAudioProcessorEditor::parseParameterValue (const juce::String& id,
                                                                       const juce::String& rawText)
{
    auto s = rawText.trim().toLowerCase();
    double v = s.getDoubleValue();
    if ((containsIgnoreCase (id, "freq") || id == "stereoFocus") && s.containsChar ('k'))
        v *= 1000.0;
    if (id == "pan")
    {
        if (s.startsWithChar ('l')) return -std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('r')) return  std::abs (s.substring (1).getDoubleValue()) / 100.0;
        if (s.startsWithChar ('c')) return 0.0;
    }
    return v;
}
