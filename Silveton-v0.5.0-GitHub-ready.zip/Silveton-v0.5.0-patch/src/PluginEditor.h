#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                      private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using APVTS = juce::AudioProcessorValueTreeState;
    using SliderAttachment = APVTS::SliderAttachment;
    using ButtonAttachment = APVTS::ButtonAttachment;
    using ComboAttachment = APVTS::ComboBoxAttachment;

    struct SliderControl
    {
        std::unique_ptr<juce::Label> label;
        std::unique_ptr<juce::Slider> slider;
        std::unique_ptr<SliderAttachment> attachment;
    };

    struct ButtonControl
    {
        std::unique_ptr<juce::ToggleButton> button;
        std::unique_ptr<ButtonAttachment> attachment;
    };

    struct ChoiceControl
    {
        std::unique_ptr<juce::Label> label;
        std::unique_ptr<juce::ComboBox> choice;
        std::unique_ptr<ComboAttachment> attachment;
    };

    ConsoleChannelStripXAudioProcessor& audioProcessor;
    std::unique_ptr<juce::LookAndFeel_V4> silvetonLookAndFeel;

    std::vector<std::unique_ptr<SliderControl>> sliderControls;
    std::vector<std::unique_ptr<ButtonControl>> buttonControls;
    std::vector<std::unique_ptr<ChoiceControl>> choiceControls;
    std::unordered_map<std::string, juce::Component*> controlsById;
    std::unordered_map<std::string, juce::Label*> labelsById;

    juce::TextButton undoButton { "UNDO" };
    juce::TextButton redoButton { "REDO" };
    juce::TextButton initButton { "INIT" };

    float inL = -72.0f, inR = -72.0f, outL = -72.0f, outR = -72.0f;
    float inHoldL = -72.0f, inHoldR = -72.0f, outHoldL = -72.0f, outHoldR = -72.0f;
    float compGr = 0.0f, gateGr = 0.0f, preSat = -72.0f;
    int inHoldTicksL = 0, inHoldTicksR = 0, outHoldTicksL = 0, outHoldTicksR = 0;

    void addSlider (const char* parameterId, const char* labelText);
    void addButton (const char* parameterId, const char* buttonText);
    void addChoice (const char* parameterId, const char* labelText, const juce::StringArray& items);
    void placeSlider (const char* parameterId, juce::Rectangle<int> bounds);
    void placeButton (const char* parameterId, juce::Rectangle<int> bounds);
    void placeChoice (const char* parameterId, juce::Rectangle<int> bounds);
    juce::Component* control (const char* parameterId) const;

    void timerCallback() override;
    void drawPanel (juce::Graphics&, juce::Rectangle<int>, const juce::String& title) const;
    void drawStereoMeter (juce::Graphics&, juce::Rectangle<int>, float leftDb, float rightDb,
                          float holdLeftDb, float holdRightDb, const juce::String& caption) const;
    void drawReductionMeter (juce::Graphics&, juce::Rectangle<int>, float reductionDb,
                             const juce::String& caption) const;
    static juce::String formatParameterValue (const juce::String& id, double value);
    static double parseParameterValue (const juce::String& id, const juce::String& text);
    static float smoothMeter (float current, float target);
    static void updatePeakHold (float value, float& hold, int& ticks);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
