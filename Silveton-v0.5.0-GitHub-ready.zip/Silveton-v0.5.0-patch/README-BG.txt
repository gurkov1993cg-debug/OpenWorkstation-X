SILVETON CHANNEL STRIP v0.5.0 — MAC INTEL / macOS 10.13

База: заключената Console Channel Strip X v0.4.1 Wien RC EQ.
DSP файловете не се променят. Workflow-ът прави SHA-256 проверка преди/след GUI промяната.

Нов GUI:
- SILVETON branding
- модерен тъмен графитен 2D интерфейс със студено син акцент
- 30 Hz метри; без blur/glow/тежки анимации
- numeric entry през value box
- double-click reset към default на всички slider-и
- 51 видими APVTS контроли, всеки вързан към реален параметър
- MUTE остава вътрешен параметър и не се показва
- Saturation: SAT IN / DRIVE / AMOUNT
- Stereo: WIDTH / PAN-BAL / FOCUS / DETUNE / DELAY
- Input / Filters / EQ / Gate-Expander / Compressor / Saturation / Stereo / Output

Файлът .github/workflows/build-silveton-v050-macos-intel.yml е самостоятелен:
той използва вече наличния ConsoleChannelStrip-X-v0.4.1-Wien-RC-source.zip в repo-то,
вкарва новия GUI, пуска DSP regression тестовете, functional GUI test за всички 51 контроли,
билдва Intel x86_64 VST3 с target macOS 10.13 и прави:
- Silveton-Channel-Strip-v0.5.0-macOS-Intel.zip
- Silveton-Channel-Strip-v0.5.0-source.zip
- gui-preview-silveton-v0.5.0.png

Важно: старата v0.4.1 не се презаписва.
