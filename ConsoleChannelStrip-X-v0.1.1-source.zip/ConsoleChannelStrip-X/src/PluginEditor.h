#pragma once
#include <JuceHeader.h>
#include <map>
#include <memory>
#include "PluginProcessor.h"

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override = default;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    void addKnob (const juce::String& id, const juce::String& label, const juce::String& suffix = {});
    void addButton (const juce::String& id, const juce::String& label);
    void timerCallback() override { repaint(); }
    void placeKnob (const juce::String& id, int x, int y, int w = 82, int h = 92);
    void placeButton (const juce::String& id, int x, int y, int w = 82, int h = 24);

    ConsoleChannelStripXAudioProcessor& processor;
    std::map<juce::String, std::unique_ptr<juce::Slider>> knobs;
    std::map<juce::String, std::unique_ptr<juce::ToggleButton>> buttons;
    std::vector<std::unique_ptr<SliderAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<ButtonAttachment>> buttonAttachments;
    juce::ComboBox routingBox;
    std::unique_ptr<ComboAttachment> routingAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
