#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    using Range = juce::NormalisableRange<float>;
    std::unique_ptr<juce::RangedAudioParameter> f (const char* id, const char* name, float min, float max, float def, float skew = 1.0f)
    {
        Range r (min, max); r.setSkewForCentre (skew == 1.0f ? (min + max) * 0.5f : skew);
        return std::make_unique<juce::AudioParameterFloat> (id, name, r, def);
    }
    std::unique_ptr<juce::RangedAudioParameter> b (const char* id, const char* name, bool def)
    { return std::make_unique<juce::AudioParameterBool> (id, name, def); }
}

ConsoleChannelStripXAudioProcessor::ConsoleChannelStripXAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

void ConsoleChannelStripXAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    engine.prepare (sampleRate, samplesPerBlock, getTotalNumOutputChannels());
}

void ConsoleChannelStripXAudioProcessor::releaseResources() {}

bool ConsoleChannelStripXAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

DspEngine::Params ConsoleChannelStripXAudioProcessor::readParams() const
{
    DspEngine::Params p;
    auto v = [this] (const char* id) { return apvts.getRawParameterValue (id)->load(); };
    p.inputGainDb = v("inputGain"); p.polarity = v("polarity") > 0.5f;
    p.hpOn = v("hpOn") > 0.5f; p.hpFreq = v("hpFreq");
    p.lpOn = v("lpOn") > 0.5f; p.lpFreq = v("lpFreq");
    p.eqOn = v("eqOn") > 0.5f; p.eSeries = v("eSeries") > 0.5f;
    p.lfBell = v("lfBell") > 0.5f; p.lfFreq = v("lfFreq"); p.lfGain = v("lfGain");
    p.lmfFreq = v("lmfFreq"); p.lmfGain = v("lmfGain"); p.lmfQ = v("lmfQ");
    p.hmfFreq = v("hmfFreq"); p.hmfGain = v("hmfGain"); p.hmfQ = v("hmfQ");
    p.hfBell = v("hfBell") > 0.5f; p.hfFreq = v("hfFreq"); p.hfGain = v("hfGain");
    p.dynOn = v("dynOn") > 0.5f; p.compThreshold = v("compThreshold"); p.compRatio = v("compRatio");
    p.compRelease = v("compRelease"); p.compFast = v("compFast") > 0.5f; p.compPeak = v("compPeak") > 0.5f; p.compMix = v("compMix");
    p.gateThreshold = v("gateThreshold"); p.gateRange = v("gateRange"); p.gateHold = v("gateHold");
    p.gateRelease = v("gateRelease"); p.gateFast = v("gateFast") > 0.5f; p.gateExpand = v("gateExpand") > 0.5f;
    p.routing = static_cast<int> (v("routing")); p.outputGainDb = v("outputGain"); p.bypass = v("bypass") > 0.5f;
    return p;
}

void ConsoleChannelStripXAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, buffer.getNumSamples());
    engine.process (buffer, readParams());
}

juce::AudioProcessorEditor* ConsoleChannelStripXAudioProcessor::createEditor() { return new ConsoleChannelStripXAudioProcessorEditor (*this); }

void ConsoleChannelStripXAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, destData);
}

void ConsoleChannelStripXAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType())) apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorValueTreeState::ParameterLayout ConsoleChannelStripXAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (f("inputGain","Input Gain",-20,20,0)); p.push_back (b("polarity","Polarity",false));
    p.push_back (b("hpOn","HP On",false)); p.push_back (f("hpFreq","HP Frequency",20,500,80,100));
    p.push_back (b("lpOn","LP On",false)); p.push_back (f("lpFreq","LP Frequency",3000,22000,22000,10000));
    p.push_back (b("eqOn","EQ On",true)); p.push_back (b("eSeries","E Character",false));
    p.push_back (b("lfBell","LF Bell",false)); p.push_back (f("lfFreq","LF Frequency",40,600,80,120)); p.push_back (f("lfGain","LF Gain",-16.5f,16.5f,0));
    p.push_back (f("lmfFreq","LMF Frequency",200,2000,500,700)); p.push_back (f("lmfGain","LMF Gain",-20,20,0)); p.push_back (f("lmfQ","LMF Q",0.5f,2.5f,1.0f));
    p.push_back (f("hmfFreq","HMF Frequency",600,7000,2500,2500)); p.push_back (f("hmfGain","HMF Gain",-20,20,0)); p.push_back (f("hmfQ","HMF Q",0.5f,2.5f,1.0f));
    p.push_back (b("hfBell","HF Bell",false)); p.push_back (f("hfFreq","HF Frequency",1500,22000,10000,8000)); p.push_back (f("hfGain","HF Gain",-20,20,0));
    p.push_back (b("dynOn","Dynamics On",true)); p.push_back (f("compThreshold","Comp Threshold",-20,10,0)); p.push_back (f("compRatio","Comp Ratio",1,20,1));
    p.push_back (f("compRelease","Comp Release",0.1f,4.0f,0.3f,0.8f)); p.push_back (b("compFast","Comp Fast",false)); p.push_back (b("compPeak","Comp Peak",false)); p.push_back (f("compMix","Comp Mix",0,1,1));
    p.push_back (f("gateThreshold","Gate Threshold",-30,10,-30)); p.push_back (f("gateRange","Gate Range",0,40,0)); p.push_back (f("gateHold","Gate Hold",0,4,0)); p.push_back (f("gateRelease","Gate Release",0.1f,4,0.3f,0.8f));
    p.push_back (b("gateFast","Gate Fast",false)); p.push_back (b("gateExpand","Gate Expand",false));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("routing","Routing", juce::StringArray {"FLT > EQ > DYN","EQ > FLT > DYN","DYN > EQ > FLT","FLT > DYN > EQ"}, 0));
    p.push_back (f("outputGain","Output Gain",-20,20,0)); p.push_back (b("bypass","Bypass",false));
    return { p.begin(), p.end() };
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new ConsoleChannelStripXAudioProcessor(); }
