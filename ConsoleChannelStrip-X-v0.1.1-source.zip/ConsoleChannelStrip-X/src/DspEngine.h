#pragma once
#include <JuceHeader.h>

class DspEngine
{
public:
    using IIR = juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>>;

    struct Params
    {
        float inputGainDb = 0.0f;
        bool polarity = false;
        bool hpOn = false;
        float hpFreq = 20.0f;
        bool lpOn = false;
        float lpFreq = 22000.0f;

        bool eqOn = true;
        bool eSeries = false;
        bool lfBell = false;
        float lfFreq = 80.0f;
        float lfGain = 0.0f;
        float lmfFreq = 500.0f;
        float lmfGain = 0.0f;
        float lmfQ = 1.0f;
        float hmfFreq = 2500.0f;
        float hmfGain = 0.0f;
        float hmfQ = 1.0f;
        bool hfBell = false;
        float hfFreq = 10000.0f;
        float hfGain = 0.0f;

        bool dynOn = true;
        float compThreshold = 0.0f;
        float compRatio = 1.0f;
        float compRelease = 0.3f;
        bool compFast = false;
        bool compPeak = false;
        float compMix = 1.0f;

        float gateThreshold = -30.0f;
        float gateRange = 0.0f;
        float gateHold = 0.0f;
        float gateRelease = 0.3f;
        bool gateFast = false;
        bool gateExpand = false;

        int routing = 0;
        float outputGainDb = 0.0f;
        bool bypass = false;
    };

    void prepare (double sampleRate, int maximumBlockSize, int numChannels);
    void reset();
    void process (juce::AudioBuffer<float>& buffer, const Params& p);

    float getCompressorGainReductionDb() const noexcept { return compMeterDb.load(); }
    float getGateGainReductionDb() const noexcept { return gateMeterDb.load(); }

private:
    void updateFilters (const Params& p);
    void processFilters (juce::AudioBuffer<float>& buffer, const Params& p);
    void processEQ (juce::AudioBuffer<float>& buffer, const Params& p);
    void processDynamics (juce::AudioBuffer<float>& buffer, const Params& p);
    static float softKneeGainReduction (float levelDb, float thresholdDb, float ratio, float kneeDb);

    double sr = 48000.0;
    IIR hp1, hp2, lp, lf, lmf, hmf, hf;
    juce::AudioBuffer<float> dryBuffer;

    float compGainDb = 0.0f;
    float rmsSquare = 0.0f;
    float gateGainDb = 0.0f;
    bool gateOpen = true;
    int holdSamplesRemaining = 0;

    std::atomic<float> compMeterDb { 0.0f };
    std::atomic<float> gateMeterDb { 0.0f };
};
