#include "DspEngine.h"

namespace
{
    inline float dbToGain (float db) { return juce::Decibels::decibelsToGain (db); }

    void runFilter (DspEngine::IIR& filter, juce::AudioBuffer<float>& buffer)
    {
        juce::dsp::AudioBlock<float> block (buffer);
        juce::dsp::ProcessContextReplacing<float> context (block);
        filter.process (context);
    }
}

void DspEngine::prepare (double sampleRate, int maximumBlockSize, int numChannels)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, static_cast<juce::uint32> (maximumBlockSize), static_cast<juce::uint32> (numChannels) };
    hp1.prepare (spec); hp2.prepare (spec); lp.prepare (spec);
    lf.prepare (spec); lmf.prepare (spec); hmf.prepare (spec); hf.prepare (spec);
    dryBuffer.setSize (numChannels, maximumBlockSize, false, false, true);
    reset();
}

void DspEngine::reset()
{
    hp1.reset(); hp2.reset(); lp.reset(); lf.reset(); lmf.reset(); hmf.reset(); hf.reset();
    compGainDb = 0.0f;
    rmsSquare = 0.0f;
    gateGainDb = 0.0f;
    gateOpen = true;
    holdSamplesRemaining = 0;
    compMeterDb.store (0.0f);
    gateMeterDb.store (0.0f);
}

void DspEngine::updateFilters (const Params& p)
{
    const auto nyquistSafe = static_cast<float> (0.45 * sr);
    const auto hpHz = juce::jlimit (20.0f, juce::jmin (500.0f, nyquistSafe), p.hpFreq);
    const auto lpHz = juce::jlimit (1000.0f, nyquistSafe, p.lpFreq);

    *hp1.state = *juce::dsp::IIR::Coefficients<float>::makeFirstOrderHighPass (sr, hpHz);
    *hp2.state = *juce::dsp::IIR::Coefficients<float>::makeHighPass (sr, hpHz, 1.0f);
    *lp.state  = *juce::dsp::IIR::Coefficients<float>::makeLowPass (sr, lpHz, 0.70710678f);

    const float eFactor = p.eSeries ? 1.0f : (0.72f + 0.28f * juce::jlimit (0.0f, 1.0f, std::abs (p.lmfGain) / 20.0f));
    const float shelfSlope = p.eSeries ? 0.82f : 0.62f;

    auto lfCoeffs = p.lfBell
        ? juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.lfFreq, 0.75f * eFactor, dbToGain (p.lfGain))
        : juce::dsp::IIR::Coefficients<float>::makeLowShelf (sr, p.lfFreq, shelfSlope, dbToGain (p.lfGain));
    *lf.state = *lfCoeffs;

    *lmf.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.lmfFreq,
        juce::jlimit (0.5f, 2.5f, p.lmfQ) * eFactor, dbToGain (p.lmfGain));

    *hmf.state = *juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.hmfFreq,
        juce::jlimit (0.5f, 2.5f, p.hmfQ) * eFactor, dbToGain (p.hmfGain));

    auto hfCoeffs = p.hfBell
        ? juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, p.hfFreq, 0.75f * eFactor, dbToGain (p.hfGain))
        : juce::dsp::IIR::Coefficients<float>::makeHighShelf (sr, p.hfFreq, shelfSlope, dbToGain (p.hfGain));
    *hf.state = *hfCoeffs;
}

void DspEngine::processFilters (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.hpOn) { runFilter (hp1, buffer); runFilter (hp2, buffer); }
    if (p.lpOn) runFilter (lp, buffer);
}

void DspEngine::processEQ (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.eqOn) return;
    runFilter (lf, buffer);
    runFilter (lmf, buffer);
    runFilter (hmf, buffer);
    runFilter (hf, buffer);
}

float DspEngine::softKneeGainReduction (float levelDb, float thresholdDb, float ratio, float kneeDb)
{
    if (ratio <= 1.0001f) return 0.0f;
    const float slope = 1.0f - 1.0f / ratio;
    const float x = levelDb - thresholdDb;
    if (kneeDb <= 0.0f) return x > 0.0f ? slope * x : 0.0f;
    const float half = 0.5f * kneeDb;
    if (x <= -half) return 0.0f;
    if (x >= half) return slope * x;
    const float t = x + half;
    return slope * t * t / (2.0f * kneeDb);
}

void DspEngine::processDynamics (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.dynOn) return;

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    dryBuffer.setSize (channels, samples, false, false, true);
    for (int ch = 0; ch < channels; ++ch)
        dryBuffer.copyFrom (ch, 0, buffer, ch, 0, samples);

    const float gateOpenThreshold = p.gateThreshold;
    const float hysteresis = 3.0f + juce::jlimit (0.0f, 5.0f, (-p.gateThreshold) * 0.10f);
    const float gateCloseThreshold = gateOpenThreshold - hysteresis;
    const int holdSamples = static_cast<int> (p.gateHold * sr);
    const float gateAttackSeconds = p.gateFast ? 0.0001f : 0.0015f;
    const float gateAttackCoeff = std::exp (-1.0f / static_cast<float> (gateAttackSeconds * sr));
    const float gateReleaseCoeff = std::exp (-1.0f / static_cast<float> (juce::jmax (0.01f, p.gateRelease) * sr));

    for (int i = 0; i < samples; ++i)
    {
        float peak = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            peak = juce::jmax (peak, std::abs (buffer.getSample (ch, i)));
        const float levelDb = juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -120.0f);

        if (p.gateRange > 0.01f)
        {
            if (! gateOpen && levelDb >= gateOpenThreshold)
            {
                gateOpen = true;
                holdSamplesRemaining = holdSamples;
            }
            else if (gateOpen)
            {
                if (levelDb >= gateOpenThreshold)
                    holdSamplesRemaining = holdSamples;
                else if (holdSamplesRemaining > 0)
                    --holdSamplesRemaining;
                else if (levelDb < gateCloseThreshold)
                    gateOpen = false;
            }

            float targetGateDb = 0.0f;
            if (! gateOpen)
            {
                if (p.gateExpand)
                    targetGateDb = -juce::jmin (p.gateRange, juce::jmax (0.0f, (gateOpenThreshold - levelDb) * 0.5f));
                else
                    targetGateDb = -p.gateRange;
            }

            const float c = targetGateDb > gateGainDb ? gateAttackCoeff : gateReleaseCoeff;
            gateGainDb = c * gateGainDb + (1.0f - c) * targetGateDb;
            const float gateGain = dbToGain (gateGainDb);
            for (int ch = 0; ch < channels; ++ch)
                buffer.setSample (ch, i, buffer.getSample (ch, i) * gateGain);
        }
        else
        {
            gateGainDb = 0.0f;
            gateOpen = true;
        }

        // Parallel compressor dry path is taken after the gate/expander, matching the
        // channel-strip idea that MIX only blends the compressor section.
        for (int ch = 0; ch < channels; ++ch)
            dryBuffer.setSample (ch, i, buffer.getSample (ch, i));

        peak = 0.0f;
        for (int ch = 0; ch < channels; ++ch)
            peak = juce::jmax (peak, std::abs (buffer.getSample (ch, i)));

        float detectorDb = -120.0f;
        if (p.compPeak)
        {
            detectorDb = juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -120.0f);
        }
        else
        {
            const float rmsCoeff = std::exp (-1.0f / static_cast<float> (0.010 * sr));
            rmsSquare = rmsCoeff * rmsSquare + (1.0f - rmsCoeff) * peak * peak;
            detectorDb = juce::Decibels::gainToDecibels (std::sqrt (juce::jmax (rmsSquare, 1.0e-18f)), -120.0f);
        }

        const float ratio = p.compRatio >= 19.95f ? 1000.0f : juce::jmax (1.0f, p.compRatio);
        const float targetGr = softKneeGainReduction (detectorDb, p.compThreshold, ratio, p.compPeak ? 0.0f : 6.0f);
        const float autoAttack = p.compFast ? 0.003f : juce::jlimit (0.003f, 0.030f, 0.030f - 0.00135f * targetGr);
        const float attackCoeff = std::exp (-1.0f / static_cast<float> (autoAttack * sr));
        const float releaseCoeff = std::exp (-1.0f / static_cast<float> (juce::jmax (0.05f, p.compRelease) * sr));
        const float targetGainDb = -targetGr;
        const float c = targetGainDb < compGainDb ? attackCoeff : releaseCoeff;
        compGainDb = c * compGainDb + (1.0f - c) * targetGainDb;

        const float makeupDb = (-juce::jmin (0.0f, p.compThreshold)) * (1.0f - 1.0f / ratio) * 0.50f;
        const float wetGain = dbToGain (compGainDb + makeupDb);
        const float mix = juce::jlimit (0.0f, 1.0f, p.compMix);
        for (int ch = 0; ch < channels; ++ch)
        {
            const float dry = dryBuffer.getSample (ch, i);
            const float wet = buffer.getSample (ch, i) * wetGain;
            buffer.setSample (ch, i, dry * (1.0f - mix) + wet * mix);
        }
    }

    compMeterDb.store (-compGainDb);
    gateMeterDb.store (-gateGainDb);
}

void DspEngine::process (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.bypass) return;

    const float inGain = dbToGain (p.inputGainDb) * (p.polarity ? -1.0f : 1.0f);
    buffer.applyGain (inGain);
    updateFilters (p);

    switch (p.routing)
    {
        case 1: processEQ (buffer, p); processFilters (buffer, p); processDynamics (buffer, p); break;
        case 2: processDynamics (buffer, p); processEQ (buffer, p); processFilters (buffer, p); break;
        case 3: processFilters (buffer, p); processDynamics (buffer, p); processEQ (buffer, p); break;
        default: processFilters (buffer, p); processEQ (buffer, p); processDynamics (buffer, p); break;
    }

    buffer.applyGain (dbToGain (p.outputGainDb));
}
