#include "PluginEditor.h"

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setSize (1200, 690);
    setResizable (true, true);
    setResizeLimits (1000, 600, 1600, 900);

    addKnob ("inputGain","INPUT"," dB"); addButton ("polarity","Ø");
    addButton ("hpOn","HP IN"); addKnob ("hpFreq","HP"," Hz"); addButton ("lpOn","LP IN"); addKnob ("lpFreq","LP"," Hz");
    addButton ("eqOn","EQ IN"); addButton ("eSeries","E MODE");
    addButton ("lfBell","LF BELL"); addKnob ("lfFreq","LF FREQ"," Hz"); addKnob ("lfGain","LF GAIN"," dB");
    addKnob ("lmfFreq","LMF FREQ"," Hz"); addKnob ("lmfGain","LMF GAIN"," dB"); addKnob ("lmfQ","LMF Q");
    addKnob ("hmfFreq","HMF FREQ"," Hz"); addKnob ("hmfGain","HMF GAIN"," dB"); addKnob ("hmfQ","HMF Q");
    addButton ("hfBell","HF BELL"); addKnob ("hfFreq","HF FREQ"," Hz"); addKnob ("hfGain","HF GAIN"," dB");
    addButton ("dynOn","DYN IN"); addKnob ("compThreshold","COMP THR"," dB"); addKnob ("compRatio","RATIO",":1"); addKnob ("compRelease","RELEASE"," s"); addKnob ("compMix","MIX"," %");
    addButton ("compFast","FAST"); addButton ("compPeak","PEAK");
    addKnob ("gateThreshold","GATE THR"," dB"); addKnob ("gateRange","RANGE"," dB"); addKnob ("gateHold","HOLD"," s"); addKnob ("gateRelease","G REL"," s");
    addButton ("gateFast","G FAST"); addButton ("gateExpand","EXPAND");
    addKnob ("outputGain","OUTPUT"," dB"); addButton ("bypass","BYPASS");

    routingBox.addItemList ({"FLT > EQ > DYN","EQ > FLT > DYN","DYN > EQ > FLT","FLT > DYN > EQ"}, 1);
    routingBox.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (routingBox);
    routingAttachment = std::make_unique<ComboAttachment> (processor.parameters(), "routing", routingBox);
    startTimerHz (30);
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label, const juce::String& suffix)
{
    auto s = std::make_unique<juce::Slider> (juce::Slider::RotaryHorizontalVerticalDrag, juce::Slider::TextBoxBelow);
    s->setName (label); s->setTextValueSuffix (suffix); s->setNumDecimalPlacesToDisplay (id.containsIgnoreCase("freq") ? 0 : 2);
    s->setColour (juce::Slider::rotarySliderFillColourId, juce::Colour (0xffd9aa36));
    s->setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colour (0xff2d3338));
    s->setColour (juce::Slider::thumbColourId, juce::Colour (0xfff3f4ee));
    addAndMakeVisible (*s);
    sliderAttachments.push_back (std::make_unique<SliderAttachment> (processor.parameters(), id, *s));
    knobs[id] = std::move (s);
}

void ConsoleChannelStripXAudioProcessorEditor::addButton (const juce::String& id, const juce::String& label)
{
    auto b = std::make_unique<juce::ToggleButton> (label);
    b->setColour (juce::ToggleButton::textColourId, juce::Colour (0xffe3e7df));
    b->setColour (juce::ToggleButton::tickColourId, juce::Colour (0xffd9aa36));
    addAndMakeVisible (*b);
    buttonAttachments.push_back (std::make_unique<ButtonAttachment> (processor.parameters(), id, *b));
    buttons[id] = std::move (b);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff111417));
    auto drawPanel = [&] (juce::Rectangle<int> r, juce::String title)
    {
        g.setColour (juce::Colour (0xff1b2024)); g.fillRoundedRectangle (r.toFloat(), 7.0f);
        g.setColour (juce::Colour (0xff3a4248)); g.drawRoundedRectangle (r.toFloat(), 7.0f, 1.0f);
        g.setColour (juce::Colour (0xffd9aa36)); g.setFont (juce::Font (15.0f, juce::Font::bold));
        g.drawText (title, r.removeFromTop (28), juce::Justification::centred);
    };

    drawPanel ({10,50,105,570}, "INPUT");
    drawPanel ({125,50,165,570}, "FILTERS");
    drawPanel ({300,50,500,570}, "4-BAND EQ");
    drawPanel ({810,50,275,570}, "DYNAMICS");
    drawPanel ({1095,50,95,570}, "OUTPUT");

    g.setColour (juce::Colour (0xfff1f2ed)); g.setFont (juce::Font (23.0f, juce::Font::bold));
    g.drawText ("CONSOLE CHANNEL STRIP X", 18, 8, 520, 34, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xff88939a)); g.setFont (12.0f);
    g.drawText ("clean-room console workflow • Intel x86_64 • VST3", 550, 14, 430, 22, juce::Justification::centredRight);

    const float comp = juce::jlimit (0.0f, 24.0f, processor.compressorMeter());
    const float gate = juce::jlimit (0.0f, 40.0f, processor.gateMeter());
    g.setColour (juce::Colour (0xff3c4246)); g.fillRect (1015, 250, 16, 160); g.fillRect (1045, 250, 16, 160);
    g.setColour (juce::Colour (0xffd9aa36)); g.fillRect (1015, 410 - static_cast<int> (160.0f * comp / 24.0f), 16, static_cast<int> (160.0f * comp / 24.0f));
    g.setColour (juce::Colour (0xff65b775)); g.fillRect (1045, 410 - static_cast<int> (160.0f * gate / 40.0f), 16, static_cast<int> (160.0f * gate / 40.0f));
    g.setColour (juce::Colour (0xffc7ccc8)); g.setFont (10.0f); g.drawText ("COMP",1002,415,42,18,juce::Justification::centred); g.drawText ("GATE",1033,415,42,18,juce::Justification::centred);

    g.setColour (juce::Colour (0xff8e999f)); g.drawText ("ROUTING", 430, 635, 90, 24, juce::Justification::centredRight);
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h) { if (auto it=knobs.find(id); it!=knobs.end()) it->second->setBounds (x,y,w,h); }
void ConsoleChannelStripXAudioProcessorEditor::placeButton (const juce::String& id, int x, int y, int w, int h) { if (auto it=buttons.find(id); it!=buttons.end()) it->second->setBounds (x,y,w,h); }

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    placeKnob("inputGain",22,90); placeButton("polarity",22,195,75); placeButton("bypass",22,560,75);
    placeButton("hpOn",145,90,110); placeKnob("hpFreq",165,125,86,92); placeButton("lpOn",145,245,110); placeKnob("lpFreq",165,280,86,92);
    placeButton("eqOn",320,82,90); placeButton("eSeries",690,82,90);
    placeButton("lfBell",320,120,80); placeKnob("lfFreq",318,155); placeKnob("lfGain",318,260);
    placeKnob("lmfFreq",430,155); placeKnob("lmfGain",430,260); placeKnob("lmfQ",430,365);
    placeKnob("hmfFreq",545,155); placeKnob("hmfGain",545,260); placeKnob("hmfQ",545,365);
    placeButton("hfBell",680,120,80); placeKnob("hfFreq",675,155); placeKnob("hfGain",675,260);
    placeButton("dynOn",825,82,90); placeButton("compFast",920,82,70); placeButton("compPeak",995,82,70);
    placeKnob("compThreshold",825,125,82,92); placeKnob("compRatio",915,125,82,92); placeKnob("compRelease",825,225,82,92); placeKnob("compMix",915,225,82,92);
    placeButton("gateFast",825,330,80); placeButton("gateExpand",915,330,82); placeKnob("gateThreshold",825,365,82,92); placeKnob("gateRange",915,365,82,92); placeKnob("gateHold",825,465,82,92); placeKnob("gateRelease",915,465,82,92);
    placeKnob("outputGain",1102,110,82,92);
    routingBox.setBounds (525,635,260,26);
}
