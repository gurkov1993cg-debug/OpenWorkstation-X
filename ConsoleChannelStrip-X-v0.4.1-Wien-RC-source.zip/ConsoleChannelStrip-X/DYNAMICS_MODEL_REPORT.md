# 4000 E style channel dynamics — circuit-domain implementation report

This file documents the implementation that is actually compiled into `Console Channel Strip X`.
It is **not** presented as an original SSL 4000 E schematic. We do not possess that schematic.
Documented 4000 E operating behaviour is used as the fitting target; the THAT 2252 family data is used only where explicitly marked.

## 1. Block diagram of the control path

Audio input L/R
→ square each channel
→ sum mean-square energy
→ detector averaging capacitor `Cdet` charged by detector timing current `Idet`
→ RMS/log conversion to detector control voltage `Vdet` at `6.1 mV/dB`
→ split the **same `Vdet`** into two branches:

**Compressor branch**
`Vdet - Vthreshold`
→ exponential diode transition (`n`, `Vt`, drive gain `A`)
→ ratio divider (`Rt`, `Rb`)
→ target reduction control voltage
→ diode-steered timing network:
normal attack = `RattackSlow` in parallel with a transient series `Ckick/Rkick` branch
plus reservoir `Rreservoir/Creservoir`;
F.ATK = `RattackFast` directly charging `Cmain`;
release = `Rrelease` with reservoir reconnected
→ compressor reduction voltage `Vc`.

**Gate/expander branch**
`Vdet` → threshold comparator
→ hold node `Rhold/Chold`
→ EXPAND fixed resistor network or hard range clamp
→ gate timing network `R/C + reservoir`
→ gate reduction voltage `Vg`.

Then:
`Vc + Vg - Vmakeup`
→ **one** dB-linear VCA control node
→ audio output.

Automatic make-up path:
threshold control voltage + ratio divider output
→ make-up divider `RmTop/RmBottom`
→ `Vmakeup` summed with opposite polarity at the same VCA control node.

## 2. Component table

| Quantity | Value | Label | Source / fitting target |
|---|---:|---|---|
| Detector/VCA scale | 6.1 mV/dB | [SPEC] | THAT 2252 family datum supplied for this project; **not claimed as a 4000 E channel part value** |
| Detector law | `tau = 0.0259 * Cdet / Idet` | [SPEC] | THAT 2252 family datum supplied for this project |
| `Cdet` | 10 nF | [CHOICE] | convenient detector timing capacitor |
| `Idet` | 25.9 nA | [FIT] | gives 10.0 ms detector averaging from the supplied law |
| diode thermal voltage `Vt` | 25.85 mV | [SPEC] | room-temperature semiconductor physics |
| diode ideality `n` | 1.8 | [FIT] | soft transition; sensitivity test proves it changes the transfer |
| diode drive gain `A` | 2.55 | [FIT] | soft-knee target; no claim of SSL resistor values |
| ratio top resistor `Rt` | 10 kΩ | [CHOICE] | convenient fixed leg |
| ratio bottom `Rb` | 0 Ω … 10 MΩ | [FIT] | selected from panel ratio using `(Rt+Rb)/Rt`; 10 MΩ approximates limiter end |
| compressor `Cmain` | 1.0 µF | [CHOICE] | timing reference capacitor |
| normal attack `Rslow` | 43.2 kΩ | [FIT] | sustained deep-step attack near 30 ms |
| F.ATK resistor | 2.90 kΩ | [FIT] | measured ~2.98 ms to 20 dB including detector |
| transient bypass `Ckick` | 0.47 µF | [FIT] | edge-sensitive normal-attack current |
| transient bypass `Rkick` | 4.32 kΩ | [FIT] | limits kick current |
| transient bleed | 100 kΩ | [CHOICE] | resets the bypass capacitor between events |
| compressor reservoir `Cres` | 22 µF | [FIT] | program memory |
| compressor reservoir `Rres` | 100 kΩ | [FIT] | sets charge exchange with timing node |
| compressor release `Rrelease` | 100 kΩ … 4 MΩ | [FIT] | RELEASE panel 0.1…4 s against `Cmain=1 µF` |
| make-up divider top | 11.7 kΩ | [FIT] | tap ~0.461 |
| make-up divider bottom | 10 kΩ | [FIT] | threshold/ratio-dependent automatic make-up |
| gate main capacitor | 0.47 µF | [CHOICE] | gate timing node |
| gate reservoir capacitor | 2.2 µF | [FIT] | program-dependent opening/closing |
| gate normal attack resistor | 2.2 kΩ | [FIT] | normal opening with reservoir loading |
| gate FAST resistor | 1.0 kΩ | [FIT] | fast opening target near 1 ms |
| gate release resistor | panel mapped | [FIT] | 0.1…4 s panel target through `R*C` |
| hold capacitor | 1.0 µF | [CHOICE] | hold storage node |
| hold resistor | panel mapped | [FIT] | HOLD control; comparator is at `e^-1`, so measured hold equals `Rhold*Chold` |
| expander resistors | 10 kΩ / 10 kΩ | [CHOICE] | unity reduction slope, giving fixed 1:2 downward expansion |

## 3. Equations

### Shared RMS/log detector

Mean-square input energy:

`P(t) = (1/N) * Σ x_ch(t)^2`

Detector averaging target:

`tau_det = 0.0259 * Cdet / Idet`

After averaging:

`L_dB = 10 log10(Pavg)`

`Vdet = S * L_dB`, where `S = 0.0061 V/dB`.

Stereo channels are combined as energy, not as `L+R` audio, so opposite-polarity channels cannot disappear from the detector.

### Diode soft knee

Let `x = Vdet - Vthreshold` and

`Vs = n * Vt / A`.

The diode transition is represented by the exponential conduction integral:

`Vsoft = Vs * ln(1 + exp(x / Vs))`.

Doubling diode ideality `n` therefore broadens the **measured transfer transition**, and the regression test measures that change from the actual gain-computer function.

### Ratio divider

`k = Rb / (Rt + Rb)`

Compressor target reduction voltage:

`Vgr,target = k * Vsoft`

Asymptotic compression ratio:

`ratio = 1 / (1-k) = (Rt + Rb) / Rt`.

There is no ratio constant in the dynamics engine; changing `Rb` changes the audio slope.

### Automatic make-up

Make-up divider tap:

`m = RmBottom / (RmTop + RmBottom)`

`Vmakeup = max(0, -Vthreshold) * k * m`.

This voltage exists whether or not instantaneous gain reduction is occurring. That intentionally preserves the documented behaviour in which lowering threshold can raise a programme that is still below threshold.

### Compressor timing network

All timing acts on the dB-linear reduction control voltage.

Sustained normal attack uses:

`target → Rslow → Cmain`

with reservoir coupling:

`Cmain node ↔ Rres ↔ Cres → ground`.

A rapid control-voltage edge additionally drives a **real series capacitor/resistor branch**:

`target → Ckick → Rkick → Cmain node`.

The series capacitor charges and stops supplying DC current; therefore a sharp edge receives more early current than a slow rise without an `attackMs` parameter.

F.ATK diode steering bypasses the normal path and selects `Rfast` directly into `Cmain`.

On release the source resistor is `Rrelease`; `Rres/Cres` remains connected. A long passage charges `Cres` more deeply and therefore produces a longer measured tail.

### Gate / expander

EXPAND deficit voltage:

`Vdeficit = max(0, VgateThreshold - Vdet)`

With equal expander resistors:

`Vg,target = min(Vrange, Vdeficit)`.

Thus 10 dB below threshold produces 10 dB additional attenuation and a 20 dB output drop relative to the threshold point: fixed 1:2 downward expansion.

Hold storage:

`Vhold(t) = exp(-t / (Rhold * Chold))`.

The comparator trips at `e^-1`, so the measured hold interval is `Rhold*Chold`.

### One VCA

`Vcontrol = Vc + Vg - Vmakeup`

Because detector and VCA use the same `S` volts-per-dB scale:

`G_dB = -Vcontrol / S`

`gain = 10^(G_dB/20)`.

This is applied once to the audio after compressor and gate control voltages are summed.

## 4. Discretisation

The two-capacitor timing networks are solved with **backward Euler** as a nodal conductance system once per sample. Positive R/C values produce a passive linear RC system, and backward Euler is unconditionally stable and monotonic for these branches.

The transient series-C/R branch is also discretised from its capacitor current equation; its capacitor history voltage is part of the state and its bleed is an actual `R*C` discharge.

Detector and hold one-poles use the exact exponential form `exp(-1/(tau*fs))`.

Stress testing at 44.1, 48, 96 and 192 kHz reports no NaN/Inf with full-scale square/impulse excitation.

## 5. Measurement / fitting report

Local circuit regression, using the same `SslDynamicsCircuit.cpp` compiled into the plug-in:

- F.ATK deep-step attack to 20 dB with the normal detector: **~2.98 ms**; target ≈3 ms.
- Normal deep-step attack to 20 dB: **~29.69 ms**; target upper programme-dependent region ≈30 ms.
- T1 timing-cap sensitivity at 192 kHz with detector made negligible for the timing measurement: **2.010 ms → 2.214 ms** for +10% `Cmain`, **+10.10%**.
- T1 diode sensitivity: measured 10–90% transition **13.15 dB → 26.29 dB** when `n` is doubled, **2.00×**.
- Divider ratios: 2:1, 4:1, 10:1 measured from the complete detector/VCA audio law with errors below **0.001%**.
- T3 release memory at the default release network, to 1 dB remaining GR: 5 ms strong burst **0.370 s**; 1 s strong passage **0.500 s**.
- T4 first 5 ms normal attack: abrupt edge **14.58 dB GR**; slow ramp to same final level **8.96 dB GR**.
- T5 hold: `Rhold*Chold = 0.250 s`; measured close start **0.250 s**.
- T6 EXPAND at 10 dB below threshold: **10.0 dB additional reduction**, output point **20 dB below threshold point**.
- T7 automatic make-up on a far-below-threshold signal, 4:1 divider: threshold 0 dB → **0.00 dB** make-up; threshold -20 dB → **+6.91 dB**.
- T8: finite control/output values at **44.1/48/96/192 kHz**.

These are fitting measurements, not claims that the listed [FIT]/[CHOICE] values are SSL factory component values.

## 6. Sound report

- Energy-linked RMS detection: a wide snare or anti-phase stereo ambience still compresses instead of unexpectedly escaping because L and R cancel in a summed sidechain.
- Soft diode knee: vocal phrases enter compression gradually, without a hard edge when syllables cross threshold.
- Divider-derived ratio: at 2:1 a vocal remains mobile; toward limiter resistance the front of a snare or bus hit becomes progressively more pinned without a separate mathematical ratio law.
- F.ATK resistor bypass: snare attacks are caught immediately and lose more leading-edge bite; on vocals consonants are controlled more aggressively.
- Normal transient C/R bypass plus slow resistor: a sharp drum edge receives quick initial control, while a slower vocal swell is allowed to rise further before sustained reduction settles.
- Reservoir branch: a long loud phrase leaves more charge and releases more slowly than a short hit, so buses breathe with programme history rather than returning with one fixed envelope.
- Automatic make-up divider: lowering threshold can make even quieter vocal material appear louder before obvious gain reduction, which is the intended console-style interaction rather than an error.
- One shared VCA: gate closure and compression do not sound like two cascaded gain stages; their control actions meet at one attenuation element.

## 7. What is not justified yet

1. The resistor/capacitor values above are **not known SSL 4000 E channel component values**. They are [FIT]/[CHOICE] values fitted to the documented behavioural targets.
2. The 6.1 mV/dB detector scale and `0.0259*C/I` detector law are sourced from the THAT 2252 family, not proven to be the exact detector used in the 4000 E channel.
3. A distinct documented electrical difference between **GATE 1** and **GATE 2** was not supplied. The current plug-in keeps EXPAND plus one hard-gate behaviour; inventing a second gate circuit would violate the no-invented-schematic rule.
4. Exact automatic make-up resistor values of the console are not known. The 11.7 kΩ / 10 kΩ divider is [FIT] and must be replaced if a primary schematic or reliable bench measurement becomes available.
5. For tighter calibration, the most valuable external measurements would be: threshold-vs-output static curves at several ratios, 20 dB attack traces for transient and slow-ramp inputs, release traces after short and long bursts, and below-threshold output level versus threshold for the original channel.
