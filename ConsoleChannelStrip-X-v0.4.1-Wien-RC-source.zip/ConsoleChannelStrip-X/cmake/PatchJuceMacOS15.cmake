if(NOT DEFINED JUCE_WINDOWING_FILE OR NOT EXISTS "${JUCE_WINDOWING_FILE}")
    message(FATAL_ERROR "JUCE windowing file not found: ${JUCE_WINDOWING_FILE}")
endif()

file(READ "${JUCE_WINDOWING_FILE}" JUCE_WINDOWING_SOURCE)

set(START_NEEDLE [=[
static Image createNSWindowSnapshot (NSWindow* nsWindow)
{
    JUCE_AUTORELEASEPOOL
    {
]=])

set(START_REPLACEMENT [=[
static Image createNSWindowSnapshot (NSWindow* nsWindow)
{
    JUCE_AUTORELEASEPOOL
    {
       // CGWindowListCreateImage is marked unavailable by the macOS 15 SDK.
       // The Console Channel Strip plug-in never needs native-window snapshots,
       // so disable only this optional helper when building with that SDK.
       #if defined (MAC_OS_VERSION_15_0) && MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_VERSION_15_0
        (void) nsWindow;
        return {};
       #else
]=])

set(END_NEEDLE [=[
        return result;
    }
}

Image createSnapshotOfNativeWindow (void* nativeWindowHandle)
]=])

set(END_REPLACEMENT [=[
        return result;
       #endif
    }
}

Image createSnapshotOfNativeWindow (void* nativeWindowHandle)
]=])

string(FIND "${JUCE_WINDOWING_SOURCE}" "${START_REPLACEMENT}" ALREADY_PATCHED)
if(NOT ALREADY_PATCHED EQUAL -1)
    message(STATUS "JUCE macOS 15 compatibility patch already applied")
    return()
endif()

string(FIND "${JUCE_WINDOWING_SOURCE}" "${START_NEEDLE}" START_POS)
string(FIND "${JUCE_WINDOWING_SOURCE}" "${END_NEEDLE}" END_POS)
if(START_POS EQUAL -1 OR END_POS EQUAL -1)
    message(FATAL_ERROR "JUCE 7.0.12 window snapshot function did not match the expected source")
endif()

string(REPLACE "${START_NEEDLE}" "${START_REPLACEMENT}" JUCE_WINDOWING_SOURCE "${JUCE_WINDOWING_SOURCE}")
string(REPLACE "${END_NEEDLE}" "${END_REPLACEMENT}" JUCE_WINDOWING_SOURCE "${JUCE_WINDOWING_SOURCE}")
file(WRITE "${JUCE_WINDOWING_FILE}" "${JUCE_WINDOWING_SOURCE}")
message(STATUS "Applied JUCE 7 macOS 15 SDK compatibility patch")
