# Console Channel Strip X v0.4.1 - E-series EQ model report

## Source drawings used

- SSL 82E02 Brown EQ: drawing `T82002-71`, Rev.5 (3/84)
  - https://www.ka-electronics.com/images/SSL/ssl_82E02.pdf
- SSL 82E242 Black EQ: drawing `T82242-70`
  - https://www.ka-electronics.com/images/SSL/ssl_82E242.pdf
- SSL 82E242 Rev.4 engineering-change note, 15-Nov-1985
  - https://www.ka-electronics.com/images/SSL/ssl_82E242_eco.pdf

Supporting historical/technical context used to avoid modelling the E EQ as a passive Wien network:

- Recycled Audio SSL EQ technical notes: Brown/Black are the E-family EQ, with Black refinements and steeper HPF.
- GroupDIY / SSLtech historical discussion: the 02/242 EQ is the classic E constant-bandwidth family; 242 primarily adds filter switching / third HPF pole.
- Pro Audio Design Forum discussion identifies the 82E02 equaliser as an active state-variable-style circuit in which the dual Q control sets Q and gain compensation.

## What is now taken directly from the schematics

`SslEseriesEqModel.cpp` stores drawing-derived frequency-network parts for both Brown and Black revisions.

Examples:

| Revision | Band | Fixed R | Freq pot | Main timing C | Drawing refs |
|---|---:|---:|---:|---:|---|
| 82E02 | HMF | 4.3 kOhm | 50 kOhm dual | 4.7 nF | R18, C9/C10 |
| 82E02 | LMF | 4.3 kOhm | 50 kOhm dual | 15 nF | R28, C12/C13 |
| 82E02 | HF | 4.3 kOhm | 50 kOhm dual | 2.2 nF | R4, C3/C5 |
| 82E02 | LF | 4.3 kOhm | 50 kOhm dual | 33 nF + 47 nF | R42, C16-C19 |
| 82E242 | HMF | 3.0 kOhm | 50 kOhm dual | 4.7 nF | R18, C9/C10 |
| 82E242 | LMF | 3.0 kOhm | 50 kOhm dual | 22 nF | R28, C12/C13 |
| 82E242 | HF | 3.0 kOhm | 50 kOhm dual | 2.2 nF | R4, C3/C5 |
| 82E242 | LF | 4.3 kOhm | 50 kOhm dual | 33 nF + 47 nF | R42, C16-C19 |

The Black Rev.4 ECO is also used for the documented fixed bell Q values: HF = 1.0, LF = 1.7.

## Transfer model

The old `WienEqModel` is no longer the preferred EQ path. The new path uses:

1. the actual drawing RC timing network to solve the equivalent frequency-control resistance;
2. a reciprocal constant-bandwidth second-order transfer for the variable-Q HMF/LMF bands;
3. a separate fixed-network-Q LF/HF bell transfer, so bell bandwidth widens with boost rather than being forced to constant effective Q;
4. second-order reciprocal LF/HF shelves with independent LF/HF damping Q, currently set to the accepted Wien shelf value `1.2315606122497924`;
5. bilinear transform with center/corner prewarping;
6. coefficient finite/stability validation before the coefficients can reach the project-owned runtime biquad.

The old model's passive equal-R/equal-C Q floor is intentionally removed from the variable-Q mid bands because the published E circuit is an active feedback equaliser, not the passive network that the previous approximation assumed. LF/HF bell mode is treated separately: its fixed component damping is preserved as network Q rather than rescaled to enforce constant audible Q.

## Safety / rollback

The previous working `WienEqModel.cpp/.h` files are preserved byte-for-byte.

For every band, `DspEngine` also calculates the old coefficient set. If a new schematic-derived coefficient set is non-finite or unstable, that band automatically receives the old coefficient set instead.

A complete rollback build can be forced with:

`CONSOLE_EQ_FORCE_LEGACY_WIEN`

No GUI parameter IDs, automation IDs, dynamics, saturation, routing or approved GUI geometry were changed for this EQ revision.

## Verification performed before packaging

A pure-C++ standalone sweep checked Brown and Black schematic EQ coefficients at 44.1, 48, 96 and 192 kHz across the current legal plug-in frequency/gain ranges. Tested coefficients remained finite and strictly stable; the worst pole radius observed was below 1.0.

The JUCE smoke-test source was extended so GitHub CI will additionally verify:

- schematic RC endpoint sanity;
- new EQ pole stability;
- second-order shelf corner/shoulder calibration and agreement with the accepted Wien shelf voicing;
- direct agreement between `DspEngine` and `SslEseriesEqModel` so the new path cannot silently fall back all the time;
- all previous Wien tests, to keep the rollback model working.

## Deliberate limit of the claim

This is a schematic-grounded linear EQ transfer model. It is **not** claimed to be a complete SPICE/MNA clone of every NE5534, trimmer tolerance, PCB parasitic, centre-tapped pot imperfection or overload mechanism of one specific physical SSL console. Those would require verified hardware measurements or a fully validated netlist/calibration dataset.
