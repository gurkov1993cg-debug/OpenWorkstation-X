#include "DspEngine.h"
#include "WienEqModel.h"
#include "DynamicsCircuitTests.h"
#include <juce_audio_basics/juce_audio_basics.h>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <vector>

namespace
{
    constexpr double sampleRate = 48000.0;

    float dbGain (float db) { return juce::Decibels::decibelsToGain (db); }

    float rms (const std::vector<float>& v, size_t begin = 0)
    {
        if (begin >= v.size()) return 0.0f;
        double sum = 0.0;
        for (size_t i = begin; i < v.size(); ++i) sum += (double) v[i] * v[i];
        return (float) std::sqrt (sum / (double) (v.size() - begin));
    }

    float differenceRms (const std::vector<float>& a, const std::vector<float>& b)
    {
        const size_t n = juce::jmin (a.size(), b.size());
        if (n == 0) return 0.0f;
        double sum = 0.0;
        for (size_t i = 0; i < n; ++i)
        {
            const double d = (double) a[i] - b[i];
            sum += d * d;
        }
        return (float) std::sqrt (sum / (double) n);
    }

    std::vector<float> makeSine (float frequency, float amplitude, int samples)
    {
        std::vector<float> out ((size_t) samples);
        for (int i = 0; i < samples; ++i)
            out[(size_t) i] = amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                    * frequency * (float) i / (float) sampleRate);
        return out;
    }

    std::vector<float> render (const DspEngine::Params& params, const std::vector<float>& input,
                               int blockSize = 512)
    {
        DspEngine engine;
        engine.prepare (sampleRate, juce::jmax (1, blockSize), 1);
        std::vector<float> output (input.size());
        int offset = 0;
        while (offset < (int) input.size())
        {
            const int n = juce::jmin (blockSize, (int) input.size() - offset);
            juce::AudioBuffer<float> block (1, n);
            for (int i = 0; i < n; ++i) block.setSample (0, i, input[(size_t) (offset + i)]);
            engine.process (block, params);
            for (int i = 0; i < n; ++i) output[(size_t) (offset + i)] = block.getSample (0, i);
            offset += n;
        }
        return output;
    }

    float steadyGainDb (DspEngine::Params p, float frequency, float amplitude = 0.05f)
    {
        const int samples = (int) sampleRate;
        auto input = makeSine (frequency, amplitude, samples);
        auto output = render (p, input, 256);
        const size_t begin = output.size() / 2;
        const float inRms = rms (input, begin);
        const float outRms = rms (output, begin);
        return juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms), -120.0f);
    }

    bool finiteVector (const std::vector<float>& v)
    {
        for (float x : v) if (! std::isfinite (x)) return false;
        return true;
    }

    void setCompressor (DspEngine::Params& p, bool enabled, float thresholdDb, float ratio,
                        float releaseSeconds = 0.30f, bool fast = false)
    {
        auto& c = p.dynamicsCircuit;
        c.compressorEnabled = enabled;
        c.compressorFastAttack = fast;
        c.compressorThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        // Keep the panel-setting CV in step with the threshold used by this test helper.
        // Auto make-up is intentionally derived from the panel threshold, while the
        // detector threshold may carry a separate dBFS calibration in PluginProcessor.
        c.compressorPanelThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = ratio >= 19.95f ? 10.0e6 : c.gainDivider.topOhm * std::max (0.0f, ratio - 1.0f);
        c.compressorTiming.releaseResistorOhm = releaseSeconds / c.compressorTiming.mainCapF;
    }

    void setGate (DspEngine::Params& p, bool enabled, bool expand, float thresholdDb, float rangeDb,
                  float holdSeconds, float releaseSeconds, bool fast = false)
    {
        auto& c = p.dynamicsCircuit;
        c.gateEnabled = enabled;
        c.gateExpandMode = expand;
        c.gateFastAttack = fast;
        c.gateThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        c.gateRangeCvV = rangeDb * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = std::max (1.0, (double) holdSeconds / c.gate.holdCapF);
        c.gate.releaseResistorOhm = std::max (1.0, (double) releaseSeconds / c.gate.mainCapF);
    }
}

int main()
{
    bool ok = true;
    if (! runDynamicsCircuitRegression())
        ok = false;

    // a) MUTE must remain absolute silence for all dry/wet positions.
    for (float mix : { 0.0f, 0.5f, 1.0f })
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.mix = mix; p.mute = true;
        const auto input = makeSine (1000.0f, 0.5f, 8192);
        const auto out = render (p, input);
        if (rms (out) > 1.0e-8f)
        {
            std::cerr << "FAIL: MUTE leaks at mix=" << mix << "\n";
            ok = false;
        }
    }
    if (ok) std::cout << "PASS: MUTE is post-mix silence\n";

    // Factory defaults must be insert-safe: no level lift, no compression, no gate.
    {
        DspEngine::Params p;
        const auto input = makeSine (997.0f, dbGain (-12.0f), 48000);
        const auto out = render (p, input, 256);
        const size_t begin = out.size() / 2;
        const float gainDb = juce::Decibels::gainToDecibels (
            rms (out, begin) / juce::jmax (1.0e-12f, rms (input, begin)), -120.0f);
        if (std::abs (gainDb) > 0.01f)
        {
            std::cerr << "FAIL: factory default is not unity, gain=" << gainDb << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: factory default is unity / insert-safe\n";
    }

    // b) Neutral Black path should be essentially transparent at nominal level.
    {
        DspEngine::Params p;
        p.eqOn = false; p.blackEq = true; p.dynOn = false;
        p.inputDrive = 0.0f; p.inputMode = 0; p.vcaFaderDb = 0.0f; p.outputTrimDb = 0.0f; p.mix = 1.0f;
        const auto input = makeSine (1000.0f, dbGain (-12.0f), 32768);
        const auto out = render (p, input);
        const float inRms = rms (input), outRms = rms (out);
        const float levelErrorDb = juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms));

        double dot = 0.0, energy = 0.0;
        for (size_t i = 0; i < input.size(); ++i)
        {
            dot += (double) out[i] * input[i];
            energy += (double) input[i] * input[i];
        }
        const float scale = energy > 0.0 ? (float) (dot / energy) : 1.0f;
        std::vector<float> scaled (input.size());
        for (size_t i = 0; i < input.size(); ++i) scaled[i] = input[i] * scale;
        const float residual = differenceRms (out, scaled);
        const float thdPercent = 100.0f * residual / juce::jmax (1.0e-12f, rms (scaled));

        if (std::abs (levelErrorDb) > 0.01f || thdPercent > 0.05f)
        {
            std::cerr << "FAIL: neutral path levelError=" << levelErrorDb << " dB, residual=" << thdPercent << "%\n";
            ok = false;
        }
        else std::cout << "PASS: neutral path level/THD\n";
    }

    // INPUT DRIVE must have a real clean centre and a clearly audible positive range.
    {
        DspEngine::Params clean, driven;
        clean.eqOn = driven.eqOn = false;
        clean.dynOn = driven.dynOn = false;
        clean.inputMode = driven.inputMode = 0;
        clean.inputDrive = 0.0f;
        driven.inputDrive = 12.0f;

        const auto input = makeSine (997.0f, dbGain (-18.0f), 32768);
        const auto cleanOut = render (clean, input);
        const auto drivenOut = render (driven, input);

        const float cleanNull = differenceRms (cleanOut, input);
        const float driveDifference = differenceRms (drivenOut, input);
        const float driveLevel = juce::Decibels::gainToDecibels (
            rms (drivenOut, drivenOut.size() / 2) / juce::jmax (1.0e-12f, rms (input, input.size() / 2)));

        if (cleanNull > 1.0e-7f || driveDifference < 0.01f || driveLevel < 2.0f)
        {
            std::cerr << "FAIL: INPUT DRIVE cleanNull=" << cleanNull
                      << " diff=" << driveDifference << " level=" << driveLevel << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: INPUT DRIVE has clean 0 dB and audible positive drive\n";
    }

    // Mix=0 must be the generator itself, not a second processed reference render.
    {
        DspEngine::Params p;
        p.inputDrive = 20.0f; p.eqOn = true; p.lfGain = 12.0f; p.dynOn = true;
        setCompressor (p, true, -20.0f, 4.0f); p.vcaFaderDb = 10.0f; p.mix = 0.0f;
        const auto input = makeSine (777.0f, 0.2f, 16384);
        const auto out = render (p, input);
        if (differenceRms (out, input) > 1.0e-7f)
        {
            std::cerr << "FAIL: Mix 0 is not dry/null-safe\n";
            ok = false;
        }
        else std::cout << "PASS: Mix 0 returns raw input\n";
    }

    // c) EXPAND must be 1:2: 10 dB below threshold -> about 10 dB extra reduction.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = true;
        setCompressor (p, false, -20.0f, 4.0f);
        setGate (p, true, true, -20.0f, 40.0f, 0.0f, 0.1f);

        // Sine RMS is peak - 3.01 dB, so -27 dBFS peak is approximately -30 dBFS RMS.
        const auto input = makeSine (1000.0f, dbGain (-27.0f), (int) (sampleRate * 2.0));
        int offset = 0;
        while (offset < (int) input.size())
        {
            const int n = juce::jmin (512, (int) input.size() - offset);
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i) b.setSample (0, i, input[(size_t) (offset + i)]);
            engine.process (b, p);
            offset += n;
        }
        const float gr = engine.getGateGainReductionDb();
        if (gr < 9.0f || gr > 11.5f)
        {
            std::cerr << "FAIL: expander 1:2 reduction=" << gr << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: expander 1:2 reduction=" << gr << " dB\n";
    }

    // d) HOLD must keep the gate open, then allow release after the hold interval.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = true;
        setCompressor (p, false, -20.0f, 4.0f);
        setGate (p, true, false, -20.0f, 40.0f, 0.5f, 0.1f);

        auto processSignal = [&] (float amplitude, float seconds)
        {
            int remaining = (int) std::round (seconds * sampleRate);
            int phase = 0;
            while (remaining > 0)
            {
                const int n = juce::jmin (512, remaining);
                juce::AudioBuffer<float> b (1, n);
                for (int i = 0; i < n; ++i)
                    b.setSample (0, i, amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                             * 1000.0f * (float) (phase + i) / (float) sampleRate));
                engine.process (b, p);
                remaining -= n;
                phase += n;
            }
        };

        processSignal (dbGain (-6.0f), 0.20f);
        processSignal (dbGain (-37.0f), 0.40f);
        const float beforeHoldEnds = engine.getGateGainReductionDb();
        processSignal (dbGain (-37.0f), 0.70f);
        const float afterHoldEnds = engine.getGateGainReductionDb();
        if (beforeHoldEnds > 1.0f || afterHoldEnds < 20.0f)
        {
            std::cerr << "FAIL: gate HOLD before=" << beforeHoldEnds << " after=" << afterHoldEnds << "\n";
            ok = false;
        }
        else std::cout << "PASS: gate HOLD/release timing\n";
    }

    // e) Program-dependent compressor attack: an abrupt transient must pull more GR
    // in the first 5 ms than a ramp reaching the same final level.
    {
        const int n = (int) std::round (sampleRate * 0.005);
        auto measure = [&] (bool ramp)
        {
            DspEngine engine;
            engine.prepare (sampleRate, n, 1);
            DspEngine::Params p;
            p.eqOn = false; p.dynOn = true;
            setGate (p, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
            setCompressor (p, true, -20.0f, 10.0f, 0.3f, false);
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i)
            {
                const float env = ramp ? (float) i / (float) juce::jmax (1, n - 1) : 1.0f;
                b.setSample (0, i, 0.9f * env * std::sin ((float) juce::MathConstants<double>::twoPi
                                                          * 1000.0f * (float) i / (float) sampleRate));
            }
            engine.process (b, p);
            return engine.getCompressorGainReductionDb();
        };

        const float abrupt = measure (false);
        const float ramped = measure (true);
        if (! (abrupt > ramped + 0.05f))
        {
            std::cerr << "FAIL: program attack abrupt=" << abrupt << " ramp=" << ramped << "\n";
            ok = false;
        }
        else std::cout << "PASS: program-dependent compressor attack\n";
    }

    // f) Shelf character: strong LF/HF boosts plus the opposite-sign broad dip
    // should create full shelf lift and a restrained shoulder around the transition.
    {
        DspEngine::Params lf;
        lf.dynOn = false; lf.blackEq = true; lf.eqOn = true; lf.lfBell = false;
        lf.lfGain = 12.0f; lf.lfFreq = 80.0f;
        const float low = steadyGainDb (lf, 35.0f);
        const float shoulder = steadyGainDb (lf, 200.0f);
        if (low < 8.0f || shoulder > 3.0f)
        {
            std::cerr << "FAIL: LF shelf shape low=" << low << " shoulder=" << shoulder << " dB\n";
            ok = false;
        }

        DspEngine::Params hf;
        hf.dynOn = false; hf.blackEq = true; hf.eqOn = true; hf.hfBell = false;
        hf.hfGain = 12.0f; hf.hfFreq = 10000.0f;
        const float high = steadyGainDb (hf, 17000.0f);
        const float highShoulder = steadyGainDb (hf, 4500.0f);
        if (high < 7.0f || highShoulder > 3.5f)
        {
            std::cerr << "FAIL: HF shelf shape high=" << high << " shoulder=" << highShoulder << " dB\n";
            ok = false;
        }
        if (low >= 8.0f && shoulder <= 3.0f && high >= 7.0f && highShoulder <= 3.5f)
            std::cout << "PASS: shelf shoulder/dip character\n";
    }

    // g) Automatic threshold/ratio make-up must remain present below threshold.
    {
        DspEngine::Params a, b;
        a.eqOn = b.eqOn = false; a.dynOn = b.dynOn = true;
        setGate (a, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        setGate (b, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        setCompressor (a, true, 0.0f, 4.0f);
        setCompressor (b, true, -20.0f, 4.0f);
        const auto input = makeSine (1000.0f, dbGain (-40.0f), 32768);
        const auto outA = render (a, input);
        const auto outB = render (b, input);
        if (! (rms (outB, outB.size() / 2) > rms (outA, outA.size() / 2) * 1.5f))
        {
            std::cerr << "FAIL: automatic compressor make-up disappeared\n";
            ok = false;
        }
        else std::cout << "PASS: automatic threshold/ratio make-up preserved\n";
    }

    // Brown/Black HPF direction and constant-Q mid behaviour sanity.
    {
        DspEngine::Params brown, black;
        brown.eqOn = black.eqOn = false; brown.dynOn = black.dynOn = false;
        brown.hpOn = black.hpOn = true; brown.hpFreq = black.hpFreq = 160.0f;
        brown.blackEq = false; black.blackEq = true;
        const auto input = makeSine (50.0f, 0.1f, 32768);
        const auto rb = render (brown, input);
        const auto rk = render (black, input);
        if (! (rms (rk, 16000) < rms (rb, 16000)))
        {
            std::cerr << "FAIL: Black HPF is not steeper than Brown HPF\n";
            ok = false;
        }
        else std::cout << "PASS: Black/Brown HPF slope direction\n";
    }

    // h) Static processing should be effectively block-size invariant.
    {
        DspEngine::Params p;
        p.blackEq = true; p.hpOn = true; p.hpFreq = 70.0f; p.eqOn = true;
        p.lmfGain = 3.0f; p.hmfGain = -2.0f; p.dynOn = true;
        setCompressor (p, true, -12.0f, 3.0f);
        setGate (p, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        const auto input = makeSine (440.0f, 0.25f, 16384);
        const auto reference = render (p, input, 16384);
        for (int block : { 32, 64, 512, 4096 })
        {
            const auto candidate = render (p, input, block);
            const float diff = differenceRms (reference, candidate);
            if (diff > 1.0e-5f)
            {
                std::cerr << "FAIL: block-size difference block=" << block << " rms=" << diff << "\n";
                ok = false;
            }
        }
        if (ok) std::cout << "PASS: block-size invariance\n";
    }

    // i) Extreme legal settings must never emit NaN/Inf.
    {
        DspEngine::Params p;
        p.inputTrimDb = 20.0f; p.inputDrive = 20.0f; p.inputMode = 1;
        p.hpOn = true; p.hpFreq = 350.0f; p.lpOn = true; p.lpFreq = 3000.0f;
        p.eqOn = true; p.blackEq = false; p.lfGain = 15.0f; p.lmfGain = 15.0f;
        p.hmfGain = 15.0f; p.hfGain = 15.0f; p.lmfQ = 3.5f; p.hmfQ = 3.5f;
        p.dynOn = true;
        setCompressor (p, true, -20.0f, 20.0f, 0.1f, true);
        setGate (p, true, false, 10.0f, 40.0f, 4.0f, 0.1f, true);
        p.vcaFaderDb = 10.0f; p.outputTrimDb = 20.0f; p.mix = 1.0f;
        const auto input = makeSine (997.0f, 0.95f, 32768);
        const auto out = render (p, input);
        if (! finiteVector (out))
        {
            std::cerr << "FAIL: NaN/Inf at extreme settings\n";
            ok = false;
        }
        else std::cout << "PASS: finite output at extreme settings\n";
    }

    // j) RC component sensitivity: changing C1 must change the transfer-derived
    // centre frequency and network Q. This is the regression that proves the
    // component values are connected to DSP rather than decorative constants.
    {
        using namespace wieneq;
        struct Case { Band band; const char* name; };
        for (const auto tc : { Case{Band::lf,"LF"}, Case{Band::lmf,"LMF"},
                               Case{Band::hmf,"HMF"}, Case{Band::hf,"HF"} })
        {
            const auto c = circuit (tc.band);
            const double r = std::sqrt (c.rMin * c.rMax);
            const auto a = wienNetwork (r, r, c.c1, c.c2, 2.0*r);
            const auto b = wienNetwork (r, r, c.c1*1.10, c.c2, 2.0*r);
            const double fa = a.w0 / (2.0*wieneq::pi);
            const double fb = b.w0 / (2.0*wieneq::pi);
            const double df = 100.0 * (fb/fa - 1.0);
            const double dq = 100.0 * (b.q/a.q - 1.0);
            if (df > -4.5 || df < -5.0 || dq < 4.5 || dq > 5.0)
            {
                std::cerr << "FAIL: " << tc.name << " C1 sensitivity df=" << df
                          << "% dq=" << dq << "%\n";
                ok = false;
            }
            else std::cout << "PASS: " << tc.name << " C1+10% -> f " << df
                           << "% Qn +" << dq << "%\n";
        }
    }

    // k) Band coverage comes from solved component endpoints, not manual frequency clamps.
    {
        using namespace wieneq;
        struct Case { Band band; const char* name; };
        for (const auto tc : { Case{Band::lf,"LF"}, Case{Band::lmf,"LMF"},
                               Case{Band::hmf,"HMF"}, Case{Band::hf,"HF"} })
        {
            const auto c = circuit (tc.band);
            const double lo = frequencyForR (c, c.rMax);
            const double hi = frequencyForR (c, c.rMin);
            const double loErr = std::abs (lo/c.targetMinHz - 1.0);
            const double hiErr = std::abs (hi/c.targetMaxHz - 1.0);
            if (loErr > 0.02 || hiErr > 0.02)
            {
                std::cerr << "FAIL: " << tc.name << " RC coverage " << lo << ".." << hi << " Hz\n";
                ok = false;
            }
            else std::cout << "PASS: " << tc.name << " RC coverage " << lo << ".." << hi << " Hz\n";
        }
    }

    // l) Effective-Q calibration at +12 dB. The passive equal-R/equal-C Wien
    // network cannot physically reach the nominal 0.10 marking with Rq>=0;
    // its honest minimum is 0.167. Maximum 3.5 is reached without a negative R.
    {
        using namespace wieneq;
        for (auto band : { Band::lmf, Band::hmf })
        {
            const auto c = circuit (band);
            const double f = std::sqrt (c.targetMinHz * c.targetMaxHz);
            const auto qMin = tuneBell (c, f, 0.10, 12.0);
            const auto qMax = tuneBell (c, f, 3.50, 12.0);
            if (qMin.effectiveQ < 0.16 || qMin.effectiveQ > 0.18
                || qMax.effectiveQ < 3.2 || qMax.effectiveQ > 3.8)
            {
                std::cerr << "FAIL: effective-Q calibration min=" << qMin.effectiveQ
                          << " max=" << qMax.effectiveQ << "\n";
                ok = false;
            }
            else std::cout << "PASS: physical Qeff range " << qMin.effectiveQ
                           << ".." << qMax.effectiveQ
                           << " (0.10 engraving is below passive topology limit)\n";
        }
    }

    // m) Digital stability over legal sample rates/settings. Any pole at or outside
    // the unit circle is a hard failure. We also print the stricter 0.999 margin;
    // at 192 kHz a low-frequency reciprocal cut can legitimately exceed that
    // arbitrary margin while remaining stable, so it is reported rather than hidden.
    {
        using namespace wieneq;
        double worst = 0.0;
        for (double fs : { 44100.0, 48000.0, 96000.0, 192000.0 })
        {
            for (auto band : { Band::lmf, Band::hmf })
            {
                const auto c = circuit (band);
                for (double f : { c.targetMinHz, std::sqrt(c.targetMinHz*c.targetMaxHz), c.targetMaxHz })
                    for (double q : { 0.10, 1.0, 3.5 })
                        for (double gain : { -18.0, 12.0, 18.0 })
                        {
                            const auto bq = reciprocalBell (fs, tuneBell(c,f,q,gain), gain);
                            const double radius = maxPoleRadius (bq);
                            worst = std::max (worst, radius);
                            if (! std::isfinite(radius) || radius >= 1.0)
                            {
                                std::cerr << "FAIL: unstable Wien bell pole radius=" << radius << "\n";
                                ok = false;
                            }
                        }
            }
        }
        std::cout << "PASS: Wien bell poles remain inside unit circle; worst=" << worst;
        if (worst >= 0.999) std::cout << " (strict 0.999 margin not met; see report)";
        std::cout << "\n";
    }

    // n) Second-order shelf checks: marked corner is half the shelf gain and the
    // shoulder/dip is produced by the second RC damping pair, never by a hidden peak EQ.
    {
        using namespace wieneq;
        const auto lfBq = lowShelf (48000.0, circuit(Band::lf), 80.0, 12.0);
        const double lfCorner = responseMagnitudeDb (lfBq, 48000.0, 80.0);
        const double lfDip = responseMagnitudeDb (lfBq, 48000.0, 176.0);
        const auto hfBq = highShelf (48000.0, circuit(Band::hf), 10000.0, 12.0);
        const double hfCorner = responseMagnitudeDb (hfBq, 48000.0, 10000.0);
        const double hfPre = responseMagnitudeDb (hfBq, 48000.0, 10000.0/2.2);
        if (std::abs(lfCorner-6.0) > 0.15 || std::abs(hfCorner-6.0) > 0.15)
        {
            std::cerr << "FAIL: shelf corner calibration LF=" << lfCorner << " HF=" << hfCorner << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: shelf corners LF=" << lfCorner << " HF=" << hfCorner
                       << " dB; RC shoulder LF@2.2fc=" << lfDip
                       << " dB HF@fc/2.2=" << hfPre << " dB\n";
    }

    // o) Fixed bell markings: LF=1.0 and HF=1.7 effective Q at full +15 dB.
    {
        using namespace wieneq;
        const auto lfN = tuneFixedQBell (circuit(Band::lf), 80.0, 1.0, 15.0);
        const auto hfN = tuneFixedQBell (circuit(Band::hf), 10000.0, 1.7, 15.0);
        if (lfN.effectiveQ < 0.9 || lfN.effectiveQ > 1.15
            || hfN.effectiveQ < 1.5 || hfN.effectiveQ > 1.9)
        {
            std::cerr << "FAIL: fixed bell Q LF=" << lfN.effectiveQ << " HF=" << hfN.effectiveQ << "\n";
            ok = false;
        }
        else std::cout << "PASS: fixed bell Q LF=" << lfN.effectiveQ << " HF=" << hfN.effectiveQ << "\n";
    }

    if (! ok)
        return 1;

    std::cout << "All v0.4.1 DSP and RC/Wien behaviour tests passed.\n";
    return 0;
}
