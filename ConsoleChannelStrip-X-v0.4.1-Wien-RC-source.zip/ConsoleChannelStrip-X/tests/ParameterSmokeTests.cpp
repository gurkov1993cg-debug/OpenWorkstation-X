#include "DspEngine.h"
#include "WienEqModel.h"
#include "SslEseriesEqModel.h"
#include "DynamicsCircuitTests.h"
#include <juce_audio_basics/juce_audio_basics.h>
#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <vector>
#include <utility>

namespace
{
    constexpr double sampleRate = 48000.0;

    float dbGain (float db) { return juce::Decibels::decibelsToGain (db); }

    float rms (const std::vector<float>& v, size_t begin = 0)
    {
        if (begin >= v.size()) return 0.0f;
        double sum = 0.0;
        for (size_t i = begin; i < v.size(); ++i) sum += (double) v[i] * v[i];
        return (float) std::sqrt (sum / (double) (v.size() - begin));
    }

    float differenceRms (const std::vector<float>& a, const std::vector<float>& b)
    {
        const size_t n = juce::jmin (a.size(), b.size());
        if (n == 0) return 0.0f;
        double sum = 0.0;
        for (size_t i = 0; i < n; ++i)
        {
            const double d = (double) a[i] - b[i];
            sum += d * d;
        }
        return (float) std::sqrt (sum / (double) n);
    }

    std::vector<float> makeSine (float frequency, float amplitude, int samples)
    {
        std::vector<float> out ((size_t) samples);
        for (int i = 0; i < samples; ++i)
            out[(size_t) i] = amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                    * frequency * (float) i / (float) sampleRate);
        return out;
    }

    std::vector<float> render (const DspEngine::Params& params, const std::vector<float>& input,
                               int blockSize = 512)
    {
        DspEngine engine;
        engine.prepare (sampleRate, juce::jmax (1, blockSize), 1);
        const int latency = DspEngine::latencySamples();
        const int total = (int) input.size() + latency;
        std::vector<float> raw ((size_t) total, 0.0f);
        int offset = 0;
        while (offset < total)
        {
            const int n = juce::jmin (blockSize, total - offset);
            juce::AudioBuffer<float> block (1, n);
            for (int i = 0; i < n; ++i)
            {
                const int source = offset + i;
                block.setSample (0, i, source < (int) input.size() ? input[(size_t) source] : 0.0f);
            }
            engine.process (block, params);
            for (int i = 0; i < n; ++i) raw[(size_t) (offset + i)] = block.getSample (0, i);
            offset += n;
        }

        std::vector<float> output (input.size());
        for (size_t i = 0; i < output.size(); ++i)
            output[i] = raw[i + (size_t) latency];
        return output;
    }

    std::pair<std::vector<float>, std::vector<float>> renderStereo (const DspEngine::Params& params,
                                                                         const std::vector<float>& leftIn,
                                                                         const std::vector<float>& rightIn,
                                                                         int blockSize = 256)
    {
        const size_t inputTotal = juce::jmin (leftIn.size(), rightIn.size());
        DspEngine engine;
        engine.prepare (sampleRate, juce::jmax (1, blockSize), 2);
        const int latency = DspEngine::latencySamples();
        const int total = (int) inputTotal + latency;
        std::vector<float> leftRaw ((size_t) total, 0.0f), rightRaw ((size_t) total, 0.0f);
        int offset = 0;
        while (offset < total)
        {
            const int n = juce::jmin (blockSize, total - offset);
            juce::AudioBuffer<float> block (2, n);
            for (int i = 0; i < n; ++i)
            {
                const int source = offset + i;
                block.setSample (0, i, source < (int) inputTotal ? leftIn[(size_t) source] : 0.0f);
                block.setSample (1, i, source < (int) inputTotal ? rightIn[(size_t) source] : 0.0f);
            }
            engine.process (block, params);
            for (int i = 0; i < n; ++i)
            {
                leftRaw[(size_t) (offset + i)] = block.getSample (0, i);
                rightRaw[(size_t) (offset + i)] = block.getSample (1, i);
            }
            offset += n;
        }

        std::vector<float> leftOut (inputTotal), rightOut (inputTotal);
        for (size_t i = 0; i < inputTotal; ++i)
        {
            leftOut[i] = leftRaw[i + (size_t) latency];
            rightOut[i] = rightRaw[i + (size_t) latency];
        }
        return { std::move (leftOut), std::move (rightOut) };
    }

    float steadyGainDb (DspEngine::Params p, float frequency, float amplitude = 0.05f)
    {
        const int samples = (int) sampleRate;
        auto input = makeSine (frequency, amplitude, samples);
        auto output = render (p, input, 256);
        const size_t begin = output.size() / 2;
        const float inRms = rms (input, begin);
        const float outRms = rms (output, begin);
        return juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms), -120.0f);
    }

    bool finiteVector (const std::vector<float>& v)
    {
        for (float x : v) if (! std::isfinite (x)) return false;
        return true;
    }

    double projectedAmplitude (const std::vector<float>& v, double frequencyHz,
                               double fs, size_t begin = 0)
    {
        if (begin >= v.size()) return 0.0;
        double re = 0.0, im = 0.0;
        const double twoPi = juce::MathConstants<double>::twoPi;
        const size_t count = v.size() - begin;
        for (size_t i = begin; i < v.size(); ++i)
        {
            const double phase = twoPi * frequencyHz * (double) (i - begin) / fs;
            re += (double) v[i] * std::cos (phase);
            im -= (double) v[i] * std::sin (phase);
        }
        return 2.0 * std::hypot (re, im) / (double) count;
    }

    double measuredBellQ (const ssleq::BiquadCoefficients& c,
                          double fs, double centreHz, double gainDb)
    {
        const double targetDb = 0.5 * gainDb;
        auto responseMinusTarget = [&] (double f)
        {
            return ssleq::responseMagnitudeDb (c, fs, f) - targetDb;
        };

        double loA = 1.0, loB = centreHz;
        for (int i = 0; i < 70; ++i)
        {
            const double mid = 0.5 * (loA + loB);
            if (responseMinusTarget (mid) < 0.0) loA = mid; else loB = mid;
        }
        const double lower = 0.5 * (loA + loB);

        double hiA = centreHz, hiB = fs * 0.499;
        if (responseMinusTarget (hiB) > 0.0)
            return -1.0; // requested bandwidth is wider than Nyquist permits
        for (int i = 0; i < 70; ++i)
        {
            const double mid = 0.5 * (hiA + hiB);
            if (responseMinusTarget (mid) > 0.0) hiA = mid; else hiB = mid;
        }
        const double upper = 0.5 * (hiA + hiB);
        return centreHz / std::max (1.0e-12, upper - lower);
    }

    void setCompressor (DspEngine::Params& p, bool enabled, float thresholdDb, float ratio,
                        float releaseSeconds = 0.30f, bool fast = false)
    {
        auto& c = p.dynamicsCircuit;
        c.compressorEnabled = enabled;
        c.compressorFastAttack = fast;
        c.compressorThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        // Keep the legacy panel-setting CV in step with the threshold used by this
        // helper. It remains in the state structure for compatibility but no longer
        // creates compressor make-up; GLOBAL AUTO LEVEL owns loudness matching.
        c.compressorPanelThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = ratio >= 19.95f ? 10.0e6 : c.gainDivider.topOhm * std::max (0.0f, ratio - 1.0f);
        c.compressorTiming.releaseResistorOhm = releaseSeconds / c.compressorTiming.mainCapF;
    }

    void setGate (DspEngine::Params& p, bool enabled, bool expand, float thresholdDb, float rangeDb,
                  float holdSeconds, float releaseSeconds, bool fast = false)
    {
        auto& c = p.dynamicsCircuit;
        c.gateEnabled = enabled;
        c.gateExpandMode = expand;
        c.gateFastAttack = fast;
        c.gateThresholdCvV = thresholdDb * c.detector.voltsPerDb;
        c.gateRangeCvV = rangeDb * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = std::max (1.0, (double) holdSeconds / c.gate.holdCapF);
        c.gate.releaseResistorOhm = std::max (1.0, (double) releaseSeconds / c.gate.mainCapF);
    }
}

int main()
{
    bool ok = true;
    if (! runDynamicsCircuitRegression())
        ok = false;

    // Meter calibration: a known 0.5 linear sample peak is exactly -6.0206 dBFS.
    // The held GUI feed must report the same number, proving the meter is sourced
    // from audio samples rather than from LED position or a cosmetic envelope.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 256, 2);
        DspEngine::Params p; p.bypass = true;
        juce::AudioBuffer<float> b (2, 256);
        b.clear();
        b.setSample (0, 17, 0.5f);
        b.setSample (1, 83, -0.5f);
        engine.process (b, p);
        constexpr float expected = -6.0205999f;
        const float inL = engine.getInputLeftPeakDb();
        const float inR = engine.getInputRightPeakDb();
        const float heldL = engine.consumeInputLeftPeakDb();
        const float heldR = engine.consumeInputRightPeakDb();
        const float outL = engine.consumeOutputLeftPeakDb();
        const float outR = engine.consumeOutputRightPeakDb();
        if (std::abs (inL - expected) > 0.001f || std::abs (inR - expected) > 0.001f
            || std::abs (heldL - expected) > 0.001f || std::abs (heldR - expected) > 0.001f
            || std::abs (outL - expected) > 0.001f || std::abs (outR - expected) > 0.001f)
        {
            std::cerr << "FAIL: sample-peak meter calibration L=" << inL << " R=" << inR
                      << " held=" << heldL << "," << heldR << " out=" << outL << "," << outR << "\n";
            ok = false;
        }
        else std::cout << "PASS: sample-peak meter calibration -6.0206 dBFS\n";
    }

    // a) MUTE must remain absolute silence for all dry/wet positions.
    for (float mix : { 0.0f, 0.5f, 1.0f })
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.mix = mix; p.mute = true;
        const auto input = makeSine (1000.0f, 0.5f, 8192);
        const auto out = render (p, input);
        if (rms (out) > 1.0e-8f)
        {
            std::cerr << "FAIL: MUTE leaks at mix=" << mix << "\n";
            ok = false;
        }
    }
    if (ok) std::cout << "PASS: MUTE is post-mix silence\n";

    // Factory defaults must be insert-safe: no level lift, no compression, no gate.
    {
        DspEngine::Params p;
        const auto input = makeSine (997.0f, dbGain (-12.0f), 48000);
        const auto out = render (p, input, 256);
        const size_t begin = out.size() / 2;
        const float gainDb = juce::Decibels::gainToDecibels (
            rms (out, begin) / juce::jmax (1.0e-12f, rms (input, begin)), -120.0f);
        if (std::abs (gainDb) > 0.01f)
        {
            std::cerr << "FAIL: factory default is not unity, gain=" << gainDb << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: factory default is unity / insert-safe\n";
    }

    // b) Neutral Black path should be essentially transparent at nominal level.
    {
        DspEngine::Params p;
        p.eqOn = false; p.blackEq = true; p.dynOn = false;
        p.inputDrive = 0.0f; p.inputMode = 0; p.vcaFaderDb = 0.0f; p.outputTrimDb = 0.0f; p.mix = 1.0f;
        const auto input = makeSine (1000.0f, dbGain (-12.0f), 32768);
        const auto out = render (p, input);
        const float inRms = rms (input), outRms = rms (out);
        const float levelErrorDb = juce::Decibels::gainToDecibels (outRms / juce::jmax (1.0e-12f, inRms));

        double dot = 0.0, energy = 0.0;
        for (size_t i = 0; i < input.size(); ++i)
        {
            dot += (double) out[i] * input[i];
            energy += (double) input[i] * input[i];
        }
        const float scale = energy > 0.0 ? (float) (dot / energy) : 1.0f;
        std::vector<float> scaled (input.size());
        for (size_t i = 0; i < input.size(); ++i) scaled[i] = input[i] * scale;
        const float residual = differenceRms (out, scaled);
        const float thdPercent = 100.0f * residual / juce::jmax (1.0e-12f, rms (scaled));

        if (std::abs (levelErrorDb) > 0.01f || thdPercent > 0.05f)
        {
            std::cerr << "FAIL: neutral path levelError=" << levelErrorDb << " dB, residual=" << thdPercent << "%\n";
            ok = false;
        }
        else std::cout << "PASS: neutral path level/THD\n";
    }

    // INPUT DRIVE must have a real clean centre and a clearly audible positive range.
    {
        DspEngine::Params clean, driven;
        clean.eqOn = driven.eqOn = false;
        clean.dynOn = driven.dynOn = false;
        clean.inputMode = driven.inputMode = 0;
        clean.inputDrive = 0.0f;
        driven.inputDrive = 12.0f;

        const auto input = makeSine (997.0f, dbGain (-18.0f), 32768);
        const auto cleanOut = render (clean, input);
        const auto drivenOut = render (driven, input);

        const float cleanNull = differenceRms (cleanOut, input);
        const float driveDifference = differenceRms (drivenOut, input);
        const float driveLevel = juce::Decibels::gainToDecibels (
            rms (drivenOut, drivenOut.size() / 2) / juce::jmax (1.0e-12f, rms (input, input.size() / 2)));

        if (cleanNull > 1.0e-7f || driveDifference < 0.01f || driveLevel < 2.0f)
        {
            std::cerr << "FAIL: INPUT DRIVE cleanNull=" << cleanNull
                      << " diff=" << driveDifference << " level=" << driveLevel << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: INPUT DRIVE has clean 0 dB and audible positive drive\n";
    }

    // The visible -20 dB PAD is real DSP, not a decorative input button.
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.inputPad = true;
        const float g = steadyGainDb (p, 1000.0f, dbGain (-18.0f));
        if (std::abs (g + 20.0f) > 0.05f)
        {
            std::cerr << "FAIL: -20 dB PAD measured " << g << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: -20 dB PAD measured " << g << " dB\n";
    }

    // Whole-strip AUTO LEVEL MATCH restores processed RMS to the raw input level.
    // A +6 dB input-stage change is deliberately used here because it is broadband
    // and therefore has an unambiguous expected compensation of about -6 dB.
    {
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.inputTrimDb = 6.0f; p.autoLevelMatch = true;
        const auto input = makeSine (997.0f, dbGain (-18.0f), (int) sampleRate * 4);
        const auto out = render (p, input, 256);
        const size_t begin = out.size() * 3 / 4;
        const float matchedDb = juce::Decibels::gainToDecibels (
            rms (out, begin) / juce::jmax (1.0e-12f, rms (input, begin)), -120.0f);
        if (std::abs (matchedDb) > 0.35f)
        {
            std::cerr << "FAIL: AUTO LEVEL MATCH residual=" << matchedDb << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: AUTO LEVEL MATCH residual=" << matchedDb << " dB\n";
    }

    // PAN is a real post-strip stereo balance: hard right silences left and leaves right unchanged.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 8192, 2);
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = false; p.pan = 1.0f;
        juce::AudioBuffer<float> block (2, 8192);
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < block.getNumSamples(); ++i)
                block.setSample (ch, i, 0.2f * std::sin ((float) juce::MathConstants<double>::twoPi * 997.0f * (float) i / (float) sampleRate));
        engine.process (block, p);
        const float left = block.getRMSLevel (0, 4096, 4096);
        const float right = block.getRMSLevel (1, 4096, 4096);
        if (left > 1.0e-5f || right < 0.13f)
        {
            std::cerr << "FAIL: PAN hard-right left=" << left << " right=" << right << "\n";
            ok = false;
        }
        else std::cout << "PASS: PAN hard-right stereo balance\n";
    }

    // Mix=0 must be the generator itself, not a second processed reference render.
    {
        DspEngine::Params p;
        p.inputDrive = 20.0f; p.eqOn = true; p.lfGain = 12.0f; p.dynOn = true;
        setCompressor (p, true, -20.0f, 4.0f); p.vcaFaderDb = 10.0f; p.mix = 0.0f;
        const auto input = makeSine (777.0f, 0.2f, 16384);
        const auto out = render (p, input);
        if (differenceRms (out, input) > 1.0e-7f)
        {
            std::cerr << "FAIL: Mix 0 is not dry/null-safe\n";
            ok = false;
        }
        else std::cout << "PASS: Mix 0 returns raw input\n";
    }

    // c) EXPAND must be 1:2: 10 dB below threshold -> about 10 dB extra reduction.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = true;
        setCompressor (p, false, -20.0f, 4.0f);
        setGate (p, true, true, -20.0f, 40.0f, 0.0f, 0.1f);

        // Sine RMS is peak - 3.01 dB, so -27 dBFS peak is approximately -30 dBFS RMS.
        const auto input = makeSine (1000.0f, dbGain (-27.0f), (int) (sampleRate * 2.0));
        int offset = 0;
        while (offset < (int) input.size())
        {
            const int n = juce::jmin (512, (int) input.size() - offset);
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i) b.setSample (0, i, input[(size_t) (offset + i)]);
            engine.process (b, p);
            offset += n;
        }
        const float gr = engine.getGateGainReductionDb();
        if (gr < 9.0f || gr > 11.5f)
        {
            std::cerr << "FAIL: expander 1:2 reduction=" << gr << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: expander 1:2 reduction=" << gr << " dB\n";
    }

    // d) HOLD must keep the gate open, then allow release after the hold interval.
    {
        DspEngine engine;
        engine.prepare (sampleRate, 512, 1);
        DspEngine::Params p;
        p.eqOn = false; p.dynOn = true;
        setCompressor (p, false, -20.0f, 4.0f);
        setGate (p, true, false, -20.0f, 40.0f, 0.5f, 0.1f);

        auto processSignal = [&] (float amplitude, float seconds)
        {
            int remaining = (int) std::round (seconds * sampleRate);
            int phase = 0;
            while (remaining > 0)
            {
                const int n = juce::jmin (512, remaining);
                juce::AudioBuffer<float> b (1, n);
                for (int i = 0; i < n; ++i)
                    b.setSample (0, i, amplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                             * 1000.0f * (float) (phase + i) / (float) sampleRate));
                engine.process (b, p);
                remaining -= n;
                phase += n;
            }
        };

        processSignal (dbGain (-6.0f), 0.20f);
        processSignal (dbGain (-37.0f), 0.40f);
        const float beforeHoldEnds = engine.getGateGainReductionDb();
        processSignal (dbGain (-37.0f), 0.70f);
        const float afterHoldEnds = engine.getGateGainReductionDb();
        if (beforeHoldEnds > 1.0f || afterHoldEnds < 20.0f)
        {
            std::cerr << "FAIL: gate HOLD before=" << beforeHoldEnds << " after=" << afterHoldEnds << "\n";
            ok = false;
        }
        else std::cout << "PASS: gate HOLD/release timing\n";
    }

    // e) Program-dependent compressor attack: an abrupt transient must pull more GR
    // in the first 5 ms than a ramp reaching the same final level.
    {
        const int n = (int) std::round (sampleRate * 0.005);
        auto measure = [&] (bool ramp)
        {
            DspEngine engine;
            engine.prepare (sampleRate, n, 1);
            DspEngine::Params p;
            p.eqOn = false; p.dynOn = true;
            setGate (p, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
            setCompressor (p, true, -20.0f, 10.0f, 0.3f, false);
            juce::AudioBuffer<float> b (1, n);
            for (int i = 0; i < n; ++i)
            {
                const float env = ramp ? (float) i / (float) juce::jmax (1, n - 1) : 1.0f;
                b.setSample (0, i, 0.9f * env * std::sin ((float) juce::MathConstants<double>::twoPi
                                                          * 1000.0f * (float) i / (float) sampleRate));
            }
            engine.process (b, p);
            return engine.getCompressorGainReductionDb();
        };

        const float abrupt = measure (false);
        const float ramped = measure (true);
        if (! (abrupt > ramped + 0.05f))
        {
            std::cerr << "FAIL: program attack abrupt=" << abrupt << " ramp=" << ramped << "\n";
            ok = false;
        }
        else std::cout << "PASS: program-dependent compressor attack\n";
    }

    // f) Shelf character: strong LF/HF boosts plus the opposite-sign broad dip
    // should create full shelf lift and a restrained shoulder around the transition.
    {
        DspEngine::Params lf;
        lf.dynOn = false; lf.blackEq = true; lf.eqOn = true; lf.lfBell = false;
        lf.lfGain = 12.0f; lf.lfFreq = 80.0f;
        const float low = steadyGainDb (lf, 35.0f);
        const float shoulder = steadyGainDb (lf, 200.0f);
        if (low < 8.0f || shoulder > 3.0f)
        {
            std::cerr << "FAIL: LF shelf shape low=" << low << " shoulder=" << shoulder << " dB\n";
            ok = false;
        }

        DspEngine::Params hf;
        hf.dynOn = false; hf.blackEq = true; hf.eqOn = true; hf.hfBell = false;
        hf.hfGain = 12.0f; hf.hfFreq = 10000.0f;
        const float high = steadyGainDb (hf, 17000.0f);
        const float highShoulder = steadyGainDb (hf, 4500.0f);
        if (high < 7.0f || highShoulder > 3.5f)
        {
            std::cerr << "FAIL: HF shelf shape high=" << high << " shoulder=" << highShoulder << " dB\n";
            ok = false;
        }
        if (low >= 8.0f && shoulder <= 3.0f && high >= 7.0f && highShoulder <= 3.5f)
            std::cout << "PASS: shelf shoulder/dip character\n";
    }

    // g) Compressor must not create automatic make-up below threshold. Changing
    // threshold alone on material that never reaches the compressor threshold must
    // therefore leave level unchanged when GLOBAL AUTO LEVEL is disabled.
    {
        DspEngine::Params a, b;
        a.eqOn = b.eqOn = false; a.dynOn = b.dynOn = true;
        setGate (a, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        setGate (b, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        setCompressor (a, true, 0.0f, 4.0f);
        setCompressor (b, true, -20.0f, 4.0f);
        const auto input = makeSine (1000.0f, dbGain (-60.0f), 32768);
        const auto outA = render (a, input);
        const auto outB = render (b, input);
        const float levelDeltaDb = juce::Decibels::gainToDecibels (
            rms (outB, outB.size() / 2) / juce::jmax (1.0e-12f, rms (outA, outA.size() / 2)), -120.0f);
        if (std::abs (levelDeltaDb) > 0.05f)
        {
            std::cerr << "FAIL: compressor adds internal make-up delta=" << levelDeltaDb << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: compressor has no internal auto make-up, delta=" << levelDeltaDb << " dB\n";
    }

    // Brown/Black HPF direction and constant-Q mid behaviour sanity.
    {
        DspEngine::Params brown, black;
        brown.eqOn = black.eqOn = false; brown.dynOn = black.dynOn = false;
        brown.hpOn = black.hpOn = true; brown.hpFreq = black.hpFreq = 160.0f;
        brown.blackEq = false; black.blackEq = true;
        const auto input = makeSine (50.0f, 0.1f, 32768);
        const auto rb = render (brown, input);
        const auto rk = render (black, input);
        if (! (rms (rk, 16000) < rms (rb, 16000)))
        {
            std::cerr << "FAIL: Black HPF is not steeper than Brown HPF\n";
            ok = false;
        }
        else std::cout << "PASS: Black/Brown HPF slope direction\n";
    }

    // h) Static processing should be effectively block-size invariant.
    {
        DspEngine::Params p;
        p.blackEq = true; p.hpOn = true; p.hpFreq = 70.0f; p.eqOn = true;
        p.lmfGain = 3.0f; p.hmfGain = -2.0f; p.dynOn = true;
        setCompressor (p, true, -12.0f, 3.0f);
        setGate (p, false, false, -20.0f, 40.0f, 0.0f, 0.3f);
        const auto input = makeSine (440.0f, 0.25f, 16384);
        const auto reference = render (p, input, 16384);
        for (int block : { 32, 64, 512, 4096 })
        {
            const auto candidate = render (p, input, block);
            const float diff = differenceRms (reference, candidate);
            if (diff > 1.0e-5f)
            {
                std::cerr << "FAIL: block-size difference block=" << block << " rms=" << diff << "\n";
                ok = false;
            }
        }
        if (ok) std::cout << "PASS: block-size invariance\n";
    }

    // i) Extreme legal settings must never emit NaN/Inf.
    {
        DspEngine::Params p;
        p.inputTrimDb = 20.0f; p.inputDrive = 20.0f; p.inputMode = 1;
        p.hpOn = true; p.hpFreq = 350.0f; p.lpOn = true; p.lpFreq = 3000.0f;
        p.eqOn = true; p.blackEq = false; p.lfGain = 15.0f; p.lmfGain = 15.0f;
        p.hmfGain = 15.0f; p.hfGain = 15.0f; p.lmfQ = 3.5f; p.hmfQ = 3.5f;
        p.dynOn = true;
        setCompressor (p, true, -20.0f, 20.0f, 0.1f, true);
        setGate (p, true, false, 10.0f, 40.0f, 4.0f, 0.1f, true);
        p.vcaFaderDb = 10.0f; p.outputTrimDb = 20.0f; p.mix = 1.0f;
        const auto input = makeSine (997.0f, 0.95f, 32768);
        const auto out = render (p, input);
        if (! finiteVector (out))
        {
            std::cerr << "FAIL: NaN/Inf at extreme settings\n";
            ok = false;
        }
        else std::cout << "PASS: finite output at extreme settings\n";
    }

    // j) RC component sensitivity: changing C1 must change the transfer-derived
    // centre frequency and network Q. This is the regression that proves the
    // component values are connected to DSP rather than decorative constants.
    {
        using namespace wieneq;
        struct Case { Band band; const char* name; };
        for (const auto tc : { Case{Band::lf,"LF"}, Case{Band::lmf,"LMF"},
                               Case{Band::hmf,"HMF"}, Case{Band::hf,"HF"} })
        {
            const auto c = circuit (tc.band);
            const double r = std::sqrt (c.rMin * c.rMax);
            const auto a = wienNetwork (r, r, c.c1, c.c2, 2.0*r);
            const auto b = wienNetwork (r, r, c.c1*1.10, c.c2, 2.0*r);
            const double fa = a.w0 / (2.0*wieneq::pi);
            const double fb = b.w0 / (2.0*wieneq::pi);
            const double df = 100.0 * (fb/fa - 1.0);
            const double dq = 100.0 * (b.q/a.q - 1.0);
            if (df > -4.5 || df < -5.0 || dq < 4.5 || dq > 5.0)
            {
                std::cerr << "FAIL: " << tc.name << " C1 sensitivity df=" << df
                          << "% dq=" << dq << "%\n";
                ok = false;
            }
            else std::cout << "PASS: " << tc.name << " C1+10% -> f " << df
                           << "% Qn +" << dq << "%\n";
        }
    }

    // k) Band coverage comes from solved component endpoints, not manual frequency clamps.
    {
        using namespace wieneq;
        struct Case { Band band; const char* name; };
        for (const auto tc : { Case{Band::lf,"LF"}, Case{Band::lmf,"LMF"},
                               Case{Band::hmf,"HMF"}, Case{Band::hf,"HF"} })
        {
            const auto c = circuit (tc.band);
            const double lo = frequencyForR (c, c.rMax);
            const double hi = frequencyForR (c, c.rMin);
            const double loErr = std::abs (lo/c.targetMinHz - 1.0);
            const double hiErr = std::abs (hi/c.targetMaxHz - 1.0);
            if (loErr > 0.02 || hiErr > 0.02)
            {
                std::cerr << "FAIL: " << tc.name << " RC coverage " << lo << ".." << hi << " Hz\n";
                ok = false;
            }
            else std::cout << "PASS: " << tc.name << " RC coverage " << lo << ".." << hi << " Hz\n";
        }
    }

    // l) Effective-Q calibration at +12 dB. The passive equal-R/equal-C Wien
    // network cannot physically reach the nominal 0.10 marking with Rq>=0;
    // its honest minimum is 0.167. Maximum 3.5 is reached without a negative R.
    {
        using namespace wieneq;
        for (auto band : { Band::lmf, Band::hmf })
        {
            const auto c = circuit (band);
            const double f = std::sqrt (c.targetMinHz * c.targetMaxHz);
            const auto qMin = tuneBell (c, f, 0.10, 12.0);
            const auto qMax = tuneBell (c, f, 3.50, 12.0);
            if (qMin.effectiveQ < 0.16 || qMin.effectiveQ > 0.18
                || qMax.effectiveQ < 3.2 || qMax.effectiveQ > 3.8)
            {
                std::cerr << "FAIL: effective-Q calibration min=" << qMin.effectiveQ
                          << " max=" << qMax.effectiveQ << "\n";
                ok = false;
            }
            else std::cout << "PASS: physical Qeff range " << qMin.effectiveQ
                           << ".." << qMax.effectiveQ
                           << " (0.10 engraving is below passive topology limit)\n";
        }
    }

    // m) Digital stability over legal sample rates/settings. Any pole at or outside
    // the unit circle is a hard failure. We also print the stricter 0.999 margin;
    // at 192 kHz a low-frequency reciprocal cut can legitimately exceed that
    // arbitrary margin while remaining stable, so it is reported rather than hidden.
    {
        using namespace wieneq;
        double worst = 0.0;
        for (double fs : { 44100.0, 48000.0, 96000.0, 192000.0 })
        {
            for (auto band : { Band::lmf, Band::hmf })
            {
                const auto c = circuit (band);
                for (double f : { c.targetMinHz, std::sqrt(c.targetMinHz*c.targetMaxHz), c.targetMaxHz })
                    for (double q : { 0.10, 1.0, 3.5 })
                        for (double gain : { -18.0, 12.0, 18.0 })
                        {
                            const auto bq = reciprocalBell (fs, tuneBell(c,f,q,gain), gain);
                            const double radius = maxPoleRadius (bq);
                            worst = std::max (worst, radius);
                            if (! std::isfinite(radius) || radius >= 1.0)
                            {
                                std::cerr << "FAIL: unstable Wien bell pole radius=" << radius << "\n";
                                ok = false;
                            }
                        }
            }
        }
        std::cout << "PASS: Wien bell poles remain inside unit circle; worst=" << worst;
        if (worst >= 0.999) std::cout << " (strict 0.999 margin not met; see report)";
        std::cout << "\n";
    }


    // n0) Schematic-derived E-series EQ validation.  This is separate from the
    // legacy Wien tests above because the Wien code is intentionally retained as
    // the emergency rollback path.  The active path must use the original drawing
    // RC timing cores, preserve constant-bandwidth mid bells, fixed-network LF/HF
    // bell damping and the accepted second-order shelf voicing, and remain stable
    // over the old-Mac sample-rate range.
    {
        using namespace ssleq;
        bool schematicOk = true;
        double worst = 0.0;

        // Component sanity from the original drawings.  The simple RC endpoints
        // land close to the engraved/documented E-series ranges before any UI
        // compatibility clamping is applied.
        const auto brownHm = circuit (Revision::brown02, Band::hmf);
        const auto blackHm = circuit (Revision::black242, Band::hmf);
        const auto brownHmLow = tuneFrequency (brownHm, 1.0).actualHz;
        const auto brownHmHigh = tuneFrequency (brownHm, 1.0e9).actualHz;
        const auto blackHmLow = tuneFrequency (blackHm, 1.0).actualHz;
        const auto blackHmHigh = tuneFrequency (blackHm, 1.0e9).actualHz;
        if (brownHmLow < 580.0 || brownHmLow > 680.0 || brownHmHigh < 7400.0 || brownHmHigh > 8300.0
            || blackHmLow < 600.0 || blackHmLow > 700.0 || blackHmHigh < 10500.0 || blackHmHigh > 12000.0)
        {
            std::cerr << "FAIL: schematic RC endpoint sanity Brown HMF=" << brownHmLow << ".." << brownHmHigh
                      << " Black HMF=" << blackHmLow << ".." << blackHmHigh << " Hz\n";
            ok = schematicOk = false;
        }
        else std::cout << "PASS: schematic RC timing cores are connected to Brown/Black HMF ranges\n";

        for (double fs : { 44100.0, 48000.0, 96000.0, 192000.0 })
        {
            for (auto revision : { Revision::brown02, Revision::black242 })
            {
                for (auto band : { Band::lf, Band::lmf, Band::hmf, Band::hf })
                {
                    const auto c = circuit (revision, band);
                    const double lo = c.documentedMinHz;
                    const double hi = c.documentedMaxHz;
                    const double q = (band == Band::lf || band == Band::hf) ? c.fixedBellQ : 0.10;
                    for (double f : { lo, std::sqrt (lo*hi), hi })
                        for (double gain : { -18.0, -12.0, 12.0, 18.0 })
                        {
                            const auto bq = (band == Band::lf || band == Band::hf)
                                ? fixedQBell (fs, c, f, q, gain)
                                : reciprocalBell (fs, c, f, q, gain);
                            const double radius = maxPoleRadius (bq);
                            worst = std::max (worst, radius);
                            if (! coefficientsUsable (bq))
                            {
                                std::cerr << "FAIL: unstable schematic E bell pole radius=" << radius << "\n";
                                ok = schematicOk = false;
                            }
                        }
                }
            }
        }

        // Second-order reciprocal E shelf: exactly half the dB gain at the marked
        // corner while preserving the accepted shelf damping/shoulder.
        const auto shelf = lowShelf (48000.0, circuit (Revision::black242, Band::lf), 80.0, 12.0);
        const double shelfCorner = responseMagnitudeDb (shelf, 48000.0, 80.0);
        if (std::abs (shelfCorner - 6.0) > 0.05)
        {
            std::cerr << "FAIL: schematic E shelf corner=" << shelfCorner << " dB\n";
            ok = schematicOk = false;
        }

        // The accepted old Wien shelf voicing is deliberately preserved by the
        // new second-order shelf damping at reachable RC frequencies.
        const auto oldShelf = wieneq::lowShelf (48000.0, wieneq::circuit (wieneq::Band::lf), 80.0, 12.0);
        const double newShoulder = responseMagnitudeDb (shelf, 48000.0, 176.0);
        const double oldShoulder = wieneq::responseMagnitudeDb (oldShelf, 48000.0, 176.0);
        if (std::abs (newShoulder - oldShoulder) > 0.02)
        {
            std::cerr << "FAIL: new shelf changed accepted Wien voicing new=" << newShoulder
                      << " old=" << oldShoulder << " dB\n";
            ok = schematicOk = false;
        }

        // LF/HF bell mode uses component-fixed network damping, not a constant
        // effective Q.  At strong boost the fixed-network bell must therefore be
        // audibly wider than the constant-bandwidth mid-bell law.
        const auto blackLfCircuit = circuit (Revision::black242, Band::lf);
        const auto fixedLfBell = fixedQBell (48000.0, blackLfCircuit, 80.0, blackLfCircuit.fixedBellQ, 15.0);
        const auto constantLfBell = reciprocalBell (48000.0, blackLfCircuit, 80.0, blackLfCircuit.fixedBellQ, 15.0);
        const double fixedAt40 = responseMagnitudeDb (fixedLfBell, 48000.0, 40.0);
        const double constantAt40 = responseMagnitudeDb (constantLfBell, 48000.0, 40.0);
        if (! (fixedAt40 > constantAt40 + 2.0))
        {
            std::cerr << "FAIL: fixed LF bell did not widen with boost fixed=" << fixedAt40
                      << " constant=" << constantAt40 << " dB\n";
            ok = schematicOk = false;
        }

        // The mid-band Q control must remain correctly calibrated at 44.1/48 kHz
        // even near 10 kHz.  This catches the old centre-only prewarp bug where a
        // marked Q=1 narrowed to roughly 1.55 at 44.1 kHz.
        for (double fs : { 44100.0, 48000.0 })
        {
            const auto hmf = circuit (Revision::black242, Band::hmf);
            for (double markedQ : { 1.0, 3.5 })
            {
                const auto bq = reciprocalBell (fs, hmf, 10000.0, markedQ, 12.0);
                const double measured = measuredBellQ (bq, fs, 10000.0, 12.0);
                if (measured < 0.0 || std::abs (measured - markedQ) > 0.015)
                {
                    std::cerr << "FAIL: HF Q precomp fs=" << fs << " marked=" << markedQ
                              << " measured=" << measured << "\n";
                    ok = schematicOk = false;
                }
            }
        }

        // The actual DspEngine must agree with the new model; this catches a build
        // that accidentally selects the preserved legacy fallback all the time.
        DspEngine::Params p;
        p.dynOn = false; p.eqOn = true; p.blackEq = true;
        p.lfBell = false; p.lfFreq = 80.0f; p.lfGain = 12.0f;
        const float engineAt200 = steadyGainDb (p, 200.0f);
        const double modelAt200 = responseMagnitudeDb (shelf, 48000.0, 200.0);
        if (std::abs ((double) engineAt200 - modelAt200) > 0.20)
        {
            std::cerr << "FAIL: DspEngine is not following schematic EQ path engine=" << engineAt200
                      << " model=" << modelAt200 << " dB\n";
            ok = schematicOk = false;
        }

        if (schematicOk)
            std::cout << "PASS: schematic 82E02/82E242 EQ active; worst pole=" << worst
                      << ", LF shelf engine/model delta=" << ((double) engineAt200 - modelAt200) << " dB\n";
    }

    // Dedicated SATURATION is a pure-C++ nonlinear circuit. OFF must null exactly,
    // while high drive must create a finite nonlinear residual without acting as a
    // second gain control. AUTO LEVEL must then return programme RMS to the input.
    {
        const int n = 48000 * 6;
        auto input = makeSine (997.0f, 0.24f, n);

        DspEngine::Params off;
        off.eqOn = false; off.dynOn = false; off.saturation = 0.0f;
        const auto clean = render (off, input, 256);
        const float nullRms = differenceRms (clean, input);
        if (nullRms > 1.0e-7f)
        {
            std::cerr << "FAIL: SATURATION 0% is not exact bypass diff=" << nullRms << "\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION 0% is exact bypass\n";

        DspEngine::Params driven = off;
        driven.saturation = 100.0f;
        const auto coloured = render (driven, input, 256);
        const float nonlinearResidual = differenceRms (coloured, input);
        if (! finiteVector (coloured) || nonlinearResidual < 5.0e-4f)
        {
            std::cerr << "FAIL: SATURATION nonlinear circuit residual=" << nonlinearResidual << "\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION produces stable nonlinear circuit colour\n";

        DspEngine::Params matched = driven;
        matched.autoLevelMatch = true;
        const auto levelMatched = render (matched, input, 256);
        const size_t begin = levelMatched.size() * 3 / 4;
        const float matchedDb = juce::Decibels::gainToDecibels (
            rms (levelMatched, begin) / juce::jmax (1.0e-12f, rms (input, begin)), -120.0f);
        if (std::abs (matchedDb) > 0.30f)
        {
            std::cerr << "FAIL: SATURATION AUTO LEVEL mismatch=" << matchedDb << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION stays input-level matched with AUTO LEVEL, error=" << matchedDb << " dB\n";

        const auto stereo = renderStereo (driven, input, input, 256);
        const float lrError = differenceRms (stereo.first, stereo.second);
        if (lrError > 1.0e-7f)
        {
            std::cerr << "FAIL: SATURATION breaks dual-mono channel symmetry diff=" << lrError << "\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION preserves matched L/R channels\n";

        // Anti-alias regression: with a 7 kHz tone, the seventh harmonic would
        // land at 49 kHz and fold to 1 kHz at 48 kHz if the nonlinear residual is
        // generated directly at base rate.  The project-owned 4x path must keep
        // that folded component below -50 dBc at a deliberately hard +12 dB drive.
        AnalogSaturationCircuit aliasTest;
        aliasTest.prepare (48000.0, 1);
        std::vector<float> aliasOut ((size_t) 48000 * 3);
        const float hardAmplitude = dbGain (-18.0f) * dbGain (12.0f);
        for (size_t i = 0; i < aliasOut.size(); ++i)
        {
            const float x = hardAmplitude * std::sin ((float) juce::MathConstants<double>::twoPi
                                                       * 7000.0f * (float) i / 48000.0f);
            aliasOut[i] = aliasTest.processSample (x, 0, 1.0f);
        }
        const size_t aliasBegin = 48000;
        const double fundamental = projectedAmplitude (aliasOut, 7000.0, 48000.0, aliasBegin);
        const double foldedAlias = projectedAmplitude (aliasOut, 1000.0, 48000.0, aliasBegin);
        const double aliasDbc = 20.0 * std::log10 (std::max (1.0e-15, foldedAlias)
                                                    / std::max (1.0e-15, fundamental));
        const double fundamentalGainDb = 20.0 * std::log10 (
            std::max (1.0e-15, fundamental) / std::max (1.0e-15, (double) hardAmplitude));
        if (! std::isfinite (aliasDbc) || aliasDbc > -50.0)
        {
            std::cerr << "FAIL: SATURATION alias suppression 7k->1k = " << aliasDbc << " dBc\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION 4x alias suppression 7k->1k = " << aliasDbc << " dBc\n";

        // Tonal-preservation regression. The accepted v1 circuit measures about
        // -12.03 dB fundamental gain in this deliberately extreme 7 kHz / +12 dB
        // drive case. The first residual-only IIR anti-alias attempt shifted this
        // to roughly +2.9 dB, so keep the new linear-phase path close to v1 while
        // still rejecting the foldback above.
        if (! std::isfinite (fundamentalGainDb) || std::abs (fundamentalGainDb + 12.0289) > 0.25)
        {
            std::cerr << "FAIL: SATURATION tonal preservation at 7 kHz = "
                      << fundamentalGainDb << " dB vs v1 -12.0289 dB\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION tonal preservation at 7 kHz = "
                       << fundamentalGainDb << " dB\n";

        // 0% saturation still has the fixed anti-alias latency so host parallel
        // paths never move when the knob changes. The delayed signal itself must
        // remain bit-exact.
        AnalogSaturationCircuit latencyTest;
        latencyTest.prepare (48000.0, 1);
        double latencyError = 0.0;
        int impulsePeak = -1;
        double impulsePeakValue = 0.0;
        for (int i = 0; i < 256; ++i)
        {
            const float x = i == 0 ? 1.0f : 0.0f;
            const float y = latencyTest.processSample (x, 0, 0.0f);
            const float expected = i == AnalogSaturationCircuit::latencySamples() ? 1.0f : 0.0f;
            latencyError = std::max (latencyError, std::abs ((double) y - (double) expected));
            if (std::abs ((double) y) > impulsePeakValue)
            {
                impulsePeakValue = std::abs ((double) y);
                impulsePeak = i;
            }
        }
        if (AnalogSaturationCircuit::latencySamples() != 48 || impulsePeak != 48 || latencyError > 1.0e-12)
        {
            std::cerr << "FAIL: SATURATION fixed latency reported="
                      << AnalogSaturationCircuit::latencySamples() << " peak=" << impulsePeak
                      << " error=" << latencyError << "\n";
            ok = false;
        }
        else std::cout << "PASS: SATURATION fixed 48-sample latency is sample-exact\n";
    }

    // Stereo image: a dual-mono sine must remain mono at WIDTH=0 and acquire
    // measurable L-R side energy when width/detune/delay are engaged.
    {
        const int n = 48000;
        const auto mono = makeSine (1200.0f, 0.12f, n);
        DspEngine::Params off; off.eqOn = false; off.dynOn = false; off.stereoWidth = 0.0f;
        DspEngine::Params on = off; on.stereoWidth = 100.0f; on.stereoDetune = 9.0f; on.stereoDelayMs = 11.0f; on.stereoFocusHz = 120.0f;
        auto a = renderStereo (off, mono, mono);
        auto b = renderStereo (on, mono, mono);
        std::vector<float> offSide ((size_t) n), onSide ((size_t) n);
        for (int i = 0; i < n; ++i)
        {
            offSide[(size_t) i] = 0.5f * (a.first[(size_t) i] - a.second[(size_t) i]);
            onSide[(size_t) i] = 0.5f * (b.first[(size_t) i] - b.second[(size_t) i]);
        }
        const float offRms = rms (offSide, (size_t) n / 2);
        const float onRms = rms (onSide, (size_t) n / 2);
        if (offRms > 1.0e-7f || onRms < 1.0e-4f)
        {
            std::cerr << "FAIL: stereo image mono->stereo offSide=" << offRms << " onSide=" << onRms << "\n";
            ok = false;
        }
        else std::cout << "PASS: stereo image creates genuine SIDE energy from mono\n";
    }


    // SAT IN regression: the dedicated section switch must bypass both the
    // pre-gain and nonlinear colour while preserving the fixed-latency signal.
    {
        const int n = 24000;
        const auto input = makeSine (997.0f, 0.08f, n);

        DspEngine::Params bypassed;
        bypassed.eqOn = false;
        bypassed.dynOn = false;
        bypassed.saturationOn = false;
        bypassed.saturation = 100.0f;
        bypassed.saturationGainDb = 18.0f;

        DspEngine::Params reference = bypassed;
        reference.saturation = 0.0f;
        reference.saturationGainDb = 0.0f;

        DspEngine::Params engaged = bypassed;
        engaged.saturationOn = true;

        const auto a = render (bypassed, input, 257);
        const auto b = render (reference, input, 257);
        const auto c = render (engaged, input, 257);

        const float bypassError = differenceRms (a, b);
        const float engagedDifference = differenceRms (c, b);
        if (bypassError > 1.0e-7f || engagedDifference < 1.0e-4f)
        {
            std::cerr << "FAIL: SAT IN bypass error=" << bypassError
                      << " engaged difference=" << engagedDifference << "\n";
            ok = false;
        }
        else std::cout << "PASS: SAT IN bypasses SAT GAIN + colour without changing latency\n";
    }

    // WIDTH must also widen genuine stereo material, not only synthesize SIDE
    // from mono. With DELAY=DETUNE=0 this test isolates the M/S width path.
    {
        const int n = 48000;
        const auto left = makeSine (1000.0f, 0.12f, n);
        auto right = left;
        const int phaseOffset = 6; // 45 degrees at 1 kHz / 48 kHz
        for (int i = 0; i < n; ++i)
            right[(size_t) i] = 0.12f * std::sin ((float) juce::MathConstants<double>::twoPi
                                                  * 1000.0f * (float) (i + phaseOffset) / (float) sampleRate);

        DspEngine::Params off;
        off.eqOn = false; off.dynOn = false; off.stereoWidth = 0.0f;
        off.stereoDetune = 0.0f; off.stereoDelayMs = 0.0f; off.stereoFocusHz = 10000.0f;
        DspEngine::Params on = off;
        on.stereoWidth = 100.0f;

        const auto a = renderStereo (off, left, right);
        const auto b = renderStereo (on, left, right);
        std::vector<float> sideOff ((size_t) n), sideOn ((size_t) n);
        for (int i = 0; i < n; ++i)
        {
            sideOff[(size_t) i] = 0.5f * (a.first[(size_t) i] - a.second[(size_t) i]);
            sideOn[(size_t) i] = 0.5f * (b.first[(size_t) i] - b.second[(size_t) i]);
        }
        const float offRms = rms (sideOff, (size_t) n / 2);
        const float onRms = rms (sideOn, (size_t) n / 2);
        if (! (onRms > offRms * 1.65f))
        {
            std::cerr << "FAIL: WIDTH does not widen existing stereo side off="
                      << offRms << " on=" << onRms << "\n";
            ok = false;
        }
        else std::cout << "PASS: WIDTH audibly widens existing stereo SIDE\n";
    }

    // DELAY and DETUNE must each be independently effective on mono material.
    {
        const int n = 48000;
        const auto mono = makeSine (1400.0f, 0.12f, n);

        auto sideRmsFor = [&] (float delayMs, float detune)
        {
            DspEngine::Params p;
            p.eqOn = false; p.dynOn = false;
            p.stereoWidth = 100.0f;
            p.stereoDelayMs = delayMs;
            p.stereoDetune = detune;
            p.stereoFocusHz = 10000.0f;
            const auto out = renderStereo (p, mono, mono);
            std::vector<float> side ((size_t) n);
            for (int i = 0; i < n; ++i)
                side[(size_t) i] = 0.5f * (out.first[(size_t) i] - out.second[(size_t) i]);
            return rms (side, (size_t) n / 2);
        };

        const float neutral = sideRmsFor (0.0f, 0.0f);
        const float delayOnly = sideRmsFor (12.0f, 0.0f);
        const float detuneOnly = sideRmsFor (0.0f, 15.0f);
        if (neutral > 1.0e-7f || delayOnly < 1.0e-4f || detuneOnly < 1.0e-4f)
        {
            std::cerr << "FAIL: stereo controls neutral=" << neutral
                      << " delayOnly=" << delayOnly
                      << " detuneOnly=" << detuneOnly << "\n";
            ok = false;
        }
        else std::cout << "PASS: DELAY and DETUNE independently create stereo SIDE\n";
    }

    // FOCUS direction regression: turning FOCUS up must widen more of the
    // spectrum.  Turning it down must keep more programme material centred.
    {
        const int n = 48000;
        const auto mono = makeSine (1000.0f, 0.12f, n);
        DspEngine::Params low; low.eqOn = false; low.dynOn = false; low.stereoWidth = 100.0f;
        low.stereoDetune = 9.0f; low.stereoDelayMs = 11.0f; low.stereoFocusHz = 20.0f;
        DspEngine::Params high = low; high.stereoFocusHz = 10000.0f;
        auto a = renderStereo (low, mono, mono);
        auto b = renderStereo (high, mono, mono);
        std::vector<float> lowSide ((size_t) n), highSide ((size_t) n);
        for (int i = 0; i < n; ++i)
        {
            lowSide[(size_t) i] = 0.5f * (a.first[(size_t) i] - a.second[(size_t) i]);
            highSide[(size_t) i] = 0.5f * (b.first[(size_t) i] - b.second[(size_t) i]);
        }
        const float lowSideRms = rms (lowSide, (size_t) n / 2);
        const float highSideRms = rms (highSide, (size_t) n / 2);
        if (! (highSideRms > lowSideRms * 1.5f))
        {
            std::cerr << "FAIL: FOCUS direction low=" << lowSideRms << " high=" << highSideRms << "\n";
            ok = false;
        }
        else std::cout << "PASS: FOCUS up widens more spectrum; down keeps more centred\n";
    }

    // n) Second-order shelf checks: marked corner is half the shelf gain and the
    // shoulder/dip is produced by the second RC damping pair, never by a hidden peak EQ.
    {
        using namespace wieneq;
        const auto lfBq = lowShelf (48000.0, circuit(Band::lf), 80.0, 12.0);
        const double lfCorner = responseMagnitudeDb (lfBq, 48000.0, 80.0);
        const double lfDip = responseMagnitudeDb (lfBq, 48000.0, 176.0);
        const auto hfBq = highShelf (48000.0, circuit(Band::hf), 10000.0, 12.0);
        const double hfCorner = responseMagnitudeDb (hfBq, 48000.0, 10000.0);
        const double hfPre = responseMagnitudeDb (hfBq, 48000.0, 10000.0/2.2);
        if (std::abs(lfCorner-6.0) > 0.15 || std::abs(hfCorner-6.0) > 0.15)
        {
            std::cerr << "FAIL: shelf corner calibration LF=" << lfCorner << " HF=" << hfCorner << " dB\n";
            ok = false;
        }
        else std::cout << "PASS: shelf corners LF=" << lfCorner << " HF=" << hfCorner
                       << " dB; RC shoulder LF@2.2fc=" << lfDip
                       << " dB HF@fc/2.2=" << hfPre << " dB\n";
    }

    // o) Fixed bell markings: LF=1.0 and HF=1.7 effective Q at full +15 dB.
    {
        using namespace wieneq;
        const auto lfN = tuneFixedQBell (circuit(Band::lf), 80.0, 1.0, 15.0);
        const auto hfN = tuneFixedQBell (circuit(Band::hf), 10000.0, 1.7, 15.0);
        if (lfN.effectiveQ < 0.9 || lfN.effectiveQ > 1.15
            || hfN.effectiveQ < 1.5 || hfN.effectiveQ > 1.9)
        {
            std::cerr << "FAIL: fixed bell Q LF=" << lfN.effectiveQ << " HF=" << hfN.effectiveQ << "\n";
            ok = false;
        }
        else std::cout << "PASS: fixed bell Q LF=" << lfN.effectiveQ << " HF=" << hfN.effectiveQ << "\n";
    }

    if (! ok)
        return 1;

    std::cout << "All v0.4.1 DSP, schematic E-EQ and legacy rollback tests passed.\n";
    return 0;
}
