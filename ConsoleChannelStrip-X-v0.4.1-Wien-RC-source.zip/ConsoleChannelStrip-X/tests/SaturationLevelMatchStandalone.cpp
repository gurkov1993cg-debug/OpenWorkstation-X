#include "../src/AnalogSaturationCircuit.h"
#include <cmath>
#include <iostream>
int main(){
  constexpr double sr=48000; constexpr int bs=256; int total=48000*6;
  AnalogSaturationCircuit sat; sat.prepare(sr,1);
  double inP=0,outP=0; float gainDb=0,gainApplied=1; double sumIn=0,sumOut=0; int count=0;
  for(int off=0;off<total;off+=bs){int n=std::min(bs,total-off); double bi=0,bo=0; float tmp[bs];
    for(int i=0;i<n;++i){float x=.24f*std::sin(2*3.141592653589793*997*(off+i)/sr); float y=sat.processSample(x,0,1); tmp[i]=y; bi+=x*x; bo+=y*y;}
    bi/=n;bo/=n; double a=1-std::exp(-n/(.350*sr)); inP+=a*(bi-inP);outP+=a*(bo-outP);
    float desired=10*std::log10(inP/outP); if(desired>18)desired=18;if(desired<-18)desired=-18; double tau=desired<gainDb?.180:.550;float ga=1-std::exp(-n/(tau*sr));gainDb+=(desired-gainDb)*ga;float tg=std::exp(gainDb*0.11512925465);
    for(int i=0;i<n;++i){float x=.24f*std::sin(2*3.141592653589793*997*(off+i)/sr);float t=(float)i/(float)n;float g=gainApplied+(tg-gainApplied)*t;float y=tmp[i]*g;if(off+i>total*3/4){sumIn+=x*x;sumOut+=y*y;++count;}}
    gainApplied=tg;
  }
  std::cout<<"match dB="<<10*std::log10(sumOut/sumIn)<<" gain="<<gainDb<<"\n";
}
