#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <chrono>
#include <cmath>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <vector>

namespace
{
    void collectWithIds (juce::Component& root, std::vector<juce::Component*>& out)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getComponentID().isNotEmpty()) out.push_back (child);
                collectWithIds (*child, out);
            }
    }

    juce::Component* findByName (juce::Component& root, const juce::String& name)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getName() == name) return child;
                if (auto* nested = findByName (*child, name)) return nested;
            }
        return nullptr;
    }
}

int main()
{
    juce::ScopedJuceInitialiser_GUI juceGui;
    ConsoleChannelStripXAudioProcessor processor;

    const auto start = std::chrono::steady_clock::now();
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds> (
        std::chrono::steady_clock::now() - start).count();

    if (editor == nullptr)
    {
        std::cerr << "FAIL: editor was not created\n";
        return 1;
    }
    if (editor->getWidth() != ConsoleChannelStripXAudioProcessorEditor::designWidth
        || editor->getHeight() != ConsoleChannelStripXAudioProcessorEditor::designHeight)
    {
        std::cerr << "FAIL: base GUI size is not 1536x1024\n";
        return 1;
    }
    if (elapsedMs > 2000)
    {
        std::cerr << "FAIL: editor construction is too slow\n";
        return 1;
    }

    std::function<bool(juce::Component&)> containsStockWidget = [&] (juce::Component& root)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (dynamic_cast<juce::Slider*> (child) != nullptr || dynamic_cast<juce::Button*> (child) != nullptr)
                    return true;
                if (containsStockWidget (*child)) return true;
            }
        return false;
    };
    if (containsStockWidget (*editor))
    {
        std::cerr << "FAIL: stock JUCE Slider/Button found\n";
        return 1;
    }

    const std::set<std::string> expectedVisibleIds {
        "inputDrive","inputTrim","inputMode","inputPad","polarity",
        "eqOn","eqModel","hfBell","hfGain","hfFreq","hmfGain","hmfFreq","hmfQ",
        "lmfGain","lmfFreq","lmfQ","lfBell","lfGain","lfFreq","hpOn","hpFreq","lpOn","lpFreq",
        "dynOn","gateOn","gateExpand","gateFast","gateThreshold","gateRange","gateHold","gateRelease",
        "compOn","compFast","compThreshold","compRatio","compRelease",
        "outputTrim","pan","channelMode"
    };

    std::vector<juce::Component*> controls;
    collectWithIds (*editor, controls);
    std::map<std::string, juce::Component*> byId;
    for (auto* c : controls)
    {
        const auto id = c->getComponentID().toStdString();
        if (! byId.emplace (id, c).second)
        {
            std::cerr << "FAIL: duplicate GUI parameter component " << id << "\n";
            return 1;
        }
    }

    std::set<std::string> actualIds;
    for (const auto& kv : byId) actualIds.insert (kv.first);
    if (actualIds != expectedVisibleIds)
    {
        std::cerr << "FAIL: visible GUI parameter set differs from approved hardware layout\n";
        for (const auto& id : expectedVisibleIds) if (actualIds.count (id) == 0) std::cerr << " missing " << id << "\n";
        for (const auto& id : actualIds) if (expectedVisibleIds.count (id) == 0) std::cerr << " extra " << id << "\n";
        return 1;
    }

    std::vector<std::pair<std::string, juce::Rectangle<int>>> bounds;
    for (const auto& id : expectedVisibleIds)
    {
        auto* c = byId[id];
        if (c == nullptr || ! c->isVisible() || c->getLocalBounds().isEmpty())
        {
            std::cerr << "FAIL: invisible/empty control " << id << "\n";
            return 1;
        }
        const auto r = editor->getLocalArea (c, c->getLocalBounds());
        if (! editor->getLocalBounds().contains (r))
        {
            std::cerr << "FAIL: control outside GUI " << id << "\n";
            return 1;
        }
        bounds.emplace_back (id, r);

        auto* p = processor.parameters().getParameter (id.c_str());
        auto* hw = dynamic_cast<ParameterHardwareControl*> (c);
        if (p == nullptr || hw == nullptr)
        {
            std::cerr << "FAIL: visible control is not APVTS-backed custom hardware: " << id << "\n";
            return 1;
        }
        const float before = p->getValue();
        hw->exerciseForTest();
        if (std::abs (p->getValue() - before) < 1.0e-6f)
        {
            std::cerr << "FAIL: dead GUI control " << id << "\n";
            return 1;
        }
    }

    for (size_t a = 0; a < bounds.size(); ++a)
        for (size_t b = a + 1; b < bounds.size(); ++b)
            if (bounds[a].second.intersects (bounds[b].second))
            {
                std::cerr << "FAIL: controls overlap: " << bounds[a].first << " / " << bounds[b].first << "\n";
                return 1;
            }

    // MUTE/SOLO must not exist in the approved Output panel.
    if (byId.count ("mute") != 0 || findByName (*editor, "ui_solo") != nullptr)
    {
        std::cerr << "FAIL: MUTE/SOLO leaked back into the GUI\n";
        return 1;
    }

    // Top POWER really controls bypass.
    auto* power = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_power"));
    auto* bypass = processor.parameters().getParameter ("bypass");
    if (power == nullptr || bypass == nullptr) return 1;
    const float bypassBefore = bypass->getValue(); power->triggerForTest();
    if (std::abs (bypass->getValue() - bypassBefore) < 1.0e-6f)
    {
        std::cerr << "FAIL: POWER does not control bypass\n";
        return 1;
    }

    // Ratio tabs are real aliases for the same ratio parameter, not decoration.
    auto* ratio20 = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_ratio_0"));
    auto* ratio = processor.parameters().getParameter ("compRatio");
    if (ratio20 == nullptr || ratio == nullptr) return 1;
    ratio20->triggerForTest();
    if (std::abs (ratio->convertFrom0to1 (ratio->getValue()) - 20.0f) > 0.1f)
    {
        std::cerr << "FAIL: ratio tab does not set compressor ratio\n";
        return 1;
    }

    // Zoom buttons really resize the editor and preserve 3:2 aspect ratio.
    auto* zoomIn = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_zoom_in"));
    auto* zoomReset = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_zoom_reset"));
    if (zoomIn == nullptr || zoomReset == nullptr) return 1;
    zoomReset->triggerForTest();
    const int baseW = editor->getWidth();
    const auto baseKnobBounds = editor->getLocalArea (byId["inputDrive"], byId["inputDrive"]->getLocalBounds());
    zoomIn->triggerForTest();
    const auto zoomedKnobBounds = editor->getLocalArea (byId["inputDrive"], byId["inputDrive"]->getLocalBounds());
    if (editor->getWidth() <= baseW || zoomedKnobBounds.getWidth() <= baseKnobBounds.getWidth()
        || std::abs ((double) editor->getWidth() / editor->getHeight() - 1.5) > 0.01)
    {
        std::cerr << "FAIL: GUI zoom does not scale window and control geometry with fixed aspect ratio\n";
        return 1;
    }
    zoomReset->triggerForTest();

    // INIT restores defaults after the GUI wiring tests changed parameters.
    auto* init = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_init"));
    auto* inputTrim = processor.parameters().getParameter ("inputTrim");
    if (init == nullptr || inputTrim == nullptr) return 1;
    inputTrim->setValueNotifyingHost (1.0f); init->triggerForTest();
    if (std::abs (inputTrim->getValue() - inputTrim->getDefaultValue()) > 1.0e-6f)
    {
        std::cerr << "FAIL: INIT does not restore defaults\n";
        return 1;
    }

    // Threshold calibration remains useful at normal digital operating levels.
    auto measuredPanelGr = [] (float panelThreshold)
    {
        ConsoleChannelStripXAudioProcessor p;
        p.prepareToPlay (48000.0, 512);
        auto setActual = [&] (const char* id, float actual)
        {
            if (auto* q = p.parameters().getParameter (id)) q->setValueNotifyingHost (q->convertTo0to1 (actual));
        };
        setActual ("eqOn", 0.0f); setActual ("dynOn", 1.0f); setActual ("compOn", 1.0f);
        setActual ("compThreshold", panelThreshold); setActual ("compRatio", 4.0f); setActual ("compRelease", 0.10f);
        setActual ("compFast", 1.0f); setActual ("gateOn", 0.0f);
        juce::MidiBuffer midi;
        const float a = juce::Decibels::decibelsToGain (-20.0f);
        for (int block = 0; block < 220; ++block)
        {
            juce::AudioBuffer<float> b (2, 512);
            for (int ch = 0; ch < 2; ++ch) for (int i = 0; i < 512; ++i) b.setSample (ch, i, a);
            p.processBlock (b, midi);
        }
        return p.compressorMeter();
    };
    const float deepGr = measuredPanelGr (-15.0f), highGr = measuredPanelGr (10.0f);
    if (deepGr < 7.0f || deepGr > 12.0f || highGr > 0.5f)
    {
        std::cerr << "FAIL: panel/dBFS threshold calibration deep=" << deepGr << " high=" << highGr << "\n";
        return 1;
    }

    const auto preview = editor->createComponentSnapshot (editor->getLocalBounds(), true, 1.0f);
    auto previewFile = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-v0.4.1.png");
    if (auto stream = previewFile.createOutputStream())
    {
        juce::PNGImageFormat png;
        if (! png.writeImageToStream (preview, *stream)) return 1;
    }
    else return 1;

    std::cout << "PASS: custom reference GUI, real controls, no MUTE/SOLO, working ratio tabs and zoom; "
              << expectedVisibleIds.size() << " APVTS controls validated.\n";
    return 0;
}
