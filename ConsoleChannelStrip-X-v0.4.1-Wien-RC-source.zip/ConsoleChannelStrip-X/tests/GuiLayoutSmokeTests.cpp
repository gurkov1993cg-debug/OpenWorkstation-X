#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <chrono>
#include <cmath>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <vector>

namespace
{
    void collectComponentsWithIds (juce::Component& root, std::vector<juce::Component*>& out)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
        {
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getComponentID().isNotEmpty())
                    out.push_back (child);
                collectComponentsWithIds (*child, out);
            }
        }
    }

    juce::Component* findByNameRecursive (juce::Component& root, const juce::String& name)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
        {
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getName() == name)
                    return child;
                if (auto* nested = findByNameRecursive (*child, name))
                    return nested;
            }
        }
        return nullptr;
    }
}

int main()
{
    juce::ScopedJuceInitialiser_GUI juceGui;
    ConsoleChannelStripXAudioProcessor processor;

    const auto start = std::chrono::steady_clock::now();
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds> (
        std::chrono::steady_clock::now() - start).count();

    if (editor == nullptr)
    {
        std::cerr << "FAIL: editor was not created\n";
        return 1;
    }

    if (editor->getWidth() != 1536 || editor->getHeight() != 942)
    {
        std::cerr << "FAIL: unexpected editor size " << editor->getWidth() << "x" << editor->getHeight() << "\n";
        return 1;
    }

    if (elapsedMs > 2000)
    {
        std::cerr << "FAIL: editor construction is too slow: " << elapsedMs << " ms\n";
        return 1;
    }

    std::set<std::string> expectedIds;
    for (auto* parameter : processor.getParameters())
    {
        if (auto* withId = dynamic_cast<juce::AudioProcessorParameterWithID*> (parameter))
            expectedIds.insert (withId->paramID.toStdString());
    }

    // New hardware GUI contract: no stock JUCE Slider/Button widgets are allowed.
    // JUCE provides the window, drawing surface and events only; parameter controls
    // must be the custom circuit-facing components from PluginEditor.h.
    std::function<bool(juce::Component&)> containsStockWidget = [&] (juce::Component& root)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
        {
            if (auto* child = root.getChildComponent (i))
            {
                if (dynamic_cast<juce::Slider*> (child) != nullptr || dynamic_cast<juce::Button*> (child) != nullptr)
                    return true;
                if (containsStockWidget (*child))
                    return true;
            }
        }
        return false;
    };
    if (containsStockWidget (*editor))
    {
        std::cerr << "FAIL: stock JUCE Slider/Button found in the hardware GUI\n";
        return 1;
    }

    std::vector<juce::Component*> controls;
    collectComponentsWithIds (*editor, controls);

    std::map<std::string, juce::Component*> byId;
    for (auto* control : controls)
    {
        const auto id = control->getComponentID().toStdString();
        if (! byId.emplace (id, control).second)
        {
            std::cerr << "FAIL: duplicate component ID: " << id << "\n";
            return 1;
        }
    }

    std::set<std::string> actualIds;
    for (const auto& [id, component] : byId)
        actualIds.insert (id);

    if (actualIds != expectedIds)
    {
        std::cerr << "FAIL: GUI/APVTS ID sets differ\n";
        for (const auto& id : expectedIds)
            if (actualIds.count (id) == 0) std::cerr << "  missing GUI control: " << id << "\n";
        for (const auto& id : actualIds)
            if (expectedIds.count (id) == 0) std::cerr << "  extra GUI control: " << id << "\n";
        return 1;
    }

    // Bounds, visibility and real parameter wiring.
    std::vector<std::pair<std::string, juce::Rectangle<int>>> parameterBounds;
    for (const auto& id : expectedIds)
    {
        auto* control = byId[id];
        if (control == nullptr || ! control->isVisible() || control->getLocalBounds().isEmpty())
        {
            std::cerr << "FAIL: invisible/0x0 control: " << id << "\n";
            return 1;
        }

        const auto boundsInEditor = editor->getLocalArea (control, control->getLocalBounds());
        if (! editor->getLocalBounds().contains (boundsInEditor))
        {
            std::cerr << "FAIL: control outside editor: " << id << "\n";
            return 1;
        }
        parameterBounds.emplace_back (id, boundsInEditor);

        auto* parameter = processor.parameters().getParameter (id.c_str());
        if (parameter == nullptr)
        {
            std::cerr << "FAIL: APVTS parameter missing: " << id << "\n";
            return 1;
        }

        const float before = parameter->getValue();
        if (auto* hardware = dynamic_cast<ParameterHardwareControl*> (control))
        {
            hardware->exerciseForTest();
        }
        else
        {
            std::cerr << "FAIL: parameter is not a custom hardware control: " << id << "\n";
            return 1;
        }

        if (std::abs (parameter->getValue() - before) < 1.0e-6f)
        {
            std::cerr << "FAIL: control is not connected to parameter: " << id << "\n";
            return 1;
        }
    }

    for (size_t a = 0; a < parameterBounds.size(); ++a)
    {
        for (size_t b = a + 1; b < parameterBounds.size(); ++b)
        {
            if (parameterBounds[a].second.intersects (parameterBounds[b].second))
            {
                std::cerr << "FAIL: parameter controls overlap: "
                          << parameterBounds[a].first << " / " << parameterBounds[b].first << "\n";
                return 1;
            }
        }
    }

    // Approved OUTPUT utility layout: ROUTING and CHANNEL MODE occupy the
    // lower OUTPUT block.  Dynamics-only EXPAND/FAST controls must not be
    // duplicated here.  This is a geometric regression test, not a text scan.
    const auto routingBounds = editor->getLocalArea (byId["routing"], byId["routing"]->getLocalBounds());
    const auto channelModeBounds = editor->getLocalArea (byId["channelMode"], byId["channelMode"]->getLocalBounds());
    constexpr int outputPanelX = 1325;
    if (routingBounds.getX() < outputPanelX || channelModeBounds.getX() < outputPanelX)
    {
        std::cerr << "FAIL: ROUTING/CHANNEL MODE moved out of OUTPUT\n";
        return 1;
    }
    if (channelModeBounds.getY() <= routingBounds.getBottom())
    {
        std::cerr << "FAIL: CHANNEL MODE is not below ROUTING\n";
        return 1;
    }

    // Top power is a second presentation of the bypass function. It is intentionally
    // not assigned a parameter componentID so the one-control-per-parameter audit
    // remains exact.
    auto* power = dynamic_cast<HardwareActionButton*> (findByNameRecursive (*editor, "ui_power"));
    auto* bypass = processor.parameters().getParameter ("bypass");
    if (power == nullptr || bypass == nullptr)
    {
        std::cerr << "FAIL: top power/bypass missing\n";
        return 1;
    }
    const float bypassBefore = bypass->getValue();
    power->triggerForTest();
    if (std::abs (bypass->getValue() - bypassBefore) < 1.0e-6f)
    {
        std::cerr << "FAIL: top power does not control bypass\n";
        return 1;
    }

    auto* inputTrim = processor.parameters().getParameter ("inputTrim");
    auto* init = dynamic_cast<HardwareActionButton*> (findByNameRecursive (*editor, "ui_init"));
    if (inputTrim == nullptr || init == nullptr)
    {
        std::cerr << "FAIL: INIT test controls missing\n";
        return 1;
    }
    inputTrim->setValueNotifyingHost (1.0f);
    init->triggerForTest();
    if (std::abs (inputTrim->getValue() - inputTrim->getDefaultValue()) > 1.0e-6f)
    {
        std::cerr << "FAIL: INIT does not restore defaults\n";
        return 1;
    }

    // Panel threshold calibration is an integration property, not a circuit-unit
    // assumption: panel 0 dB is [CHOICE] -18 dBFS. A normal -20 dBFS steady input
    // at panel -15 / 4:1 must therefore reach useful heavy compression, while the
    // +10 panel position must remain above that signal.
    auto measuredPanelGr = [] (float panelThreshold)
    {
        ConsoleChannelStripXAudioProcessor p;
        p.prepareToPlay (48000.0, 512);
        auto setActual = [&] (const char* id, float actual)
        {
            if (auto* q = p.parameters().getParameter (id))
            {
                q->beginChangeGesture();
                q->setValueNotifyingHost (q->convertTo0to1 (actual));
                q->endChangeGesture();
            }
        };
        setActual ("eqOn", 0.0f);
        setActual ("dynOn", 1.0f);
        setActual ("compOn", 1.0f);
        setActual ("compThreshold", panelThreshold);
        setActual ("compRatio", 4.0f);
        setActual ("compRelease", 0.10f);
        setActual ("compFast", 1.0f);
        setActual ("gateOn", 0.0f);

        juce::MidiBuffer midi;
        const float a = juce::Decibels::decibelsToGain (-20.0f);
        for (int block = 0; block < 220; ++block)
        {
            juce::AudioBuffer<float> b (2, 512);
            for (int ch = 0; ch < 2; ++ch) b.clear (ch, 0, 512);
            for (int ch = 0; ch < 2; ++ch)
                for (int i = 0; i < 512; ++i)
                    b.setSample (ch, i, a);
            p.processBlock (b, midi);
        }
        return p.compressorMeter();
    };

    const float deepGr = measuredPanelGr (-15.0f);
    const float highThresholdGr = measuredPanelGr (10.0f);
    if (deepGr < 7.0f || deepGr > 12.0f || highThresholdGr > 0.5f)
    {
        std::cerr << "FAIL: panel/dBFS threshold calibration deepGR=" << deepGr
                  << " highThresholdGR=" << highThresholdGr << "\n";
        return 1;
    }

    const auto preview = editor->createComponentSnapshot (editor->getLocalBounds(), true, 1.0f);
    auto previewFile = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-v0.4.1.png");
    if (auto stream = previewFile.createOutputStream())
    {
        juce::PNGImageFormat png;
        if (! png.writeImageToStream (preview, *stream))
        {
            std::cerr << "FAIL: could not encode GUI preview PNG\n";
            return 1;
        }
    }
    else
    {
        std::cerr << "FAIL: could not create GUI preview PNG\n";
        return 1;
    }

    std::cout << "PASS: GUI has exactly " << expectedIds.size()
              << " APVTS controls, all visible/in-bounds/wired/non-overlapping; editor created in "
              << elapsedMs << " ms.\n";
    return 0;
}
