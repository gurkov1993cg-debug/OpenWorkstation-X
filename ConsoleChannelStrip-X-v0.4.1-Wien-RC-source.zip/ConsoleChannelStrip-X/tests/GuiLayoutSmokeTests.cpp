#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <chrono>
#include <cmath>
#include <functional>
#include <iostream>
#include <map>
#include <set>
#include <vector>

namespace
{
    void collectWithIds (juce::Component& root, std::vector<juce::Component*>& out)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getComponentID().isNotEmpty()) out.push_back (child);
                collectWithIds (*child, out);
            }
    }

    juce::Component* findByName (juce::Component& root, const juce::String& name)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (child->getName() == name) return child;
                if (auto* nested = findByName (*child, name)) return nested;
            }
        return nullptr;
    }
}

int main()
{
    juce::ScopedJuceInitialiser_GUI juceGui;
    ConsoleChannelStripXAudioProcessor processor;

    const auto start = std::chrono::steady_clock::now();
    std::unique_ptr<juce::AudioProcessorEditor> editor (processor.createEditor());
    const auto elapsedMs = std::chrono::duration_cast<std::chrono::milliseconds> (
        std::chrono::steady_clock::now() - start).count();

    if (editor == nullptr)
    {
        std::cerr << "FAIL: editor was not created\n";
        return 1;
    }
    constexpr float startupScale = 0.75f;
    const int expectedStartupW = juce::roundToInt ((float) ConsoleChannelStripXAudioProcessorEditor::designWidth * startupScale);
    const int expectedStartupH = juce::roundToInt ((float) ConsoleChannelStripXAudioProcessorEditor::designHeight * startupScale);
    if (editor->getWidth() != expectedStartupW || editor->getHeight() != expectedStartupH)
    {
        std::cerr << "FAIL: unexpected startup GUI size " << editor->getWidth() << "x" << editor->getHeight() << "\n";
        return 1;
    }
    if (elapsedMs > 2000)
    {
        std::cerr << "FAIL: editor construction is too slow\n";
        return 1;
    }

    std::function<bool(juce::Component&)> containsStockWidget = [&] (juce::Component& root)
    {
        for (int i = 0; i < root.getNumChildComponents(); ++i)
            if (auto* child = root.getChildComponent (i))
            {
                if (dynamic_cast<juce::Slider*> (child) != nullptr || dynamic_cast<juce::Button*> (child) != nullptr)
                    return true;
                if (containsStockWidget (*child)) return true;
            }
        return false;
    };
    if (containsStockWidget (*editor))
    {
        std::cerr << "FAIL: stock JUCE Slider/Button found\n";
        return 1;
    }

    const std::set<std::string> expectedVisibleIds {
        "inputDrive","inputTrim","inputMode","inputPad","polarity",
        "eqOn","eqModel","hfBell","hfGain","hfFreq","hmfGain","hmfFreq","hmfQ",
        "lmfGain","lmfFreq","lmfQ","lfBell","lfGain","lfFreq","hpOn","hpFreq","lpOn","lpFreq",
        "dynOn","gateOn","gateExpand","gateFast","gateThreshold","gateRange","gateHold","gateRelease",
        "compOn","compFast","compPeak","compThreshold","compRatio","compRelease",
        "outputTrim","autoLevel","pan","saturationOn","saturation","satGain",
        "stereoWidth","stereoFocus","stereoDetune","stereoDelay"
    };

    std::vector<juce::Component*> controls;
    collectWithIds (*editor, controls);
    std::map<std::string, juce::Component*> byId;
    for (auto* c : controls)
    {
        const auto id = c->getComponentID().toStdString();
        if (! byId.emplace (id, c).second)
        {
            std::cerr << "FAIL: duplicate GUI parameter component " << id << "\n";
            return 1;
        }
    }

    std::set<std::string> actualIds;
    for (const auto& kv : byId) actualIds.insert (kv.first);
    if (actualIds != expectedVisibleIds)
    {
        std::cerr << "FAIL: visible GUI parameter set differs from approved hardware layout\n";
        for (const auto& id : expectedVisibleIds) if (actualIds.count (id) == 0) std::cerr << " missing " << id << "\n";
        for (const auto& id : actualIds) if (expectedVisibleIds.count (id) == 0) std::cerr << " extra " << id << "\n";
        return 1;
    }

    std::vector<std::pair<std::string, juce::Rectangle<int>>> bounds;
    for (const auto& id : expectedVisibleIds)
    {
        auto* c = byId[id];
        if (c == nullptr || ! c->isVisible() || c->getLocalBounds().isEmpty())
        {
            std::cerr << "FAIL: invisible/empty control " << id << "\n";
            return 1;
        }
        const auto r = editor->getLocalArea (c, c->getLocalBounds());
        if (! editor->getLocalBounds().contains (r))
        {
            std::cerr << "FAIL: control outside GUI " << id << "\n";
            return 1;
        }
        bounds.emplace_back (id, r);

        auto* p = processor.parameters().getParameter (id.c_str());
        auto* hw = dynamic_cast<ParameterHardwareControl*> (c);
        if (p == nullptr || hw == nullptr)
        {
            std::cerr << "FAIL: visible control is not APVTS-backed custom hardware: " << id << "\n";
            return 1;
        }
        const float before = p->getValue();
        hw->exerciseForTest();
        if (std::abs (p->getValue() - before) < 1.0e-6f)
        {
            std::cerr << "FAIL: dead GUI control " << id << "\n";
            return 1;
        }
    }

    for (size_t a = 0; a < bounds.size(); ++a)
        for (size_t b = a + 1; b < bounds.size(); ++b)
            if (bounds[a].second.intersects (bounds[b].second))
            {
                std::cerr << "FAIL: controls overlap: " << bounds[a].first << " / " << bounds[b].first << "\n";
                return 1;
            }

    // MUTE/SOLO must not exist in the approved Output panel.
    if (byId.count ("mute") != 0 || findByName (*editor, "ui_solo") != nullptr)
    {
        std::cerr << "FAIL: MUTE/SOLO leaked back into the GUI\n";
        return 1;
    }

    // Top POWER really controls bypass.
    auto* power = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_power"));
    auto* bypass = processor.parameters().getParameter ("bypass");
    if (power == nullptr || bypass == nullptr) return 1;
    const float bypassBefore = bypass->getValue(); power->triggerForTest();
    if (std::abs (bypass->getValue() - bypassBefore) < 1.0e-6f)
    {
        std::cerr << "FAIL: POWER does not control bypass\n";
        return 1;
    }

    // Fixed ratio shortcut tabs were intentionally removed; the continuous
    // compressor RATIO knob is now the single ratio control.
    if (findByName (*editor, "ui_ratio_0") != nullptr
        || processor.parameters().getParameter ("compRatio") == nullptr
        || byId.count ("compRatio") == 0)
    {
        std::cerr << "FAIL: ratio shortcuts returned or continuous RATIO knob is missing\n";
        return 1;
    }

    // Zoom regression: both position and size must scale ONCE.  The previous
    // implementation pre-scaled x/y and then transformed the component again,
    // collapsing controls toward the top-left at 50%.
    auto* zoomOut = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_zoom_out"));
    auto* zoomIn = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_zoom_in"));
    auto* zoomReset = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_zoom_reset"));
    if (zoomOut == nullptr || zoomIn == nullptr || zoomReset == nullptr) return 1;

    zoomReset->triggerForTest();
    if (editor->getWidth() != ConsoleChannelStripXAudioProcessorEditor::designWidth
        || editor->getHeight() != ConsoleChannelStripXAudioProcessorEditor::designHeight)
    {
        std::cerr << "FAIL: 100% zoom reset is not design size\n";
        return 1;
    }

    // Capture the full-size geometry once. Every supported zoom must be a pure
    // uniform scaling of these rectangles. This checks the whole GUI, not just
    // two representative knobs, and fails if any child starts drifting.
    std::map<std::string, juce::Rectangle<int>> fullScaleBounds;
    for (const auto& id : expectedVisibleIds)
        fullScaleBounds.emplace (id, editor->getLocalArea (byId[id], byId[id]->getLocalBounds()));

    auto checkPureScale = [&] (float scale, const char* scaleName)
    {
        for (const auto& id : expectedVisibleIds)
        {
            const auto actual = editor->getLocalArea (byId[id], byId[id]->getLocalBounds());
            const auto base = fullScaleBounds.at (id);
            const juce::Rectangle<int> expected {
                juce::roundToInt ((float) base.getX() * scale),
                juce::roundToInt ((float) base.getY() * scale),
                juce::roundToInt ((float) base.getWidth() * scale),
                juce::roundToInt ((float) base.getHeight() * scale)
            };
            const auto close = [] (int a, int b) { return std::abs (a - b) <= 2; };
            if (! close (actual.getX(), expected.getX())
                || ! close (actual.getY(), expected.getY())
                || ! close (actual.getWidth(), expected.getWidth())
                || ! close (actual.getHeight(), expected.getHeight()))
            {
                std::cerr << "FAIL: control drift at " << scaleName << ": " << id
                          << " expected=" << expected.toString()
                          << " actual=" << actual.toString() << "\n";
                return false;
            }
        }
        return true;
    };

    for (int i = 0; i < 5; ++i) zoomOut->triggerForTest();
    const auto halfInput = editor->getLocalArea (byId["inputDrive"], byId["inputDrive"]->getLocalBounds());
    const auto halfHf = editor->getLocalArea (byId["hfGain"], byId["hfGain"]->getLocalBounds());

    // Do not hard-code coordinates from an older visual layout here.  The GUI may
    // intentionally move or enlarge controls while preserving the one-surface zoom
    // architecture.  What must remain invariant is a single 0.5x transform of the
    // current 100% design geometry.  This still catches the original double-scale
    // regression, but it does not reject legitimate visual redesigns.
    const auto halfExpected = [&] (const std::string& id)
    {
        const auto base = fullScaleBounds.at (id);
        return juce::Rectangle<int> {
            juce::roundToInt ((float) base.getX() * 0.5f),
            juce::roundToInt ((float) base.getY() * 0.5f),
            juce::roundToInt ((float) base.getWidth() * 0.5f),
            juce::roundToInt ((float) base.getHeight() * 0.5f)
        };
    };
    const auto expectedHalfInput = halfExpected ("inputDrive");
    const auto expectedHalfHf = halfExpected ("hfGain");
    const auto closeHalf = [] (int a, int b) { return std::abs (a - b) <= 2; };
    const auto rectClose = [&] (juce::Rectangle<int> actual, juce::Rectangle<int> expected)
    {
        return closeHalf (actual.getX(), expected.getX())
            && closeHalf (actual.getY(), expected.getY())
            && closeHalf (actual.getWidth(), expected.getWidth())
            && closeHalf (actual.getHeight(), expected.getHeight());
    };

    if (editor->getWidth() != ConsoleChannelStripXAudioProcessorEditor::designWidth / 2
        || editor->getHeight() != ConsoleChannelStripXAudioProcessorEditor::designHeight / 2
        || ! rectClose (halfInput, expectedHalfInput)
        || ! rectClose (halfHf, expectedHalfHf))
    {
        std::cerr << "FAIL: 50% zoom double-scaled or misplaced controls: input="
                  << halfInput.toString() << " expected=" << expectedHalfInput.toString()
                  << " hf=" << halfHf.toString() << " expected=" << expectedHalfHf.toString() << "\n";
        return 1;
    }

    // At half size the Input control must still stay in the Input panel and the HF
    // gain must start in the Equaliser panel; this directly catches the video bug.
    if (halfInput.getRight() > 100 || halfHf.getX() < 100)
    {
        std::cerr << "FAIL: 50% zoom panel geometry collapsed\n";
        return 1;
    }

    // Every supported zoom must preserve the same relative layout.  We test
    // transformed on-screen rectangles, not just the design-space table, because
    // integer pixel rounding can turn touching edges into a one-pixel overlap.
    auto checkNoOverlapAtCurrentZoom = [&] (const char* scaleName)
    {
        std::vector<std::pair<std::string, juce::Rectangle<int>>> scaledBounds;
        for (const auto& id : expectedVisibleIds)
        {
            auto* c = byId[id];
            const auto r = editor->getLocalArea (c, c->getLocalBounds());
            if (! editor->getLocalBounds().contains (r))
            {
                std::cerr << "FAIL: control outside GUI at " << scaleName << ": " << id << " " << r.toString() << "\n";
                return false;
            }
            scaledBounds.emplace_back (id, r);
        }
        for (size_t a = 0; a < scaledBounds.size(); ++a)
            for (size_t b = a + 1; b < scaledBounds.size(); ++b)
                if (scaledBounds[a].second.intersects (scaledBounds[b].second))
                {
                    std::cerr << "FAIL: controls overlap at " << scaleName << ": "
                              << scaledBounds[a].first << " / " << scaledBounds[b].first
                              << "  " << scaledBounds[a].second.toString()
                              << "  " << scaledBounds[b].second.toString() << "\n";
                    return false;
                }
        return true;
    };

    zoomReset->triggerForTest();
    for (int i = 0; i < 5; ++i) zoomOut->triggerForTest();
    if (! checkPureScale (0.50f, "50%") || ! checkNoOverlapAtCurrentZoom ("50%")) return 1;

    zoomReset->triggerForTest();
    for (int i = 0; i < 3; ++i) zoomOut->triggerForTest();
    if (! checkPureScale (0.70f, "70%") || ! checkNoOverlapAtCurrentZoom ("70%")) return 1;

    zoomReset->triggerForTest();
    if (! checkPureScale (1.00f, "100%") || ! checkNoOverlapAtCurrentZoom ("100%")) return 1;

    for (int i = 0; i < 2; ++i) zoomIn->triggerForTest();
    if (! checkPureScale (1.20f, "120%") || ! checkNoOverlapAtCurrentZoom ("120%")) return 1;

    for (int i = 0; i < 3; ++i) zoomIn->triggerForTest();
    const int expected150W = juce::roundToInt ((float) ConsoleChannelStripXAudioProcessorEditor::designWidth * 1.5f);
    const int expected150H = juce::roundToInt ((float) ConsoleChannelStripXAudioProcessorEditor::designHeight * 1.5f);
    const double aspect150 = (double) editor->getWidth() / (double) editor->getHeight();
    if (editor->getWidth() != expected150W
        || editor->getHeight() != expected150H
        || std::abs (aspect150 - 1.5) > 0.01
        || ! checkPureScale (1.50f, "150%")
        || ! checkNoOverlapAtCurrentZoom ("150%"))
    {
        std::cerr << "FAIL: zoom-in/aspect-ratio regression size="
                  << editor->getWidth() << "x" << editor->getHeight()
                  << " expected=" << expected150W << "x" << expected150H
                  << " aspect=" << aspect150 << "\n";
        return 1;
    }
    zoomReset->triggerForTest();

    // INIT restores defaults after the GUI wiring tests changed parameters.
    auto* init = dynamic_cast<HardwareActionButton*> (findByName (*editor, "ui_init"));
    auto* inputTrim = processor.parameters().getParameter ("inputTrim");
    if (init == nullptr || inputTrim == nullptr) return 1;
    inputTrim->setValueNotifyingHost (1.0f); init->triggerForTest();
    if (std::abs (inputTrim->getValue() - inputTrim->getDefaultValue()) > 1.0e-6f)
    {
        std::cerr << "FAIL: INIT does not restore defaults\n";
        return 1;
    }

    // Threshold calibration remains useful at normal digital operating levels.
    auto measuredPanelGr = [] (float panelThreshold)
    {
        ConsoleChannelStripXAudioProcessor p;
        p.prepareToPlay (48000.0, 512);
        auto setActual = [&] (const char* id, float actual)
        {
            if (auto* q = p.parameters().getParameter (id)) q->setValueNotifyingHost (q->convertTo0to1 (actual));
        };
        setActual ("eqOn", 0.0f); setActual ("dynOn", 1.0f); setActual ("compOn", 1.0f);
        setActual ("compThreshold", panelThreshold); setActual ("compRatio", 4.0f); setActual ("compRelease", 0.10f);
        setActual ("compFast", 1.0f); setActual ("compPeak", 0.0f); setActual ("gateOn", 0.0f);
        juce::MidiBuffer midi;
        const float a = juce::Decibels::decibelsToGain (-20.0f);
        for (int block = 0; block < 220; ++block)
        {
            juce::AudioBuffer<float> b (2, 512);
            for (int ch = 0; ch < 2; ++ch) for (int i = 0; i < 512; ++i) b.setSample (ch, i, a);
            p.processBlock (b, midi);
        }
        return p.compressorMeter();
    };
    const float deepGr = measuredPanelGr (-15.0f), highGr = measuredPanelGr (10.0f);
    if (deepGr < 7.0f || deepGr > 12.0f || highGr > 0.5f)
    {
        std::cerr << "FAIL: panel/dBFS threshold calibration deep=" << deepGr << " high=" << highGr << "\n";
        return 1;
    }

    const auto preview = editor->createComponentSnapshot (editor->getLocalBounds(), true, 1.0f);
    auto previewFile = juce::File::getCurrentWorkingDirectory().getChildFile ("gui-preview-v0.4.1.png");
    if (auto stream = previewFile.createOutputStream())
    {
        juce::PNGImageFormat png;
        if (! png.writeImageToStream (preview, *stream)) return 1;
    }
    else return 1;

    std::cout << "PASS: custom reference GUI, real controls, no MUTE/SOLO, continuous RATIO knob and working zoom; "
              << expectedVisibleIds.size() << " APVTS controls validated.\n";
    return 0;
}
