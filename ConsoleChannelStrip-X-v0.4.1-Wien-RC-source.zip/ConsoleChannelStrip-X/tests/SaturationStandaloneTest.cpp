#include "../src/AnalogSaturationCircuit.h"
#include <cmath>
#include <iostream>
void run(float amt){
  AnalogSaturationCircuit s; s.prepare(48000,1);
  double diff=0,in2=0,out2=0; int n=48000*2;
  for(int i=0;i<n;++i){ float x=0.25f*std::sin(2.0*3.141592653589793*997.0*i/48000.0); float y=s.processSample(x,0,amt); if(i>48000){double d=y-x;diff+=d*d;in2+=x*x;out2+=y*y;}}
  std::cout<<amt<<" resid="<<std::sqrt(diff/48000.0)<<" gainDb="<<20*std::log10(std::sqrt(out2/in2))<<"\n";
}
int main(){for(float a: {0.0f,0.1f,0.25f,0.5f,0.75f,1.0f}) run(a);}
