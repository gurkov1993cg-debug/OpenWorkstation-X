#include "SslDynamicsCircuit.h"
#include "DynamicsCircuitTests.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <vector>

namespace
{
    double powerForDb (double db) { return std::pow (10.0, db / 10.0); }
    double gainDb (double gain) { return 20.0 * std::log10 (std::max (gain, 1.0e-30)); }

    SslDynamicsCircuit makeCircuit (SslDynamicsCircuit::Circuit c, double fs)
    {
        SslDynamicsCircuit d;
        d.setCircuit (c);
        d.prepare (fs);
        return d;
    }

    double measureAttack20Ms (SslDynamicsCircuit::Circuit c, double fs)
    {
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.compressorFastAttack = true;
        c.compressorThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = 10.0e6;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        auto d = makeCircuit (c, fs);
        for (int i = 0; i < static_cast<int> (0.2 * fs); ++i)
        {
            d.processPower (powerForDb (20.0));
            if (d.compressorReductionDb() >= 20.0)
                return 1000.0 * static_cast<double> (i) / fs;
        }
        return std::numeric_limits<double>::infinity();
    }

    double measuredKneeWidth (SslDynamicsCircuit::Circuit c)
    {
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = 10000.0; // k = 0.5; normalise slope below.
        SslDynamicsCircuit d;
        d.setCircuit (c);
        d.prepare (48000.0);

        const double k = c.gainDivider.bottomOhm / (c.gainDivider.topOhm + c.gainDivider.bottomOhm);
        const double vpd = c.detector.voltsPerDb;
        auto slope = [&] (double db)
        {
            const double h = 0.001;
            const double a = d.staticCompressorReductionCv ((db - h) * vpd);
            const double b = d.staticCompressorReductionCv ((db + h) * vpd);
            return ((b - a) / (2.0 * h * vpd)) / k;
        };

        double p10 = std::numeric_limits<double>::quiet_NaN();
        double p90 = std::numeric_limits<double>::quiet_NaN();
        const double thresholdDb = c.compressorThresholdCvV / vpd;
        for (double db = thresholdDb - 40.0; db <= thresholdDb + 40.0; db += 0.01)
        {
            const double s = slope (db);
            if (! std::isfinite (p10) && s >= 0.10) p10 = db;
            if (! std::isfinite (p90) && s >= 0.90) { p90 = db; break; }
        }
        return p90 - p10;
    }

    double measuredRatioFromAudioLaw (SslDynamicsCircuit::Circuit c, double lowDb, double highDb)
    {
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.compressorFastAttack = true;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        c.compressorTiming.releaseResistorOhm = 1000.0;
        auto settleOutputDb = [&] (double inputDb)
        {
            auto d = makeCircuit (c, 48000.0);
            float g = 1.0f;
            for (int i = 0; i < 48000; ++i)
                g = d.processPower (powerForDb (inputDb));
            return inputDb + gainDb (g);
        };
        const double outLow = settleOutputDb (lowDb);
        const double outHigh = settleOutputDb (highDb);
        return (highDb - lowDb) / (outHigh - outLow);
    }

    double releaseTailSeconds (SslDynamicsCircuit::Circuit c, double passageSeconds)
    {
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.compressorFastAttack = true;
        c.compressorThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = 10.0e6;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        const double fs = 48000.0;
        auto d = makeCircuit (c, fs);
        for (int i = 0; i < static_cast<int> (passageSeconds * fs); ++i)
            d.processPower (powerForDb (20.0));
        for (int i = 0; i < static_cast<int> (5.0 * fs); ++i)
        {
            d.processPower (powerForDb (-120.0));
            if (d.compressorReductionDb() <= 1.0)
                return static_cast<double> (i) / fs;
        }
        return 5.0;
    }

    double reductionAfterFiveMs (SslDynamicsCircuit::Circuit c, bool ramp)
    {
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.compressorFastAttack = false;
        c.compressorThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = 10.0e6;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        const double fs = 48000.0;
        auto d = makeCircuit (c, fs);
        const int n = static_cast<int> (0.005 * fs);
        for (int i = 0; i < n; ++i)
        {
            const double db = ramp ? -40.0 + 60.0 * static_cast<double> (i) / (n - 1) : 20.0;
            d.processPower (powerForDb (db));
        }
        return d.compressorReductionDb();
    }

    double measureGateOpenMs (SslDynamicsCircuit::Circuit c, bool fast, double fs)
    {
        c.compressorEnabled = false;
        c.gateEnabled = true;
        c.gateExpandMode = false;
        c.gateFastAttack = fast;
        c.gateThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gateRangeCvV = 40.0 * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = 1.0;
        c.gate.releaseResistorOhm = 100.0;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        auto d = makeCircuit (c, fs);
        for (int i = 0; i < static_cast<int> (0.05 * fs); ++i)
            d.processPower (powerForDb (-80.0));
        for (int i = 0; i < static_cast<int> (0.02 * fs); ++i)
        {
            d.processPower (powerForDb (0.0));
            if (d.gateReductionDb() <= 1.0)
                return 1000.0 * static_cast<double> (i) / fs;
        }
        return std::numeric_limits<double>::infinity();
    }
}

bool runDynamicsCircuitRegression()
{
    bool ok = true;
    SslDynamicsCircuit::Circuit base;

    // Calibration sanity: a detector truly at -20 dB with threshold -10 dB and
    // a 4:1 divider must not show several dB of GR. This catches V/dB offsets.
    {
        auto c = base;
        c.compressorEnabled = true;
        c.gateEnabled = false;
        c.compressorThresholdCvV = -10.0 * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = 30000.0;
        SslDynamicsCircuit d;
        d.setCircuit (c);
        d.prepare (48000.0);
        const double grDb = d.staticCompressorReductionCv (-20.0 * c.detector.voltsPerDb)
                          / c.detector.voltsPerDb;
        std::cout << "CAL detector -20 dB / threshold -10 dB / 4:1: GR=" << grDb << " dB\n";
        if (grDb > 0.20) ok = false;
    }

    // T1a: +10% timing capacitance must move measured attack time by +10% +/-0.5%.
    const double attack0 = measureAttack20Ms (base, 192000.0);
    auto capChanged = base;
    capChanged.compressorTiming.mainCapF *= 1.10;
    const double attack1 = measureAttack20Ms (capChanged, 192000.0);
    const double attackChange = 100.0 * (attack1 / attack0 - 1.0);
    std::cout << "T1 attack: " << attack0 << " ms -> " << attack1
              << " ms, change=" << attackChange << "%\n";
    if (std::abs (attackChange - 10.0) > 0.5) ok = false;

    // T1b: diode ideality changes the measured soft transition width.
    const double knee0 = measuredKneeWidth (base);
    auto diodeChanged = base;
    diodeChanged.kneeDiode.ideality *= 2.0;
    const double knee1 = measuredKneeWidth (diodeChanged);
    std::cout << "T1 diode: knee10-90 " << knee0 << " dB -> " << knee1 << " dB\n";
    if (std::abs (knee1 / knee0 - 2.0) > 0.03) ok = false;

    // T1c/T2: divider component sets the asymptotic audio ratio through the shared V/dB law.
    for (double rb : { 10000.0, 30000.0, 90000.0 })
    {
        auto c = base;
        c.compressorThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gainDivider.topOhm = 10000.0;
        c.gainDivider.bottomOhm = rb;
        const double expected = (c.gainDivider.topOhm + c.gainDivider.bottomOhm) / c.gainDivider.topOhm;
        const double measured = measuredRatioFromAudioLaw (c, 20.0, 40.0);
        const double errPct = 100.0 * std::abs (measured / expected - 1.0);
        std::cout << "T1/T2 ratio Rb=" << rb << ": expected=" << expected
                  << " measured=" << measured << " error=" << errPct << "%\n";
        if (errPct > 5.0) ok = false;
    }

    // T3: reservoir memory makes release after a long passage measurably longer.
    const double shortTail = releaseTailSeconds (base, 0.005);
    const double longTail = releaseTailSeconds (base, 1.0);
    std::cout << "T3 release memory: short=" << shortTail << " s long=" << longTail << " s\n";
    if (! (longTail > shortTail * 1.20)) ok = false;

    // T4: transient assist gives more early GR to a sharp edge than a slow ramp.
    const double sharpGr = reductionAfterFiveMs (base, false);
    const double rampGr = reductionAfterFiveMs (base, true);
    std::cout << "T4 program attack: sharp=" << sharpGr << " dB ramp=" << rampGr << " dB\n";
    if (! (sharpGr > rampGr + 1.0)) ok = false;

    // T5: hold comparator is at e^-1, so measured hold is the physical Rhold*Chold.
    {
        auto c = base;
        c.compressorEnabled = false;
        c.gateEnabled = true;
        c.gateExpandMode = false;
        c.gateThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gateRangeCvV = 40.0 * c.detector.voltsPerDb;
        c.gate.holdCapF = 1.0e-6;
        c.gate.holdResistorOhm = 250000.0;
        c.gate.releaseResistorOhm = 1000.0;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        const double fs = 192000.0;
        auto d = makeCircuit (c, fs);
        for (int i = 0; i < static_cast<int> (0.02 * fs); ++i) d.processPower (powerForDb (0.0));
        int closeSample = -1;
        for (int i = 0; i < static_cast<int> (1.0 * fs); ++i)
        {
            d.processPower (powerForDb (-60.0));
            if (d.gateReductionDb() > 0.1) { closeSample = i; break; }
        }
        const double measuredHold = static_cast<double> (closeSample) / fs;
        const double expectedHold = c.gate.holdResistorOhm * c.gate.holdCapF;
        std::cout << "T5 hold: expected=" << expectedHold << " s measured=" << measuredHold << " s\n";
        if (closeSample < 0 || std::abs (measuredHold / expectedHold - 1.0) > 0.02) ok = false;
    }

    // T5b: the gate opening path is calibrated independently of the compressor:
    // normal is about 1.5 ms for a 40 dB transition and FAST about 0.1 ms.
    {
        const double fs = 192000.0;
        const double normalMs = measureGateOpenMs (base, false, fs);
        const double fastMs = measureGateOpenMs (base, true, fs);
        std::cout << "T5b gate attack: normal=" << normalMs << " ms fast=" << fastMs << " ms\n";
        if (! (normalMs > 1.20 && normalMs < 1.80 && fastMs > 0.06 && fastMs < 0.16)) ok = false;
    }

    // T5c: OPEN and CLOSE thresholds are intentionally different.  After the
    // gate has opened, a level slightly below the OPEN threshold must remain
    // open; a clearly lower level must cross CLOSE and allow the gate to shut.
    {
        auto c = base;
        c.compressorEnabled = false;
        c.gateEnabled = true;
        c.gateExpandMode = false;
        c.gateThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gateRangeCvV = 40.0 * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = 1.0;
        c.gate.releaseResistorOhm = 1000.0;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        const double fs = 48000.0;
        auto d = makeCircuit (c, fs);
        for (int i = 0; i < static_cast<int> (0.05 * fs); ++i) d.processPower (powerForDb (0.0));
        for (int i = 0; i < static_cast<int> (0.10 * fs); ++i) d.processPower (powerForDb (-24.0));
        const double withinHysteresisGr = d.gateReductionDb();
        for (int i = 0; i < static_cast<int> (0.10 * fs); ++i) d.processPower (powerForDb (-40.0));
        const double belowCloseGr = d.gateReductionDb();
        std::cout << "T5c gate hysteresis: near-open GR=" << withinHysteresisGr
                  << " dB below-close GR=" << belowCloseGr << " dB\n";
        if (withinHysteresisGr > 0.20 || belowCloseGr < 30.0) ok = false;
    }

    // T6: EXPAND is fixed 1:2: ten dB below threshold adds ten dB of reduction.
    {
        auto c = base;
        c.compressorEnabled = false;
        c.gateEnabled = true;
        c.gateExpandMode = true;
        c.gateThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gateRangeCvV = 40.0 * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = 1.0;
        c.gate.releaseResistorOhm = 1000.0;
        c.gate.expanderTopOhm = 10000.0;
        c.gate.expanderBottomOhm = 10000.0;
        c.detector.averagingCapF = 1.0e-12;
        c.detector.timingCurrentA = 1.0e-6;
        auto d = makeCircuit (c, 48000.0);
        float g = 1.0f;
        for (int i = 0; i < 48000; ++i) g = d.processPower (powerForDb (-30.0));
        const double reduction = -gainDb (g);
        const double outputDb = -30.0 + gainDb (g);
        std::cout << "T6 expand: reduction=" << reduction << " dB output=" << outputDb << " dB\n";
        if (std::abs (reduction - 10.0) > 1.0 || std::abs (outputDb + 40.0) > 1.0) ok = false;
    }

    // T6b: the integrated gate path must preserve the 1:2 law for real audio.
    // The fast gate envelope is intentionally peak-like for opening speed, while
    // EXPAND depth is calibrated from the RMS detector. A -27 dBFS peak sine is
    // about -30 dBFS RMS, so at a -20 dB threshold it should settle near 10 dB GR.
    {
        auto c = base;
        c.compressorEnabled = false;
        c.gateEnabled = true;
        c.gateExpandMode = true;
        c.gateThresholdCvV = -20.0 * c.detector.voltsPerDb;
        c.gateRangeCvV = 40.0 * c.detector.voltsPerDb;
        c.gate.holdResistorOhm = 1.0;
        c.gate.releaseResistorOhm = 0.1 / c.gate.mainCapF;
        auto d = makeCircuit (c, 48000.0);
        const double peak = std::pow (10.0, -27.0 / 20.0);
        for (int i = 0; i < 96000; ++i)
        {
            const double x = peak * std::sin (2.0 * 3.14159265358979323846 * 1000.0
                                             * static_cast<double> (i) / 48000.0);
            d.processPowers (x * x, x * x);
        }
        const double reduction = d.gateReductionDb();
        std::cout << "T6b expand sine/RMS: reduction=" << reduction << " dB\n";
        if (reduction < 9.0 || reduction > 11.5) ok = false;
    }

    // T7: automatic make-up is threshold/ratio derived and remains below threshold.
    {
        auto gainAtThreshold = [&] (double thresholdDb)
        {
            auto c = base;
            c.gateEnabled = false;
            c.compressorEnabled = true;
            c.compressorThresholdCvV = thresholdDb * c.detector.voltsPerDb;
            c.compressorPanelThresholdCvV = thresholdDb * c.detector.voltsPerDb;
            c.gainDivider.topOhm = 10000.0;
            c.gainDivider.bottomOhm = 30000.0;
            c.detector.averagingCapF = 1.0e-12;
            c.detector.timingCurrentA = 1.0e-6;
            auto d = makeCircuit (c, 48000.0);
            float g = 1.0f;
            for (int i = 0; i < 48000; ++i) g = d.processPower (powerForDb (-60.0));
            return gainDb (g);
        };
        const double makeupAt0 = gainAtThreshold (0.0);
        const double makeupAtMinus20 = gainAtThreshold (-20.0);
        std::cout << "T7 auto makeup below threshold: threshold0=" << makeupAt0
                  << " dB threshold-20=" << makeupAtMinus20 << " dB\n";
        if (! (makeupAtMinus20 > makeupAt0 + 3.0)) ok = false;
    }

    // T8: full-scale square/impulse stress must stay finite at all supported rates.
    for (double fs : { 44100.0, 48000.0, 96000.0, 192000.0 })
    {
        auto c = base;
        c.compressorEnabled = true;
        c.gateEnabled = true;
        c.gateExpandMode = false;
        auto d = makeCircuit (c, fs);
        bool finite = true;
        for (int i = 0; i < static_cast<int> (2.0 * fs); ++i)
        {
            const double x = (i % 257 == 0) ? 1.0 : ((i & 1) ? 1.0 : -1.0);
            const float g = d.processPower (x * x);
            finite = finite && std::isfinite (g) && std::isfinite (d.compressorReductionDb())
                            && std::isfinite (d.gateReductionDb());
        }
        std::cout << "T8 stability fs=" << fs << " finite=" << (finite ? "yes" : "NO") << "\n";
        if (! finite) ok = false;
    }

    // T9: SSL PEAK mode is peak sensing + hard knee. At the exact threshold the
    // hard-knee path must produce zero reduction, while RMS mode retains its
    // diode-shaped soft transition. A short isolated peak must also drive the
    // PEAK detector more strongly than the averaged RMS detector.
    {
        auto rms = base;
        rms.compressorEnabled = true;
        rms.gateEnabled = false;
        rms.compressorPeakDetect = false;
        rms.compressorThresholdCvV = 0.0;
        rms.gainDivider.topOhm = 10000.0;
        rms.gainDivider.bottomOhm = 30000.0;
        auto peak = rms;
        peak.compressorPeakDetect = true;

        SslDynamicsCircuit drms; drms.setCircuit (rms); drms.prepare (48000.0);
        SslDynamicsCircuit dpeak; dpeak.setCircuit (peak); dpeak.prepare (48000.0);
        const double rmsAtKnee = drms.staticCompressorReductionCv (0.0) / rms.detector.voltsPerDb;
        const double peakAtKnee = dpeak.staticCompressorReductionCv (0.0) / peak.detector.voltsPerDb;

        peak.compressorThresholdCvV = -20.0 * peak.detector.voltsPerDb;
        rms.compressorThresholdCvV = -20.0 * rms.detector.voltsPerDb;
        dpeak.setCircuit (peak); dpeak.reset();
        drms.setCircuit (rms); drms.reset();
        // 8 ms high-crest burst: the RMS feed stays far below threshold while
        // the peak-envelope RC catches and holds the crest long enough for the
        // compressor timing network to respond.
        for (int i = 0; i < static_cast<int> (0.008 * 48000.0); ++i)
        {
            dpeak.processPowers (powerForDb (-60.0), powerForDb (0.0));
            drms.processPowers (powerForDb (-60.0), powerForDb (0.0));
        }
        const double peakGr = dpeak.compressorReductionDb();
        const double rmsGr = drms.compressorReductionDb();

        std::cout << "T9 PEAK: rms-knee=" << rmsAtKnee << " dB peak-knee=" << peakAtKnee
                  << " dB transient GR peak=" << peakGr << " rms=" << rmsGr << " dB\n";
        if (! (rmsAtKnee > 0.01 && std::abs (peakAtKnee) < 1.0e-12 && peakGr > rmsGr + 1.0))
            ok = false;
    }

    if (! ok)
    {
        std::cerr << "SSL dynamics circuit regression FAILED\n";
        return false;
    }

    std::cout << "SSL dynamics circuit regression PASSED\n";
    return true;
}
