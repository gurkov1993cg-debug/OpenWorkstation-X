#pragma once

bool runDynamicsCircuitRegression();
