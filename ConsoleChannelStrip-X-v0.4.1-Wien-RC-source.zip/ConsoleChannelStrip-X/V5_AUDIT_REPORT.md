# Console Channel Strip X — V5 audited candidate

This package keeps the approved V4/V5 sonic DSP character and the approved continuous-meter GUI style.

Audit fixes included:
- EQ/HPF/LPF inactive-state reset to prevent stale filter-memory bursts on re-enable.
- Stereo Image state reset when WIDTH is disabled, preventing stale delayed content on re-enable.
- Warm internal DSP state during plug-in bypass while output remains latency-aligned dry.
- Compressor and Gate GR peak capture for accurate meter reporting between GUI ticks.
- Gate GR remains truthful during silence/closed-gate attenuation.
- Regression coverage added for the corrected state-transition and metering cases.

Local audit results:
- EQ re-enable silence residual: 0
- Stereo re-enable silence residual: 0
- Bypass re-enable silence residual: 0
- Warm-bypass reference difference after unbypass: 0
- Compressor within-block peak test: current 13.4382 dB, captured peak 25.2266 dB
- Gate within-block peak capture test: captured peak 5.51171 dB
- Random stress: PASS, 1,290,240 stereo samples across 44.1/48/96/192 kHz and 32..1024 sample blocks
- ASan + UBSan random stress: PASS

No juce::dsp algorithms are used in the audio DSP path.

This source still requires the normal GitHub Windows/macOS workflows to pass before the binary artifacts are named GOTOVA VERCIYA 5.
