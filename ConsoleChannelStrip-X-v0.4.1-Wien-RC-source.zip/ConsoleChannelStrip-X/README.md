# Console Channel Strip X v0.4.1

Console Channel Strip X is an original C++17/JUCE 7.0.12 VST3 channel strip for Intel macOS. The project targets x86_64 and macOS 10.13+.

## v0.4.1 EQ model

The four EQ bands no longer use JUCE `makePeakFilter`, `makeLowShelf` or `makeHighShelf` designers. JUCE remains the plug-in/audio framework and the runtime IIR container; the EQ coefficients themselves come from an analog Wien/RC model and are transformed with the reviewed bilinear/prewarp path.

The bell topology is a Wien band network: series R1/C1, parallel R2/C2, with a damping resistance Rq in the feedback-dependent Q term. The frequency control selects resistance first; `w0` is then calculated from the RC network. The mid Q controls select a ganged `Rq/R` ratio; network Q is converted to the engraved effective-Q scale as a function of boost/cut gain.

All component values in `WienEqModel.cpp` are **[FIT]** values: values fitted to the documented E-series control ranges. They are **not SSL schematic values** and this project does not claim an exact component-for-component copy of an 82E02/82E242 module.

Fitted band coverage:

- LF: 100 nF / 100 nF, 53.05 kOhm .. 3.537 kOhm -> 30 .. 450 Hz
- LMF: 22 nF / 22 nF, 36.17 kOhm .. 2.894 kOhm -> 200 .. 2500 Hz
- HMF: 6.8 nF / 6.8 nF, 39.01 kOhm .. 3.344 kOhm -> 600 .. 7000 Hz
- HF: 2.2 nF / 2.2 nF, 48.23 kOhm .. 4.521 kOhm -> 1500 .. 16000 Hz

LF and HF shelves are genuine second-order analog prototypes with a second RC-derived damping network; they do not use a hidden corrective peak filter. At +12 dB the LF shelf is calibrated to +6 dB at the marked corner and approximately -1.5 dB at 2.2 times the corner at 48 kHz. The HF shelf uses the frequency-inverted topology; bilinear warping near Nyquist makes its pre-shelf feature sample-rate/frequency dependent and the tests report the measured value instead of hiding it with another EQ.

LF bell effective Q is 1.0 and HF bell effective Q is 1.7. LMF/HMF expose 0.10 .. 3.5 as the engraved range, but the passive equal-R/equal-C Wien equation with `Rq >= 0` has an honest physical minimum of about 0.167 at +12 dB. The implementation clamps to that physical limit instead of inventing a negative resistor. Maximum effective Q 3.5 is reached with a positive Rq and damping margin.

Black bell mode allows up to +/-18 dB; shelves are limited to +/-15 dB and Brown is limited to +/-15 dB. The frequency ranges remain 30..450 Hz, 200..2500 Hz, 600..7000 Hz and 1.5..16 kHz.

## Filters

HPF is corrected so the marked frequency behaves as the -3 dB point: Brown uses one second-order section at Q=0.7071 (about 12 dB/oct), while Black uses a Q=1.0 second-order section followed by a first-order section (about 18 dB/oct). LPF remains a second-order filter.

## Verification

`ConsoleChannelStripXSmokeTests` includes the previous channel-strip behaviour checks plus RC-specific regression tests:

- +10% C1 sensitivity on LF/LMF/HMF/HF must move centre frequency about -4.65% and network Q about +4.88%; this proves component values reach the transfer function.
- Band endpoints are calculated from `C1/C2/rMin/rMax`, not manual DSP frequency clamps.
- Effective-Q calibration and the passive minimum are reported.
- Pole stability is checked at 44.1, 48, 96 and 192 kHz over legal mid-band controls.
- Second-order shelf corner and pre-shelf feature are measured.
- LF/HF bell Q values are checked.

The stricter requested pole-radius margin `< 0.999` is reported separately: a stable low-frequency reciprocal cut at 96/192 kHz can exceed that arbitrary margin while remaining strictly inside the unit circle. The hard failure criterion is an actual pole radius `>= 1.0`; the worst measured margin is printed by CI.

## GUI

The editor has been rewritten as a custom hardware UI matching the approved compact console reference: INPUT, EQUALISER/FILTERS, DYNAMICS, a central INPUT/OUTPUT meter bridge and OUTPUT as the final panel. Gate/expander and compressor gain reduction are displayed separately inside their own dynamics subsections. The old VST Instruments / VST Effects / Loops / Browser utility column, plug-in SOLO button and duplicate dynamics buttons are not present.

The runtime editor contains no stock `juce::Slider`, `juce::Button`, `juce::TextButton`, `juce::ToggleButton` or LookAndFeel-skinned controls. JUCE remains the plug-in/window/graphics/event framework, while knobs, faders, illuminated switches, selectors and top-bar actions are purpose-built `Component` classes that write directly to the corresponding APVTS parameter with host automation gestures. CI enforces one visible custom parameter control per APVTS parameter and fails on missing/dead/overlapping controls or stock JUCE widgets.

The dynamics panel intentionally has no free compressor ATTACK knob, PEAK detector switch or free gate ATTACK knob: documented channel behaviour uses programme-dependent normal attack with dedicated FAST switching, so those controls would contradict the circuit model. Threshold, ratio, release, FAST, range and hold remain real controls and map to control voltages or components before entering DSP.

## Build process

The v0.4.1 workflow operates on a normal source tree. It only checks out, configures, builds, runs tests, verifies the Intel/macOS 10.13 binary target and packages the artifact. It does **not** rewrite or patch C++ source inside CI.

## Dynamics circuit revision

The dynamics section now uses `SslDynamicsCircuit`, a hand-written circuit-domain control path. JUCE is not used for compression, limiting, gating, envelope ballistics or gain-computer math.

The shared detector produces a control voltage at 6.1 mV/dB using a THAT-2252-family scale. Compressor and gate/expander reduction voltages are calculated separately, summed at one control node, and applied once through one dB-linear VCA law. Stereo linking uses mean-square channel energy, so anti-phase L/R audio cannot cancel in the detector.

The compressor ratio control maps to the lower resistor of a divider. Release maps to a physical release resistor against a fixed timing capacitor. `F.ATK` changes the charging resistor; normal attack uses a slow resistor plus an edge-sensitive series-C/R bypass and a reservoir branch, so its program dependence comes from stored charge rather than from an `attackMs` variable. Soft knee comes from an exponential diode equation. Automatic make-up remains threshold/ratio derived through a resistor divider even when the programme is below threshold.

The engraved compressor/gate threshold numbers are analogue panel levels, not dBFS. Plug-in integration therefore uses a **[CHOICE] calibration of panel 0 dB = -18 dBFS** before the detector comparator. This makes the compressor usable on normal digital recording levels without falsely extending the SSL-style -20..+10 panel scale. Automatic make-up is still derived from the panel threshold setting itself, not from the -18 dBFS calibration offset, so calibration does not create a default gain jump.

The old free compressor ATTACK knob and PEAK detector switch were removed because they are not part of the documented 4000 E channel behaviour being targeted here. The gate ATTACK knob was also removed; normal/FAST gate opening now comes from timing components.

No component value in this dynamics model is claimed as an original SSL 4000 E channel component unless explicitly marked as a sourced family specification. See `DYNAMICS_MODEL_REPORT.md` for the [SPEC]/[FIT]/[CHOICE] table and measured regression results.

### Reference GUI / zoom revision
The v0.4.1 editor now follows the approved 1536x1024 dark console reference with a table-driven layout and fully custom control renderer. The window is resizable at a fixed 3:2 aspect ratio and includes working zoom controls (50%-150%). Visible controls are APVTS/DSP-backed; the GUI intentionally omits fake 48 V control, MUTE/SOLO browser-style controls, and a decorative free compressor-attack knob. A real -20 dB software input pad, stereo output balance PAN, and independent L/R input/output metering were added for the visible functions that the reference requires.
