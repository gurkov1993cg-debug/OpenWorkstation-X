# Console Channel Strip X v0.4.1

Console Channel Strip X is an original C++17/JUCE 7.0.12 VST3 channel strip for Intel macOS. The project targets x86_64 and macOS 10.13+.

## v0.4.1 EQ model

The active four-band EQ path is now `SslEseriesEqModel`, with `WienEqModel` retained unchanged as an immediate rollback/safety path. JUCE remains only the plug-in/host/GUI infrastructure. The complete audio DSP path now uses project-owned code: custom biquad execution, custom coefficient smoothing, custom HPF/LPF designers, the schematic-derived E-series EQ model, dynamics and saturation. No `juce::dsp` runtime/filter designer is used in the effects path.

### Schematic-grounded E-series core

The frequency-setting networks are taken from the published SSL drawings `T82002-71` (82E02 / Brown) and `T82242-70` (82E242 / Black). The code records the actual fixed resistors, 50 kOhm dual frequency pots and timing capacitors shown around each band. Examples used directly by the model include Brown HMF `4.3 kOhm + 50 kOhm` with `4.7 nF`, Brown LMF `4.3 kOhm + 50 kOhm` with `15 nF`, Black HMF `3.0 kOhm + 50 kOhm` with `4.7 nF`, Black LMF `3.0 kOhm + 50 kOhm` with `22 nF`, and the LF `33 nF + 47 nF` timing branch.

The HMF/LMF E-series bell response is reciprocal and constant-bandwidth. The previous passive equal-R/equal-C Wien approximation imposed a false low-Q floor; the active feedback model allows the exposed 0.10..3.5 Q control to reach its requested effective Q instead of being clamped by a fictitious passive network.

The mid-band Q calibration also compensates the bilinear transform's bandwidth warping. Centre-frequency prewarp alone kept 10 kHz in the right place but made a marked Q=1 read about 1.55 at 44.1 kHz. The new project-owned correction solves the exact tan() frequency mapping for the analog prototype Q before coefficient generation; Q=1 and Q=3.5 now measure correctly at 10 kHz for 44.1/48 kHz. Extremely wide settings that mathematically require bandwidth beyond Nyquist are left at the widest representable digital response rather than faking an impossible bandwidth.

LF/HF bell mode now uses a separate fixed-network-Q law. The component damping is not multiplied by sqrt(gain), so the audible bell becomes progressively wider as boost increases, as expected when the damping is set by fixed hardware components. For the Black 82E242 revision, the fixed network-Q values follow the 15-Nov-1985 Rev.4 ECO: HF 1.0 and LF 1.7. The Brown fixed bell network is represented with the approximately 0.6 value already used by the schematic model.

HF and LF shelf mode uses a second-order reciprocal shelf. Its damping Q is split into independent LF/HF constants and is currently set to `1.2315606122497924`, deliberately preserving the accepted shelf voicing of the previous working Wien model at all reachable RC frequencies. The drawing-derived 80 nF Brown LF timing core physically bottoms out at about 36.64 Hz; the public 30 Hz control is retained for session/GUI compatibility and therefore resolves to that physical limit rather than introducing a fitted capacitor.

This is a **schematic-grounded transfer model**, not a claim that every NE5534 non-ideality, component tolerance, PCB parasitic or calibration-trimmer position of one physical console has been measured. The important difference from the old model is that the frequency RC cores and E-series response family now come from the actual drawings rather than fitted fictitious R/C tables.

### Rollback protection

`WienEqModel.cpp/.h` remains in the source unchanged. `DspEngine` calculates the legacy coefficients alongside the new ones. If a new coefficient set is non-finite or unstable, the engine automatically uses the legacy coefficient set for that band. A complete rollback build can also be forced with the compile definition `CONSOLE_EQ_FORCE_LEGACY_WIEN`. This makes field testing reversible without deleting the old sound.

The public parameter IDs, GUI layout and current 30..450 / 200..2500 / 600..7000 / 1.5..16 kHz control ranges are retained for session and GUI compatibility. The Black schematic table also records the wider Rev.4 ECO ranges internally for verification.

## Filters

HPF is corrected so the marked frequency behaves as the -3 dB point: Brown uses one second-order section at Q=0.7071 (about 12 dB/oct), while Black uses a Q=1.0 second-order section followed by a first-order section (about 18 dB/oct). LPF remains a second-order filter.

## Verification

`ConsoleChannelStripXSmokeTests` keeps all previous dynamics/saturation/GUI-facing regressions and all legacy Wien tests so the rollback path cannot silently rot. It also validates the new schematic EQ path:

- Brown/Black RC endpoint sanity is derived from the drawing resistor/capacitor values.
- HMF/LMF use the reciprocal constant-bandwidth law with no passive-Wien Q floor.
- LF/HF fixed-network bells widen with boost instead of being forced to constant effective Q.
- Second-order HF/LF shelves are exactly half the requested gain in dB at the marked corner and preserve the accepted Wien shelf shoulder/dip.
- Pole stability is checked at 44.1, 48, 96 and 192 kHz over the legal plug-in control ranges.
- A dedicated high-frequency Q regression verifies 10 kHz Q calibration at 44.1/48 kHz so centre-only prewarp cannot reintroduce narrowed bells.
- A DspEngine response is compared directly against `SslEseriesEqModel` so CI fails if the build accidentally uses the legacy fallback all the time.
- The preserved `WienEqModel` component-sensitivity, endpoint, shelf and pole tests still run as rollback verification.

A separate pure-C++ standalone validation was also run locally for the new model across the same sample-rate range; the tested legal settings remained finite and strictly stable. Full JUCE/VST3 and old-mac deployment validation still belongs to the GitHub macOS build workflow.

## GUI

The editor has been rewritten as a custom hardware UI matching the approved compact console reference: INPUT, EQUALISER/FILTERS, DYNAMICS, a central INPUT/OUTPUT meter bridge and OUTPUT as the final panel. Gate/expander and compressor gain reduction are displayed separately inside their own dynamics subsections. The old VST Instruments / VST Effects / Loops / Browser utility column, plug-in SOLO button and duplicate dynamics buttons are not present.

The runtime editor contains no stock `juce::Slider`, `juce::Button`, `juce::TextButton`, `juce::ToggleButton` or LookAndFeel-skinned controls. JUCE remains the plug-in/window/graphics/event framework, while knobs, faders, illuminated switches, selectors and top-bar actions are purpose-built `Component` classes that write directly to the corresponding APVTS parameter with host automation gestures. CI enforces one visible custom parameter control per APVTS parameter and fails on missing/dead/overlapping controls or stock JUCE widgets.

The dynamics panel intentionally has no free compressor ATTACK knob, PEAK detector switch or free gate ATTACK knob: documented channel behaviour uses programme-dependent normal attack with dedicated FAST switching, so those controls would contradict the circuit model. Threshold, ratio, release, FAST, range and hold remain real controls and map to control voltages or components before entering DSP.

## Build process

The v0.4.1 workflow operates on a normal source tree. It only checks out, configures, builds, runs tests, verifies the Intel/macOS 10.13 binary target and packages the artifact. It does **not** rewrite or patch C++ source inside CI.

## Dynamics circuit revision

The dynamics section now uses `SslDynamicsCircuit`, a hand-written circuit-domain control path. JUCE is not used for compression, limiting, gating, envelope ballistics or gain-computer math.

The shared detector produces a control voltage at 6.1 mV/dB using a THAT-2252-family scale. Compressor and gate/expander reduction voltages are calculated separately, summed at one control node, and applied once through one dB-linear VCA law. Stereo linking uses mean-square channel energy, so anti-phase L/R audio cannot cancel in the detector.

The compressor ratio control maps to the lower resistor of a divider. Release maps to a physical release resistor against a fixed timing capacitor. `F.ATK` changes the charging resistor; normal attack uses a slow resistor plus an edge-sensitive series-C/R bypass and a reservoir branch, so its program dependence comes from stored charge rather than from an `attackMs` variable. Soft knee comes from an exponential diode equation. The compressor does **not** add internal automatic make-up; whole-strip loudness matching is handled later by GLOBAL AUTO LEVEL.

The engraved compressor/gate threshold numbers are analogue panel levels, not dBFS. Plug-in integration therefore uses a **[CHOICE] calibration of panel 0 dB = -18 dBFS** before the detector comparator. This makes the compressor usable on normal digital recording levels without falsely extending the SSL-style -20..+10 panel scale. No compressor make-up is derived from this calibration; GLOBAL AUTO LEVEL performs the optional final loudness match.

The old free compressor ATTACK knob and PEAK detector switch were removed because they are not part of the documented 4000 E channel behaviour being targeted here. The gate ATTACK knob was also removed; normal/FAST gate opening now comes from timing components.

No component value in this dynamics model is claimed as an original SSL 4000 E channel component unless explicitly marked as a sourced family specification. See `DYNAMICS_MODEL_REPORT.md` for the [SPEC]/[FIT]/[CHOICE] table and measured regression results.

### Reference GUI / zoom revision
The v0.4.1 editor now follows the approved 1536x1024 dark console reference with a table-driven layout and fully custom control renderer. The editor uses a fixed 1536x1024 design surface with explicit working zoom controls (50%-150%); free host drag-resizing is disabled so the hardware geometry cannot drift. Visible controls are APVTS/DSP-backed; the GUI intentionally omits fake 48 V control, MUTE/SOLO browser-style controls, and a decorative free compressor-attack knob. A real -20 dB software input pad, stereo output balance PAN, and independent L/R input/output metering were added for the visible functions that the reference requires.


## Current usability additions
- HMF/LMF Q controls enlarged for clearer adjustment.
- Double-click a numeric knob/fader value to type an exact value; `k` suffix is accepted for kHz.
- AUTO LEVEL is enabled by default in the plug-in and matches the processed wet RMS to the raw input RMS before manual Output Level/Pan. It freezes while the gate is actively reducing so it cannot undo the gate.
- Compressor AUTO MAKE-UP is removed from the shared VCA control node; compressor and gate contribute attenuation only.
- SAT GAIN adds -12..+18 dB of smoothed pre-gain immediately before the saturation circuit, with 0 dB neutral.
- PRE-SAT meter reads the true peak after SAT GAIN and before the nonlinear circuit/AUTO LEVEL, with peak hold so hot drive remains visible.
- EQ gain LED rings are centre-relative: at exactly 0 dB no coloured boost/cut segments are lit; coloured segments appear only when a band is actually boosted or cut.
- Panel push-buttons/selectors are rendered as circular hardware switches with adjacent legends; utility toolbar actions remain compact controls.


## Saturation / Stereo Image
- The former CHANNEL MODE control has been removed. The strip processes normal mono or stereo programme paths and no longer exposes MID/SIDE processor targeting.
- SATURATION is a dedicated pure-C++ nonlinear circuit stage placed before AUTO LEVEL. Its core solves an emitter-degenerated bipolar differential-pair transfer with Newton iterations, controlled device mismatch, finite nonlinear bandwidth and a DC servo. The static nonlinear core is evaluated at 4x through project-owned 193-tap linear-phase equiripple interpolation/decimation FIRs. The generated nonlinear residual is band-limited before returning to base rate, while the programme path is delayed by the exact 48-sample group delay so dry/wet phase stays coherent. JUCE oversampling/filter DSP is not used; JUCE only reports the fixed latency to the host. CI checks both alias rejection and tonal preservation against the accepted v1 circuit.
- STEREO IMAGE is an original micro-pitch widening implementation inspired by the public MicroShift concept: WIDTH, FOCUS, DETUNE, and DELAY. It uses a focused pair of time-varying delays to generate side energy and supports mono-input/stereo-output layouts. FOCUS is intentionally user-facing: turning it up widens progressively more of the spectrum; turning it down keeps progressively more content centred.

Gate/expander now uses its own fast envelope, variable OPEN/CLOSE hysteresis, and calibrated approximately 1.5 ms normal / 0.1 ms FAST opening behaviour. Compressor and EQ algorithms are unchanged by this gate revision.
