# Console Channel Strip X v0.4.1

Console Channel Strip X is an original C++17/JUCE 7.0.12 VST3 channel strip for Intel macOS. The project targets x86_64 and macOS 10.13+.

## v0.4.1 EQ model

The four EQ bands no longer use JUCE `makePeakFilter`, `makeLowShelf` or `makeHighShelf` designers. JUCE remains the plug-in/audio framework and the runtime IIR container; the EQ coefficients themselves come from an analog Wien/RC model and are transformed with the reviewed bilinear/prewarp path.

The bell topology is a Wien band network: series R1/C1, parallel R2/C2, with a damping resistance Rq in the feedback-dependent Q term. The frequency control selects resistance first; `w0` is then calculated from the RC network. The mid Q controls select a ganged `Rq/R` ratio; network Q is converted to the engraved effective-Q scale as a function of boost/cut gain.

All component values in `WienEqModel.cpp` are **[FIT]** values: values fitted to the documented E-series control ranges. They are **not SSL schematic values** and this project does not claim an exact component-for-component copy of an 82E02/82E242 module.

Fitted band coverage:

- LF: 100 nF / 100 nF, 53.05 kOhm .. 3.537 kOhm -> 30 .. 450 Hz
- LMF: 22 nF / 22 nF, 36.17 kOhm .. 2.894 kOhm -> 200 .. 2500 Hz
- HMF: 6.8 nF / 6.8 nF, 39.01 kOhm .. 3.344 kOhm -> 600 .. 7000 Hz
- HF: 2.2 nF / 2.2 nF, 48.23 kOhm .. 4.521 kOhm -> 1500 .. 16000 Hz

LF and HF shelves are genuine second-order analog prototypes with a second RC-derived damping network; they do not use a hidden corrective peak filter. At +12 dB the LF shelf is calibrated to +6 dB at the marked corner and approximately -1.5 dB at 2.2 times the corner at 48 kHz. The HF shelf uses the frequency-inverted topology; bilinear warping near Nyquist makes its pre-shelf feature sample-rate/frequency dependent and the tests report the measured value instead of hiding it with another EQ.

LF bell effective Q is 1.0 and HF bell effective Q is 1.7. LMF/HMF expose 0.10 .. 3.5 as the engraved range, but the passive equal-R/equal-C Wien equation with `Rq >= 0` has an honest physical minimum of about 0.167 at +12 dB. The implementation clamps to that physical limit instead of inventing a negative resistor. Maximum effective Q 3.5 is reached with a positive Rq and damping margin.

Black bell mode allows up to +/-18 dB; shelves are limited to +/-15 dB and Brown is limited to +/-15 dB. The frequency ranges remain 30..450 Hz, 200..2500 Hz, 600..7000 Hz and 1.5..16 kHz.

## Filters

HPF is corrected so the marked frequency behaves as the -3 dB point: Brown uses one second-order section at Q=0.7071 (about 12 dB/oct), while Black uses a Q=1.0 second-order section followed by a first-order section (about 18 dB/oct). LPF remains a second-order filter.

## Verification

`ConsoleChannelStripXSmokeTests` includes the previous channel-strip behaviour checks plus RC-specific regression tests:

- +10% C1 sensitivity on LF/LMF/HMF/HF must move centre frequency about -4.65% and network Q about +4.88%; this proves component values reach the transfer function.
- Band endpoints are calculated from `C1/C2/rMin/rMax`, not manual DSP frequency clamps.
- Effective-Q calibration and the passive minimum are reported.
- Pole stability is checked at 44.1, 48, 96 and 192 kHz over legal mid-band controls.
- Second-order shelf corner and pre-shelf feature are measured.
- LF/HF bell Q values are checked.

The stricter requested pole-radius margin `< 0.999` is reported separately: a stable low-frequency reciprocal cut at 96/192 kHz can exceed that arbitrary margin while remaining strictly inside the unit circle. The hard failure criterion is an actual pole radius `>= 1.0`; the worst measured margin is printed by CI.

## GUI

The approved v0.2.8 SSL-style layout is preserved. v0.4.1 only changes the version label and the mid-Q scale labels to 0.10..3.5; no layout redesign is introduced.

## Build process

The v0.4.1 workflow operates on a normal source tree. It only checks out, configures, builds, runs tests, verifies the Intel/macOS 10.13 binary target and packages the artifact. It does **not** rewrite or patch C++ source inside CI.
