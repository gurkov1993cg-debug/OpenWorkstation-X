# GUI LOCK — v0.4.1 custom hardware editor

This is the approved visual direction from the 2026-09-03 reference: a compact, dark, hardware-style console channel strip. The window ends at OUTPUT. There is no DAW/browser utility column and no empty fifth utility area.

Fixed composition at 1536 × 942:

1. INPUT
2. EQUALISER + FILTERS
3. DYNAMICS
4. INPUT / GR / OUTPUT meter bridge
5. OUTPUT (last panel; window ends here)

Rules:

- No VST Instruments, VST Effects, Loops & Samples, File Browser, Favorites or fake DAW-browser controls.
- No SOLO inside the plug-in; track solo belongs to the host.
- No duplicate EXPAND or FAST ATTACK controls in OUTPUT. EXPAND belongs only to Gate/Expander; compressor/gate FAST controls stay only in their dynamics sections.
- ROUTING and CHANNEL MODE live at the bottom of OUTPUT.
- No fake S/C LISTEN button until a real detector-listen path exists in DSP.
- No free compressor ATTACK knob and no free gate ATTACK knob; normal attack is programme-dependent and FAST selects the actual component timing branch.
- No real third-party company logos/trademark artwork; use Channel Strip X / OpenWorkstation X branding only.
- Every APVTS parameter has exactly one parameter control in the editor. The top POWER control is an intentional second presentation of BYPASS and has no APVTS component ID.
- No visible raw JUCE text boxes.
- No stock `juce::Slider`, `juce::Button`, `juce::TextButton`, `juce::ToggleButton` or LookAndFeel skin controls in the runtime editor. JUCE provides Component/Graphics/mouse events and the plug-in shell only; knobs, faders, lamps, selectors and action buttons are custom components.
- All custom controls send proper host parameter gestures and follow host automation on repaint.
- Compressor and gate gain-reduction metering displays actual DSP reduction. The central GR column is the sum at the shared VCA control node; the footer readout also shows compressor and gate contributions separately.
- The CI GUI test must fail if a stock JUCE widget returns, if an APVTS control is missing/dead/overlapping/outside the editor, or if ROUTING/CHANNEL MODE leave OUTPUT.
- The real C++ editor is rendered by CI to `gui-preview-v0.4.1.png`; generated concept art is reference only and is never used as a runtime background asset.
