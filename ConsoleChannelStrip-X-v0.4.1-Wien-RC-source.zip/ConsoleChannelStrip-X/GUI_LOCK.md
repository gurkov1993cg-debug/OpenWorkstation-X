# GUI LOCK — v0.4.1 reference hardware editor

Approved runtime direction: clear, spacious dark hardware-style Console Channel Strip X. The window ends at OUTPUT. No DAW/browser utility column exists and no generated reference bitmap is used as a runtime skin.

Design coordinate space: 1536 × 1024, fixed 3:2 aspect ratio.

Panel order:
1. INPUT
2. EQUALISER + FILTERS
3. DYNAMICS
4. INPUT / OUTPUT meter bridge; GATE GR and COMP GR live inside their own dynamics subsections
5. OUTPUT

Rules:

- Runtime GUI is drawn by custom C++ components. No stock `juce::Slider`, `juce::Button`, `juce::TextButton`, `juce::ToggleButton`, or standard LookAndFeel drawing is used.
- Layout geometry lives in KnobSpec/FaderSpec/ButtonSpec/ChoiceSpec/SectionSpec tables. `resized()` iterates the tables rather than scattering magic coordinates.
- Rotary knobs use strictly circular, concentric hardware geometry with a neutral metal skirt, narrow coloured accent ring, dark anodised cap, segmented position ring, high-contrast pointer and larger custom value boxes. Octagonal/asymmetric knob bodies are not allowed.
- UI scale is controlled explicitly from 50% to 150% with `- / 100% / +` controls. Free host drag-resizing is disabled so the fixed hardware geometry remains deterministic.
- No VST Instruments, VST Effects, Loops & Samples, File Browser, Favorites, MUTE or SOLO controls are present in the approved GUI.
- The software does not pretend to control hardware phantom power. INPUT exposes the real LINE/MIC model, polarity and a real -20 dB DSP pad.
- No decorative compressor ATTACK knob. Normal compressor attack is program-dependent and FAST ATTACK switches the real component timing branch.
- Gate/expander uses real THRESHOLD, RANGE, HOLD, RELEASE, EXPAND, FAST ATTACK and IN controls only.
- Compressor ratio is controlled by one continuous RATIO knob. The redundant fixed ratio-tab aliases have been removed.
- Compressor automatic make-up is intentionally absent. GLOBAL AUTO LEVEL is the only automatic loudness compensation stage.
- INPUT and OUTPUT meters are genuine stereo L/R measurements. Gate/expander GR and compressor GR are two matched large 0–40 dB meters inside their respective dynamics subsections; their readings are never summed in the GUI.
- OUTPUT contains real LEVEL, real stereo-balance PAN, then the saturation signal-flow controls in the visual order SAT GAIN (-12..+18 dB) → SATURATION, plus a PRE-SAT peak meter, and the STEREO IMAGE controls. MUTE/SOLO are deliberately absent.
- OPENWORKSTATION X is the only centre footer branding. Third-party company names/logos from the visual reference are not reproduced.
- The top POWER action controls real bypass. INIT restores parameter defaults. Undo/Redo remain functional.
- CI must fail for stock JUCE widgets, dead visible APVTS controls, duplicate visible IDs, overlaps, out-of-bounds controls, fake MUTE/SOLO return, broken zoom, broken POWER/bypass wiring, or broken threshold calibration.
- CI writes `gui-preview-v0.4.1.png` from the real C++ editor so the compiled UI, not concept art, is what gets reviewed.
- EQ gain ring rule: HF/HMF/LMF/LF gain rings are dark at the 0 dB default. Coloured segments illuminate only from the 0 dB centre toward a real boost or cut value.
- Normal panel push-buttons and model selectors use circular physical switch faces with adjacent text labels. Wide controls such as AUTO LEVEL keep a full-width illuminated face so they never collapse into a small dot.
- Generic active switches use a cold ice-blue/white illumination. Orange/amber is reserved for band/saturation colour coding rather than general ON-state indication.
- The PRE-SAT meter is sampled after SAT GAIN and before the saturation nonlinearity and GLOBAL AUTO LEVEL, so level matching cannot hide an over-driven saturation input.

