# GUI LOCK — v0.4.1 reference hardware editor

Approved runtime direction: compact dark hardware-style Console Channel Strip X. The window ends at OUTPUT. No DAW/browser utility column exists and no generated reference bitmap is used as a runtime skin.

Design coordinate space: 1536 × 1024, fixed 3:2 aspect ratio.

Panel order:
1. INPUT
2. EQUALISER + FILTERS
3. DYNAMICS
4. INPUT / GR / OUTPUT meter bridge
5. OUTPUT

Rules:

- Runtime GUI is drawn by custom C++ components. No stock `juce::Slider`, `juce::Button`, `juce::TextButton`, `juce::ToggleButton`, or standard LookAndFeel drawing is used.
- Layout geometry lives in KnobSpec/FaderSpec/ButtonSpec/ChoiceSpec/SectionSpec tables. `resized()` iterates the tables rather than scattering magic coordinates.
- Knobs are dark matte hardware controls with eleven external tick marks, long pointer lines and custom optional value boxes.
- UI is resizable from 50% to 150% with a fixed 3:2 aspect ratio. `- / 100% / +` zoom controls are functional and the corner resizer permits continuous scaling in the same limits.
- No VST Instruments, VST Effects, Loops & Samples, File Browser, Favorites, MUTE or SOLO controls are present in the approved GUI.
- The software does not pretend to control hardware phantom power. INPUT exposes the real LINE/MIC model, polarity and a real -20 dB DSP pad.
- No decorative compressor ATTACK knob. Normal compressor attack is program-dependent and FAST ATTACK switches the real component timing branch.
- Gate/expander uses real THRESHOLD, RANGE, HOLD, RELEASE, EXPAND, FAST ATTACK and IN controls only.
- Compressor ratio has one continuous knob plus six functional ratio-tab aliases. The tabs write the same APVTS ratio parameter and are not decorative.
- Authentic automatic make-up remains active with the compressor and is shown as an indicator, not a fake toggle.
- INPUT and OUTPUT meters are genuine stereo L/R measurements. GR shows the summed compressor + gate reduction controlling the shared VCA.
- OUTPUT contains real LEVEL, real stereo-balance PAN and CHANNEL MODE. MUTE/SOLO are deliberately absent.
- OPENWORKSTATION X is the only centre footer branding. Third-party company names/logos from the visual reference are not reproduced.
- The top POWER action controls real bypass. INIT restores parameter defaults. Undo/Redo remain functional.
- CI must fail for stock JUCE widgets, dead visible APVTS controls, duplicate visible IDs, overlaps, out-of-bounds controls, fake MUTE/SOLO return, broken ratio tabs, broken zoom, broken POWER/bypass wiring, or broken threshold calibration.
- CI writes `gui-preview-v0.4.1.png` from the real C++ editor so the compiled UI, not concept art, is what gets reviewed.
