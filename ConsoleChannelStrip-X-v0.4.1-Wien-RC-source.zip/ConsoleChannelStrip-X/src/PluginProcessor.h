#pragma once
#include <JuceHeader.h>
#include "DspEngine.h"

class ConsoleChannelStripXAudioProcessor final : public juce::AudioProcessor
{
public:
    ConsoleChannelStripXAudioProcessor();
    ~ConsoleChannelStripXAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.10; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;
    juce::AudioProcessorParameter* getBypassParameter() const override;

    juce::AudioProcessorValueTreeState& parameters() noexcept { return apvts; }
    void undo() { undoManager.undo(); }
    void redo() { undoManager.redo(); }
    void resetParametersToDefaults();
    float compressorMeter() const noexcept { return engine.getCompressorGainReductionDb(); }
    float gateMeter() const noexcept { return engine.getGateGainReductionDb(); }
    float inputMeter() const noexcept { return engine.getInputPeakDb(); }
    float outputMeter() const noexcept { return engine.getOutputPeakDb(); }
    float inputMeterL() noexcept { return engine.consumeInputLeftPeakDb(); }
    float inputMeterR() noexcept { return engine.consumeInputRightPeakDb(); }
    float outputMeterL() noexcept { return engine.consumeOutputLeftPeakDb(); }
    float outputMeterR() noexcept { return engine.consumeOutputRightPeakDb(); }
    float preSaturationMeter() noexcept { return engine.consumePreSaturationPeakDb(); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    DspEngine::Params readParams() const;

    juce::UndoManager undoManager;
    juce::AudioProcessorValueTreeState apvts;
    DspEngine engine;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessor)
};
