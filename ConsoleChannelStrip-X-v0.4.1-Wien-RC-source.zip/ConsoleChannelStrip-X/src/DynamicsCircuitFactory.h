#pragma once

#include "SslDynamicsCircuit.h"
#include <algorithm>

namespace DynamicsCircuitFactory
{
    // Single source of truth for translating the plugin panel controls into the
    // circuit-domain dynamics model. Tests use this same function so the plugin
    // and regression suite cannot silently drift to different component values.
    inline SslDynamicsCircuit::Circuit fromPanel (float compThresholdDb, float compRatioPanel,
                                                   float compReleaseSeconds, bool compFast,
                                                   bool compPeak, bool compOn,
                                                   float gateThresholdDb, float gateRangeDb,
                                                   float gateHoldSeconds, float gateReleaseSeconds,
                                                   bool gateFast, bool gateExpand, bool gateOn)
    {
        SslDynamicsCircuit::Circuit c;

        // Detector/VCA scale is common to the entire control path. [SPEC-FAMILY]
        constexpr double voltsPerDb = 0.0061;
        c.detector.voltsPerDb = voltsPerDb;
        c.detector.averagingCapF = 10.0e-9;   // [CHOICE]
        c.detector.timingCurrentA = 25.9e-9;  // [FIT] -> about 10 ms detector averaging

        // COMP PEAK uses a separate full-wave peak-envelope RC. The values are
        // [FIT], chosen to preserve short crests long enough for the existing
        // programme-dependent compressor timing network to respond audibly.
        c.detector.peakEnvelopeCapF = 100.0e-9;
        c.detector.peakChargeResistorOhm = 2200.0;       // ~0.22 ms charge
        c.detector.peakDischargeResistorOhm = 470000.0; // ~47 ms discharge

        // The console panel scale is analogue operating level, not dBFS. [CHOICE]
        // Calibrate panel 0 dB to -18 dBFS so ordinary recorded material can reach
        // useful 7-10 dB reductions without driving the plug-in near full scale.
        // This offset is a plug-in reference calibration, not an invented SSL part.
        constexpr double panelZeroReferenceDbFs = -18.0; // [CHOICE]
        c.compressorThresholdCvV = (static_cast<double> (compThresholdDb) + panelZeroReferenceDbFs) * voltsPerDb;
        // Retained only for backward-compatible circuit/state structure. The
        // compressor no longer creates make-up gain; GLOBAL AUTO LEVEL performs
        // whole-strip level matching after EQ/dynamics/stereo/saturation.
        c.compressorPanelThresholdCvV = static_cast<double> (compThresholdDb) * voltsPerDb;
        c.compressorEnabled = compOn;
        c.compressorFastAttack = compFast;
        c.compressorPeakDetect = compPeak;

        // Panel ratio selects the lower resistor of the gain-computer divider.
        // ratio = (Rt + Rb) / Rt; the panel's INF end uses a finite laboratory
        // approximation of 10 Mohm rather than a magic slope constant.
        c.gainDivider.topOhm = 10000.0; // [CHOICE]
        if (compRatioPanel >= 19.95f)
            c.gainDivider.bottomOhm = 10.0e6; // [CHOICE] practical limiter approximation
        else
            c.gainDivider.bottomOhm = c.gainDivider.topOhm
                                    * std::max (0.0, static_cast<double> (compRatioPanel) - 1.0);

        // RELEASE panel moves the release resistor; the timing capacitor is fixed.
        c.compressorTiming.mainCapF = 1.0e-6;
        c.compressorTiming.releaseResistorOhm = std::max (1.0, static_cast<double> (compReleaseSeconds)
                                                              / c.compressorTiming.mainCapF);

        // Gate/expander uses the same final VCA control node. Gate opening/closing
        // is driven by its own fast envelope while EXPAND depth uses the linked RMS
        // detector so the fixed 1:2 law remains calibrated in RMS terms.
        c.gateEnabled = gateOn;
        c.gateFastAttack = gateFast;
        c.gateExpandMode = gateExpand;
        c.gateThresholdCvV = (static_cast<double> (gateThresholdDb) + panelZeroReferenceDbFs) * voltsPerDb;
        c.gateRangeCvV = std::max (0.0, static_cast<double> (gateRangeDb)) * voltsPerDb;
        c.gate.releaseResistorOhm = std::max (1.0, static_cast<double> (gateReleaseSeconds) / c.gate.mainCapF);
        c.gate.holdResistorOhm = std::max (1.0, static_cast<double> (gateHoldSeconds) / c.gate.holdCapF);
        return c;
    }
}
