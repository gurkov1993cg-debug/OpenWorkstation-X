#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <vector>

namespace consoledsp
{
    constexpr double pi = 3.141592653589793238462643383279502884;
    constexpr double twoPi = 2.0 * pi;

    inline float clampf (float value, float lo, float hi) noexcept
    {
        return std::clamp (value, lo, hi);
    }

    inline double clampd (double value, double lo, double hi) noexcept
    {
        return std::clamp (value, lo, hi);
    }

    inline float dbToGain (float db) noexcept
    {
        return std::pow (10.0f, db * 0.05f);
    }

    inline float gainToDb (float gain, float floorDb = -100.0f) noexcept
    {
        const float floorGain = std::pow (10.0f, floorDb * 0.05f);
        if (! std::isfinite (gain) || gain <= floorGain)
            return floorDb;
        return 20.0f * std::log10 (gain);
    }

    struct BiquadCoefficients
    {
        double b0 = 1.0;
        double b1 = 0.0;
        double b2 = 0.0;
        double a1 = 0.0;
        double a2 = 0.0;
    };

    inline BiquadCoefficients firstOrderHighPass (double sampleRate, double frequencyHz) noexcept
    {
        const double sr = std::max (1.0, sampleRate);
        const double f = clampd (frequencyHz, 1.0, sr * 0.45);
        const double k = std::tan (pi * f / sr);
        const double norm = 1.0 / (1.0 + k);
        return { norm, -norm, 0.0, (k - 1.0) * norm, 0.0 };
    }

    inline BiquadCoefficients lowPass (double sampleRate, double frequencyHz, double q) noexcept
    {
        const double sr = std::max (1.0, sampleRate);
        const double f = clampd (frequencyHz, 1.0, sr * 0.45);
        const double safeQ = std::max (0.05, q);
        const double w0 = twoPi * f / sr;
        const double cs = std::cos (w0);
        const double sn = std::sin (w0);
        const double alpha = sn / (2.0 * safeQ);
        const double a0 = 1.0 + alpha;
        return {
            ((1.0 - cs) * 0.5) / a0,
            (1.0 - cs) / a0,
            ((1.0 - cs) * 0.5) / a0,
            (-2.0 * cs) / a0,
            (1.0 - alpha) / a0
        };
    }

    inline BiquadCoefficients highPass (double sampleRate, double frequencyHz, double q) noexcept
    {
        const double sr = std::max (1.0, sampleRate);
        const double f = clampd (frequencyHz, 1.0, sr * 0.45);
        const double safeQ = std::max (0.05, q);
        const double w0 = twoPi * f / sr;
        const double cs = std::cos (w0);
        const double sn = std::sin (w0);
        const double alpha = sn / (2.0 * safeQ);
        const double a0 = 1.0 + alpha;
        return {
            ((1.0 + cs) * 0.5) / a0,
            (-(1.0 + cs)) / a0,
            ((1.0 + cs) * 0.5) / a0,
            (-2.0 * cs) / a0,
            (1.0 - alpha) / a0
        };
    }

    inline bool finiteAndStable (const BiquadCoefficients& c) noexcept
    {
        if (! std::isfinite (c.b0) || ! std::isfinite (c.b1) || ! std::isfinite (c.b2)
            || ! std::isfinite (c.a1) || ! std::isfinite (c.a2))
            return false;

        // Jury stability conditions for z^2 + a1*z + a2.
        return (1.0 + c.a1 + c.a2) > 0.0
            && (1.0 - c.a1 + c.a2) > 0.0
            && (1.0 - c.a2) > 0.0;
    }

    class BiquadBank
    {
    public:
        void prepare (int channels)
        {
            states.assign (static_cast<std::size_t> (std::max (1, channels)), {});
        }

        void reset() noexcept
        {
            for (auto& s : states)
                s = {};
        }

        void setCoefficients (const BiquadCoefficients& c) noexcept
        {
            coeff = c;
        }

        const BiquadCoefficients& coefficients() const noexcept { return coeff; }

        void moveCoefficientsTowards (const BiquadCoefficients& target, double alpha) noexcept
        {
            const double a = clampd (alpha, 0.0, 1.0);
            coeff.b0 += (target.b0 - coeff.b0) * a;
            coeff.b1 += (target.b1 - coeff.b1) * a;
            coeff.b2 += (target.b2 - coeff.b2) * a;
            coeff.a1 += (target.a1 - coeff.a1) * a;
            coeff.a2 += (target.a2 - coeff.a2) * a;
        }

        float processSample (int channel, float input) noexcept
        {
            if (states.empty())
                return input;

            const std::size_t index = static_cast<std::size_t> (
                std::clamp (channel, 0, static_cast<int> (states.size()) - 1));
            auto& s = states[index];

            // Transposed direct-form II. Coefficients and state are double precision;
            // only the plug-in I/O sample itself remains float.
            const double x = static_cast<double> (input);
            const double y = coeff.b0 * x + s.z1;
            s.z1 = coeff.b1 * x - coeff.a1 * y + s.z2;
            s.z2 = coeff.b2 * x - coeff.a2 * y;
            return static_cast<float> (y);
        }

    private:
        struct State { double z1 = 0.0, z2 = 0.0; };
        BiquadCoefficients coeff {};
        std::vector<State> states;
    };

    class LinearSmoother
    {
    public:
        explicit LinearSmoother (float initial = 0.0f) noexcept
            : current (initial), target (initial) {}

        void reset (double sampleRate, double seconds) noexcept
        {
            rampSamples = std::max (1, static_cast<int> (std::llround (sampleRate * seconds)));
            remaining = 0;
            step = 0.0f;
        }

        void setCurrentAndTargetValue (float value) noexcept
        {
            current = target = value;
            remaining = 0;
            step = 0.0f;
        }

        void setTargetValue (float value) noexcept
        {
            if (value == target)
                return;
            target = value;
            remaining = rampSamples;
            step = (target - current) / static_cast<float> (remaining);
        }

        float getNextValue() noexcept
        {
            if (remaining > 0)
            {
                current += step;
                if (--remaining == 0)
                    current = target;
            }
            return current;
        }

    private:
        float current = 0.0f;
        float target = 0.0f;
        float step = 0.0f;
        int rampSamples = 1;
        int remaining = 0;
    };

    class MultiplicativeSmoother
    {
    public:
        explicit MultiplicativeSmoother (float initial = 1.0f) noexcept
            : current (initial), target (initial) {}

        void reset (double sampleRate, double seconds) noexcept
        {
            rampSamples = std::max (1, static_cast<int> (std::llround (sampleRate * seconds)));
            remaining = 0;
            ratio = 1.0f;
            linearStep = 0.0f;
            useLinearFallback = false;
        }

        void setCurrentAndTargetValue (float value) noexcept
        {
            current = target = value;
            remaining = 0;
            ratio = 1.0f;
            linearStep = 0.0f;
            useLinearFallback = false;
        }

        void setTargetValue (float value) noexcept
        {
            if (value == target)
                return;

            target = value;
            remaining = rampSamples;
            useLinearFallback = current <= 0.0f || target <= 0.0f;

            if (useLinearFallback)
            {
                linearStep = (target - current) / static_cast<float> (remaining);
                ratio = 1.0f;
            }
            else
            {
                ratio = std::pow (target / current, 1.0f / static_cast<float> (remaining));
                linearStep = 0.0f;
            }
        }

        float getNextValue() noexcept
        {
            if (remaining > 0)
            {
                current = useLinearFallback ? current + linearStep : current * ratio;
                if (--remaining == 0)
                    current = target;
            }
            return current;
        }

    private:
        float current = 1.0f;
        float target = 1.0f;
        float ratio = 1.0f;
        float linearStep = 0.0f;
        int rampSamples = 1;
        int remaining = 0;
        bool useLinearFallback = false;
    };
}
