#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>

// Circuit-domain model for the shared dynamics control path.
// No attack/release/ratio/knee parameters exist here: only electrical values.
class SslDynamicsCircuit
{
public:
    struct DetectorComponents
    {
        double voltsPerDb = 0.0061;       // THAT 2252 family scale [SPEC-FAMILY]
        double averagingCapF = 10.0e-9;   // [CHOICE]
        double timingCurrentA = 25.9e-9;  // [FIT] -> about 10 ms from tau=0.0259*C/I

        // PEAK mode uses a separate full-wave peak-envelope RC before the same
        // gain computer. The fast charge / slower discharge preserves crest
        // factor long enough for the compressor timing network to react, instead
        // of feeding it a one-sample impulse. [FIT]
        double peakEnvelopeCapF = 100.0e-9;
        double peakChargeResistorOhm = 2200.0;       // ~0.22 ms
        double peakDischargeResistorOhm = 470000.0; // ~47 ms
    };

    struct DiodeComponents
    {
        double ideality = 1.8;            // [FIT]
        double thermalVoltageV = 0.02585; // room-temperature physics [SPEC]
        double driveGain = 2.55;          // [FIT] -> roughly six-dB soft transition
    };

    struct GainDivider
    {
        double topOhm = 10000.0;          // [CHOICE]
        double bottomOhm = 30000.0;       // [FIT from panel ratio]; 4:1 when Rt=10k, Rb=30k
    };

    struct TimingNetwork
    {
        double mainCapF = 1.0e-6;             // [CHOICE]
        double reservoirCapF = 22.0e-6;       // [FIT]
        double attackResistorOhm = 43200.0;     // [FIT] slow charge path, ~30 ms alone
        double fastAttackResistorOhm = 2900.0;  // [FIT] F.ATK, ~3 ms including detector
        double releaseResistorOhm = 300000.0;   // [FIT from RELEASE panel]
        double reservoirResistorOhm = 100000.0; // [FIT] program-memory branch
        double transientCapF = 0.47e-6;          // [FIT] edge-sensitive normal-attack bypass
        double transientResistorOhm = 4320.0;    // [FIT] current limit for bypass
        double transientBleedOhm = 100000.0;     // [CHOICE] resets bypass between events
    };

    struct MakeupDivider
    {
        double topOhm = 11700.0;    // [FIT]
        double bottomOhm = 10000.0; // [FIT], tap ~= 0.461
    };

    struct GateComponents
    {
        double mainCapF = 0.47e-6;              // [CHOICE]
        double reservoirCapF = 2.2e-6;          // [FIT]
        // Separate fast gate detector: the gate must see drum edges before the
        // slower compressor RMS detector does.  Charge is deliberately quick;
        // discharge is slower so the hysteresis comparator is not chatter-prone.
        double detectorCapF = 10.0e-9;
        double detectorChargeResistorOhm = 4700.0;    // ~47 us envelope charge
        double detectorDischargeResistorOhm = 100000.0; // ~1 ms envelope release
        // Calibrated against the complete RC opening path: approximately 1.5 ms
        // normal and 0.1 ms FAST for a 40 dB closed-to-open transition.
        double normalAttackResistorOhm = 750.0;
        double fastAttackResistorOhm = 55.0;
        double releaseResistorOhm = 638000.0;    // [FIT from RELEASE panel]
        double reservoirResistorOhm = 33000.0;   // [FIT]
        double holdCapF = 1.0e-6;                // [CHOICE]
        double holdResistorOhm = 50000.0;         // [FIT from HOLD panel]
        double expanderTopOhm = 10000.0;          // [CHOICE]
        double expanderBottomOhm = 10000.0;       // [CHOICE], unity GR slope -> 1:2 downward
    };

    struct Circuit
    {
        DetectorComponents detector;
        DiodeComponents kneeDiode;
        GainDivider gainDivider;
        TimingNetwork compressorTiming;
        MakeupDivider makeup;
        GateComponents gate;

        double compressorThresholdCvV = -0.061;      // calibrated detector threshold control voltage
        double compressorPanelThresholdCvV = -0.061; // legacy panel-setting CV retained for state/source compatibility
        double gateThresholdCvV = -0.183;
        double gateRangeCvV = 0.122;

        bool compressorEnabled = true;
        bool compressorFastAttack = false;
        bool compressorPeakDetect = false;
        bool gateEnabled = false;
        bool gateFastAttack = false;
        bool gateExpandMode = false;
    };

    void prepare (double sampleRate) noexcept;
    void reset() noexcept;
    void setCircuit (const Circuit& newCircuit) noexcept { circuit = sanitised (newCircuit); }

    // power is mean-square signal energy across all linked channels.
    float processPower (double power) noexcept;

    // Separate RMS and peak detector feeds. rmsPower is mean-square energy;
    // peakPower is the largest instantaneous squared sample across linked channels.
    // PEAK mode selects peakPower only for the compressor. Gate/expander stays on
    // the RMS detector path.
    float processPowers (double rmsPower, double peakPower) noexcept;

    double compressorReductionDb() const noexcept;
    double gateReductionDb() const noexcept;
    // Meter-only block peaks. These never feed the VCA/control law; they simply
    // retain the largest compressor/gate reduction reached since the last read.
    double consumeMaxCompressorReductionDb() noexcept;
    double consumeMaxGateReductionDb() noexcept;
    double detectorDb() const noexcept;
    double makeupDb() const noexcept;

    // Measurement helpers expose the circuit transfer, not a second DSP path.
    double staticCompressorReductionCv (double detectorCvV) const noexcept;
    double staticGateReductionCv (double detectorCvV) const noexcept;
    double compressionFactorFromDivider() const noexcept;
    double kneeTenToNinetyDb() const noexcept;
    double detectorTimeConstantSeconds() const noexcept;

    const Circuit& getCircuit() const noexcept { return circuit; }

private:
    struct TwoNodeState
    {
        double mainV = 0.0;
        double reservoirV = 0.0;
        double transientCapV = 0.0;
    };

    static Circuit sanitised (Circuit c) noexcept;
    static double safePositive (double x, double fallback) noexcept;
    static double softplus (double x) noexcept;
    static double gainFromDb (double db) noexcept;

    double diodeOverdriveCv (double overThresholdCvV) const noexcept;
    double updateTimingNetwork (TwoNodeState& state,
                                double targetV,
                                double mainCapF,
                                double reservoirCapF,
                                double sourceResistorOhm,
                                double reservoirResistorOhm,
                                bool connectReservoir) const noexcept;

    double updateCompressorTiming (double targetCvV) noexcept;
    double updateGateTiming (double targetCvV) noexcept;
    void updateHoldNode (bool detectorAboveThreshold) noexcept;
    double gateHysteresisDb() const noexcept;

    Circuit circuit;
    double fs = 48000.0;
    double detectorPowerState = 0.0;
    double peakEnvelopeState = 0.0;
    double detectorCvState = -0.732;
    double compressorDetectorCvState = -0.732;
    double gateDetectorCvState = -0.732;
    double gateEnvelopeState = 0.0;
    bool gateOpen = false;
    TwoNodeState compressorState;
    TwoNodeState gateState;
    double holdNode = 0.0;
    double lastMakeupCv = 0.0;
    double maxCompressorCvSinceRead = 0.0;
    double maxGateCvSinceRead = 0.0;
};
