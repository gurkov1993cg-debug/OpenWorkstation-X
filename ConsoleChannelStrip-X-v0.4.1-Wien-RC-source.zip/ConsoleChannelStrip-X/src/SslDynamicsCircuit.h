#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>

// Circuit-domain model for the shared dynamics control path.
// No attack/release/ratio/knee parameters exist here: only electrical values.
class SslDynamicsCircuit
{
public:
    struct DetectorComponents
    {
        double voltsPerDb = 0.0061;       // THAT 2252 family scale [SPEC-FAMILY]
        double averagingCapF = 10.0e-9;   // [CHOICE]
        double timingCurrentA = 25.9e-9;  // [FIT] -> about 10 ms from tau=0.0259*C/I
    };

    struct DiodeComponents
    {
        double ideality = 1.8;            // [FIT]
        double thermalVoltageV = 0.02585; // room-temperature physics [SPEC]
        double driveGain = 2.55;          // [FIT] -> roughly six-dB soft transition
    };

    struct GainDivider
    {
        double topOhm = 10000.0;          // [CHOICE]
        double bottomOhm = 30000.0;       // [FIT from panel ratio]; 4:1 when Rt=10k, Rb=30k
    };

    struct TimingNetwork
    {
        double mainCapF = 1.0e-6;             // [CHOICE]
        double reservoirCapF = 22.0e-6;       // [FIT]
        double attackResistorOhm = 43200.0;     // [FIT] slow charge path, ~30 ms alone
        double fastAttackResistorOhm = 2900.0;  // [FIT] F.ATK, ~3 ms including detector
        double releaseResistorOhm = 300000.0;   // [FIT from RELEASE panel]
        double reservoirResistorOhm = 100000.0; // [FIT] program-memory branch
        double transientCapF = 0.47e-6;          // [FIT] edge-sensitive normal-attack bypass
        double transientResistorOhm = 4320.0;    // [FIT] current limit for bypass
        double transientBleedOhm = 100000.0;     // [CHOICE] resets bypass between events
    };

    struct MakeupDivider
    {
        double topOhm = 11700.0;    // [FIT]
        double bottomOhm = 10000.0; // [FIT], tap ~= 0.461
    };

    struct GateComponents
    {
        double mainCapF = 0.47e-6;              // [CHOICE]
        double reservoirCapF = 2.2e-6;          // [FIT]
        double normalAttackResistorOhm = 2200.0; // [FIT], program branch gives slower behaviour
        double fastAttackResistorOhm = 1000.0;   // [FIT], approximately 1 ms opening
        double releaseResistorOhm = 638000.0;    // [FIT from RELEASE panel]
        double reservoirResistorOhm = 33000.0;   // [FIT]
        double holdCapF = 1.0e-6;                // [CHOICE]
        double holdResistorOhm = 50000.0;         // [FIT from HOLD panel]
        double expanderTopOhm = 10000.0;          // [CHOICE]
        double expanderBottomOhm = 10000.0;       // [CHOICE], unity GR slope -> 1:2 downward
    };

    struct Circuit
    {
        DetectorComponents detector;
        DiodeComponents kneeDiode;
        GainDivider gainDivider;
        TimingNetwork compressorTiming;
        MakeupDivider makeup;
        GateComponents gate;

        double compressorThresholdCvV = -0.061; // control voltage, not a dB DSP parameter
        double gateThresholdCvV = -0.183;
        double gateRangeCvV = 0.122;

        bool compressorEnabled = true;
        bool compressorFastAttack = false;
        bool gateEnabled = false;
        bool gateFastAttack = false;
        bool gateExpandMode = false;
    };

    void prepare (double sampleRate) noexcept;
    void reset() noexcept;
    void setCircuit (const Circuit& newCircuit) noexcept { circuit = sanitised (newCircuit); }

    // power is mean-square signal energy across all linked channels.
    float processPower (double power) noexcept;

    double compressorReductionDb() const noexcept;
    double gateReductionDb() const noexcept;
    double detectorDb() const noexcept;
    double makeupDb() const noexcept;

    // Measurement helpers expose the circuit transfer, not a second DSP path.
    double staticCompressorReductionCv (double detectorCvV) const noexcept;
    double staticGateReductionCv (double detectorCvV) const noexcept;
    double compressionFactorFromDivider() const noexcept;
    double kneeTenToNinetyDb() const noexcept;
    double detectorTimeConstantSeconds() const noexcept;

    const Circuit& getCircuit() const noexcept { return circuit; }

private:
    struct TwoNodeState
    {
        double mainV = 0.0;
        double reservoirV = 0.0;
        double transientCapV = 0.0;
    };

    static Circuit sanitised (Circuit c) noexcept;
    static double safePositive (double x, double fallback) noexcept;
    static double softplus (double x) noexcept;
    static double gainFromDb (double db) noexcept;

    double diodeOverdriveCv (double overThresholdCvV) const noexcept;
    double updateTimingNetwork (TwoNodeState& state,
                                double targetV,
                                double mainCapF,
                                double reservoirCapF,
                                double sourceResistorOhm,
                                double reservoirResistorOhm,
                                bool connectReservoir) const noexcept;

    double updateCompressorTiming (double targetCvV) noexcept;
    double updateGateTiming (double targetCvV) noexcept;
    void updateHoldNode (bool detectorAboveThreshold) noexcept;

    Circuit circuit;
    double fs = 48000.0;
    double detectorPowerState = 0.0;
    double detectorCvState = -0.732;
    TwoNodeState compressorState;
    TwoNodeState gateState;
    double holdNode = 0.0;
    double lastMakeupCv = 0.0;
};
