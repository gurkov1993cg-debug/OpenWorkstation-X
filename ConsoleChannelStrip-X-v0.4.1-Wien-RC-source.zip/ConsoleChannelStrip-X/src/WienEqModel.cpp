#include "WienEqModel.h"

#include <complex>

namespace wieneq
{
    namespace
    {
        // Every component below is [FIT], never [SPEC]. The capacitors are E12 values;
        // the resistance endpoints are solved from the documented E-series frequency
        // ranges. They are not claimed to be SSL schematic values.
        constexpr BandCircuit lfCircuit {
            100.0e-9, 100.0e-9,
            3536.77651315323, 53051.64769729845,
            2.86, 30.0, 450.0,
            "[FIT] C=100nF; R=53.05k..3.537k -> 30..450Hz"
        };

        constexpr BandCircuit lmfCircuit {
            22.0e-9, 22.0e-9,
            2893.726238034461, 36171.57797543076,
            2.86, 200.0, 2500.0,
            "[FIT] C=22nF; R=36.17k..2.894k -> 200..2500Hz"
        };

        constexpr BandCircuit hmfCircuit {
            6.8e-9, 6.8e-9,
            3343.591241426373, 39008.56448330768,
            2.86, 600.0, 7000.0,
            "[FIT] C=6.8nF; R=39.01k..3.344k -> 600..7000Hz"
        };

        constexpr BandCircuit hfCircuit {
            2.2e-9, 2.2e-9,
            4521.447246928845, 48228.77063390768,
            2.86, 1500.0, 16000.0,
            "[FIT] C=2.2nF; R=48.23k..4.521k -> 1500..16000Hz"
        };

        constexpr double shelfShapeQ = 1.2315606122497924;
        constexpr double shelfRqFrac = 2.188022099721736;

        double gainAbs (double gainDb) noexcept
        {
            return std::pow (10.0, std::abs (gainDb) / 20.0);
        }

        double clampedPrewarpHz (double sampleRate, double hz) noexcept
        {
            return std::clamp (hz, 1.0, sampleRate * 0.45);
        }

        NetworkTuning tuneShelfNetwork (const BandCircuit& c, double wantedHz) noexcept
        {
            const double r = resistanceForFrequency (c, wantedHz);
            // Second Wien/RC pair sets the second-order shelf damping. This [FIT]
            // qFrac gives about -1.5 dB at 2.2*fc for a +12 dB LF shelf, while the
            // marked corner remains exactly half the shelf gain (+6 dB at +12 dB).
            const double rq = std::min (shelfRqFrac, c.rqFracMax) * r;
            auto n = wienNetwork (r, r, c.c1, c.c2, rq);
            // Keep the fitted target explicit so a future component change cannot
            // silently turn this back into a knob-designed shelf.
            n.q = std::min (n.q, shelfShapeQ);
            n.effectiveQ = n.q;
            return n;
        }
    }

    const BandCircuit& circuit (Band band) noexcept
    {
        switch (band)
        {
            case Band::lf:  return lfCircuit;
            case Band::lmf: return lmfCircuit;
            case Band::hmf: return hmfCircuit;
            case Band::hf:  return hfCircuit;
        }
        return lmfCircuit;
    }

    double frequencyForR (const BandCircuit& c, double r) noexcept
    {
        const double safeR = std::max (1.0e-9, r);
        return 1.0 / (2.0 * pi * safeR * std::sqrt (c.c1 * c.c2));
    }

    double resistanceForFrequency (const BandCircuit& c, double wantedHz) noexcept
    {
        const double safeHz = std::max (1.0e-9, wantedHz);
        const double r = 1.0 / (2.0 * pi * safeHz * std::sqrt (c.c1 * c.c2));
        return std::clamp (r, c.rMin, c.rMax);
    }

    NetworkTuning wienNetwork (double r1, double r2, double c1, double c2, double rq) noexcept
    {
        const double prod = std::max (1.0e-30, r1 * r2 * c1 * c2);
        const double damp = r1*c1 + r2*c2 + r2*c1 - rq*c1;
        const double safeDamp = std::max (1.0e-12, damp);
        return { 1.0 / std::sqrt (prod), std::sqrt (prod) / safeDamp,
                 std::sqrt (std::max (0.0, r1*r2)), rq, 0.0 };
    }

    NetworkTuning tuneBell (const BandCircuit& c, double wantedHz, double effectiveQ, double gainDb) noexcept
    {
        const double r = resistanceForFrequency (c, wantedHz);
        const double G = gainAbs (gainDb);
        const double sqrtG = std::sqrt (G);

        // For this reciprocal analog bell, half-gain bandwidth gives
        // Qeff = Qn/sqrt(G). Therefore Qn is derived from the engraved effective-Q
        // control, rather than treating the knob value as the network Q directly.
        const double requestedQeff = std::clamp (effectiveQ, 0.10, 3.50);
        const double wantedQn = requestedQeff * sqrtG;

        // With R1=R2 and C1=C2, a passive Rq>=0 has Qn>=1/3. We refuse to invent
        // a negative resistance merely to hit the nominal 0.10 marking at +12 dB.
        const double physicalQn = std::max (1.0/3.0, wantedQn);
        double qFrac = 3.0 - 1.0 / physicalQn;
        qFrac = std::clamp (qFrac, 0.0, c.rqFracMax);

        auto n = wienNetwork (r, r, c.c1, c.c2, qFrac * r);
        n.effectiveQ = n.q / sqrtG;
        return n;
    }

    NetworkTuning tuneFixedQBell (const BandCircuit& c, double wantedHz, double effectiveQ, double gainDb) noexcept
    {
        return tuneBell (c, wantedHz, effectiveQ, gainDb);
    }

    BiquadCoefficients biquadFromAnalog (double sr,
                                         double b2, double b1, double b0,
                                         double a2, double a1, double a0,
                                         double prewarpHz) noexcept
    {
        prewarpHz = clampedPrewarpHz (sr, prewarpHz);
        const double K = 2.0 * sr * std::tan (pi * prewarpHz / sr)
                         / (2.0 * pi * prewarpHz);
        const double k = 2.0 * sr / K;
        const double B0 = b2*k*k + b1*k + b0;
        const double B1 = 2.0*(b0 - b2*k*k);
        const double B2 = b2*k*k - b1*k + b0;
        const double A0 = a2*k*k + a1*k + a0;
        const double A1 = 2.0*(a0 - a2*k*k);
        const double A2 = a2*k*k - a1*k + a0;
        return { B0/A0, B1/A0, B2/A0, A1/A0, A2/A0 };
    }

    BiquadCoefficients reciprocalBell (double sr,
                                       const NetworkTuning& tuning,
                                       double gainDb) noexcept
    {
        const double w = tuning.w0;
        const double Q = std::max (0.05, tuning.q);
        const double G = gainAbs (gainDb);
        const double f = w / (2.0 * pi);
        if (gainDb >= 0.0)
            return biquadFromAnalog (sr, 1.0, G*w/Q, w*w, 1.0, w/Q, w*w, f);
        return biquadFromAnalog (sr, 1.0, w/Q, w*w, 1.0, G*w/Q, w*w, f);
    }

    BiquadCoefficients lowShelf (double sr,
                                 const BandCircuit& c,
                                 double wantedHz,
                                 double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        const auto n = tuneShelfNetwork (c, wantedHz);
        const double w = n.w0;
        const double Q = n.q;
        const double G = gainAbs (gainDb);
        const double A = std::sqrt (G);
        const double rootA = std::sqrt (A);
        const double f = w / (2.0*pi);

        // Second-order analog shelf. Both numerator and denominator have genuine
        // s^2 terms; there is no pole/zero cancellation at z=-1.
        // Boost: DC=G, HF=1, |H(fc)|=sqrt(G). Cut is the exact reciprocal.
        const double nb2 = 1.0;
        const double nb1 = rootA*w/Q;
        const double nb0 = A*w*w;
        const double da2 = A;
        const double da1 = rootA*w/Q;
        const double da0 = w*w;

        if (gainDb >= 0.0)
            return biquadFromAnalog (sr, A*nb2, A*nb1, A*nb0,
                                     da2, da1, da0, f);
        return biquadFromAnalog (sr, da2, da1, da0,
                                 A*nb2, A*nb1, A*nb0, f);
    }

    BiquadCoefficients highShelf (double sr,
                                  const BandCircuit& c,
                                  double wantedHz,
                                  double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        const auto n = tuneShelfNetwork (c, wantedHz);
        const double w = n.w0;
        const double Q = n.q;
        const double G = gainAbs (gainDb);
        const double A = std::sqrt (G);
        const double rootA = std::sqrt (A);
        const double f = w / (2.0*pi);

        // Frequency-inverted counterpart of lowShelf: LF=1, HF=G and the same
        // component-derived second-order damping. Cut remains reciprocal.
        const double nb2 = A;
        const double nb1 = rootA*w/Q;
        const double nb0 = w*w;
        const double da2 = 1.0;
        const double da1 = rootA*w/Q;
        const double da0 = A*w*w;

        if (gainDb >= 0.0)
            return biquadFromAnalog (sr, A*nb2, A*nb1, A*nb0,
                                     da2, da1, da0, f);
        return biquadFromAnalog (sr, da2, da1, da0,
                                 A*nb2, A*nb1, A*nb0, f);
    }

    double maxPoleRadius (const BiquadCoefficients& c) noexcept
    {
        using C = std::complex<double>;
        const C disc = C (c.a1*c.a1 - 4.0*c.a2, 0.0);
        const C root = std::sqrt (disc);
        const C p1 = (-c.a1 + root) * 0.5;
        const C p2 = (-c.a1 - root) * 0.5;
        return std::max (std::abs (p1), std::abs (p2));
    }

    double responseMagnitudeDb (const BiquadCoefficients& c,
                                double sampleRate,
                                double frequencyHz) noexcept
    {
        using C = std::complex<double>;
        const double omega = 2.0*pi*frequencyHz/sampleRate;
        const C z1 = std::exp (C (0.0, -omega));
        const C z2 = z1*z1;
        const C num = c.b0 + c.b1*z1 + c.b2*z2;
        const C den = 1.0 + c.a1*z1 + c.a2*z2;
        return 20.0*std::log10 (std::max (1.0e-15, std::abs (num/den)));
    }
}
