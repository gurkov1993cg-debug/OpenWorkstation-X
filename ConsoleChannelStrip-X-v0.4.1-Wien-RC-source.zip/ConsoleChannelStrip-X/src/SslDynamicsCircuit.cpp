#include "SslDynamicsCircuit.h"

namespace
{
    constexpr double kDetectorTauFactor = 0.0259;
    constexpr double kMinPower = 1.0e-24;
    constexpr double kHoldComparator = 0.36787944117144233; // e^-1, so crossing occurs at R*C
}

double SslDynamicsCircuit::safePositive (double x, double fallback) noexcept
{
    return std::isfinite (x) && x > 0.0 ? x : fallback;
}

SslDynamicsCircuit::Circuit SslDynamicsCircuit::sanitised (Circuit c) noexcept
{
    c.detector.voltsPerDb = safePositive (c.detector.voltsPerDb, 0.0061);
    c.detector.averagingCapF = safePositive (c.detector.averagingCapF, 10.0e-9);
    c.detector.timingCurrentA = safePositive (c.detector.timingCurrentA, 25.9e-9);
    c.detector.peakEnvelopeCapF = safePositive (c.detector.peakEnvelopeCapF, 100.0e-9);
    c.detector.peakChargeResistorOhm = safePositive (c.detector.peakChargeResistorOhm, 2200.0);
    c.detector.peakDischargeResistorOhm = safePositive (c.detector.peakDischargeResistorOhm, 470000.0);

    c.kneeDiode.ideality = safePositive (c.kneeDiode.ideality, 1.8);
    c.kneeDiode.thermalVoltageV = safePositive (c.kneeDiode.thermalVoltageV, 0.02585);
    c.kneeDiode.driveGain = safePositive (c.kneeDiode.driveGain, 2.55);

    c.gainDivider.topOhm = safePositive (c.gainDivider.topOhm, 10000.0);
    c.gainDivider.bottomOhm = std::max (0.0, std::isfinite (c.gainDivider.bottomOhm) ? c.gainDivider.bottomOhm : 30000.0);

    auto sanitiseTiming = [] (TimingNetwork& t)
    {
        t.mainCapF = safePositive (t.mainCapF, 1.0e-6);
        t.reservoirCapF = safePositive (t.reservoirCapF, 22.0e-6);
        t.attackResistorOhm = safePositive (t.attackResistorOhm, 43200.0);
        t.fastAttackResistorOhm = safePositive (t.fastAttackResistorOhm, 2900.0);
        t.releaseResistorOhm = safePositive (t.releaseResistorOhm, 300000.0);
        t.reservoirResistorOhm = safePositive (t.reservoirResistorOhm, 100000.0);
        t.transientCapF = safePositive (t.transientCapF, 0.47e-6);
        t.transientResistorOhm = safePositive (t.transientResistorOhm, 4320.0);
        t.transientBleedOhm = safePositive (t.transientBleedOhm, 100000.0);
    };
    sanitiseTiming (c.compressorTiming);

    c.makeup.topOhm = safePositive (c.makeup.topOhm, 11700.0);
    c.makeup.bottomOhm = safePositive (c.makeup.bottomOhm, 10000.0);

    c.gate.mainCapF = safePositive (c.gate.mainCapF, 0.47e-6);
    c.gate.reservoirCapF = safePositive (c.gate.reservoirCapF, 2.2e-6);
    c.gate.detectorCapF = safePositive (c.gate.detectorCapF, 10.0e-9);
    c.gate.detectorChargeResistorOhm = safePositive (c.gate.detectorChargeResistorOhm, 4700.0);
    c.gate.detectorDischargeResistorOhm = safePositive (c.gate.detectorDischargeResistorOhm, 100000.0);
    c.gate.normalAttackResistorOhm = safePositive (c.gate.normalAttackResistorOhm, 750.0);
    c.gate.fastAttackResistorOhm = safePositive (c.gate.fastAttackResistorOhm, 55.0);
    c.gate.releaseResistorOhm = safePositive (c.gate.releaseResistorOhm, 638000.0);
    c.gate.reservoirResistorOhm = safePositive (c.gate.reservoirResistorOhm, 33000.0);
    c.gate.holdCapF = safePositive (c.gate.holdCapF, 1.0e-6);
    c.gate.holdResistorOhm = safePositive (c.gate.holdResistorOhm, 50000.0);
    c.gate.expanderTopOhm = safePositive (c.gate.expanderTopOhm, 10000.0);
    c.gate.expanderBottomOhm = safePositive (c.gate.expanderBottomOhm, 10000.0);

    if (! std::isfinite (c.compressorThresholdCvV)) c.compressorThresholdCvV = -0.061;
    if (! std::isfinite (c.compressorPanelThresholdCvV)) c.compressorPanelThresholdCvV = -0.061;
    if (! std::isfinite (c.gateThresholdCvV)) c.gateThresholdCvV = -0.183;
    if (! std::isfinite (c.gateRangeCvV) || c.gateRangeCvV < 0.0) c.gateRangeCvV = 0.122;
    return c;
}

void SslDynamicsCircuit::prepare (double sampleRate) noexcept
{
    fs = safePositive (sampleRate, 48000.0);
    circuit = sanitised (circuit);
    reset();
}

void SslDynamicsCircuit::reset() noexcept
{
    detectorPowerState = 0.0;
    peakEnvelopeState = 0.0;
    detectorCvState = circuit.detector.voltsPerDb * -120.0;
    compressorDetectorCvState = detectorCvState;
    gateDetectorCvState = detectorCvState;
    gateEnvelopeState = 0.0;
    gateOpen = false;
    compressorState = {};
    gateState = {};
    holdNode = 0.0;
    lastMakeupCv = 0.0;
}

double SslDynamicsCircuit::softplus (double x) noexcept
{
    if (x > 40.0) return x;
    if (x < -40.0) return std::exp (x);
    return std::log1p (std::exp (x));
}

double SslDynamicsCircuit::gainFromDb (double db) noexcept
{
    return std::pow (10.0, db / 20.0);
}

double SslDynamicsCircuit::detectorTimeConstantSeconds() const noexcept
{
    return kDetectorTauFactor * circuit.detector.averagingCapF / circuit.detector.timingCurrentA;
}

double SslDynamicsCircuit::compressionFactorFromDivider() const noexcept
{
    return (circuit.gainDivider.topOhm + circuit.gainDivider.bottomOhm) / circuit.gainDivider.topOhm;
}

double SslDynamicsCircuit::diodeOverdriveCv (double overThresholdCvV) const noexcept
{
    const double scaleV = circuit.kneeDiode.ideality * circuit.kneeDiode.thermalVoltageV
                        / circuit.kneeDiode.driveGain;
    return scaleV * softplus (overThresholdCvV / scaleV);
}

double SslDynamicsCircuit::staticCompressorReductionCv (double detectorCvV) const noexcept
{
    if (! circuit.compressorEnabled)
        return 0.0;

    const double dividerK = circuit.gainDivider.bottomOhm
                          / (circuit.gainDivider.topOhm + circuit.gainDivider.bottomOhm);
    const double overThresholdCv = detectorCvV - circuit.compressorThresholdCvV;

    // SSL PEAK mode changes two things together: peak sensing and a hard knee.
    // RMS mode keeps the diode-shaped soft transition.
    if (circuit.compressorPeakDetect)
        return dividerK * std::max (0.0, overThresholdCv);

    return dividerK * diodeOverdriveCv (overThresholdCv);
}

double SslDynamicsCircuit::staticGateReductionCv (double detectorCvV) const noexcept
{
    if (! circuit.gateEnabled || detectorCvV >= circuit.gateThresholdCvV)
        return 0.0;

    if (! circuit.gateExpandMode)
        return circuit.gateRangeCvV;

    const double deficitV = circuit.gateThresholdCvV - detectorCvV;
    const double expanderGain = circuit.gate.expanderBottomOhm / circuit.gate.expanderTopOhm;
    return std::min (circuit.gateRangeCvV, deficitV * expanderGain);
}

double SslDynamicsCircuit::kneeTenToNinetyDb() const noexcept
{
    if (circuit.compressorPeakDetect) return 0.0;
    // Derivative of softplus is logistic. 10% and 90% points are +/-ln(9)*scale.
    const double scaleV = circuit.kneeDiode.ideality * circuit.kneeDiode.thermalVoltageV
                        / circuit.kneeDiode.driveGain;
    return 2.0 * std::log (9.0) * scaleV / circuit.detector.voltsPerDb;
}

double SslDynamicsCircuit::updateTimingNetwork (TwoNodeState& state,
                                                 double targetV,
                                                 double mainCapF,
                                                 double reservoirCapF,
                                                 double sourceResistorOhm,
                                                 double reservoirResistorOhm,
                                                 bool connectReservoir) const noexcept
{
    // Backward-Euler solution of the physical two-capacitor RC network:
    // target -- Rsource -- Cmain, with Cmain -- Rreservoir -- Creservoir.
    // It is unconditionally stable and monotonic for positive R/C values.
    const double dt = 1.0 / fs;
    const double gSource = 1.0 / sourceResistorOhm;
    const double gReservoir = connectReservoir ? 1.0 / reservoirResistorOhm : 0.0;
    const double c1 = mainCapF / dt;
    const double c2 = reservoirCapF / dt;

    const double a11 = c1 + gSource + gReservoir;
    const double a12 = -gReservoir;
    const double a21 = -gReservoir;
    const double a22 = c2 + gReservoir;
    const double b1 = c1 * state.mainV + gSource * targetV;
    const double b2 = c2 * state.reservoirV;
    const double det = a11 * a22 - a12 * a21;

    if (! std::isfinite (det) || std::abs (det) < 1.0e-30)
        return state.mainV;

    const double newMain = (b1 * a22 - a12 * b2) / det;
    const double newReservoir = (a11 * b2 - b1 * a21) / det;
    state.mainV = std::max (0.0, std::isfinite (newMain) ? newMain : 0.0);
    state.reservoirV = std::max (0.0, std::isfinite (newReservoir) ? newReservoir : 0.0);
    return state.mainV;
}

double SslDynamicsCircuit::updateCompressorTiming (double targetCvV) noexcept
{
    const auto& t = circuit.compressorTiming;
    const bool attacking = targetCvV > compressorState.mainV;

    if (! attacking)
    {
        // Diode steering removes the transient-assist branch on release. A real
        // bleed resistor resets its capacitor for the next edge.
        const double bleedTau = t.transientBleedOhm * t.transientCapF;
        compressorState.transientCapV *= std::exp (-1.0 / (bleedTau * fs));
        return updateTimingNetwork (compressorState, targetCvV, t.mainCapF, t.reservoirCapF,
                                    t.releaseResistorOhm, t.reservoirResistorOhm, true);
    }

    if (circuit.compressorFastAttack)
    {
        // F.ATK is a component bypass: the small resistor directly charges Cmain.
        compressorState.transientCapV = 0.0;
        return updateTimingNetwork (compressorState, targetCvV, t.mainCapF, t.reservoirCapF,
                                    t.fastAttackResistorOhm, t.reservoirResistorOhm, false);
    }

    // Normal attack: slow resistor plus a series-C/R transient path. The series
    // capacitor only supplies current on a rapid CV edge; once it charges, the
    // slow resistor owns the sustained attack. This creates 3..30 ms behaviour
    // from components rather than from an attack-time parameter.
    const double dt = 1.0 / fs;
    const double gSlow = 1.0 / t.attackResistorOhm;
    const double gRes = 1.0 / t.reservoirResistorOhm;
    const double c1 = t.mainCapF / dt;
    const double c2 = t.reservoirCapF / dt;

    const double gC = t.transientCapF / dt;
    const double gR = 1.0 / t.transientResistorOhm;
    const double gKick = (gC * gR) / (gC + gR);
    const double kickSourceV = targetCvV - compressorState.transientCapV;

    const double a11 = c1 + gSlow + gKick + gRes;
    const double a12 = -gRes;
    const double a21 = -gRes;
    const double a22 = c2 + gRes;
    const double b1 = c1 * compressorState.mainV + gSlow * targetCvV + gKick * kickSourceV;
    const double b2 = c2 * compressorState.reservoirV;
    const double det = a11 * a22 - a12 * a21;
    if (! std::isfinite (det) || std::abs (det) < 1.0e-30)
        return compressorState.mainV;

    const double newMain = (b1 * a22 - a12 * b2) / det;
    const double newReservoir = (a11 * b2 - b1 * a21) / det;
    compressorState.mainV = std::max (0.0, std::isfinite (newMain) ? newMain : 0.0);
    compressorState.reservoirV = std::max (0.0, std::isfinite (newReservoir) ? newReservoir : 0.0);

    const double nodeAfterCap = (gC * (targetCvV - compressorState.transientCapV)
                               + gR * compressorState.mainV) / (gC + gR);
    compressorState.transientCapV = targetCvV - nodeAfterCap;
    if (! std::isfinite (compressorState.transientCapV))
        compressorState.transientCapV = 0.0;
    return compressorState.mainV;
}

double SslDynamicsCircuit::gateHysteresisDb() const noexcept
{
    // The E-series threshold circuit uses more hysteresis at lower threshold
    // settings.  The panel maps +10..-30 dB to about -8..-48 dBFS in this model.
    // A 2..10 dB close-threshold offset gives the same useful behaviour: high
    // thresholds stay precise, while low thresholds let drum/instrument tails
    // decay naturally before the gate starts closing.
    const double vpd = safePositive (circuit.detector.voltsPerDb, 0.0061);
    const double openThresholdDbFs = circuit.gateThresholdCvV / vpd;
    const double depth = std::clamp ((-openThresholdDbFs - 8.0) / 40.0, 0.0, 1.0);
    return 2.0 + 8.0 * depth;
}

void SslDynamicsCircuit::updateHoldNode (bool detectorAboveThreshold) noexcept
{
    if (detectorAboveThreshold)
    {
        holdNode = 1.0;
        return;
    }

    const double tau = circuit.gate.holdResistorOhm * circuit.gate.holdCapF;
    const double alpha = std::exp (-1.0 / (safePositive (tau, 1.0e-6) * fs));
    holdNode *= alpha;
}

double SslDynamicsCircuit::updateGateTiming (double targetCvV) noexcept
{
    const auto& g = circuit.gate;
    const bool opening = targetCvV < gateState.mainV;
    const double rSource = opening
        ? (circuit.gateFastAttack ? g.fastAttackResistorOhm : g.normalAttackResistorOhm)
        : g.releaseResistorOhm;
    const bool connectReservoir = ! (opening && circuit.gateFastAttack);
    return updateTimingNetwork (gateState, targetCvV, g.mainCapF, g.reservoirCapF,
                                rSource, g.reservoirResistorOhm, connectReservoir);
}

float SslDynamicsCircuit::processPower (double power) noexcept
{
    return processPowers (power, power);
}

float SslDynamicsCircuit::processPowers (double rmsPower, double peakPower) noexcept
{
    rmsPower = std::max (kMinPower, std::isfinite (rmsPower) ? rmsPower : kMinPower);
    peakPower = std::max (kMinPower, std::isfinite (peakPower) ? peakPower : kMinPower);

    // RMS detector: physical averaging network used by the normal compressor mode
    // and by the gate/expander.
    const double tau = detectorTimeConstantSeconds();
    const double detectorAlpha = std::exp (-1.0 / (safePositive (tau, 1.0e-6) * fs));
    detectorPowerState = detectorAlpha * detectorPowerState + (1.0 - detectorAlpha) * rmsPower;

    const double rmsLevelDb = 10.0 * std::log10 (std::max (detectorPowerState, kMinPower));
    detectorCvState = circuit.detector.voltsPerDb * rmsLevelDb;

    // PEAK mode is not an audio clipper. It uses a separate full-wave peak
    // envelope with a fast charge and a short RC discharge, then feeds the same
    // compressor timing network. Keeping the crest for tens of milliseconds is
    // important: a one-sample absolute peak would otherwise be largely averaged
    // away by the program-dependent attack network and the PEAK button would have
    // little audible effect on drums and other transient material.
    const double peakMagnitude = std::sqrt (peakPower);
    const bool peakCharging = peakMagnitude > peakEnvelopeState;
    const double peakR = peakCharging ? circuit.detector.peakChargeResistorOhm
                                      : circuit.detector.peakDischargeResistorOhm;
    const double peakTau = safePositive (peakR * circuit.detector.peakEnvelopeCapF, 1.0e-6);
    const double peakAlpha = std::exp (-1.0 / (peakTau * fs));
    peakEnvelopeState = peakAlpha * peakEnvelopeState + (1.0 - peakAlpha) * peakMagnitude;
    if (! std::isfinite (peakEnvelopeState))
        peakEnvelopeState = 0.0;

    const double peakLevelDb = 20.0 * std::log10 (std::max (peakEnvelopeState, 1.0e-12));
    compressorDetectorCvState = circuit.compressorPeakDetect
        ? circuit.detector.voltsPerDb * peakLevelDb
        : detectorCvState;

    const double compressorTargetCv = staticCompressorReductionCv (compressorDetectorCvState);
    const double compressorCv = circuit.compressorEnabled ? updateCompressorTiming (compressorTargetCv) : 0.0;
    if (! circuit.compressorEnabled)
        compressorState = {};

    // Gate/expander has its own fast full-wave envelope instead of borrowing the
    // compressor's 10 ms RMS detector.  This preserves the leading edge of drums.
    const double gateMagnitude = std::sqrt (peakPower);
    const bool gateDetectorCharging = gateMagnitude > gateEnvelopeState;
    const double gateDetectorR = gateDetectorCharging ? circuit.gate.detectorChargeResistorOhm
                                                       : circuit.gate.detectorDischargeResistorOhm;
    const double gateDetectorTau = safePositive (gateDetectorR * circuit.gate.detectorCapF, 1.0e-6);
    const double gateDetectorAlpha = std::exp (-1.0 / (gateDetectorTau * fs));
    gateEnvelopeState = gateDetectorAlpha * gateEnvelopeState + (1.0 - gateDetectorAlpha) * gateMagnitude;
    if (! std::isfinite (gateEnvelopeState))
        gateEnvelopeState = 0.0;
    gateDetectorCvState = circuit.detector.voltsPerDb
                        * (20.0 * std::log10 (std::max (gateEnvelopeState, 1.0e-12)));

    double gateTargetCv = 0.0;
    if (circuit.gateEnabled)
    {
        // True hysteresis: THRESHOLD is the OPEN level.  Once open, the gate
        // remains open until the faster detector falls through a quieter CLOSE
        // threshold. HOLD begins only after that close crossing.
        const double closeThresholdCv = circuit.gateThresholdCvV
                                      - gateHysteresisDb() * circuit.detector.voltsPerDb;
        if (gateOpen)
        {
            if (gateDetectorCvState < closeThresholdCv)
                gateOpen = false;
        }
        else if (gateDetectorCvState >= circuit.gateThresholdCvV)
        {
            gateOpen = true;
        }

        updateHoldNode (gateOpen);
        if (! gateOpen && holdNode <= kHoldComparator)
        {
            // Keep the fast full-wave envelope for OPEN/CLOSE timing so drum
            // transients are not clipped, but compute EXPAND depth from the
            // calibrated RMS detector.  Using the peak envelope for the 1:2
            // transfer law makes the amount depend on crest factor (a sine at
            // -30 dBFS RMS appears about 3 dB hotter to a peak detector), which
            // breaks the panel's fixed 1:2 ratio.  Hard-gate mode is unaffected
            // because its static reduction is simply RANGE.
            const double gateGainComputerCv = circuit.gateExpandMode
                                              ? detectorCvState
                                              : gateDetectorCvState;
            gateTargetCv = staticGateReductionCv (gateGainComputerCv);
        }
    }

    const double gateCv = circuit.gateEnabled ? updateGateTiming (gateTargetCv) : 0.0;
    if (! circuit.gateEnabled)
    {
        gateState = {};
        holdNode = 0.0;
        gateOpen = false;
        gateEnvelopeState = 0.0;
        gateDetectorCvState = circuit.detector.voltsPerDb * -120.0;
    }

    // The compressor no longer applies an internal automatic make-up boost.
    // Gain reduction from compressor and gate/expander meet at the one shared VCA;
    // whole-strip loudness compensation is handled later by GLOBAL AUTO LEVEL.
    lastMakeupCv = 0.0;
    const double totalControlCv = compressorCv + gateCv;
    const double gainDb = -totalControlCv / circuit.detector.voltsPerDb;
    const double gain = gainFromDb (gainDb);
    return static_cast<float> (std::isfinite (gain) ? gain : 0.0);
}

double SslDynamicsCircuit::compressorReductionDb() const noexcept
{
    return compressorState.mainV / circuit.detector.voltsPerDb;
}

double SslDynamicsCircuit::gateReductionDb() const noexcept
{
    return gateState.mainV / circuit.detector.voltsPerDb;
}

double SslDynamicsCircuit::detectorDb() const noexcept
{
    return detectorCvState / circuit.detector.voltsPerDb;
}

double SslDynamicsCircuit::makeupDb() const noexcept
{
    return lastMakeupCv / circuit.detector.voltsPerDb;
}
