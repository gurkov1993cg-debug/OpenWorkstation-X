#include "AnalogSaturationCircuit.h"

#include <algorithm>
#include <cmath>

namespace
{
    constexpr double kPi = 3.141592653589793238462643383279502884;
    constexpr double kBoltzmann = 1.380649e-23;
    constexpr double kElectronCharge = 1.602176634e-19;
    constexpr double kTemperatureKelvin = 300.0;
    constexpr double kThermalVoltage = kBoltzmann * kTemperatureKelvin / kElectronCharge;

    // 193-tap symmetric equiripple low-pass used by both the 4x interpolator and
    // decimator. Design bands are normalised to the 4x Nyquist rate: passband
    // 0..0.208, stopband 0.25..1.0. The original fixed coefficients are embedded
    // so runtime behaviour has no external DSP dependency.
    constexpr std::array<double, 193> kOversamplingFir {
-5.943078469198172632e-05,
        -1.413973236251772495e-05,
        2.973743546352364899e-05,
        1.003394167195580740e-04,
        1.722886311680173882e-04,
        2.092372544768325397e-04,
        1.805737855910230949e-04,
        8.040095330553645578e-05,
        -6.174989209319995125e-05,
        -1.870570728178596741e-04,
        -2.314114823179751613e-04,
        -1.583655835885810169e-04,
        1.515147486796585484e-05,
        2.162483665959841943e-04,
        3.433388571953856889e-04,
        3.146657914900034716e-04,
        1.158200049238945566e-04,
        -1.798486085829416943e-04,
        -4.341333263010248408e-04,
        -5.058519561718399261e-04,
        -3.256217281001160652e-04,
        5.459753418760829747e-05,
        4.685448962227931275e-04,
        7.048718820496908087e-04,
        6.114837490869555643e-04,
        1.856062632004262683e-04,
        -4.010741683494105456e-04,
        -8.667152946204582367e-04,
        -9.504461601485596428e-04,
        -5.533203646310748403e-04,
        1.865515862068205493e-04,
        9.323708449118839120e-04,
        1.297326599078468812e-03,
        1.040188839952954679e-03,
        2.112864003764351674e-04,
        -8.347622284479046511e-04,
        -1.584026442925519926e-03,
        -1.610515060248158105e-03,
        -8.093764924328243323e-04,
        5.079630648532455512e-04,
        1.723890558049972609e-03,
        2.197899239737564122e-03,
        1.596325462763270630e-03,
        1.022102421504874454e-04,
        -1.618284080345362306e-03,
        -2.704321233482926985e-03,
        -2.523434051471038549e-03,
        -1.024832351793476988e-03,
        1.168239791887413668e-03,
        3.004495741174750302e-03,
        3.499623004125729155e-03,
        2.251517192766771484e-03,
        -2.884509748543057778e-04,
        -2.954787507438753295e-03,
        -4.390937049281042059e-03,
        -3.726867694733092262e-03,
        -1.079021184529323999e-03,
        2.404272126048011271e-03,
        5.023214630280352887e-03,
        5.341373295932233534e-03,
        2.951257574342932254e-03,
        -1.207639750984902238e-03,
        -5.188361850160833934e-03,
        -6.928396307905146552e-03,
        -5.294847388849430181e-03,
        -7.640230254651231333e-04,
        4.650580508298774243e-03,
        8.264148332637649003e-03,
        8.022260455232570198e-03,
        3.621011621830096897e-03,
        -3.144608250903757098e-03,
        -9.064500251647412618e-03,
        -1.099424109225809881e-02,
        -7.469029770179482983e-03,
        3.523758930314899434e-04,
        8.966957426658544658e-03,
        1.402902810634951668e-02,
        1.246008115870943234e-02,
        4.178469109704647036e-03,
        -7.464241160313213157e-03,
        -1.691824134076885811e-02,
        -1.893970659332154180e-02,
        -1.128942532425043256e-02,
        3.675754309087389191e-03,
        1.944734778891388585e-02,
        2.791592788514593929e-02,
        2.311142809031428713e-02,
        4.548380615042998606e-03,
        -2.141813525641022772e-02,
        -4.310596322178376905e-02,
        -4.759110507877845064e-02,
        -2.591295266673001099e-02,
        2.267040981550915921e-02,
        8.922334880169104088e-02,
        1.572954206864360105e-01,
        2.081053265617848758e-01,
        2.269000889957867861e-01,
        2.081053265617848758e-01,
        1.572954206864360105e-01,
        8.922334880169104088e-02,
        2.267040981550915921e-02,
        -2.591295266673001099e-02,
        -4.759110507877845064e-02,
        -4.310596322178376905e-02,
        -2.141813525641022772e-02,
        4.548380615042998606e-03,
        2.311142809031428713e-02,
        2.791592788514593929e-02,
        1.944734778891388585e-02,
        3.675754309087389191e-03,
        -1.128942532425043256e-02,
        -1.893970659332154180e-02,
        -1.691824134076885811e-02,
        -7.464241160313213157e-03,
        4.178469109704647036e-03,
        1.246008115870943234e-02,
        1.402902810634951668e-02,
        8.966957426658544658e-03,
        3.523758930314899434e-04,
        -7.469029770179482983e-03,
        -1.099424109225809881e-02,
        -9.064500251647412618e-03,
        -3.144608250903757098e-03,
        3.621011621830096897e-03,
        8.022260455232570198e-03,
        8.264148332637649003e-03,
        4.650580508298774243e-03,
        -7.640230254651231333e-04,
        -5.294847388849430181e-03,
        -6.928396307905146552e-03,
        -5.188361850160833934e-03,
        -1.207639750984902238e-03,
        2.951257574342932254e-03,
        5.341373295932233534e-03,
        5.023214630280352887e-03,
        2.404272126048011271e-03,
        -1.079021184529323999e-03,
        -3.726867694733092262e-03,
        -4.390937049281042059e-03,
        -2.954787507438753295e-03,
        -2.884509748543057778e-04,
        2.251517192766771484e-03,
        3.499623004125729155e-03,
        3.004495741174750302e-03,
        1.168239791887413668e-03,
        -1.024832351793476988e-03,
        -2.523434051471038549e-03,
        -2.704321233482926985e-03,
        -1.618284080345362306e-03,
        1.022102421504874454e-04,
        1.596325462763270630e-03,
        2.197899239737564122e-03,
        1.723890558049972609e-03,
        5.079630648532455512e-04,
        -8.093764924328243323e-04,
        -1.610515060248158105e-03,
        -1.584026442925519926e-03,
        -8.347622284479046511e-04,
        2.112864003764351674e-04,
        1.040188839952954679e-03,
        1.297326599078468812e-03,
        9.323708449118839120e-04,
        1.865515862068205493e-04,
        -5.533203646310748403e-04,
        -9.504461601485596428e-04,
        -8.667152946204582367e-04,
        -4.010741683494105456e-04,
        1.856062632004262683e-04,
        6.114837490869555643e-04,
        7.048718820496908087e-04,
        4.685448962227931275e-04,
        5.459753418760829747e-05,
        -3.256217281001160652e-04,
        -5.058519561718399261e-04,
        -4.341333263010248408e-04,
        -1.798486085829416943e-04,
        1.158200049238945566e-04,
        3.146657914900034716e-04,
        3.433388571953856889e-04,
        2.162483665959841943e-04,
        1.515147486796585484e-05,
        -1.583655835885810169e-04,
        -2.314114823179751613e-04,
        -1.870570728178596741e-04,
        -6.174989209319995125e-05,
        8.040095330553645578e-05,
        1.805737855910230949e-04,
        2.092372544768325397e-04,
        1.722886311680173882e-04,
        1.003394167195580740e-04,
        2.973743546352364899e-05,
        -1.413973236251772495e-05,
        -5.943078469198172632e-05
    };

    inline double onePoleCoefficient (double cutoffHz, double sampleRate) noexcept
    {
        cutoffHz = std::max (0.01, std::min (cutoffHz, sampleRate * 0.45));
        return 1.0 - std::exp (-2.0 * kPi * cutoffHz / sampleRate);
    }
}

void AnalogSaturationCircuit::prepare (double sampleRate, int numChannels)
{
    sr = std::max (8000.0, sampleRate);
    states.assign ((size_t) std::max (1, numChannels), {});

    // Keep the original 15 ms control law at base rate. Oversampling is only for
    // the audio nonlinearity, so automation timing remains identical to v1.
    amountAlpha = 1.0 - std::exp (-1.0 / (0.015 * sr));
    reset();
}

void AnalogSaturationCircuit::reset() noexcept
{
    for (auto& state : states)
        state = {};
}

double AnalogSaturationCircuit::clampUnit (double x) noexcept
{
    return std::max (-0.9999995, std::min (0.9999995, x));
}

double AnalogSaturationCircuit::fastDbToGain (double db) noexcept
{
    return std::exp (db * 0.1151292546497022842); // ln(10) / 20
}

double AnalogSaturationCircuit::solveDifferentialPair (double v,
                                                         double thermalTerm,
                                                         double emitterTerm,
                                                         double initial) noexcept
{
    double m = clampUnit (initial);
    const double linearEstimate = clampUnit (v / std::max (1.0e-12, thermalTerm + emitterTerm));
    if (! std::isfinite (m) || std::abs (m - linearEstimate) > 0.85)
        m = linearEstimate;

    for (int iteration = 0; iteration < 5; ++iteration)
    {
        m = clampUnit (m);
        const double oneMinusM2 = std::max (1.0e-10, 1.0 - m * m);
        const double f = thermalTerm * std::atanh (m) + emitterTerm * m - v;
        const double df = thermalTerm / oneMinusM2 + emitterTerm;
        const double step = f / std::max (1.0e-12, df);
        m = clampUnit (m - step);

        if (std::abs (step) < 1.0e-10)
            break;
    }

    return m;
}

double AnalogSaturationCircuit::nonlinearResidual (double input,
                                                     double amount,
                                                     ChannelState& state) noexcept
{
    if (amount < 1.0e-12)
        return 0.0;

    const double driveDb = 24.0 * std::pow (amount, 1.35);
    const double drive = fastDbToGain (driveDb);

    constexpr double voltsPerDigitalPeak = 0.115;
    const double ideality = 1.06;
    const double thermalTerm = 2.0 * ideality * kThermalVoltage;
    const double emitterDegenerationTerm = 0.145 - 0.040 * amount;
    const double linearScale = thermalTerm + emitterDegenerationTerm;
    // Slightly emphasise differential-pair asymmetry in the middle of the SAT
    // range for more low-order console colour.  The emphasis collapses to zero
    // at amount=0 and amount=1, preserving the clean and maximum endpoints.
    const double asymmetryMid = 4.0 * amount * (1.0 - amount);
    const double biasVoltage = 0.0040 * amount * (1.0 + 0.05 * asymmetryMid);
    const double physicalInput = input * voltsPerDigitalPeak * drive + biasVoltage;

    const double m = solveDifferentialPair (physicalInput,
                                            thermalTerm,
                                            emitterDegenerationTerm,
                                            state.previousPairState);
    const double m0 = solveDifferentialPair (biasVoltage,
                                             thermalTerm,
                                             emitterDegenerationTerm,
                                             0.0);
    state.previousPairState = m;

    const double pairOutput = (m - m0) * linearScale;
    const double normalisedOutput = pairOutput / (voltsPerDigitalPeak * drive);
    return normalisedOutput - input;
}

double AnalogSaturationCircuit::delayAmount (double amount, ChannelState& state) noexcept
{
    state.amountDelay[(size_t) state.amountWriteIndex] = amount;
    int readIndex = state.amountWriteIndex + 1;
    if (readIndex >= (int) state.amountDelay.size())
        readIndex = 0;

    const double delayed = state.amountDelay[(size_t) readIndex];
    if (++state.amountWriteIndex >= (int) state.amountDelay.size())
        state.amountWriteIndex = 0;
    return delayed;
}

double AnalogSaturationCircuit::interpolatePhase (const ChannelState& state,
                                                    int phase) noexcept
{
    // Polyphase form of zero-stuff + FIR interpolation. Across all four phases
    // every FIR coefficient is used once, so this costs one 193-tap convolution
    // per base-rate sample rather than four full convolutions.
    double output = 0.0;
    int delay = 0;

    for (int tap = phase; tap < firTaps; tap += oversampleFactor, ++delay)
    {
        int index = state.inputWriteIndex - 1 - delay;
        while (index < 0)
            index += inputHistorySamples;
        output += kOversamplingFir[(size_t) tap] * state.inputHistory[(size_t) index];
    }

    return output * (double) oversampleFactor;
}

double AnalogSaturationCircuit::decimateResidual (ChannelState& state) noexcept
{
    double output = 0.0;
    int index = state.residualWriteIndex - 1;
    if (index < 0)
        index += firTaps;

    for (int tap = 0; tap < firTaps; ++tap)
    {
        output += kOversamplingFir[(size_t) tap] * state.residualHistory[(size_t) index];
        if (--index < 0)
            index = firTaps - 1;
    }

    return output;
}

double AnalogSaturationCircuit::delayDry (double input, ChannelState& state) noexcept
{
    state.dryDelay[(size_t) state.dryWriteIndex] = input;
    int readIndex = state.dryWriteIndex + 1;
    if (readIndex >= (int) state.dryDelay.size())
        readIndex = 0;

    const double delayed = state.dryDelay[(size_t) readIndex];
    if (++state.dryWriteIndex >= (int) state.dryDelay.size())
        state.dryWriteIndex = 0;
    return delayed;
}

float AnalogSaturationCircuit::processSample (float input, int channel, float amount) noexcept
{
    if (states.empty())
        return input;

    channel = std::max (0, std::min (channel, (int) states.size() - 1));
    auto& state = states[(size_t) channel];

    const double targetAmount = std::clamp ((double) amount, 0.0, 1.0);
    state.smoothedAmount += amountAlpha * (targetAmount - state.smoothedAmount);
    const double smoothedAmount = delayAmount (state.smoothedAmount, state);

    // Keep the interpolation history current even while SATURATION is off. This
    // makes an automation transition start from real preceding programme samples,
    // but avoids all FIR convolution and Newton work while the delayed amount is
    // fully zero. The dry path still retains the fixed 48-sample latency.
    state.inputHistory[(size_t) state.inputWriteIndex] = (double) input;
    if (++state.inputWriteIndex >= inputHistorySamples)
        state.inputWriteIndex = 0;

    if (smoothedAmount < 1.0e-8 && targetAmount < 1.0e-8)
    {
        if (state.antiAliasActive)
        {
            state.residualHistory.fill (0.0);
            state.residualWriteIndex = 0;
            state.residualIntegrator = 0.0;
            state.dcEstimate = 0.0;
            state.previousPairState = 0.0;
            state.antiAliasActive = false;
        }
        return (float) delayDry ((double) input, state);
    }

    state.antiAliasActive = true;
    double residual = 0.0;
    for (int phase = 0; phase < oversampleFactor; ++phase)
    {
        const double oversampledInput = interpolatePhase (state, phase);
        const double oversampledResidual = nonlinearResidual (oversampledInput,
                                                               smoothedAmount,
                                                               state);
        state.residualHistory[(size_t) state.residualWriteIndex] = oversampledResidual;
        if (++state.residualWriteIndex >= firTaps)
            state.residualWriteIndex = 0;

        // Sample the decimator at oversampled phase zero. Each 193-tap FIR has
        // 96 samples of group delay at 4x = 24 base samples. Sampling phase zero
        // makes the two-filter total exactly 48 base samples with no fractional
        // dry/residual skew.
        if (phase == 0)
            residual = decimateResidual (state);
    }

    // Preserve the v1 analogue residual-bandwidth and 4 Hz DC-servo transfers at
    // base rate. The anti-alias work happens before these stages, not instead of
    // them, which keeps the accepted saturation voicing essentially unchanged.
    const double residualCutoff = std::min (sr * 0.42, 36000.0 - 9000.0 * smoothedAmount);
    const double residualAlpha = onePoleCoefficient (residualCutoff, sr);
    state.residualIntegrator += residualAlpha * (residual - state.residualIntegrator);
    residual = state.residualIntegrator;

    const double dcAlpha = onePoleCoefficient (4.0, sr);
    state.dcEstimate += dcAlpha * (residual - state.dcEstimate);
    residual -= state.dcEstimate;

    const double dry = delayDry ((double) input, state);
    const double output = dry + residual;
    if (! std::isfinite (output))
    {
        state = {};
        return 0.0f;
    }

    return (float) output;
}
