#include "AnalogSaturationCircuit.h"

#include <algorithm>
#include <cmath>

namespace
{
    constexpr double kBoltzmann = 1.380649e-23;
    constexpr double kElectronCharge = 1.602176634e-19;
    constexpr double kTemperatureKelvin = 300.0; // roughly 27 C console interior
    constexpr double kThermalVoltage = kBoltzmann * kTemperatureKelvin / kElectronCharge; // ~25.85 mV

    inline double onePoleCoefficient (double cutoffHz, double sampleRate) noexcept
    {
        cutoffHz = std::max (0.01, std::min (cutoffHz, sampleRate * 0.45));
        return 1.0 - std::exp (-2.0 * 3.14159265358979323846 * cutoffHz / sampleRate);
    }
}

void AnalogSaturationCircuit::prepare (double sampleRate, int numChannels)
{
    sr = std::max (8000.0, sampleRate);
    states.assign ((size_t) std::max (1, numChannels), {});

    // 15 ms control smoothing is short enough to feel immediate but prevents the
    // nonlinear transfer itself from jumping when automation moves the knob.
    amountAlpha = 1.0 - std::exp (-1.0 / (0.015 * sr));
    reset();
}

void AnalogSaturationCircuit::reset() noexcept
{
    for (auto& s : states)
        s = {};
}

double AnalogSaturationCircuit::clampUnit (double x) noexcept
{
    return std::max (-0.9999995, std::min (0.9999995, x));
}

double AnalogSaturationCircuit::fastDbToGain (double db) noexcept
{
    return std::exp (db * 0.1151292546497022842); // ln(10) / 20
}

double AnalogSaturationCircuit::solveDifferentialPair (double v,
                                                         double thermalTerm,
                                                         double emitterTerm,
                                                         double initial) noexcept
{
    // Solve v = A*atanh(m) + B*m.  The function is monotonic for positive A/B,
    // therefore Newton cannot jump to a second root.  Limiting m away from +/-1
    // keeps the derivative finite even under pathological DAW levels.
    double m = clampUnit (initial);

    // A small-signal estimate is a better starting point after reset or a large
    // discontinuity than carrying an unrelated saturated state.
    const double linearEstimate = clampUnit (v / std::max (1.0e-12, thermalTerm + emitterTerm));
    if (! std::isfinite (m) || std::abs (m - linearEstimate) > 0.85)
        m = linearEstimate;

    for (int iteration = 0; iteration < 5; ++iteration)
    {
        m = clampUnit (m);
        const double oneMinusM2 = std::max (1.0e-10, 1.0 - m * m);
        const double f = thermalTerm * std::atanh (m) + emitterTerm * m - v;
        const double df = thermalTerm / oneMinusM2 + emitterTerm;
        const double step = f / std::max (1.0e-12, df);
        m = clampUnit (m - step);

        if (std::abs (step) < 1.0e-10)
            break;
    }

    return m;
}

float AnalogSaturationCircuit::processSample (float input, int channel, float amount) noexcept
{
    if (states.empty())
        return input;

    channel = std::max (0, std::min (channel, (int) states.size() - 1));
    auto& state = states[(size_t) channel];

    const double targetAmount = std::max (0.0, std::min (1.0, (double) amount));
    state.smoothedAmount += amountAlpha * (targetAmount - state.smoothedAmount);
    const double a = state.smoothedAmount;

    // Preserve a true null at the OFF position.  The state values are already zero
    // after prepare/reset, so no hidden filter or gain stage touches the signal.
    if (a < 1.0e-8 && targetAmount < 1.0e-8)
        return input;

    // The knob primarily increases analogue drive.  A convex law keeps the first
    // half useful for subtle colour and reserves the upper quarter for obvious
    // saturation.  Internal post-normalisation means drive does not act like a
    // second fader; the strip's AUTO LEVEL then corrects the remaining RMS change.
    const double driveDb = 24.0 * std::pow (a, 1.35);
    const double drive = fastDbToGain (driveDb);

    // Scale the floating-point DAW sample to the differential voltage presented to
    // the model.  At normal programme level (-18 dBFS vicinity) the pair is mostly
    // linear; peaks and added drive progressively steer the pair toward its finite
    // tail-current limit.
    constexpr double voltsPerDigitalPeak = 0.115;

    // Ebers-Moll differential pair term: 2*n*Vt.  Emitter degeneration is reduced
    // slightly with drive, reproducing the familiar transition from broad/soft
    // compression to a denser top end without ever changing to a hard clipper.
    const double ideality = 1.06;
    const double thermalTerm = 2.0 * ideality * kThermalVoltage;
    const double emitterDegenerationTerm = 0.145 - 0.040 * a;
    const double linearScale = thermalTerm + emitterDegenerationTerm;

    // A tiny transistor mismatch is intentional.  Solving both the signal and the
    // zero-input operating point then subtracting them guarantees no static jump at
    // zero while retaining a controlled amount of even-harmonic asymmetry.
    const double biasVoltage = 0.0040 * a;
    const double physicalInput = (double) input * voltsPerDigitalPeak * drive + biasVoltage;

    const double m = solveDifferentialPair (physicalInput,
                                            thermalTerm,
                                            emitterDegenerationTerm,
                                            state.previousPairState);
    const double m0 = solveDifferentialPair (biasVoltage,
                                             thermalTerm,
                                             emitterDegenerationTerm,
                                             0.0);
    state.previousPairState = m;

    // Multiplication by the small-signal denominator restores unity gain around the
    // origin.  Dividing by drive makes the control change harmonic density instead
    // of simply making the channel louder.
    const double pairOutput = (m - m0) * linearScale;
    const double normalisedOutput = pairOutput / (voltsPerDigitalPeak * drive);
    double residual = normalisedOutput - (double) input;

    // Analogue stages do not create unlimited ultrasonic harmonic energy.  Rather
    // than low-passing the entire audio path, only the nonlinear residual is given
    // a finite bandwidth.  The dry signal therefore keeps the exact original HF
    // response while generated harmonics roll away before the Nyquist region.
    const double residualCutoff = std::min (sr * 0.42, 36000.0 - 9000.0 * a);
    const double residualAlpha = onePoleCoefficient (residualCutoff, sr);
    state.residualIntegrator += residualAlpha * (residual - state.residualIntegrator);
    residual = state.residualIntegrator;

    // 4 Hz DC servo removes the minute offset produced by the deliberate device
    // mismatch without altering bass programme content.
    const double dcAlpha = onePoleCoefficient (4.0, sr);
    state.dcEstimate += dcAlpha * (residual - state.dcEstimate);
    residual -= state.dcEstimate;

    const double output = (double) input + residual;
    if (! std::isfinite (output))
    {
        state = {};
        return input;
    }

    return (float) output;
}
