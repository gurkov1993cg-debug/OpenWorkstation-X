#pragma once

#include <JuceHeader.h>
#include <array>
#include <functional>
#include <map>
#include <memory>
#include <vector>
#include "PluginProcessor.h"

enum class ConsoleValueStyle
{
    dB,
    drive,
    frequency,
    q,
    ratio,
    release,
    percent,
    hold,
    pan,
    plain
};

enum class ConsoleButtonStyle { Square, Wide, RatioTab };

struct KnobSpec
{
    const char* paramId;
    const char* label;
    int x, y, w, h;
    uint32_t faceColour;
    const char* topText;
    const char* minText;
    const char* unitText;
    const char* maxText;
    bool hasValueBox;
    ConsoleValueStyle valueStyle;
};

struct FaderSpec
{
    const char* paramId;
    const char* label;
    int x, y, w, h;
    uint32_t faceColour;
    const char* topText;
    const char* bottomText;
    bool hasValueBox;
    ConsoleValueStyle valueStyle;
};

struct ButtonSpec
{
    const char* paramId;
    const char* text;
    int x, y, w, h;
    ConsoleButtonStyle style;
    uint32_t onColour;
    bool hasLed;
};

struct ChoiceSpec
{
    const char* paramId;
    const char* labelA;
    const char* labelB;
    int x, y, w, h;
    uint32_t onColour;
};

struct SectionSpec
{
    const char* title;
    int x, y, w, h;
    bool hasScrews;
};

struct LabelSpec
{
    const char* text;
    int x, y, w, h;
    float size;
    uint32_t colour;
    int justification;
};

class ParameterHardwareControl : public juce::Component
{
public:
    ParameterHardwareControl (juce::String parameterId, juce::RangedAudioParameter* parameter);
    ~ParameterHardwareControl() override = default;

    juce::RangedAudioParameter* getParameter() const noexcept { return param; }
    float normalisedValue() const noexcept;
    double actualValue() const noexcept;
    void setNormalisedValue (float value, bool withGesture);
    void resetToDefault();
    virtual void exerciseForTest() = 0;

protected:
    void beginGesture();
    void endGesture();
    juce::RangedAudioParameter* param = nullptr;
    bool gestureActive = false;
};

class HardwareKnob final : public ParameterHardwareControl
{
public:
    HardwareKnob (const KnobSpec&, juce::RangedAudioParameter*);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void exerciseForTest() override;

private:
    juce::String label, topText, minText, unitText, maxText;
    juce::Colour faceColour;
    ConsoleValueStyle style = ConsoleValueStyle::plain;
    bool hasValueBox = false;
    float dragStartValue = 0.0f;
    int dragStartY = 0;
};

class HardwareFader final : public ParameterHardwareControl
{
public:
    HardwareFader (const FaderSpec&, juce::RangedAudioParameter*);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void exerciseForTest() override;

private:
    juce::String label, topText, bottomText;
    juce::Colour faceColour;
    ConsoleValueStyle style = ConsoleValueStyle::plain;
    bool hasValueBox = false;
    float dragStartValue = 0.0f;
    int dragStartY = 0;
};

class HardwareToggle final : public ParameterHardwareControl
{
public:
    HardwareToggle (const ButtonSpec&, juce::RangedAudioParameter*);

    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void exerciseForTest() override;
    bool isOn() const noexcept { return normalisedValue() >= 0.5f; }

private:
    juce::String label;
    juce::Colour onColour;
    ConsoleButtonStyle buttonStyle = ConsoleButtonStyle::Square;
    bool hasLed = false;
};

class HardwareChoice final : public ParameterHardwareControl
{
public:
    HardwareChoice (const ChoiceSpec&, juce::RangedAudioParameter*);

    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void exerciseForTest() override;

private:
    int currentIndex() const noexcept;
    void chooseIndex (int index, bool withGesture);
    juce::String a, b;
    juce::Colour onColour;
};

class HardwareActionButton final : public juce::Component
{
public:
    HardwareActionButton (juce::String name,
                          juce::String text,
                          juce::Colour accent,
                          std::function<void()> action,
                          std::function<bool()> stateProvider = {});

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void triggerForTest();

private:
    juce::String text;
    juce::Colour accent;
    std::function<void()> action;
    std::function<bool()> stateProvider;
    bool pressed = false;
};

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

    static constexpr int designWidth = 1536;
    static constexpr int designHeight = 1024;
    static void drawLed (juce::Graphics&, float x, float y, bool on, juce::Colour colour);

private:
    void timerCallback() override;
    void resetToInit();
    void setUiScale (float newScale);
    void setParameterActual (const char* id, float actual);
    float parameterActual (const char* id) const;

    void createControlsFromLayout();
    void placeDesignBounds (juce::Component&, int x, int y, int w, int h);

    static juce::String formatValue (double, ConsoleValueStyle);
    static void drawScrew (juce::Graphics&, float, float, float angle);
    static void drawPanel (juce::Graphics&, const SectionSpec&);
    static void drawStereoMeter (juce::Graphics&, juce::Rectangle<int>, float leftDb, float rightDb,
                                 bool scaleOnRight, const juce::String& title);
    static void drawGrMeter (juce::Graphics&, juce::Rectangle<int>, float grDb);
    static void drawBandCurve (juce::Graphics&, juce::Rectangle<float>, bool shelf, bool high);

    void rebuildStaticLayer();
    void paintStaticDesign (juce::Graphics&);
    void paintDynamicDesign (juce::Graphics&);

    ConsoleChannelStripXAudioProcessor& audioProcessor;

    std::map<juce::String, std::unique_ptr<HardwareKnob>> knobs;
    std::map<juce::String, std::unique_ptr<HardwareFader>> faders;
    std::map<juce::String, std::unique_ptr<HardwareToggle>> toggles;
    std::map<juce::String, std::unique_ptr<HardwareChoice>> choices;

    std::unique_ptr<HardwareActionButton> powerButton;
    std::unique_ptr<HardwareActionButton> undoButton;
    std::unique_ptr<HardwareActionButton> redoButton;
    std::unique_ptr<HardwareActionButton> initButton;
    std::unique_ptr<HardwareActionButton> zoomOutButton;
    std::unique_ptr<HardwareActionButton> zoomResetButton;
    std::unique_ptr<HardwareActionButton> zoomInButton;
    std::array<std::unique_ptr<HardwareActionButton>, 6> ratioTabs;

    juce::Image staticLayer;
    float uiScale = 1.0f;
    float compGrDisplayDb = 0.0f;
    float gateGrDisplayDb = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
