#pragma once

#include <JuceHeader.h>
#include <functional>
#include <map>
#include <memory>
#include <vector>
#include "PluginProcessor.h"

// The editor deliberately does not use JUCE Slider/Button/LookAndFeel widgets.
// JUCE is only the windowing/graphics/event framework here. Every visible control
// below owns the exact APVTS parameter it manipulates and draws its own hardware UI.

enum class ConsoleValueStyle
{
    dB,
    drive,
    frequency,
    q,
    ratio,
    release,
    percent,
    hold,
    plain
};

class ParameterHardwareControl : public juce::Component
{
public:
    ParameterHardwareControl (juce::String parameterId, juce::RangedAudioParameter* parameter);
    ~ParameterHardwareControl() override = default;

    juce::RangedAudioParameter* getParameter() const noexcept { return param; }
    float normalisedValue() const noexcept;
    double actualValue() const noexcept;
    void setNormalisedValue (float value, bool withGesture);
    void resetToDefault();

    // Used by the real GUI regression test to prove that each control changes
    // its APVTS parameter. Implementations exercise their actual interaction law.
    virtual void exerciseForTest() = 0;

protected:
    void beginGesture();
    void endGesture();
    juce::RangedAudioParameter* param = nullptr;
    bool gestureActive = false;
};

class HardwareKnob final : public ParameterHardwareControl
{
public:
    HardwareKnob (juce::String parameterId,
                  juce::RangedAudioParameter* parameter,
                  juce::String label,
                  juce::Colour accent,
                  ConsoleValueStyle valueStyle,
                  juce::String leftScale,
                  juce::String rightScale);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void exerciseForTest() override;

private:
    juce::String label;
    juce::String leftScale;
    juce::String rightScale;
    juce::Colour accent;
    ConsoleValueStyle style;
    float dragStartValue = 0.0f;
    int dragStartY = 0;
};

class HardwareFader final : public ParameterHardwareControl
{
public:
    HardwareFader (juce::String parameterId,
                   juce::RangedAudioParameter* parameter,
                   juce::String label,
                   juce::Colour accent,
                   ConsoleValueStyle valueStyle,
                   juce::String topScale,
                   juce::String bottomScale);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
    void exerciseForTest() override;

private:
    juce::String label;
    juce::String topScale;
    juce::String bottomScale;
    juce::Colour accent;
    ConsoleValueStyle style;
    float dragStartValue = 0.0f;
    int dragStartY = 0;
};

class HardwareToggle final : public ParameterHardwareControl
{
public:
    HardwareToggle (juce::String parameterId,
                    juce::RangedAudioParameter* parameter,
                    juce::String label,
                    juce::Colour accent);

    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void exerciseForTest() override;
    bool isOn() const noexcept { return normalisedValue() >= 0.5f; }

private:
    juce::String label;
    juce::Colour accent;
};

class HardwareChoice final : public ParameterHardwareControl
{
public:
    HardwareChoice (juce::String parameterId,
                    juce::RangedAudioParameter* parameter,
                    juce::StringArray labels);

    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void exerciseForTest() override;

private:
    int currentIndex() const noexcept;
    void chooseIndex (int index, bool withGesture);
    juce::StringArray choices;
};

class HardwareActionButton final : public juce::Component
{
public:
    HardwareActionButton (juce::String name,
                          juce::String text,
                          juce::Colour accent,
                          std::function<void()> action,
                          std::function<bool()> stateProvider = {});

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void triggerForTest();

private:
    juce::String text;
    juce::Colour accent;
    std::function<void()> action;
    std::function<bool()> stateProvider;
    bool pressed = false;
};

class ConsoleChannelStripXAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                       private juce::Timer
{
public:
    explicit ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor&);
    ~ConsoleChannelStripXAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;

    void addKnob (const juce::String& id, const juce::String& label, juce::Colour accent,
                  ConsoleValueStyle style, const juce::String& leftScale = {}, const juce::String& rightScale = {});
    void addFader (const juce::String& id, const juce::String& label, juce::Colour accent,
                   ConsoleValueStyle style, const juce::String& topScale = {}, const juce::String& bottomScale = {});
    void addToggle (const juce::String& id, const juce::String& label, juce::Colour accent);
    void addChoice (const juce::String& id, juce::StringArray labels);

    void placeKnob (const juce::String& id, int x, int y, int w, int h);
    void placeFader (const juce::String& id, int x, int y, int w, int h);
    void placeToggle (const juce::String& id, int x, int y, int w, int h);
    void placeChoice (const juce::String& id, int x, int y, int w, int h);

    static juce::String formatValue (double, ConsoleValueStyle);
    static void drawScrew (juce::Graphics&, float, float, float angle = 0.0f);
    static void drawHardwarePanel (juce::Graphics&, juce::Rectangle<int>, const juce::String& title);
    static void drawMeterScreen (juce::Graphics&, juce::Rectangle<int>, float inputDb, float compGrDb,
                                 float gateGrDb, float outputDb, float inPeakDb, float outPeakDb);
    static void drawMiniLedMeter (juce::Graphics&, juce::Rectangle<int>, float db);
    static void drawSectionLabel (juce::Graphics&, juce::Rectangle<int>, const juce::String&, juce::Colour);

    void rebuildStaticLayer();
    void paintStatic (juce::Graphics&);
    void resetToInit();

    ConsoleChannelStripXAudioProcessor& audioProcessor;

    std::map<juce::String, std::unique_ptr<HardwareKnob>> knobs;
    std::map<juce::String, std::unique_ptr<HardwareFader>> faders;
    std::map<juce::String, std::unique_ptr<HardwareToggle>> toggles;
    std::map<juce::String, std::unique_ptr<HardwareChoice>> choices;

    std::unique_ptr<HardwareActionButton> powerButton;
    std::unique_ptr<HardwareActionButton> undoButton;
    std::unique_ptr<HardwareActionButton> redoButton;
    std::unique_ptr<HardwareActionButton> initButton;

    juce::Image staticLayer;
    float inputPeakHoldDb = -60.0f;
    float outputPeakHoldDb = -60.0f;
    float compGrDisplayDb = 0.0f;
    float gateGrDisplayDb = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ConsoleChannelStripXAudioProcessorEditor)
};
