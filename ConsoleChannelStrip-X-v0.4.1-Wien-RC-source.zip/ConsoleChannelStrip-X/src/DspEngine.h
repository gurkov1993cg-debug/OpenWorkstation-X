#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <atomic>
#include <vector>
#include "SslDynamicsCircuit.h"
#include "AnalogSaturationCircuit.h"
#include "ConsoleDspPrimitives.h"

class DspEngine
{
public:
    struct Params
    {
        float inputTrimDb = 0.0f;
        float inputDrive = 0.0f;
        int inputMode = 0; // 0 = line, 1 = mic/preamp colour
        bool inputPad = false; // real -20 dB software pad before the input stage
        bool polarity = false;

        bool hpOn = false;
        float hpFreq = 80.0f;
        bool lpOn = false;
        float lpFreq = 18000.0f;

        bool eqOn = true;
        bool blackEq = true; // false = 02 Brown, true = 242 Black
        bool lfBell = false;
        float lfFreq = 80.0f;
        float lfGain = 0.0f;
        float lmfFreq = 500.0f;
        float lmfGain = 0.0f;
        float lmfQ = 1.0f;
        float hmfFreq = 2500.0f;
        float hmfGain = 0.0f;
        float hmfQ = 1.0f;
        bool hfBell = false;
        float hfFreq = 10000.0f;
        float hfGain = 0.0f;

        bool dynOn = false;
        SslDynamicsCircuit::Circuit dynamicsCircuit {};

        int routing = 0;
        float vcaFaderDb = 0.0f;
        float outputTrimDb = 0.0f;
        bool autoLevelMatch = false; // processor default is ON; direct engine tests opt in explicitly
        float pan = 0.0f; // -1 = left, 0 = centre, +1 = right (stereo balance)
        float mix = 1.0f;
        bool mute = false;
        bool bypass = false;

        // Dedicated console saturation. saturationOn is a true section bypass:
        // when OFF, both SAT GAIN and nonlinear colour are bypassed while the
        // project-owned 48-sample anti-alias delay remains aligned.
        bool saturationOn = true;
        float saturation = 0.0f; // 0..100 %
        float saturationGainDb = 0.0f; // -12..+18 dB pre-gain into saturation circuit

        // MicroShift-inspired stereo image section.  The implementation is original:
        // a focused, time-varying dual-delay micro-pitch network that adds side energy
        // without touching the low band below stereoFocusHz.
        float stereoWidth = 0.0f;   // 0..100 %, default OFF for session compatibility
        float stereoDetune = 7.0f;  // 0..20 cents modulation depth
        float stereoDelayMs = 10.0f; // 0..25 ms nominal offset
        float stereoFocusHz = 120.0f; // 20 Hz..10 kHz crossover
    };

    void prepare (double sampleRate, int maximumBlockSize, int numChannels);
    void reset();
    void process (juce::AudioBuffer<float>& buffer, const Params& p);
    static constexpr int latencySamples() noexcept { return AnalogSaturationCircuit::latencySamples(); }

    float getCompressorGainReductionDb() const noexcept { return compMeterDb.load(); }
    float getGateGainReductionDb() const noexcept { return gateMeterDb.load(); }
    float consumeCompressorPeakReductionDb() noexcept { return compReductionHeldDb.exchange (0.0f); }
    float consumeGatePeakReductionDb() noexcept { return gateReductionHeldDb.exchange (0.0f); }
    float getInputPeakDb() const noexcept { return inputPeakDb.load(); }
    float getOutputPeakDb() const noexcept { return outputPeakDb.load(); }
    float getInputLeftPeakDb() const noexcept { return inputLeftPeakDb.load(); }
    float getInputRightPeakDb() const noexcept { return inputRightPeakDb.load(); }
    float getOutputLeftPeakDb() const noexcept { return outputLeftPeakDb.load(); }
    float getOutputRightPeakDb() const noexcept { return outputRightPeakDb.load(); }
    float getPreSaturationPeakDb() const noexcept { return preSaturationPeakDb.load(); }

    // Peak accumulators retain the highest sample peak between GUI reads, so a
    // transient cannot disappear merely because the editor refresh rate is slower
    // than the audio block rate.
    float consumeInputLeftPeakDb() noexcept { return inputLeftPeakHeldDb.exchange (-100.0f); }
    float consumeInputRightPeakDb() noexcept { return inputRightPeakHeldDb.exchange (-100.0f); }
    float consumeOutputLeftPeakDb() noexcept { return outputLeftPeakHeldDb.exchange (-100.0f); }
    float consumeOutputRightPeakDb() noexcept { return outputRightPeakHeldDb.exchange (-100.0f); }
    float consumePreSaturationPeakDb() noexcept { return preSaturationPeakHeldDb.exchange (-100.0f); }

private:
    void updateFilters (const Params& p, int blockSamples);
    void processFilters (juce::AudioBuffer<float>& buffer, const Params& p);
    void processEQ (juce::AudioBuffer<float>& buffer, const Params& p);
    void processDynamics (juce::AudioBuffer<float>& buffer, const Params& p);
    void processInputStage (juce::AudioBuffer<float>& buffer, const Params& p);
    void processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p);
    void processAutoLevelMatch (juce::AudioBuffer<float>& buffer, const juce::AudioBuffer<float>& reference, const Params& p);
    void processSaturation (juce::AudioBuffer<float>& buffer, const Params& p);
    void processStereoWidth (juce::AudioBuffer<float>& buffer, const Params& p);
    float readStereoDelay (float delaySamples) const noexcept;
    bool filterParametersChanged (const Params& p) const noexcept;
    void setFilterTargets (const Params& p);
    void smoothFilterCoefficients (int blockSamples);

    static float transformerSaturate (float x, float amount);
    static float vcaSaturate (float x, float amount);
    static float bufferPeakDb (const juce::AudioBuffer<float>& buffer);
    static float channelPeakDb (const juce::AudioBuffer<float>& buffer, int channel);
    static double bufferMeanSquare (const juce::AudioBuffer<float>& buffer, int numSamples) noexcept;
    static void accumulatePeak (std::atomic<float>& destination, float candidate) noexcept;

    double sr = 48000.0;
    consoledsp::BiquadBank hp1, hp2, lp, lf, lmf, hmf, hf;
    consoledsp::BiquadCoefficients hp1Target {}, hp2Target {}, lpTarget {};
    consoledsp::BiquadCoefficients lfTarget {}, lmfTarget {}, hmfTarget {}, hfTarget {};
    juce::AudioBuffer<float> globalDryBuffer;
    std::vector<std::vector<float>> dryLatencyLines;
    int dryLatencyWriteIndex = 0;

    std::vector<float> stereoDelayLine;
    int stereoDelayWriteIndex = 0;
    double stereoLfoPhaseL = 0.0;
    double stereoLfoPhaseR = consoledsp::pi;
    float stereoFocusLowState = 0.0f;
    float stereoSideLowState = 0.0f;

    Params lastFilterParams;
    bool filterCacheValid = false;
    bool filterStatesInitialised = false;
    bool gainSmoothersInitialised = false;
    bool stereoWidthWasActive = false;

    consoledsp::MultiplicativeSmoother inputTrimGain { 1.0f };
    consoledsp::LinearSmoother panLeftGain { 1.0f };
    consoledsp::LinearSmoother panRightGain { 1.0f };
    consoledsp::MultiplicativeSmoother inputDriveGain { 1.0f };
    consoledsp::MultiplicativeSmoother vcaGain { 1.0f };
    consoledsp::MultiplicativeSmoother outputTrimGain { 1.0f };
    consoledsp::LinearSmoother mixSmoother { 1.0f };
    consoledsp::LinearSmoother vcaSaturationSmoother { 0.0f };
    consoledsp::MultiplicativeSmoother saturationDriveGain { 1.0f };

    // Whole-strip level matching.  Two slow energy detectors estimate the raw
    // input and processed wet level.  A separate, slower gain servo then brings
    // the processed path back to the input RMS without touching the actual EQ,
    // compressor or gate control laws.
    double autoInputPower = 0.0;
    double autoOutputPower = 0.0;
    float autoMatchGainDb = 0.0f;
    float autoMatchAppliedGain = 1.0f;

    SslDynamicsCircuit dynamicsCircuit;
    AnalogSaturationCircuit saturationCircuit;

    std::atomic<float> compMeterDb { 0.0f };
    std::atomic<float> gateMeterDb { 0.0f };
    std::atomic<float> compReductionHeldDb { 0.0f };
    std::atomic<float> gateReductionHeldDb { 0.0f };
    std::atomic<float> inputPeakDb { -100.0f };
    std::atomic<float> outputPeakDb { -100.0f };
    std::atomic<float> inputLeftPeakDb { -100.0f };
    std::atomic<float> inputRightPeakDb { -100.0f };
    std::atomic<float> outputLeftPeakDb { -100.0f };
    std::atomic<float> outputRightPeakDb { -100.0f };
    std::atomic<float> preSaturationPeakDb { -100.0f };
    std::atomic<float> inputLeftPeakHeldDb { -100.0f };
    std::atomic<float> inputRightPeakHeldDb { -100.0f };
    std::atomic<float> outputLeftPeakHeldDb { -100.0f };
    std::atomic<float> outputRightPeakHeldDb { -100.0f };
    std::atomic<float> preSaturationPeakHeldDb { -100.0f };
};
