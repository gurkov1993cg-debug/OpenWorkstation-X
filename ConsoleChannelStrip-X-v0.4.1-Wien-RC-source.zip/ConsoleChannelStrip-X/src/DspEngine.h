#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_dsp/juce_dsp.h>
#include <atomic>
#include "SslDynamicsCircuit.h"

class DspEngine
{
public:
    using IIR = juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>>;
    using Coefficients = juce::dsp::IIR::Coefficients<float>;
    using CoeffPtr = Coefficients::Ptr;

    struct Params
    {
        float inputTrimDb = 0.0f;
        float inputDrive = 0.0f;
        int inputMode = 0; // 0 = line, 1 = mic/preamp colour
        bool polarity = false;

        bool hpOn = false;
        float hpFreq = 80.0f;
        bool lpOn = false;
        float lpFreq = 18000.0f;

        bool eqOn = true;
        bool blackEq = true; // false = 02 Brown, true = 242 Black
        bool lfBell = false;
        float lfFreq = 80.0f;
        float lfGain = 0.0f;
        float lmfFreq = 500.0f;
        float lmfGain = 0.0f;
        float lmfQ = 1.0f;
        float hmfFreq = 2500.0f;
        float hmfGain = 0.0f;
        float hmfQ = 1.0f;
        bool hfBell = false;
        float hfFreq = 10000.0f;
        float hfGain = 0.0f;

        bool dynOn = true;
        SslDynamicsCircuit::Circuit dynamicsCircuit {};

        int routing = 0;
        float vcaFaderDb = 0.0f;
        float outputTrimDb = 0.0f;
        float mix = 1.0f;
        bool mute = false;
        bool bypass = false;
        int channelMode = 0; // 0 = stereo, 1 = mid/side processing
    };

    void prepare (double sampleRate, int maximumBlockSize, int numChannels);
    void reset();
    void process (juce::AudioBuffer<float>& buffer, const Params& p);

    float getCompressorGainReductionDb() const noexcept { return compMeterDb.load(); }
    float getGateGainReductionDb() const noexcept { return gateMeterDb.load(); }
    float getInputPeakDb() const noexcept { return inputPeakDb.load(); }
    float getOutputPeakDb() const noexcept { return outputPeakDb.load(); }

private:
    void updateFilters (const Params& p, int blockSamples);
    void processFilters (juce::AudioBuffer<float>& buffer, const Params& p);
    void processEQ (juce::AudioBuffer<float>& buffer, const Params& p);
    void processDynamics (juce::AudioBuffer<float>& buffer, const Params& p);
    void processInputStage (juce::AudioBuffer<float>& buffer, const Params& p);
    void processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p);
    void encodeMidSide (juce::AudioBuffer<float>& buffer);
    void decodeMidSide (juce::AudioBuffer<float>& buffer);
    bool filterParametersChanged (const Params& p) const noexcept;
    void setFilterTargets (const Params& p);
    void smoothFilterCoefficients (int blockSamples);

    static float transformerSaturate (float x, float amount);
    static float vcaSaturate (float x, float amount);
    static float bufferPeakDb (const juce::AudioBuffer<float>& buffer);
    static void moveCoefficientsTowards (IIR& filter, const CoeffPtr& target, float alpha);

    double sr = 48000.0;
    IIR hp1, hp2, lp, lf, lmf, hmf, hf;
    CoeffPtr hp1Target, hp2Target, lpTarget, lfTarget, lmfTarget, hmfTarget, hfTarget;
    juce::AudioBuffer<float> globalDryBuffer;

    Params lastFilterParams;
    bool filterCacheValid = false;
    bool filterStatesInitialised = false;
    bool gainSmoothersInitialised = false;

    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Multiplicative> inputTrimGain { 1.0f };
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Multiplicative> inputDriveGain { 1.0f };
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Multiplicative> vcaGain { 1.0f };
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Multiplicative> outputTrimGain { 1.0f };
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> mixSmoother { 1.0f };
    juce::SmoothedValue<float, juce::ValueSmoothingTypes::Linear> vcaSaturationSmoother { 0.0f };

    SslDynamicsCircuit dynamicsCircuit;

    std::atomic<float> compMeterDb { 0.0f };
    std::atomic<float> gateMeterDb { 0.0f };
    std::atomic<float> inputPeakDb { -100.0f };
    std::atomic<float> outputPeakDb { -100.0f };
};
