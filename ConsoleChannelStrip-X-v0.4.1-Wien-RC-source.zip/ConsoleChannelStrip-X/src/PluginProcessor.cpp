#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    using Range = juce::NormalisableRange<float>;

    std::unique_ptr<juce::RangedAudioParameter> makeFloat (const char* id, const char* name,
                                                            float min, float max, float def,
                                                            float centre = 0.0f)
    {
        Range r (min, max);
        if (centre > min && centre < max)
            r.setSkewForCentre (centre);
        return std::make_unique<juce::AudioParameterFloat> (id, name, r, def);
    }

    std::unique_ptr<juce::RangedAudioParameter> makeBool (const char* id, const char* name, bool def)
    {
        return std::make_unique<juce::AudioParameterBool> (id, name, def);
    }

    SslDynamicsCircuit::Circuit makeDynamicsCircuit (float compThresholdDb, float compRatioPanel,
                                                      float compReleaseSeconds, bool compFast, bool compOn,
                                                      float gateThresholdDb, float gateRangeDb,
                                                      float gateHoldSeconds, float gateReleaseSeconds,
                                                      bool gateFast, bool gateExpand, bool gateOn)
    {
        SslDynamicsCircuit::Circuit c;

        // Detector/VCA scale is common to the entire control path. [SPEC-FAMILY]
        constexpr double voltsPerDb = 0.0061;
        c.detector.voltsPerDb = voltsPerDb;
        c.detector.averagingCapF = 10.0e-9;   // [CHOICE]
        c.detector.timingCurrentA = 25.9e-9;  // [FIT] -> about 10 ms detector averaging

        // The console panel scale is analogue operating level, not dBFS. [CHOICE]
        // Calibrate panel 0 dB to -18 dBFS so ordinary recorded material can reach
        // useful 7-10 dB reductions without driving the plug-in near full scale.
        // This offset is a plug-in reference calibration, not an invented SSL part.
        constexpr double panelZeroReferenceDbFs = -18.0; // [CHOICE]
        c.compressorThresholdCvV = (static_cast<double> (compThresholdDb) + panelZeroReferenceDbFs) * voltsPerDb;
        // Authentic auto make-up follows the panel threshold setting itself, not
        // the digital dBFS calibration offset. Otherwise merely choosing -18 dBFS
        // nominal level would create make-up gain at a +10 dB panel threshold.
        c.compressorPanelThresholdCvV = static_cast<double> (compThresholdDb) * voltsPerDb;
        c.compressorEnabled = compOn;
        c.compressorFastAttack = compFast;

        // Panel ratio selects the lower resistor of the gain-computer divider.
        // ratio = (Rt + Rb) / Rt; the panel's INF end uses a finite laboratory
        // approximation of 10 Mohm rather than a magic slope constant.
        c.gainDivider.topOhm = 10000.0; // [CHOICE]
        if (compRatioPanel >= 19.95f)
            c.gainDivider.bottomOhm = 10.0e6; // [CHOICE] practical limiter approximation
        else
            c.gainDivider.bottomOhm = c.gainDivider.topOhm * std::max (0.0, static_cast<double> (compRatioPanel) - 1.0);

        // RELEASE panel moves the release resistor; the timing capacitor is fixed.
        c.compressorTiming.mainCapF = 1.0e-6;
        c.compressorTiming.releaseResistorOhm = std::max (1.0, static_cast<double> (compReleaseSeconds)
                                                              / c.compressorTiming.mainCapF);

        // Gate/expander uses the same detector and the same final VCA control node.
        c.gateEnabled = gateOn;
        c.gateFastAttack = gateFast;
        c.gateExpandMode = gateExpand;
        c.gateThresholdCvV = (static_cast<double> (gateThresholdDb) + panelZeroReferenceDbFs) * voltsPerDb;
        c.gateRangeCvV = std::max (0.0, static_cast<double> (gateRangeDb)) * voltsPerDb;
        c.gate.releaseResistorOhm = std::max (1.0, static_cast<double> (gateReleaseSeconds) / c.gate.mainCapF);
        c.gate.holdResistorOhm = std::max (1.0, static_cast<double> (gateHoldSeconds) / c.gate.holdCapF);
        return c;
    }
}

ConsoleChannelStripXAudioProcessor::ConsoleChannelStripXAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, &undoManager, "PARAMETERS", createParameterLayout())
{
}

void ConsoleChannelStripXAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    engine.prepare (sampleRate, samplesPerBlock, getTotalNumOutputChannels());
}

void ConsoleChannelStripXAudioProcessor::releaseResources() {}

bool ConsoleChannelStripXAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (in != out)
        return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

DspEngine::Params ConsoleChannelStripXAudioProcessor::readParams() const
{
    DspEngine::Params p;
    auto v = [this] (const char* id) { return apvts.getRawParameterValue (id)->load(); };

    p.inputTrimDb = v ("inputTrim");
    p.inputDrive = v ("inputDrive");
    p.inputMode = static_cast<int> (v ("inputMode"));
    p.inputPad = v ("inputPad") > 0.5f;
    p.polarity = v ("polarity") > 0.5f;

    p.hpOn = v ("hpOn") > 0.5f;
    p.hpFreq = v ("hpFreq");
    p.lpOn = v ("lpOn") > 0.5f;
    p.lpFreq = v ("lpFreq");

    p.eqOn = v ("eqOn") > 0.5f;
    p.blackEq = v ("eqModel") > 0.5f;
    p.lfBell = v ("lfBell") > 0.5f;
    p.lfFreq = v ("lfFreq");
    p.lfGain = v ("lfGain");
    p.lmfFreq = v ("lmfFreq");
    p.lmfGain = v ("lmfGain");
    p.lmfQ = v ("lmfQ");
    p.hmfFreq = v ("hmfFreq");
    p.hmfGain = v ("hmfGain");
    p.hmfQ = v ("hmfQ");
    p.hfBell = v ("hfBell") > 0.5f;
    p.hfFreq = v ("hfFreq");
    p.hfGain = v ("hfGain");

    p.dynOn = v ("dynOn") > 0.5f;
    p.dynamicsCircuit = makeDynamicsCircuit (
        v ("compThreshold"), v ("compRatio"), v ("compRelease"),
        v ("compFast") > 0.5f, v ("compOn") > 0.5f,
        v ("gateThreshold"), v ("gateRange"), v ("gateHold"), v ("gateRelease"),
        v ("gateFast") > 0.5f, v ("gateExpand") > 0.5f, v ("gateOn") > 0.5f);

    p.routing = static_cast<int> (v ("routing"));
    p.vcaFaderDb = v ("vcaFader");
    p.outputTrimDb = v ("outputTrim");
    p.pan = v ("pan");
    p.mix = v ("mix") * 0.01f;
    p.mute = v ("mute") > 0.5f;
    p.bypass = v ("bypass") > 0.5f;
    p.channelMode = static_cast<int> (v ("channelMode"));
    return p;
}

void ConsoleChannelStripXAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, buffer.getNumSamples());
    engine.process (buffer, readParams());
}

juce::AudioProcessorEditor* ConsoleChannelStripXAudioProcessor::createEditor()
{
    return new ConsoleChannelStripXAudioProcessorEditor (*this);
}

void ConsoleChannelStripXAudioProcessor::resetParametersToDefaults()
{
    undoManager.beginNewTransaction ("INIT");
    for (auto* parameter : getParameters())
    {
        if (auto* ranged = dynamic_cast<juce::RangedAudioParameter*> (parameter))
        {
            ranged->beginChangeGesture();
            ranged->setValueNotifyingHost (ranged->getDefaultValue());
            ranged->endChangeGesture();
        }
    }
}

void ConsoleChannelStripXAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void ConsoleChannelStripXAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorParameter* ConsoleChannelStripXAudioProcessor::getBypassParameter() const
{
    return apvts.getParameter ("bypass");
}

juce::AudioProcessorValueTreeState::ParameterLayout ConsoleChannelStripXAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (makeFloat ("inputTrim", "Input Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeFloat ("inputDrive", "Input Drive", -20.0f, 20.0f, 0.0f));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("inputMode", "Input Mode",
                                                                juce::StringArray { "Line", "Mic" }, 0));
    p.push_back (makeBool ("inputPad", "Input Pad -20 dB", false));
    p.push_back (makeBool ("polarity", "Polarity", false));

    p.push_back (makeBool ("hpOn", "High Pass On", false));
    p.push_back (makeFloat ("hpFreq", "High Pass Frequency", 16.0f, 350.0f, 80.0f, 100.0f));
    p.push_back (makeBool ("lpOn", "Low Pass On", false));
    p.push_back (makeFloat ("lpFreq", "Low Pass Frequency", 3000.0f, 22000.0f, 18000.0f, 10000.0f));

    p.push_back (makeBool ("eqOn", "EQ On", true));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("eqModel", "EQ Model",
                                                                juce::StringArray { "02 Brown", "242 Black" }, 1));
    p.push_back (makeBool ("hfBell", "HF Bell", false));
    p.push_back (makeFloat ("hfFreq", "HF Frequency", 1500.0f, 16000.0f, 10000.0f, 8000.0f));
    p.push_back (makeFloat ("hfGain", "HF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("hmfFreq", "HMF Frequency", 600.0f, 7000.0f, 2500.0f, 2500.0f));
    p.push_back (makeFloat ("hmfGain", "HMF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("hmfQ", "HMF Q", 0.10f, 3.5f, 1.0f, 1.0f));
    p.push_back (makeFloat ("lmfFreq", "LMF Frequency", 200.0f, 2500.0f, 500.0f, 700.0f));
    p.push_back (makeFloat ("lmfGain", "LMF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("lmfQ", "LMF Q", 0.10f, 3.5f, 1.0f, 1.0f));
    p.push_back (makeBool ("lfBell", "LF Bell", false));
    p.push_back (makeFloat ("lfFreq", "LF Frequency", 30.0f, 450.0f, 80.0f, 120.0f));
    p.push_back (makeFloat ("lfGain", "LF Gain", -18.0f, 18.0f, 0.0f));

    // Factory state is electrically neutral: dynamics are out of circuit.
    // Authentic automatic make-up remains active whenever the compressor is engaged.
    p.push_back (makeBool ("dynOn", "Dynamics On", false));
    p.push_back (makeBool ("compOn", "Compressor On", false));
    p.push_back (makeFloat ("compThreshold", "Compressor Threshold", -20.0f, 10.0f, 10.0f));
    p.push_back (makeFloat ("compRatio", "Compressor Ratio", 1.0f, 20.0f, 1.0f, 4.0f));
    p.push_back (makeFloat ("compRelease", "Compressor Release", 0.10f, 4.0f, 0.30f, 0.50f));
    p.push_back (makeBool ("compFast", "Compressor Fast", false));

    p.push_back (makeBool ("gateOn", "Gate On", false));
    p.push_back (makeFloat ("gateThreshold", "Gate Threshold", -30.0f, 10.0f, -30.0f));
    p.push_back (makeFloat ("gateRange", "Gate Range", 0.0f, 40.0f, 20.0f));
    p.push_back (makeFloat ("gateHold", "Gate Hold", 0.0f, 4.0f, 0.05f, 0.4f));
    p.push_back (makeFloat ("gateRelease", "Gate Release", 0.10f, 4.0f, 0.30f, 0.50f));
    p.push_back (makeBool ("gateFast", "Gate Fast", false));
    p.push_back (makeBool ("gateExpand", "Expander Mode", false));

    p.push_back (std::make_unique<juce::AudioParameterChoice> ("routing", "Routing",
                                                                juce::StringArray { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" }, 0));
    p.push_back (makeFloat ("vcaFader", "VCA Fader", -20.0f, 10.0f, 0.0f));
    p.push_back (makeFloat ("outputTrim", "Output Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeFloat ("pan", "Pan / Balance", -1.0f, 1.0f, 0.0f));
    p.push_back (makeFloat ("mix", "Mix", 0.0f, 100.0f, 100.0f));
    p.push_back (makeBool ("mute", "Mute", false));
    p.push_back (makeBool ("bypass", "Bypass", false));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("channelMode", "Channel Mode",
                                                                juce::StringArray { "Stereo", "Mid/Side" }, 0));

    return { p.begin(), p.end() };
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ConsoleChannelStripXAudioProcessor();
}
