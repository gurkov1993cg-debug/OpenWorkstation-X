#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    using Range = juce::NormalisableRange<float>;

    std::unique_ptr<juce::RangedAudioParameter> makeFloat (const char* id, const char* name,
                                                            float min, float max, float def,
                                                            float centre = 0.0f)
    {
        Range r (min, max);
        if (centre > min && centre < max)
            r.setSkewForCentre (centre);
        return std::make_unique<juce::AudioParameterFloat> (id, name, r, def);
    }

    std::unique_ptr<juce::RangedAudioParameter> makeBool (const char* id, const char* name, bool def)
    {
        return std::make_unique<juce::AudioParameterBool> (id, name, def);
    }
}

ConsoleChannelStripXAudioProcessor::ConsoleChannelStripXAudioProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, &undoManager, "PARAMETERS", createParameterLayout())
{
}

void ConsoleChannelStripXAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    engine.prepare (sampleRate, samplesPerBlock, getTotalNumOutputChannels());
}

void ConsoleChannelStripXAudioProcessor::releaseResources() {}

bool ConsoleChannelStripXAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();
    if (in != out)
        return false;
    return out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo();
}

DspEngine::Params ConsoleChannelStripXAudioProcessor::readParams() const
{
    DspEngine::Params p;
    auto v = [this] (const char* id) { return apvts.getRawParameterValue (id)->load(); };

    p.inputTrimDb = v ("inputTrim");
    p.inputDrive = v ("inputDrive");
    p.inputMode = static_cast<int> (v ("inputMode"));
    p.polarity = v ("polarity") > 0.5f;

    p.hpOn = v ("hpOn") > 0.5f;
    p.hpFreq = v ("hpFreq");
    p.lpOn = v ("lpOn") > 0.5f;
    p.lpFreq = v ("lpFreq");

    p.eqOn = v ("eqOn") > 0.5f;
    p.blackEq = v ("eqModel") > 0.5f;
    p.lfBell = v ("lfBell") > 0.5f;
    p.lfFreq = v ("lfFreq");
    p.lfGain = v ("lfGain");
    p.lmfFreq = v ("lmfFreq");
    p.lmfGain = v ("lmfGain");
    p.lmfQ = v ("lmfQ");
    p.hmfFreq = v ("hmfFreq");
    p.hmfGain = v ("hmfGain");
    p.hmfQ = v ("hmfQ");
    p.hfBell = v ("hfBell") > 0.5f;
    p.hfFreq = v ("hfFreq");
    p.hfGain = v ("hfGain");

    p.dynOn = v ("dynOn") > 0.5f;
    p.compOn = v ("compOn") > 0.5f;
    p.compThresholdDb = v ("compThreshold");
    p.compRatio = v ("compRatio");
    p.compAttackMs = v ("compAttack");
    p.compReleaseSec = v ("compRelease");
    p.compFast = v ("compFast") > 0.5f;
    p.compPeak = v ("compPeak") > 0.5f;

    p.gateOn = v ("gateOn") > 0.5f;
    p.gateThresholdDb = v ("gateThreshold");
    p.gateRangeDb = v ("gateRange");
    p.gateHoldSec = v ("gateHold");
    p.gateAttackMs = v ("gateAttack");
    p.gateReleaseSec = v ("gateRelease");
    p.gateFast = v ("gateFast") > 0.5f;
    p.gateExpand = v ("gateExpand") > 0.5f;

    p.routing = static_cast<int> (v ("routing"));
    p.vcaFaderDb = v ("vcaFader");
    p.outputTrimDb = v ("outputTrim");
    p.mix = v ("mix") * 0.01f;
    p.mute = v ("mute") > 0.5f;
    p.bypass = v ("bypass") > 0.5f;
    p.channelMode = static_cast<int> (v ("channelMode"));
    return p;
}

void ConsoleChannelStripXAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, buffer.getNumSamples());
    engine.process (buffer, readParams());
}

juce::AudioProcessorEditor* ConsoleChannelStripXAudioProcessor::createEditor()
{
    return new ConsoleChannelStripXAudioProcessorEditor (*this);
}

void ConsoleChannelStripXAudioProcessor::resetParametersToDefaults()
{
    undoManager.beginNewTransaction ("INIT");
    for (auto* parameter : getParameters())
    {
        if (auto* ranged = dynamic_cast<juce::RangedAudioParameter*> (parameter))
        {
            ranged->beginChangeGesture();
            ranged->setValueNotifyingHost (ranged->getDefaultValue());
            ranged->endChangeGesture();
        }
    }
}

void ConsoleChannelStripXAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void ConsoleChannelStripXAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorParameter* ConsoleChannelStripXAudioProcessor::getBypassParameter() const
{
    return apvts.getParameter ("bypass");
}

juce::AudioProcessorValueTreeState::ParameterLayout ConsoleChannelStripXAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (makeFloat ("inputTrim", "Input Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeFloat ("inputDrive", "Input Drive", -20.0f, 20.0f, 0.0f));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("inputMode", "Input Mode",
                                                                juce::StringArray { "Line", "Mic" }, 0));
    p.push_back (makeBool ("polarity", "Polarity", false));

    p.push_back (makeBool ("hpOn", "High Pass On", false));
    p.push_back (makeFloat ("hpFreq", "High Pass Frequency", 16.0f, 350.0f, 80.0f, 100.0f));
    p.push_back (makeBool ("lpOn", "Low Pass On", false));
    p.push_back (makeFloat ("lpFreq", "Low Pass Frequency", 3000.0f, 22000.0f, 18000.0f, 10000.0f));

    p.push_back (makeBool ("eqOn", "EQ On", true));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("eqModel", "EQ Model",
                                                                juce::StringArray { "02 Brown", "242 Black" }, 1));
    p.push_back (makeBool ("hfBell", "HF Bell", false));
    p.push_back (makeFloat ("hfFreq", "HF Frequency", 1500.0f, 16000.0f, 10000.0f, 8000.0f));
    p.push_back (makeFloat ("hfGain", "HF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("hmfFreq", "HMF Frequency", 600.0f, 7000.0f, 2500.0f, 2500.0f));
    p.push_back (makeFloat ("hmfGain", "HMF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("hmfQ", "HMF Q", 0.10f, 3.5f, 1.0f, 1.0f));
    p.push_back (makeFloat ("lmfFreq", "LMF Frequency", 200.0f, 2500.0f, 500.0f, 700.0f));
    p.push_back (makeFloat ("lmfGain", "LMF Gain", -18.0f, 18.0f, 0.0f));
    p.push_back (makeFloat ("lmfQ", "LMF Q", 0.10f, 3.5f, 1.0f, 1.0f));
    p.push_back (makeBool ("lfBell", "LF Bell", false));
    p.push_back (makeFloat ("lfFreq", "LF Frequency", 30.0f, 450.0f, 80.0f, 120.0f));
    p.push_back (makeFloat ("lfGain", "LF Gain", -18.0f, 18.0f, 0.0f));

    p.push_back (makeBool ("dynOn", "Dynamics On", true));
    p.push_back (makeBool ("compOn", "Compressor On", true));
    p.push_back (makeFloat ("compThreshold", "Compressor Threshold", -20.0f, 10.0f, -10.0f));
    p.push_back (makeFloat ("compRatio", "Compressor Ratio", 1.0f, 20.0f, 4.0f, 4.0f));
    p.push_back (makeFloat ("compAttack", "Compressor Attack", 0.10f, 100.0f, 10.0f, 10.0f));
    p.push_back (makeFloat ("compRelease", "Compressor Release", 0.10f, 4.0f, 0.30f, 0.50f));
    p.push_back (makeBool ("compFast", "Compressor Fast", false));
    p.push_back (makeBool ("compPeak", "Compressor Peak Detector", false));

    p.push_back (makeBool ("gateOn", "Gate On", false));
    p.push_back (makeFloat ("gateThreshold", "Gate Threshold", -30.0f, 10.0f, -30.0f));
    p.push_back (makeFloat ("gateRange", "Gate Range", 0.0f, 40.0f, 20.0f));
    p.push_back (makeFloat ("gateHold", "Gate Hold", 0.0f, 4.0f, 0.05f, 0.4f));
    p.push_back (makeFloat ("gateAttack", "Gate Attack", 0.05f, 50.0f, 1.5f, 1.5f));
    p.push_back (makeFloat ("gateRelease", "Gate Release", 0.10f, 4.0f, 0.30f, 0.50f));
    p.push_back (makeBool ("gateFast", "Gate Fast", false));
    p.push_back (makeBool ("gateExpand", "Expander Mode", false));

    p.push_back (std::make_unique<juce::AudioParameterChoice> ("routing", "Routing",
                                                                juce::StringArray { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" }, 0));
    p.push_back (makeFloat ("vcaFader", "VCA Fader", -20.0f, 10.0f, 0.0f));
    p.push_back (makeFloat ("outputTrim", "Output Trim", -20.0f, 20.0f, 0.0f));
    p.push_back (makeFloat ("mix", "Mix", 0.0f, 100.0f, 100.0f));
    p.push_back (makeBool ("mute", "Mute", false));
    p.push_back (makeBool ("bypass", "Bypass", false));
    p.push_back (std::make_unique<juce::AudioParameterChoice> ("channelMode", "Channel Mode",
                                                                juce::StringArray { "Stereo", "Mid/Side" }, 0));

    return { p.begin(), p.end() };
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ConsoleChannelStripXAudioProcessor();
}
