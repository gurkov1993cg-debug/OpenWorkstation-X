#pragma once

#include <algorithm>
#include <array>
#include <cmath>

namespace wieneq
{
    constexpr double pi = 3.1415926535897932384626433832795;

    enum class Band { lf, lmf, hmf, hf };

    struct BandCircuit
    {
        double c1;
        double c2;
        double rMin;
        double rMax;
        double rqFracMax;
        double targetMinHz;
        double targetMaxHz;
        const char* fitNote;
    };

    struct NetworkTuning
    {
        double w0;
        double q;
        double r;
        double rq;
        double effectiveQ;
    };

    struct BiquadCoefficients
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
    };

    const BandCircuit& circuit (Band band) noexcept;
    double frequencyForR (const BandCircuit& c, double r) noexcept;
    double resistanceForFrequency (const BandCircuit& c, double wantedHz) noexcept;
    NetworkTuning wienNetwork (double r1, double r2, double c1, double c2, double rq) noexcept;
    NetworkTuning tuneBell (const BandCircuit& c, double wantedHz, double effectiveQ, double gainDb) noexcept;
    NetworkTuning tuneFixedQBell (const BandCircuit& c, double wantedHz, double effectiveQ, double gainDb) noexcept;

    // This is intentionally the same algebra as the already-reviewed v0.4.0 helper.
    // It accepts arbitrary analog coefficients; JUCE stock EQ designers are not used.
    BiquadCoefficients biquadFromAnalog (double sampleRate,
                                         double b2, double b1, double b0,
                                         double a2, double a1, double a0,
                                         double prewarpHz) noexcept;

    BiquadCoefficients reciprocalBell (double sampleRate,
                                       const NetworkTuning& tuning,
                                       double gainDb) noexcept;

    BiquadCoefficients lowShelf (double sampleRate,
                                 const BandCircuit& c,
                                 double wantedHz,
                                 double gainDb) noexcept;

    BiquadCoefficients highShelf (double sampleRate,
                                  const BandCircuit& c,
                                  double wantedHz,
                                  double gainDb) noexcept;

    double maxPoleRadius (const BiquadCoefficients& c) noexcept;
    double responseMagnitudeDb (const BiquadCoefficients& c,
                                double sampleRate,
                                double frequencyHz) noexcept;
}
