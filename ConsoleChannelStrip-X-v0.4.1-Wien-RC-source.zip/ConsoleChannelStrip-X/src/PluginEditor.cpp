#include "PluginEditor.h"
#include <cmath>

namespace
{
    namespace C
    {
        const juce::Colour bg       { 0xff07090a };
        const juce::Colour top      { 0xff0c0f10 };
        const juce::Colour panel    { 0xff171a1c };
        const juce::Colour panel2   { 0xff101315 };
        const juce::Colour border   { 0xff4b5053 };
        const juce::Colour text     { 0xffe8e4dc };
        const juce::Colour muted    { 0xff9ba0a2 };
        const juce::Colour amber    { 0xffe58a20 };
        const juce::Colour red      { 0xffc83c35 };
        const juce::Colour green    { 0xff177e46 };
        const juce::Colour blue     { 0xff116eaf };
        const juce::Colour purple   { 0xff5366b8 };
        const juce::Colour silver   { 0xffaaa9a5 };
    }

    juce::String formatConsoleValue (double v, ConsoleValueStyle style)
    {
        switch (style)
        {
            case ConsoleValueStyle::dB:
            case ConsoleValueStyle::drive:
                return juce::String (v, std::abs (v) < 10.0 ? 1 : 0) + " dB";
            case ConsoleValueStyle::frequency:
                return v >= 1000.0 ? juce::String (v / 1000.0, v >= 10000.0 ? 1 : 2) + " kHz"
                                   : juce::String (v, v >= 100.0 ? 0 : 1) + " Hz";
            case ConsoleValueStyle::q:
                return juce::String (v, 2);
            case ConsoleValueStyle::ratio:
                return v >= 19.95 ? "INF:1" : juce::String (v, v < 3.0 ? 1 : 0) + ":1";
            case ConsoleValueStyle::release:
            case ConsoleValueStyle::hold:
                return juce::String (v, v < 1.0 ? 2 : 1) + " s";
            case ConsoleValueStyle::percent:
                return juce::String ((int) std::round (v)) + "%";
            case ConsoleValueStyle::plain:
            default:
                return juce::String (v, 2);
        }
    }

    void drawMetalButton (juce::Graphics& g, juce::Rectangle<float> r, bool on, bool pressed,
                          juce::Colour accent, const juce::String& text)
    {
        g.setColour (juce::Colours::black.withAlpha (0.65f));
        g.fillRoundedRectangle (r.translated (1.0f, 2.0f), 4.0f);

        const auto top = on ? juce::Colour (0xff70431f) : juce::Colour (0xff2b2e30);
        const auto bottom = on ? juce::Colour (0xff1d1009) : juce::Colour (0xff090b0c);
        juce::ColourGradient grad (pressed ? top.darker (0.15f) : top, r.getX(), r.getY(),
                                   bottom, r.getX(), r.getBottom(), false);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (r, 4.0f);
        g.setColour (on ? accent.brighter (0.15f) : juce::Colour (0xff62686a));
        g.drawRoundedRectangle (r, 4.0f, on ? 1.4f : 0.9f);

        if (on)
        {
            g.setColour (accent.withAlpha (0.13f));
            g.fillRoundedRectangle (r.expanded (3.0f), 6.0f);
        }

        g.setColour (C::text);
        g.setFont (juce::Font (11.0f, juce::Font::bold));
        g.drawFittedText (text, r.toNearestInt().reduced (5, 1), juce::Justification::centred, 1, 0.85f);
    }

    void drawKnobBody (juce::Graphics& g, juce::Rectangle<float> knob, float norm, juce::Colour accent)
    {
        const float start = juce::MathConstants<float>::pi * 1.25f;
        const float end = juce::MathConstants<float>::pi * 2.75f;
        const float angle = start + juce::jlimit (0.0f, 1.0f, norm) * (end - start);
        const auto c = knob.getCentre();
        const float radius = knob.getWidth() * 0.5f;

        g.setColour (juce::Colours::black.withAlpha (0.62f));
        g.fillEllipse (knob.translated (2.0f, 4.0f).expanded (7.0f));
        juce::ColourGradient socket (juce::Colour (0xff030405), c.x, knob.getY() - 6.0f,
                                     juce::Colour (0xff15191a), c.x, knob.getBottom() + 8.0f, false);
        g.setGradientFill (socket);
        g.fillEllipse (knob.expanded (7.0f));
        g.setColour (juce::Colour (0xff73787b).withAlpha (0.56f));
        g.drawEllipse (knob.expanded (6.0f), 1.0f);

        for (int i = 0; i <= 10; ++i)
        {
            const float a = start + (end - start) * (float) i / 10.0f;
            const float ro = radius + 12.0f;
            const float d = (i == 0 || i == 5 || i == 10) ? 3.2f : 2.2f;
            const float px = c.x + std::sin (a) * ro;
            const float py = c.y - std::cos (a) * ro;
            g.setColour (juce::Colours::white.withAlpha (i == 0 || i == 5 || i == 10 ? 0.92f : 0.62f));
            g.fillEllipse (px - d * 0.5f, py - d * 0.5f, d, d);
        }

        juce::ColourGradient rim (juce::Colour (0xffc4c6c6), knob.getX(), knob.getY(),
                                  juce::Colour (0xff343638), knob.getRight(), knob.getBottom(), false);
        g.setGradientFill (rim);
        g.fillEllipse (knob);
        g.setColour (juce::Colour (0xff0b0c0d));
        g.drawEllipse (knob, 1.3f);

        auto cap = knob.reduced (5.5f);
        const bool neutral = accent.getSaturation() < 0.10f;
        const auto capTop = neutral ? juce::Colour (0xffadb0b0) : accent.brighter (0.28f);
        const auto capBottom = neutral ? juce::Colour (0xff474a4c) : accent.darker (0.58f);
        juce::ColourGradient capGrad (capTop, cap.getX() + cap.getWidth() * 0.18f, cap.getY(),
                                      capBottom, cap.getRight(), cap.getBottom(), false);
        g.setGradientFill (capGrad);
        g.fillEllipse (cap);
        g.setColour (juce::Colours::white.withAlpha (0.13f));
        g.drawEllipse (cap.reduced (1.4f), 1.0f);

        juce::Path pointer;
        pointer.startNewSubPath (0.0f, -radius * 0.16f);
        pointer.lineTo (0.0f, -radius * 0.72f);
        g.setColour (juce::Colours::white.withAlpha (0.97f));
        g.strokePath (pointer, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved,
                                                     juce::PathStrokeType::rounded),
                      juce::AffineTransform::rotation (angle).translated (c.x, c.y));
    }

    juce::Colour meterColourForDb (float db)
    {
        if (db > -3.0f) return juce::Colour (0xffd83c2f);
        if (db > -10.0f) return juce::Colour (0xfff1b523);
        return juce::Colour (0xff58b744);
    }
}

ParameterHardwareControl::ParameterHardwareControl (juce::String parameterId,
                                                    juce::RangedAudioParameter* parameter)
    : param (parameter)
{
    setComponentID (std::move (parameterId));
    setWantsKeyboardFocus (false);
}

float ParameterHardwareControl::normalisedValue() const noexcept
{
    return param != nullptr ? param->getValue() : 0.0f;
}

double ParameterHardwareControl::actualValue() const noexcept
{
    return param != nullptr ? (double) param->convertFrom0to1 (param->getValue()) : 0.0;
}

void ParameterHardwareControl::beginGesture()
{
    if (param != nullptr && ! gestureActive)
    {
        param->beginChangeGesture();
        gestureActive = true;
    }
}

void ParameterHardwareControl::endGesture()
{
    if (param != nullptr && gestureActive)
    {
        param->endChangeGesture();
        gestureActive = false;
    }
}

void ParameterHardwareControl::setNormalisedValue (float value, bool withGesture)
{
    if (param == nullptr)
        return;
    value = juce::jlimit (0.0f, 1.0f, value);
    if (withGesture) beginGesture();
    param->setValueNotifyingHost (value);
    if (withGesture) endGesture();
    repaint();
}

void ParameterHardwareControl::resetToDefault()
{
    if (param != nullptr)
        setNormalisedValue (param->getDefaultValue(), true);
}

HardwareKnob::HardwareKnob (juce::String parameterId,
                            juce::RangedAudioParameter* parameter,
                            juce::String newLabel,
                            juce::Colour newAccent,
                            ConsoleValueStyle valueStyle,
                            juce::String newLeftScale,
                            juce::String newRightScale)
    : ParameterHardwareControl (std::move (parameterId), parameter),
      label (std::move (newLabel)), leftScale (std::move (newLeftScale)), rightScale (std::move (newRightScale)),
      accent (newAccent), style (valueStyle)
{
}

void HardwareKnob::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto valueBox = r.removeFromBottom (20.0f);
    auto labelBox = r.removeFromBottom (17.0f);
    auto knobZone = r.reduced (4.0f, 2.0f);
    const float d = juce::jmax (28.0f, juce::jmin (knobZone.getWidth(), knobZone.getHeight()) - 28.0f);
    auto knob = knobZone.withSizeKeepingCentre (d, d);

    drawKnobBody (g, knob, normalisedValue(), accent);

    g.setColour (C::text.withAlpha (0.88f));
    g.setFont (juce::Font (9.5f, juce::Font::plain));
    const int sy = (int) knob.getBottom() - 1;
    g.drawText (leftScale, (int) knobZone.getX(), sy, (int) knobZone.getWidth() / 2, 14, juce::Justification::centredLeft);
    g.drawText (rightScale, (int) knobZone.getCentreX(), sy, (int) knobZone.getWidth() / 2, 14, juce::Justification::centredRight);

    g.setColour (C::text);
    g.setFont (juce::Font (10.8f, juce::Font::bold));
    g.drawFittedText (label, labelBox.toNearestInt(), juce::Justification::centred, 1, 0.86f);

    auto vb = valueBox.reduced (8.0f, 1.5f);
    g.setColour (juce::Colour (0xff050607));
    g.fillRoundedRectangle (vb, 2.5f);
    g.setColour (juce::Colour (0xff43484b));
    g.drawRoundedRectangle (vb, 2.5f, 0.8f);
    g.setColour (accent.getSaturation() > 0.1f ? accent.brighter (0.55f) : C::text.withAlpha (0.85f));
    g.setFont (juce::Font (9.5f, juce::Font::plain));
    g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt().reduced (2, 0),
                      juce::Justification::centred, 1, 0.8f);
}

void HardwareKnob::mouseDown (const juce::MouseEvent& e)
{
    dragStartY = e.getScreenPosition().y;
    dragStartValue = normalisedValue();
    beginGesture();
}

void HardwareKnob::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 700.0f : 220.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta));
    repaint();
}

void HardwareKnob::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareKnob::mouseDoubleClick (const juce::MouseEvent&) { resetToDefault(); }

void HardwareKnob::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
}

void HardwareKnob::exerciseForTest()
{
    const float before = normalisedValue();
    setNormalisedValue (before < 0.5f ? 0.84f : 0.16f, true);
}

HardwareFader::HardwareFader (juce::String parameterId,
                              juce::RangedAudioParameter* parameter,
                              juce::String newLabel,
                              juce::Colour newAccent,
                              ConsoleValueStyle valueStyle,
                              juce::String newTopScale,
                              juce::String newBottomScale)
    : ParameterHardwareControl (std::move (parameterId), parameter), label (std::move (newLabel)),
      topScale (std::move (newTopScale)), bottomScale (std::move (newBottomScale)), accent (newAccent), style (valueStyle)
{
}

void HardwareFader::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto valueBox = r.removeFromBottom (22.0f);
    auto labelBox = r.removeFromTop (20.0f);
    auto trackArea = r.reduced (18.0f, 10.0f);
    const float cx = trackArea.getCentreX();

    g.setColour (C::text);
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawFittedText (label, labelBox.toNearestInt(), juce::Justification::centred, 1, 0.85f);

    g.setColour (juce::Colour (0xff030405));
    g.fillRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, trackArea.getY(), 10.0f, trackArea.getHeight()), 3.0f);
    g.setColour (juce::Colour (0xff545a5d));
    g.drawRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, trackArea.getY(), 10.0f, trackArea.getHeight()), 3.0f, 0.8f);

    for (int i = 0; i <= 10; ++i)
    {
        const float y = trackArea.getY() + trackArea.getHeight() * (float) i / 10.0f;
        const float len = (i == 0 || i == 5 || i == 10) ? 12.0f : 7.0f;
        g.setColour (juce::Colours::white.withAlpha (0.55f));
        g.drawHorizontalLine ((int) y, cx - 18.0f, cx - 18.0f + len);
        g.drawHorizontalLine ((int) y, cx + 18.0f - len, cx + 18.0f);
    }

    const float y = trackArea.getBottom() - normalisedValue() * trackArea.getHeight();
    auto handle = juce::Rectangle<float> (cx - 28.0f, y - 13.0f, 56.0f, 26.0f);
    g.setColour (juce::Colours::black.withAlpha (0.58f));
    g.fillRoundedRectangle (handle.translated (1.0f, 2.0f), 3.0f);
    juce::ColourGradient grad (accent.brighter (0.24f), handle.getX(), handle.getY(),
                               accent.darker (0.55f), handle.getX(), handle.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (handle, 3.0f);
    g.setColour (juce::Colour (0xffd7d8d8).withAlpha (0.70f));
    for (int i = -2; i <= 2; ++i)
        g.drawHorizontalLine ((int) (y + i * 3.0f), handle.getX() + 7.0f, handle.getRight() - 7.0f);

    g.setColour (C::muted);
    g.setFont (juce::Font (9.0f, juce::Font::plain));
    g.drawText (topScale, 0, (int) trackArea.getY() - 3, getWidth(), 14, juce::Justification::centredRight);
    g.drawText (bottomScale, 0, (int) trackArea.getBottom() - 10, getWidth(), 14, juce::Justification::centredRight);

    auto vb = valueBox.reduced (9.0f, 2.0f);
    g.setColour (juce::Colour (0xff050607));
    g.fillRoundedRectangle (vb, 2.5f);
    g.setColour (juce::Colour (0xff43484b));
    g.drawRoundedRectangle (vb, 2.5f, 0.8f);
    g.setColour (C::text);
    g.setFont (juce::Font (9.5f, juce::Font::plain));
    g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt(), juce::Justification::centred, 1, 0.8f);
}

void HardwareFader::mouseDown (const juce::MouseEvent& e)
{
    dragStartY = e.getScreenPosition().y;
    dragStartValue = normalisedValue();
    beginGesture();
}

void HardwareFader::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 950.0f : 360.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta));
    repaint();
}

void HardwareFader::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareFader::mouseDoubleClick (const juce::MouseEvent&) { resetToDefault(); }
void HardwareFader::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
}
void HardwareFader::exerciseForTest()
{
    const float before = normalisedValue();
    setNormalisedValue (before < 0.5f ? 0.78f : 0.22f, true);
}

HardwareToggle::HardwareToggle (juce::String parameterId,
                                juce::RangedAudioParameter* parameter,
                                juce::String newLabel,
                                juce::Colour newAccent)
    : ParameterHardwareControl (std::move (parameterId), parameter), label (std::move (newLabel)), accent (newAccent)
{
}

void HardwareToggle::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    const bool on = isOn();
    const float lampSide = juce::jmin (26.0f, r.getHeight() - 4.0f);
    auto lamp = juce::Rectangle<float> (r.getX() + 3.0f, r.getCentreY() - lampSide * 0.5f, lampSide, lampSide);
    auto textArea = r.withTrimmedLeft (lampSide + 10.0f);

    g.setColour (juce::Colours::black.withAlpha (0.75f));
    g.fillRoundedRectangle (lamp.expanded (3.0f).translated (1.0f, 2.0f), 3.0f);
    juce::ColourGradient bezel (juce::Colour (0xff64686a), lamp.getX(), lamp.getY(),
                                juce::Colour (0xff111314), lamp.getRight(), lamp.getBottom(), false);
    g.setGradientFill (bezel);
    g.fillRoundedRectangle (lamp.expanded (2.0f), 3.0f);
    g.setColour (juce::Colour (0xff030404));
    g.fillRoundedRectangle (lamp, 2.0f);

    if (on)
    {
        g.setColour (accent.withAlpha (0.18f));
        g.fillRoundedRectangle (lamp.expanded (7.0f), 7.0f);
        juce::ColourGradient glow (juce::Colour (0xffffe6a0), lamp.getCentreX(), lamp.getY(),
                                   accent.darker (0.10f), lamp.getCentreX(), lamp.getBottom(), false);
        g.setGradientFill (glow);
        g.fillRoundedRectangle (lamp.reduced (3.0f), 2.0f);
    }
    else
    {
        g.setColour (juce::Colour (0xff4d5254));
        g.fillRoundedRectangle (lamp.reduced (3.0f), 2.0f);
    }

    g.setColour (C::text);
    g.setFont (juce::Font (10.7f, juce::Font::bold));
    g.drawFittedText (label, textArea.toNearestInt(), juce::Justification::centredLeft, 1, 0.84f);
}

void HardwareToggle::mouseUp (const juce::MouseEvent& e)
{
    if (getLocalBounds().contains (e.getPosition()))
        setNormalisedValue (isOn() ? 0.0f : 1.0f, true);
}

void HardwareToggle::exerciseForTest() { setNormalisedValue (isOn() ? 0.0f : 1.0f, true); }

HardwareChoice::HardwareChoice (juce::String parameterId,
                                juce::RangedAudioParameter* parameter,
                                juce::StringArray labels)
    : ParameterHardwareControl (std::move (parameterId), parameter), choices (std::move (labels))
{
}

int HardwareChoice::currentIndex() const noexcept
{
    if (param == nullptr || choices.isEmpty()) return 0;
    return juce::jlimit (0, choices.size() - 1, (int) std::round (param->convertFrom0to1 (param->getValue())));
}

void HardwareChoice::chooseIndex (int index, bool withGesture)
{
    if (param == nullptr || choices.isEmpty()) return;
    index = juce::jlimit (0, choices.size() - 1, index);
    setNormalisedValue (param->convertTo0to1 ((float) index), withGesture);
}

void HardwareChoice::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    const int selected = currentIndex();

    if (choices.size() <= 2)
    {
        const float gap = 5.0f;
        const float w = (r.getWidth() - gap) * 0.5f;
        for (int i = 0; i < choices.size(); ++i)
        {
            auto b = juce::Rectangle<float> (r.getX() + i * (w + gap), r.getY(), w, r.getHeight());
            drawMetalButton (g, b, i == selected, false, C::amber, choices[i]);
        }
        return;
    }

    g.setColour (juce::Colours::black.withAlpha (0.66f));
    g.fillRoundedRectangle (r.translated (1.0f, 2.0f), 4.0f);
    juce::ColourGradient grad (juce::Colour (0xff262a2c), r.getX(), r.getY(),
                               juce::Colour (0xff090b0c), r.getX(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (juce::Colour (0xff666b6e));
    g.drawRoundedRectangle (r, 4.0f, 0.9f);

    g.setColour (C::amber);
    g.setFont (juce::Font (16.0f, juce::Font::bold));
    g.drawText ("‹", r.removeFromLeft (22.0f).toNearestInt(), juce::Justification::centred);
    g.drawText ("›", r.removeFromRight (22.0f).toNearestInt(), juce::Justification::centred);
    g.setColour (C::text);
    g.setFont (juce::Font (10.5f, juce::Font::bold));
    g.drawFittedText (choices[selected], r.toNearestInt().reduced (2, 0), juce::Justification::centred, 1, 0.76f);
}

void HardwareChoice::mouseUp (const juce::MouseEvent& e)
{
    if (choices.isEmpty() || ! getLocalBounds().contains (e.getPosition())) return;
    if (choices.size() <= 2)
    {
        const int index = e.x < getWidth() / 2 ? 0 : 1;
        chooseIndex (index, true);
    }
    else
    {
        const int dir = e.x < getWidth() / 2 ? -1 : 1;
        const int next = (currentIndex() + dir + choices.size()) % choices.size();
        chooseIndex (next, true);
    }
}

void HardwareChoice::exerciseForTest()
{
    if (choices.isEmpty()) return;
    chooseIndex ((currentIndex() + 1) % choices.size(), true);
}

HardwareActionButton::HardwareActionButton (juce::String componentName,
                                            juce::String buttonText,
                                            juce::Colour newAccent,
                                            std::function<void()> newAction,
                                            std::function<bool()> newStateProvider)
    : text (std::move (buttonText)), accent (newAccent), action (std::move (newAction)),
      stateProvider (std::move (newStateProvider))
{
    setName (std::move (componentName));
}

void HardwareActionButton::paint (juce::Graphics& g)
{
    const bool on = stateProvider ? stateProvider() : false;
    auto r = getLocalBounds().toFloat().reduced (1.0f);
    drawMetalButton (g, r, on, pressed, accent, text);
}

void HardwareActionButton::mouseDown (const juce::MouseEvent&)
{
    pressed = true;
    repaint();
}

void HardwareActionButton::mouseUp (const juce::MouseEvent& e)
{
    const bool trigger = pressed && getLocalBounds().contains (e.getPosition());
    pressed = false;
    repaint();
    if (trigger && action) action();
}

void HardwareActionButton::triggerForTest()
{
    if (action) action();
    repaint();
}

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setOpaque (true);

    // INPUT
    addKnob ("inputDrive", "INPUT DRIVE", C::red, ConsoleValueStyle::drive, "-20", "+20");
    addFader ("inputTrim", "INPUT TRIM", C::silver, ConsoleValueStyle::dB, "+20", "-20");
    addChoice ("inputMode", { "LINE", "MIC" });
    addToggle ("polarity", "PHASE Ø", C::amber);

    // EQ + FILTERS
    addToggle ("eqOn", "EQ IN", C::amber);
    addChoice ("eqModel", { "BROWN", "BLACK" });
    addToggle ("hfBell", "BELL", C::red);
    addKnob ("hfGain", "HF GAIN", C::red, ConsoleValueStyle::dB, "-15", "+15");
    addKnob ("hfFreq", "HF FREQ", C::silver, ConsoleValueStyle::frequency, "1.5k", "16k");
    addKnob ("hmfGain", "HMF GAIN", C::amber.darker (0.16f), ConsoleValueStyle::dB, "-15", "+15");
    addKnob ("hmfFreq", "HMF FREQ", C::silver, ConsoleValueStyle::frequency, "0.6k", "7k");
    addKnob ("hmfQ", "HMF Q", C::green, ConsoleValueStyle::q, "0.1", "3.5");
    addKnob ("lmfGain", "LMF GAIN", C::green, ConsoleValueStyle::dB, "-15", "+15");
    addKnob ("lmfFreq", "LMF FREQ", C::silver, ConsoleValueStyle::frequency, "0.2k", "2.5k");
    addKnob ("lmfQ", "LMF Q", C::green.darker (0.18f), ConsoleValueStyle::q, "0.1", "3.5");
    addToggle ("lfBell", "BELL", C::blue);
    addKnob ("lfGain", "LF GAIN", C::blue, ConsoleValueStyle::dB, "-15", "+15");
    addKnob ("lfFreq", "LF FREQ", C::silver, ConsoleValueStyle::frequency, "30", "450");
    addToggle ("hpOn", "HP IN", C::amber);
    addKnob ("hpFreq", "HPF", C::silver, ConsoleValueStyle::frequency, "16", "350");
    addToggle ("lpOn", "LP IN", C::amber);
    addKnob ("lpFreq", "LPF", C::silver, ConsoleValueStyle::frequency, "3k", "22k");

    // DYNAMICS: no decorative attack knobs. FAST switches are the actual component bypasses.
    addToggle ("dynOn", "DYN IN", C::amber);
    addToggle ("gateOn", "GATE", C::amber);
    addToggle ("gateExpand", "EXPAND", C::purple);
    addToggle ("gateFast", "FAST ATTACK", C::amber);
    addKnob ("gateThreshold", "THRESHOLD", C::green, ConsoleValueStyle::dB, "-30", "+10");
    addKnob ("gateRange", "RANGE", C::green.darker (0.08f), ConsoleValueStyle::dB, "0", "40");
    addKnob ("gateHold", "HOLD", C::silver, ConsoleValueStyle::hold, "0", "4.0");
    addKnob ("gateRelease", "RELEASE", C::silver, ConsoleValueStyle::release, "0.1", "4.0");

    addToggle ("compOn", "COMP", C::amber);
    addToggle ("compFast", "FAST ATTACK", C::amber);
    addKnob ("compThreshold", "THRESHOLD", C::blue, ConsoleValueStyle::dB, "-20", "+10");
    addKnob ("compRatio", "RATIO", C::blue, ConsoleValueStyle::ratio, "1:1", "INF");
    addKnob ("compRelease", "RELEASE", C::silver, ConsoleValueStyle::release, "0.1", "4.0");

    // OUTPUT: no SOLO and no fake DAW-browser controls.
    addKnob ("outputTrim", "OUTPUT TRIM", C::silver, ConsoleValueStyle::dB, "-20", "+20");
    addFader ("vcaFader", "CHANNEL FADER", C::silver, ConsoleValueStyle::dB, "+10", "-20");
    addKnob ("mix", "MIX", C::silver, ConsoleValueStyle::percent, "0", "100");
    addToggle ("mute", "MUTE", C::red);
    addToggle ("bypass", "BYPASS", C::amber);
    addChoice ("routing", { "FLT > EQ > DYN", "FLT > DYN > EQ", "DYN > FLT > EQ" });
    addChoice ("channelMode", { "STEREO", "MID/SIDE" });

    powerButton = std::make_unique<HardwareActionButton> (
        "ui_power", "POWER", C::amber,
        [this]
        {
            if (auto* pBypass = audioProcessor.parameters().getParameter ("bypass"))
            {
                pBypass->beginChangeGesture();
                pBypass->setValueNotifyingHost (pBypass->getValue() < 0.5f ? 1.0f : 0.0f);
                pBypass->endChangeGesture();
            }
        },
        [this]
        {
            if (auto* pBypass = audioProcessor.parameters().getParameter ("bypass"))
                return pBypass->getValue() < 0.5f;
            return false;
        });
    undoButton = std::make_unique<HardwareActionButton> ("ui_undo", "UNDO", C::silver, [this] { audioProcessor.undo(); });
    redoButton = std::make_unique<HardwareActionButton> ("ui_redo", "REDO", C::silver, [this] { audioProcessor.redo(); });
    initButton = std::make_unique<HardwareActionButton> ("ui_init", "A: DEFAULT / INIT", C::amber, [this] { resetToInit(); });
    addAndMakeVisible (*powerButton);
    addAndMakeVisible (*undoButton);
    addAndMakeVisible (*redoButton);
    addAndMakeVisible (*initButton);

    setResizable (false, false);
    setSize (1536, 942);
    startTimerHz (20);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor()
{
    stopTimer();
}

void ConsoleChannelStripXAudioProcessorEditor::addKnob (const juce::String& id, const juce::String& label,
                                                        juce::Colour accent, ConsoleValueStyle style,
                                                        const juce::String& leftScale, const juce::String& rightScale)
{
    auto* p = audioProcessor.parameters().getParameter (id);
    jassert (p != nullptr);
    auto c = std::make_unique<HardwareKnob> (id, p, label, accent, style, leftScale, rightScale);
    addAndMakeVisible (*c);
    knobs.emplace (id, std::move (c));
}

void ConsoleChannelStripXAudioProcessorEditor::addFader (const juce::String& id, const juce::String& label,
                                                         juce::Colour accent, ConsoleValueStyle style,
                                                         const juce::String& topScale, const juce::String& bottomScale)
{
    auto* p = audioProcessor.parameters().getParameter (id);
    jassert (p != nullptr);
    auto c = std::make_unique<HardwareFader> (id, p, label, accent, style, topScale, bottomScale);
    addAndMakeVisible (*c);
    faders.emplace (id, std::move (c));
}

void ConsoleChannelStripXAudioProcessorEditor::addToggle (const juce::String& id, const juce::String& label, juce::Colour accent)
{
    auto* p = audioProcessor.parameters().getParameter (id);
    jassert (p != nullptr);
    auto c = std::make_unique<HardwareToggle> (id, p, label, accent);
    addAndMakeVisible (*c);
    toggles.emplace (id, std::move (c));
}

void ConsoleChannelStripXAudioProcessorEditor::addChoice (const juce::String& id, juce::StringArray labels)
{
    auto* p = audioProcessor.parameters().getParameter (id);
    jassert (p != nullptr);
    auto c = std::make_unique<HardwareChoice> (id, p, std::move (labels));
    addAndMakeVisible (*c);
    choices.emplace (id, std::move (c));
}

void ConsoleChannelStripXAudioProcessorEditor::placeKnob (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = knobs.find (id); it != knobs.end()) it->second->setBounds (x, y, w, h);
}
void ConsoleChannelStripXAudioProcessorEditor::placeFader (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = faders.find (id); it != faders.end()) it->second->setBounds (x, y, w, h);
}
void ConsoleChannelStripXAudioProcessorEditor::placeToggle (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = toggles.find (id); it != toggles.end()) it->second->setBounds (x, y, w, h);
}
void ConsoleChannelStripXAudioProcessorEditor::placeChoice (const juce::String& id, int x, int y, int w, int h)
{
    if (auto it = choices.find (id); it != choices.end()) it->second->setBounds (x, y, w, h);
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double v, ConsoleValueStyle style)
{
    return formatConsoleValue (v, style);
}

void ConsoleChannelStripXAudioProcessorEditor::drawScrew (juce::Graphics& g, float x, float y, float angle)
{
    const auto r = juce::Rectangle<float> (x - 5.0f, y - 5.0f, 10.0f, 10.0f);
    juce::ColourGradient metal (juce::Colour (0xff9ea3a5), r.getX(), r.getY(),
                                juce::Colour (0xff2a2e30), r.getRight(), r.getBottom(), false);
    g.setGradientFill (metal);
    g.fillEllipse (r);
    g.setColour (juce::Colour (0xff111314));
    g.drawEllipse (r, 0.8f);
    const float dx = std::cos (angle) * 3.0f, dy = std::sin (angle) * 3.0f;
    g.drawLine (x - dx, y - dy, x + dx, y + dy, 1.1f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawHardwarePanel (juce::Graphics& g, juce::Rectangle<int> bounds,
                                                                  const juce::String& title)
{
    auto r = bounds.toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.72f));
    g.fillRoundedRectangle (r.translated (2.0f, 3.0f), 4.0f);
    juce::ColourGradient grad (juce::Colour (0xff22272a), r.getX(), r.getY(),
                               juce::Colour (0xff0d1011), r.getRight(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (C::border.withAlpha (0.82f));
    g.drawRoundedRectangle (r, 4.0f, 1.0f);

    // Fine vertical grain makes the panel read like textured metal without an image asset.
    for (int x = bounds.getX() + 3; x < bounds.getRight() - 3; x += 5)
    {
        g.setColour (juce::Colours::white.withAlpha ((x & 1) ? 0.012f : 0.007f));
        g.drawVerticalLine (x, (float) bounds.getY() + 4.0f, (float) bounds.getBottom() - 4.0f);
    }

    drawScrew (g, r.getX() + 11.0f, r.getY() + 11.0f, 0.3f);
    drawScrew (g, r.getRight() - 11.0f, r.getY() + 11.0f, -0.6f);
    drawScrew (g, r.getX() + 11.0f, r.getBottom() - 11.0f, -0.25f);
    drawScrew (g, r.getRight() - 11.0f, r.getBottom() - 11.0f, 0.75f);

    if (title.isNotEmpty())
    {
        g.setColour (C::text);
        g.setFont (juce::Font (17.0f, juce::Font::bold));
        g.drawText (title, bounds.getX() + 20, bounds.getY() + 10, bounds.getWidth() - 40, 24,
                    juce::Justification::centredLeft);
        g.setColour (juce::Colours::white.withAlpha (0.13f));
        g.drawHorizontalLine (bounds.getY() + 42, (float) bounds.getX() + 18.0f, (float) bounds.getRight() - 18.0f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawSectionLabel (juce::Graphics& g, juce::Rectangle<int> r,
                                                                 const juce::String& text, juce::Colour accent)
{
    g.setColour (accent);
    g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText (text, r, juce::Justification::centredLeft);
    g.setColour (accent.withAlpha (0.30f));
    g.drawHorizontalLine (r.getBottom() - 1, (float) r.getX(), (float) r.getRight());
}

void ConsoleChannelStripXAudioProcessorEditor::drawMiniLedMeter (juce::Graphics& g, juce::Rectangle<int> bounds, float db)
{
    const int segments = 12;
    for (int i = 0; i < segments; ++i)
    {
        const float segTopDb = -60.0f + (float) (i + 1) * 60.0f / segments;
        const int y = bounds.getBottom() - (i + 1) * bounds.getHeight() / segments;
        auto seg = juce::Rectangle<float> ((float) bounds.getX(), (float) y, (float) bounds.getWidth(),
                                           (float) bounds.getHeight() / segments - 2.0f);
        const bool lit = db >= segTopDb;
        const auto colour = meterColourForDb (segTopDb);
        g.setColour (lit ? colour : colour.darker (0.78f).withAlpha (0.34f));
        g.fillRoundedRectangle (seg, 1.2f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawMeterScreen (juce::Graphics& g, juce::Rectangle<int> bounds,
                                                                float inputDb, float compGrDb, float gateGrDb,
                                                                float outputDb, float inPeakDb, float outPeakDb)
{
    auto r = bounds.toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.75f));
    g.fillRoundedRectangle (r.translated (2.0f, 3.0f), 5.0f);
    juce::ColourGradient glass (juce::Colour (0xff121719), r.getX(), r.getY(),
                                juce::Colour (0xff010203), r.getRight(), r.getBottom(), false);
    g.setGradientFill (glass);
    g.fillRoundedRectangle (r, 5.0f);
    g.setColour (juce::Colour (0xff4b5255));
    g.drawRoundedRectangle (r, 5.0f, 1.0f);

    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.setColour (C::text.withAlpha (0.85f));
    g.drawText ("INPUT", bounds.getX() + 30, bounds.getY() + 18, 72, 20, juce::Justification::centred);
    g.drawText ("GR", bounds.getCentreX() - 36, bounds.getY() + 18, 72, 20, juce::Justification::centred);
    g.drawText ("OUTPUT", bounds.getRight() - 102, bounds.getY() + 18, 72, 20, juce::Justification::centred);

    const int meterTop = bounds.getY() + 58;
    const int meterHeight = bounds.getHeight() - 112;
    juce::Rectangle<int> inMeter { bounds.getX() + 55, meterTop, 24, meterHeight };
    juce::Rectangle<int> outMeter { bounds.getRight() - 79, meterTop, 24, meterHeight };
    drawMiniLedMeter (g, inMeter, inputDb);
    drawMiniLedMeter (g, outMeter, outputDb);

    const float totalGr = juce::jlimit (0.0f, 40.0f, compGrDb + gateGrDb);
    juce::Rectangle<int> grMeter { bounds.getCentreX() - 10, meterTop, 20, meterHeight };
    const int grSegments = 16;
    for (int i = 0; i < grSegments; ++i)
    {
        const float threshold = (float) (i + 1) * 40.0f / grSegments;
        const int y = grMeter.getY() + i * grMeter.getHeight() / grSegments;
        auto seg = juce::Rectangle<float> ((float) grMeter.getX(), (float) y, (float) grMeter.getWidth(),
                                           (float) grMeter.getHeight() / grSegments - 2.0f);
        const bool lit = totalGr >= threshold;
        auto col = i < 5 ? C::amber : (i < 11 ? C::red : C::purple);
        g.setColour (lit ? col : col.darker (0.78f).withAlpha (0.32f));
        g.fillRoundedRectangle (seg, 1.2f);
    }

    g.setColour (C::muted);
    g.setFont (juce::Font (9.0f, juce::Font::plain));
    for (int i = 0; i <= 6; ++i)
    {
        const int db = i * 10;
        const int y = meterTop + i * meterHeight / 6;
        g.drawText (juce::String (db), bounds.getX() + 6, y - 7, 34, 14, juce::Justification::centredRight);
        g.drawText (juce::String (db), bounds.getRight() - 40, y - 7, 34, 14, juce::Justification::centredLeft);
    }
    for (int i = 0; i <= 4; ++i)
    {
        const int db = i * 10;
        const int y = meterTop + i * meterHeight / 4;
        g.drawText (juce::String (db), bounds.getCentreX() + 15, y - 7, 28, 14, juce::Justification::centredLeft);
    }

    auto peakY = [meterTop, meterHeight] (float db)
    {
        const float n = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
        return (float) meterTop + (1.0f - n) * (float) meterHeight;
    };
    g.setColour (juce::Colour (0xffffd35a));
    g.drawHorizontalLine ((int) peakY (inPeakDb), (float) inMeter.getX() - 4.0f, (float) inMeter.getRight() + 4.0f);
    g.drawHorizontalLine ((int) peakY (outPeakDb), (float) outMeter.getX() - 4.0f, (float) outMeter.getRight() + 4.0f);

    g.setColour (C::text.withAlpha (0.82f));
    g.setFont (juce::Font (10.0f, juce::Font::plain));
    const juce::String grText = "COMP " + juce::String (compGrDb, 1) + " dB   GATE " + juce::String (gateGrDb, 1) + " dB";
    g.drawFittedText (grText, bounds.getX() + 50, bounds.getBottom() - 40, bounds.getWidth() - 100, 20,
                      juce::Justification::centred, 1, 0.82f);
}

void ConsoleChannelStripXAudioProcessorEditor::paintStatic (juce::Graphics& g)
{
    g.fillAll (C::bg);

    juce::ColourGradient topGrad (juce::Colour (0xff181d20), 0.0f, 0.0f,
                                  juce::Colour (0xff050708), 0.0f, 58.0f, false);
    g.setGradientFill (topGrad);
    g.fillRect (0, 0, getWidth(), 58);
    g.setColour (juce::Colours::white.withAlpha (0.08f));
    g.drawHorizontalLine (1, 0.0f, (float) getWidth());
    g.setColour (juce::Colour (0xff3e4447));
    g.drawHorizontalLine (57, 0.0f, (float) getWidth());

    g.setColour (C::text);
    g.setFont (juce::Font (18.0f, juce::Font::bold));
    g.drawText ("CONSOLE CHANNEL STRIP X", 520, 14, 500, 28, juce::Justification::centred);
    g.setColour (C::muted);
    g.setFont (juce::Font (10.5f, juce::Font::plain));
    g.drawText ("v0.4.1  WIEN RC / COMPONENT DYNAMICS", 980, 17, 330, 22, juce::Justification::centredRight);

    drawHardwarePanel (g, { 10, 66, 190, 866 }, "INPUT");
    drawHardwarePanel (g, { 205, 66, 350, 866 }, "EQUALISER");
    drawHardwarePanel (g, { 560, 66, 365, 866 }, "DYNAMICS");
    drawHardwarePanel (g, { 930, 66, 390, 866 }, "");
    drawHardwarePanel (g, { 1325, 66, 201, 866 }, "OUTPUT");

    // EQ band dividers and section labels.
    drawSectionLabel (g, { 225, 118, 310, 20 }, "HF", C::red.brighter (0.22f));
    drawSectionLabel (g, { 225, 260, 310, 20 }, "HMF", C::amber.brighter (0.15f));
    drawSectionLabel (g, { 225, 402, 310, 20 }, "LMF", C::green.brighter (0.18f));
    drawSectionLabel (g, { 225, 544, 310, 20 }, "LF", C::blue.brighter (0.25f));
    drawSectionLabel (g, { 225, 690, 310, 20 }, "FILTERS", C::text.withAlpha (0.82f));

    drawSectionLabel (g, { 580, 122, 325, 20 }, "GATE / EXPANDER", C::green.brighter (0.18f));
    drawSectionLabel (g, { 580, 480, 325, 20 }, "COMPRESSOR / LIMITER", C::blue.brighter (0.25f));

    // Meter bridge metal title plate.
    auto plate = juce::Rectangle<float> (950.0f, 84.0f, 350.0f, 70.0f);
    juce::ColourGradient pgrad (juce::Colour (0xffc4c7c7), plate.getX(), plate.getY(),
                                juce::Colour (0xff585d60), plate.getX(), plate.getBottom(), false);
    g.setGradientFill (pgrad);
    g.fillRoundedRectangle (plate, 4.0f);
    g.setColour (juce::Colours::white.withAlpha (0.12f));
    for (int y = 88; y < 150; y += 3) g.drawHorizontalLine (y, 955.0f, 1295.0f);
    g.setColour (juce::Colours::black.withAlpha (0.78f));
    g.drawRoundedRectangle (plate, 4.0f, 1.0f);
    drawScrew (g, 959.0f, 93.0f, 0.35f); drawScrew (g, 1291.0f, 93.0f, -0.4f);
    drawScrew (g, 959.0f, 145.0f, -0.5f); drawScrew (g, 1291.0f, 145.0f, 0.8f);
    g.setColour (juce::Colour (0xff0a0b0c));
    g.setFont (juce::Font (27.0f, juce::Font::bold));
    g.drawText ("Channel Strip X", 985, 92, 280, 30, juce::Justification::centred);
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    g.drawText ("CONSOLE DSP / ONE SHARED VCA", 985, 124, 280, 18, juce::Justification::centred);

    // Meter bottom branding is real information only, not fake controls.
    g.setColour (C::text.withAlpha (0.72f));
    g.setFont (juce::Font (18.0f, juce::Font::plain));
    g.drawText ("OPENWORKSTATION X", 960, 826, 330, 26, juce::Justification::centred);
    g.setColour (C::muted);
    g.setFont (juce::Font (11.0f, juce::Font::plain));
    g.drawText ("E-SERIES INSPIRED / FITTED CIRCUIT MODEL", 960, 854, 330, 20, juce::Justification::centred);

    // OUTPUT utility labels. There is no SOLO and no browser panel.
    g.setColour (C::text.withAlpha (0.86f));
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawText ("ROUTING", 1340, 742, 170, 18, juce::Justification::centred);
    g.drawText ("CHANNEL MODE", 1340, 836, 170, 18, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::rebuildStaticLayer()
{
    staticLayer = juce::Image (juce::Image::RGB, getWidth(), getHeight(), true);
    juce::Graphics g (staticLayer);
    paintStatic (g);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    if (staticLayer.isNull()) rebuildStaticLayer();
    g.drawImageAt (staticLayer, 0, 0);
    drawMiniLedMeter (g, { 162, 102, 18, 130 }, audioProcessor.inputMeter());
    drawMeterScreen (g, { 950, 170, 350, 628 }, audioProcessor.inputMeter(), compGrDisplayDb, gateGrDisplayDb,
                     audioProcessor.outputMeter(), inputPeakHoldDb, outputPeakHoldDb);
}

void ConsoleChannelStripXAudioProcessorEditor::resetToInit()
{
    audioProcessor.resetParametersToDefaults();
    repaint();
}

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    constexpr float fallPerTickDb = 12.0f / 20.0f;
    const float in = audioProcessor.inputMeter();
    const float out = audioProcessor.outputMeter();
    inputPeakHoldDb = in >= inputPeakHoldDb ? in : juce::jmax (-60.0f, inputPeakHoldDb - fallPerTickDb);
    outputPeakHoldDb = out >= outputPeakHoldDb ? out : juce::jmax (-60.0f, outputPeakHoldDb - fallPerTickDb);

    auto follow = [] (float current, float target)
    {
        target = juce::jlimit (0.0f, 40.0f, target);
        const float coeff = target > current ? 0.58f : 0.14f;
        const float next = current + (target - current) * coeff;
        return std::abs (next - target) < 0.02f ? target : next;
    };
    compGrDisplayDb = follow (compGrDisplayDb, audioProcessor.compressorMeter());
    gateGrDisplayDb = follow (gateGrDisplayDb, audioProcessor.gateMeter());

    // Host automation can alter APVTS values without mouse input; repaint custom
    // hardware controls at UI rate so their positions always follow automation.
    for (auto& [id, c] : knobs) c->repaint();
    for (auto& [id, c] : faders) c->repaint();
    for (auto& [id, c] : toggles) c->repaint();
    for (auto& [id, c] : choices) c->repaint();
    if (powerButton) powerButton->repaint();
    repaint (145, 90, 45, 150);
    repaint (945, 165, 360, 640);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    powerButton->setBounds (14, 11, 74, 36);
    undoButton->setBounds (98, 11, 66, 36);
    redoButton->setBounds (170, 11, 66, 36);
    initButton->setBounds (250, 11, 250, 36);

    // INPUT
    placeKnob ("inputDrive", 31, 96, 145, 150);
    placeChoice ("inputMode", 28, 258, 154, 34);
    placeToggle ("polarity", 46, 305, 118, 32);
    placeFader ("inputTrim", 44, 362, 122, 490);

    // EQ
    placeToggle ("eqOn", 226, 83, 86, 30);
    placeChoice ("eqModel", 326, 82, 207, 32);

    placeKnob ("hfGain", 226, 142, 94, 108);
    placeKnob ("hfFreq", 330, 142, 94, 108);
    placeToggle ("hfBell", 442, 174, 88, 30);

    placeKnob ("hmfGain", 220, 283, 92, 108);
    placeKnob ("hmfFreq", 324, 283, 92, 108);
    placeKnob ("hmfQ", 428, 283, 92, 108);

    placeKnob ("lmfGain", 220, 425, 92, 108);
    placeKnob ("lmfFreq", 324, 425, 92, 108);
    placeKnob ("lmfQ", 428, 425, 92, 108);

    placeKnob ("lfGain", 226, 568, 94, 108);
    placeKnob ("lfFreq", 330, 568, 94, 108);
    placeToggle ("lfBell", 442, 600, 88, 30);

    placeKnob ("hpFreq", 235, 724, 120, 122);
    placeToggle ("hpOn", 250, 852, 92, 30);
    placeKnob ("lpFreq", 405, 724, 120, 122);
    placeToggle ("lpOn", 420, 852, 92, 30);

    // DYNAMICS
    placeToggle ("dynOn", 814, 83, 88, 30);
    placeToggle ("gateOn", 585, 151, 86, 30);
    placeToggle ("gateExpand", 681, 151, 96, 30);
    placeToggle ("gateFast", 787, 151, 116, 30);
    placeKnob ("gateThreshold", 580, 201, 78, 118);
    placeKnob ("gateRange", 663, 201, 78, 118);
    placeKnob ("gateHold", 746, 201, 78, 118);
    placeKnob ("gateRelease", 829, 201, 78, 118);

    // A second dynamics row keeps the panel breathable and avoids fake controls.
    placeToggle ("compOn", 585, 510, 86, 30);
    placeToggle ("compFast", 744, 510, 158, 30);
    placeKnob ("compThreshold", 592, 570, 98, 128);
    placeKnob ("compRatio", 700, 570, 98, 128);
    placeKnob ("compRelease", 808, 570, 98, 128);

    // OUTPUT
    placeKnob ("outputTrim", 1351, 102, 150, 150);
    placeFader ("vcaFader", 1363, 270, 126, 285);
    placeKnob ("mix", 1372, 566, 108, 116);
    placeToggle ("mute", 1342, 692, 82, 34);
    placeToggle ("bypass", 1430, 692, 82, 34);
    placeChoice ("routing", 1340, 764, 170, 46);
    placeChoice ("channelMode", 1340, 862, 170, 44);

    rebuildStaticLayer();
}
