#include "PluginEditor.h"
#include <cmath>
#include <tuple>

namespace
{
    namespace C
    {
        const juce::Colour bg       { 0xff0a0c0e };
        const juce::Colour top      { 0xff0d0f11 };
        const juce::Colour panelA   { 0xff1c1f22 };
        const juce::Colour panelB   { 0xff16191c };
        const juce::Colour border   { 0xff3a3e42 };
        const juce::Colour text     { 0xffe8e8e8 };
        const juce::Colour muted    { 0xff9a9a9a };
        const juce::Colour tick     { 0xff8f9296 };
        const juce::Colour red      { 0xffb02a26 };
        const juce::Colour orange   { 0xffc06a1e };
        const juce::Colour green    { 0xff2f7a3a };
        const juce::Colour blue     { 0xff1f5fb8 };
        const juce::Colour grey     { 0xff45494d };
        const juce::Colour active   { 0xff1663d8 };
        const juce::Colour lamp     { 0xff3fd44f };
        const juce::Colour amber    { 0xffd98222 };
    }

    const juce::String kInfinity (juce::CharPointer_UTF8 ("\xE2\x88\x9E"));
    const juce::String kPhase (juce::CharPointer_UTF8 ("\xC3\x98"));

    const std::array<SectionSpec, 5> sectionSpecs {{
        { "INPUT",      8,    56, 198, 908, true },
        { "EQUALISER", 212,   56, 370, 908, true },
        { "DYNAMICS",  588,   56, 406, 908, true },
        { "",         1000,   56, 292, 908, true },
        { "OUTPUT",   1298,   56, 230, 908, true }
    }};

    const std::array<KnobSpec, 27> knobSpecs {{
        { "inputDrive",    "GAIN",       32, 105, 150, 200, 0xffb02a26, "0",  "-20", "dB",  "+20", true,  ConsoleValueStyle::drive },

        { "hfGain",        "",          258, 120, 128, 150, 0xffb02a26, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "hfFreq",        "",          394, 120, 112, 150, 0xff45494d, "",   "1.5", "kHz", "16",  true,  ConsoleValueStyle::frequency },
        { "hmfGain",       "",          258, 280, 128, 150, 0xffc06a1e, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "hmfFreq",       "",          394, 280,  88, 150, 0xff45494d, "",   "0.6", "kHz", "7",   true,  ConsoleValueStyle::frequency },
        { "hmfQ",          "Q",         486, 310,  90, 128, 0xff45494d, "",   "0.1", "",    "3.5", true,  ConsoleValueStyle::q },
        { "lmfGain",       "",          258, 440, 128, 150, 0xff2f7a3a, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "lmfFreq",       "",          394, 440,  88, 150, 0xff45494d, "",   "0.2", "kHz", "2.5", true,  ConsoleValueStyle::frequency },
        { "lmfQ",          "Q",         486, 470,  90, 128, 0xff45494d, "",   "0.1", "",    "3.5", true,  ConsoleValueStyle::q },
        { "lfGain",        "",          258, 600, 128, 150, 0xff1f5fb8, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "lfFreq",        "",          394, 600, 112, 150, 0xff45494d, "",   "30",  "Hz",  "450", true,  ConsoleValueStyle::frequency },
        { "hpFreq",        "HPF",       245, 780, 130, 145, 0xff45494d, "",   "16",  "Hz",  "350", true,  ConsoleValueStyle::frequency },
        { "lpFreq",        "LPF",       410, 780, 130, 145, 0xff45494d, "",   "3",   "kHz", "22",  true,  ConsoleValueStyle::frequency },

        { "gateThreshold", "THRESHOLD", 606, 165, 118, 150, 0xff2f7a3a, "",   "-30", "dB",  "+10", true,  ConsoleValueStyle::dB },
        { "gateRange",     "RANGE",     735, 165, 118, 150, 0xff2f7a3a, "",   "0",   "dB",  "40",  true,  ConsoleValueStyle::dB },
        { "gateHold",      "HOLD",      606, 325, 118, 150, 0xff45494d, "",   "0",   "s",   "4",   true,  ConsoleValueStyle::hold },
        { "gateRelease",   "RELEASE",   735, 325, 118, 150, 0xff45494d, "",   "0.1", "s",   "4",   true,  ConsoleValueStyle::release },

        { "compThreshold", "THRESHOLD", 606, 610, 118, 150, 0xff1f5fb8, "",   "-20", "dB",  "+10", true,  ConsoleValueStyle::dB },
        { "compRatio",     "RATIO",     735, 610, 118, 150, 0xff1f5fb8, "",   "1:1", ":1",  "INF", true,  ConsoleValueStyle::ratio },
        { "compRelease",   "RELEASE",   606, 765, 118, 140, 0xff45494d, "",   "0.1", "s",   "4",   true,  ConsoleValueStyle::release },

        { "outputTrim",    "LEVEL",    1324, 100, 178, 190, 0xff45494d, "0",  "-20", "dB",  "+20", true,  ConsoleValueStyle::dB },
        { "pan",           "PAN",      1336, 300, 154, 175, 0xff45494d, "C",  "L",   "",    "R",   true,  ConsoleValueStyle::pan },
        { "saturation",    "SATURATION",1336, 538, 154, 138, 0xffc06a1e, "",   "0",   "%",   "100", true, ConsoleValueStyle::percent },
        { "stereoWidth",   "WIDTH",    1306, 700, 104, 130, 0xff1f5fb8, "",   "0",   "%",   "100", true, ConsoleValueStyle::percent },
        { "stereoFocus",   "FOCUS",    1416, 700, 104, 130, 0xff45494d, "",   "20",  "Hz",  "10k", true, ConsoleValueStyle::frequency },
        { "stereoDetune",  "DETUNE",   1306, 832, 104, 130, 0xffc06a1e, "",   "0",   "ct",  "20",  true, ConsoleValueStyle::cents },
        { "stereoDelay",   "DELAY",    1416, 832, 104, 130, 0xff45494d, "",   "0",   "ms",  "25",  true, ConsoleValueStyle::milliseconds }
    }};

    const std::array<FaderSpec, 1> faderSpecs {{
        { "inputTrim", "INPUT TRIM", 31, 450, 154, 470, 0xff45494d, "+20", "-20", true, ConsoleValueStyle::dB }
    }};

    const std::array<ButtonSpec, 13> buttonSpecs {{
        { "inputPad",   "-20dB",       111, 372, 72, 36, ConsoleButtonStyle::Square, 0xffb02a26, false },
        { "polarity",   "PHASE",        35, 372, 66, 36, ConsoleButtonStyle::Square, 0xffd98222, false },
        { "eqOn",       "EQ IN",       228,  88, 78, 30, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "hfBell",     "BELL",        512, 225, 58, 30, ConsoleButtonStyle::Square, 0xffb02a26, false },
        { "lfBell",     "BELL",        512, 705, 58, 30, ConsoleButtonStyle::Square, 0xff1f5fb8, false },
        { "hpOn",       "IN",          286, 930, 48, 28, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "lpOn",       "IN",          451, 930, 48, 28, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "dynOn",      "DYN IN",      900,  82, 78, 30, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "gateOn",     "IN",          606, 118, 62, 32, ConsoleButtonStyle::Square, 0xff2f7a3a, true  },
        { "gateExpand", "EXPAND",      680, 118, 96, 32, ConsoleButtonStyle::Square, 0xff2f7a3a, true  },
        { "gateFast",   "FAST ATTACK", 790, 118,126, 32, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "compOn",     "IN",          606, 555, 62, 32, ConsoleButtonStyle::Square, 0xff1f5fb8, true  },
        { "autoLevel",  "AUTO LEVEL", 1327, 490,174, 34, ConsoleButtonStyle::Wide,   0xff1663d8, true  }
    }};

    const std::array<ChoiceSpec, 2> choiceSpecs {{
        { "inputMode",   "LINE",   "MIC",   "",      35, 320, 148, 38, 0xffd98222 },
        { "eqModel",     "BROWN",  "BLACK", "",     410,  88, 160, 30, 0xffd98222 }
    }};

    juce::String formatConsoleValue (double v, ConsoleValueStyle style)
    {
        switch (style)
        {
            case ConsoleValueStyle::dB:
            case ConsoleValueStyle::drive:
            {
                const auto number = juce::String (v, std::abs (v) < 10.0 ? 1 : 0);
                return (v > 0.0005 ? "+" : "") + number + " dB";
            }
            case ConsoleValueStyle::frequency:
                return v >= 1000.0 ? juce::String (v / 1000.0, v >= 10000.0 ? 1 : 2) + " kHz"
                                   : juce::String (v, v >= 100.0 ? 0 : 1) + " Hz";
            case ConsoleValueStyle::q:
                return "Q " + juce::String (v, 2);
            case ConsoleValueStyle::ratio:
                return v >= 19.95 ? "INF:1" : juce::String (v, v < 3.0 ? 1 : 0) + ":1";
            case ConsoleValueStyle::release:
            case ConsoleValueStyle::hold:
                return juce::String (v, v < 1.0 ? 2 : 1) + " s";
            case ConsoleValueStyle::percent:
                return juce::String ((int) std::round (v)) + "%";
            case ConsoleValueStyle::pan:
                if (std::abs (v) < 0.015) return "C";
                return v < 0.0 ? "L " + juce::String ((int) std::round (-v * 100.0))
                               : "R " + juce::String ((int) std::round ( v * 100.0));
            case ConsoleValueStyle::cents:
                return juce::String (v, 1) + " ct";
            case ConsoleValueStyle::milliseconds:
                return juce::String (v, 2) + " ms";
            case ConsoleValueStyle::plain:
            default:
                return juce::String (v, 2);
        }
    }

    juce::String friendlyParameterName (const juce::String& id)
    {
        static const std::map<juce::String, juce::String> names {
            { "inputDrive", "INPUT GAIN" }, { "inputTrim", "INPUT TRIM" },
            { "hfGain", "HF GAIN" }, { "hfFreq", "HF FREQ" },
            { "hmfGain", "HMF GAIN" }, { "hmfFreq", "HMF FREQ" }, { "hmfQ", "HMF Q" },
            { "lmfGain", "LMF GAIN" }, { "lmfFreq", "LMF FREQ" }, { "lmfQ", "LMF Q" },
            { "lfGain", "LF GAIN" }, { "lfFreq", "LF FREQ" },
            { "hpFreq", "HPF FREQ" }, { "lpFreq", "LPF FREQ" },
            { "gateThreshold", "GATE THRESHOLD" }, { "gateRange", "GATE RANGE" },
            { "gateHold", "GATE HOLD" }, { "gateRelease", "GATE RELEASE" },
            { "compThreshold", "COMP THRESHOLD" }, { "compRatio", "COMP RATIO" }, { "compPeak", "COMP PEAK" },
            { "compRelease", "COMP RELEASE" }, { "outputTrim", "OUTPUT LEVEL" },
            { "pan", "PAN" }, { "saturation", "SATURATION" }, { "stereoWidth", "STEREO WIDTH" }, { "stereoFocus", "STEREO FOCUS" },
            { "stereoDetune", "STEREO DETUNE" }, { "stereoDelay", "STEREO DELAY" }
        };
        if (auto it = names.find (id); it != names.end()) return it->second;
        return id.toUpperCase();
    }

    void drawButtonBody (juce::Graphics& g, juce::Rectangle<float> r, bool on, bool pressed,
                         juce::Colour onColour, const juce::String& text, ConsoleButtonStyle style)
    {
        r = r.reduced (0.5f);
        const auto offTop = juce::Colour (0xff2b3034);
        const auto offBottom = juce::Colour (0xff1d2124);
        const auto fillTop = on ? onColour.brighter (0.10f) : offTop;
        const auto fillBottom = on ? onColour.darker (0.16f) : offBottom;

        g.setColour (juce::Colours::black.withAlpha (0.60f));
        g.fillRoundedRectangle (r.translated (1.0f, 2.0f), 4.0f);

        juce::ColourGradient grad (pressed ? fillTop.darker (0.12f) : fillTop, r.getX(), r.getY(),
                                   pressed ? fillBottom.darker (0.12f) : fillBottom, r.getX(), r.getBottom(), false);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (r, 4.0f);

        g.setColour (on ? onColour.brighter (0.38f) : juce::Colour (0xff50565b));
        g.drawRoundedRectangle (r, 4.0f, 1.0f);

        g.setColour (on ? juce::Colours::white : juce::Colour (0xffd6d8da));
        g.setFont (juce::Font (style == ConsoleButtonStyle::RatioTab ? 10.8f : 11.8f, juce::Font::bold));
        g.drawFittedText (text, r.toNearestInt().reduced (4, 1), juce::Justification::centred, 1, 0.88f);
    }

    void drawKnobBody (juce::Graphics& g, juce::Rectangle<float> knob, float norm, juce::Colour faceColour)
    {
        const float start = juce::degreesToRadians (-140.0f);
        const float end   = juce::degreesToRadians ( 140.0f);
        const float angle = start + juce::jlimit (0.0f, 1.0f, norm) * (end - start);
        const auto c = knob.getCentre();
        const float radius = knob.getWidth() * 0.5f;

        // Larger, clearer hardware scale. The centre and end ticks are stronger
        // so the position is readable at a glance without making the control busy.
        for (int i = 0; i <= 10; ++i)
        {
            const bool major = (i == 0 || i == 5 || i == 10);
            const float a = start + (end - start) * (float) i / 10.0f;
            const float inner = radius * (major ? 1.13f : 1.18f);
            const float outer = radius * 1.30f;
            const auto p1 = c + juce::Point<float> (std::sin (a) * inner, -std::cos (a) * inner);
            const auto p2 = c + juce::Point<float> (std::sin (a) * outer, -std::cos (a) * outer);
            g.setColour (major ? C::text.withAlpha (0.72f) : C::tick.withAlpha (0.82f));
            g.drawLine (juce::Line<float> (p1, p2), major ? 1.7f : 1.2f);
        }

        // Soft shadow and a neutral metal skirt keep the coloured bands from
        // looking like toy knobs.
        g.setColour (juce::Colours::black.withAlpha (0.58f));
        g.fillEllipse (knob.expanded (3.0f).translated (1.5f, 2.5f));

        juce::ColourGradient rim (juce::Colour (0xff666b70), c.x, knob.getY(),
                                  juce::Colour (0xff202428), c.x, knob.getBottom(), false);
        g.setGradientFill (rim);
        g.fillEllipse (knob.expanded (2.0f));
        g.setColour (juce::Colour (0xff0c0e10));
        g.drawEllipse (knob.expanded (2.0f), 1.2f);

        auto cap = knob.reduced (radius * 0.13f);
        juce::ColourGradient face (faceColour.brighter (0.18f), c.x, cap.getY(),
                                   faceColour.darker (0.48f), c.x, cap.getBottom(), false);
        g.setGradientFill (face);
        g.fillEllipse (cap);

        g.setColour (juce::Colours::white.withAlpha (0.11f));
        g.fillEllipse (cap.withTrimmedBottom (cap.getHeight() * 0.54f).reduced (cap.getWidth() * 0.18f, 0.0f));

        g.setColour (juce::Colours::black.withAlpha (0.42f));
        g.drawEllipse (cap, 1.2f);

        const float len = cap.getWidth() * 0.43f;
        const auto p2 = c + juce::Point<float> (std::sin (angle) * len, -std::cos (angle) * len);
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.drawLine (juce::Line<float> (c.translated (1.0f, 1.0f), p2.translated (1.0f, 1.0f)), 3.0f);
        g.setColour (juce::Colour (0xfff4f4f4));
        g.drawLine (juce::Line<float> (c, p2), 2.5f);

        g.setColour (juce::Colour (0xffd8dadd));
        g.fillEllipse (c.x - 3.2f, c.y - 3.2f, 6.4f, 6.4f);
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.drawEllipse (c.x - 3.2f, c.y - 3.2f, 6.4f, 6.4f, 0.8f);
    }
}

ParameterHardwareControl::ParameterHardwareControl (juce::String parameterId, juce::RangedAudioParameter* parameter)
    : param (parameter)
{
    setComponentID (std::move (parameterId));
    setWantsKeyboardFocus (false);

    addChildComponent (valueEditor);
    valueEditor.setMultiLine (false);
    valueEditor.setReturnKeyStartsNewLine (false);
    valueEditor.setScrollbarsShown (false);
    valueEditor.setSelectAllWhenFocused (true);
    valueEditor.setColour (juce::TextEditor::backgroundColourId, juce::Colour (0xff050708));
    valueEditor.setColour (juce::TextEditor::textColourId, juce::Colours::white);
    valueEditor.setColour (juce::TextEditor::outlineColourId, C::active);
    valueEditor.setColour (juce::TextEditor::focusedOutlineColourId, C::active.brighter (0.20f));
    valueEditor.setFont (juce::Font (14.0f, juce::Font::bold));
    valueEditor.onReturnKey = [this] { commitValueEditor(); };
    valueEditor.onEscapeKey = [this] { valueEditor.setVisible (false); repaint(); };
    valueEditor.onFocusLost = [this] { if (valueEditor.isVisible()) commitValueEditor(); };
}

float ParameterHardwareControl::normalisedValue() const noexcept { return param != nullptr ? param->getValue() : 0.0f; }
double ParameterHardwareControl::actualValue() const noexcept
{
    return param != nullptr ? (double) param->convertFrom0to1 (param->getValue()) : 0.0;
}
void ParameterHardwareControl::beginGesture()
{
    if (param != nullptr && ! gestureActive) { param->beginChangeGesture(); gestureActive = true; }
}
void ParameterHardwareControl::endGesture()
{
    if (param != nullptr && gestureActive) { param->endChangeGesture(); gestureActive = false; }
}
void ParameterHardwareControl::setNormalisedValue (float value, bool withGesture)
{
    if (param == nullptr) return;
    value = juce::jlimit (0.0f, 1.0f, value);
    if (withGesture) beginGesture();
    param->setValueNotifyingHost (value);
    if (withGesture) endGesture();
    repaint();
}
void ParameterHardwareControl::resetToDefault()
{
    if (param != nullptr) setNormalisedValue (param->getDefaultValue(), true);
}

double ParameterHardwareControl::parseEditorValue (juce::String text, ConsoleValueStyle style, double fallback)
{
    text = text.trim().toLowerCase();
    if (text.isEmpty())
        return fallback;

    if (style == ConsoleValueStyle::ratio && text.contains ("inf"))
        return 20.0;

    const bool kilo = style == ConsoleValueStyle::frequency && text.containsChar ('k');
    text = text.retainCharacters ("0123456789+-.eE");
    if (text.isEmpty() || text == "+" || text == "-" || text == ".")
        return fallback;

    double value = text.getDoubleValue();
    if (kilo)
        value *= 1000.0;
    return std::isfinite (value) ? value : fallback;
}

void ParameterHardwareControl::showValueEditor (ConsoleValueStyle style, juce::Rectangle<int> bounds)
{
    if (param == nullptr)
        return;

    editorStyle = style;
    positionValueEditor (bounds);

    const double v = actualValue();
    juce::String text;
    if (style == ConsoleValueStyle::frequency && std::abs (v) >= 1000.0)
        text = juce::String (v / 1000.0, 3) + "k";
    else if (style == ConsoleValueStyle::q)
        text = juce::String (v, 3);
    else if (style == ConsoleValueStyle::release || style == ConsoleValueStyle::hold)
        text = juce::String (v, 3);
    else
        text = juce::String (v, 2);

    valueEditor.setText (text, false);
    valueEditor.setVisible (true);
    valueEditor.toFront (false);
    valueEditor.grabKeyboardFocus();
    valueEditor.selectAll();
}

void ParameterHardwareControl::positionValueEditor (juce::Rectangle<int> bounds)
{
    valueEditor.setBounds (bounds);
}

void ParameterHardwareControl::commitValueEditor()
{
    if (param == nullptr || ! valueEditor.isVisible())
        return;

    const juce::String typedText = valueEditor.getText();
    double value = parseEditorValue (typedText, editorStyle, actualValue());

    // Frequency boxes accept either Hz or a convenient kHz shorthand.  If a bare
    // decimal would be below this parameter's Hz range but x1000 lands inside it,
    // interpret it as kHz (e.g. 2.50 on HMF -> 2500 Hz, while 80 on LF stays 80 Hz).
    if (editorStyle == ConsoleValueStyle::frequency && ! typedText.toLowerCase().containsChar ('k'))
    {
        const double minHz = param->convertFrom0to1 (0.0f);
        const double maxHz = param->convertFrom0to1 (1.0f);
        if (value < minHz && value * 1000.0 >= minHz && value * 1000.0 <= maxHz)
            value *= 1000.0;
    }

    const float normalised = param->convertTo0to1 (static_cast<float> (value));
    setNormalisedValue (normalised, true);
    valueEditor.setVisible (false);
    repaint();
}

HardwareKnob::HardwareKnob (const KnobSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.label), topText (s.topText), minText (s.minText),
      unitText (s.unitText), maxText (s.maxText), faceColour (s.faceColour), style (s.valueStyle), hasValueBox (s.hasValueBox)
{
}

void HardwareKnob::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const float valueH = hasValueBox ? 28.0f : 0.0f;
    if (hasValueBox) r.removeFromBottom (valueH);

    g.setColour (C::text.withAlpha (0.97f));
    g.setFont (juce::Font (12.5f, juce::Font::bold));
    g.drawFittedText (label, 0, 0, getWidth(), 19, juce::Justification::centred, 1, 0.92f);

    g.setColour (C::muted.brighter (0.12f));
    g.setFont (juce::Font (10.6f));
    g.drawText (topText, 0, 19, getWidth(), 14, juce::Justification::centred);

    auto zone = r.withTrimmedTop (32.0f).withTrimmedBottom (19.0f);
    const float d = juce::jmin (zone.getWidth() * 0.72f, zone.getHeight() * 0.84f);
    auto knob = zone.withSizeKeepingCentre (d, d);
    drawKnobBody (g, knob, normalisedValue(), faceColour);

    const int sy = (int) knob.getBottom() + 6;
    g.setColour (C::muted.brighter (0.10f));
    g.setFont (juce::Font (10.4f));
    g.drawText (minText, 3, sy, getWidth() / 2 - 3, 14, juce::Justification::centredLeft);
    g.drawText (maxText, getWidth() / 2, sy, getWidth() / 2 - 3, 14, juce::Justification::centredRight);
    g.drawText (unitText, 0, sy, getWidth(), 14, juce::Justification::centred);

    if (hasValueBox)
    {
        auto vb = juce::Rectangle<float> (5.0f, (float) getHeight() - 26.0f, (float) getWidth() - 10.0f, 23.0f);
        g.setColour (juce::Colour (0xff06080a));
        g.fillRoundedRectangle (vb, 3.5f);
        g.setColour (C::active.withAlpha (0.88f));
        g.drawRoundedRectangle (vb, 3.5f, 1.1f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::Font (13.0f, juce::Font::bold));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt().reduced (3, 0),
                          juce::Justification::centred, 1, 0.84f);
    }
    else if (style == ConsoleValueStyle::q)
    {
        auto vb = juce::Rectangle<int> (1, getHeight() - 20, getWidth() - 2, 18);
        g.setColour (juce::Colour (0xff080a0c)); g.fillRoundedRectangle (vb.toFloat(), 2.0f);
        g.setColour (juce::Colours::white); g.setFont (juce::Font (10.5f, juce::Font::bold));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb, juce::Justification::centred, 1, 0.78f);
    }
}

void HardwareKnob::resized()
{
    positionValueEditor (juce::Rectangle<int> (5, getHeight() - 28, juce::jmax (20, getWidth() - 10), 25));
}

void HardwareKnob::reportValue()
{
    if (valueReporter) valueReporter (getComponentID(), formatConsoleValue (actualValue(), style));
}

void HardwareKnob::mouseDown (const juce::MouseEvent& e)
{
    dragStartY = e.getScreenPosition().y; dragStartValue = normalisedValue(); beginGesture(); reportValue();
}
void HardwareKnob::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 900.0f : 280.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta));
    reportValue(); repaint();
}
void HardwareKnob::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareKnob::mouseDoubleClick (const juce::MouseEvent& e)
{
    const juce::Rectangle<int> valueBox (5, getHeight() - 28, juce::jmax (20, getWidth() - 10), 25);
    if (hasValueBox && valueBox.contains (e.getPosition()))
        showValueEditor (style, valueBox);
    else
        resetToDefault();

    reportValue();
    repaint();
}
void HardwareKnob::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
    reportValue();
}
void HardwareKnob::exerciseForTest()
{
    const float before = normalisedValue(); setNormalisedValue (before < 0.5f ? 0.73f : 0.27f, true);
}

HardwareFader::HardwareFader (const FaderSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.label), topText (s.topText), bottomText (s.bottomText),
      faceColour (s.faceColour), style (s.valueStyle), hasValueBox (s.hasValueBox)
{
}

void HardwareFader::resized()
{
    positionValueEditor (juce::Rectangle<int> (18, getHeight() - 28, juce::jmax (20, getWidth() - 36), 25));
}

void HardwareFader::reportValue()
{
    if (valueReporter) valueReporter (getComponentID(), formatConsoleValue (actualValue(), style));
}

void HardwareFader::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto labelBox = r.removeFromTop (22.0f);
    auto valueBox = hasValueBox ? r.removeFromBottom (26.0f) : juce::Rectangle<float>();
    auto track = r.reduced (32.0f, 15.0f);
    const float cx = track.getCentreX();

    g.setColour (C::text); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawFittedText (label, labelBox.toNearestInt(), juce::Justification::centred, 1, 0.85f);

    g.setColour (juce::Colour (0xff090b0c));
    g.fillRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, track.getY(), 10.0f, track.getHeight()), 3.0f);
    g.setColour (juce::Colour (0xff42474a));
    g.drawRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, track.getY(), 10.0f, track.getHeight()), 3.0f, 1.0f);

    static const std::array<const char*, 5> marks {{ "+20", "+10", "0", "-10", "-20" }};
    for (int i = 0; i < (int) marks.size(); ++i)
    {
        const float y = track.getY() + track.getHeight() * (float) i / (float) (marks.size() - 1);
        g.setColour (C::tick); g.drawHorizontalLine ((int) y, cx - 27.0f, cx - 15.0f); g.drawHorizontalLine ((int) y, cx + 15.0f, cx + 27.0f);
        g.setColour (C::muted); g.setFont (juce::Font (9.5f));
        g.drawText (marks[(size_t) i], 0, (int) y - 7, (int) (cx - 30.0f), 14, juce::Justification::centredRight);
    }

    const float y = track.getBottom() - normalisedValue() * track.getHeight();
    auto handle = juce::Rectangle<float> (cx - 31.0f, y - 16.0f, 62.0f, 32.0f);
    juce::ColourGradient hgrad (juce::Colour (0xffd0d2d2), handle.getX(), handle.getY(),
                                faceColour.darker (0.45f), handle.getX(), handle.getBottom(), false);
    g.setGradientFill (hgrad); g.fillRoundedRectangle (handle, 3.0f);
    g.setColour (juce::Colour (0xff2b2e30)); g.drawRoundedRectangle (handle, 3.0f, 1.0f);
    g.setColour (juce::Colours::white.withAlpha (0.50f));
    for (int i = -2; i <= 2; ++i) g.drawHorizontalLine ((int) (y + i * 3.0f), handle.getX() + 7.0f, handle.getRight() - 7.0f);

    if (hasValueBox)
    {
        auto vb = valueBox.reduced (18.0f, 3.0f);
        g.setColour (juce::Colour (0xff0e1012)); g.fillRoundedRectangle (vb, 2.0f);
        g.setColour (C::border); g.drawRoundedRectangle (vb, 2.0f, 1.0f);
        g.setColour (C::text); g.setFont (juce::Font (12.0f));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt(), juce::Justification::centred, 1, 0.9f);
    }
}
void HardwareFader::mouseDown (const juce::MouseEvent& e) { dragStartY = e.getScreenPosition().y; dragStartValue = normalisedValue(); beginGesture(); reportValue(); }
void HardwareFader::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 1000.0f : 420.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta)); reportValue(); repaint();
}
void HardwareFader::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareFader::mouseDoubleClick (const juce::MouseEvent& e)
{
    const juce::Rectangle<int> valueBox (18, getHeight() - 28, juce::jmax (20, getWidth() - 36), 25);
    if (hasValueBox && valueBox.contains (e.getPosition()))
        showValueEditor (style, valueBox);
    else
        resetToDefault();

    reportValue();
    repaint();
}
void HardwareFader::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
    reportValue();
}
void HardwareFader::exerciseForTest() { const float before = normalisedValue(); setNormalisedValue (before < 0.5f ? 0.75f : 0.25f, true); }

HardwareToggle::HardwareToggle (const ButtonSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.text), onColour (s.onColour), buttonStyle (s.style), hasLed (s.hasLed)
{
    if (getComponentID() == "polarity") label = kPhase;
}
void HardwareToggle::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto button = hasLed ? r.withTrimmedRight (18.0f) : r;
    drawButtonBody (g, button, isOn(), false, onColour, label, buttonStyle);
    if (hasLed) ConsoleChannelStripXAudioProcessorEditor::drawLed (g, r.getRight() - 9.0f, r.getCentreY(), isOn(), C::lamp);
}
void HardwareToggle::mouseUp (const juce::MouseEvent& e)
{
    if (getLocalBounds().contains (e.getPosition())) setNormalisedValue (isOn() ? 0.0f : 1.0f, true);
}
void HardwareToggle::exerciseForTest() { setNormalisedValue (isOn() ? 0.0f : 1.0f, true); }

HardwareChoice::HardwareChoice (const ChoiceSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), a (s.labelA), b (s.labelB), c (s.labelC),
      numChoices (c.isNotEmpty() ? 3 : 2), onColour (s.onColour)
{
}
int HardwareChoice::currentIndex() const noexcept
{
    return param == nullptr ? 0 : juce::jlimit (0, numChoices - 1, (int) std::round (param->convertFrom0to1 (param->getValue())));
}
void HardwareChoice::chooseIndex (int index, bool withGesture)
{
    if (param == nullptr) return; index = juce::jlimit (0, numChoices - 1, index); setNormalisedValue (param->convertTo0to1 ((float) index), withGesture);
}
void HardwareChoice::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    const float gap = 4.0f;
    const float w = (r.getWidth() - gap * (float) (numChoices - 1)) / (float) numChoices;
    const std::array<juce::String, 3> labels {{ a, b, c }};
    for (int i = 0; i < numChoices; ++i)
        drawButtonBody (g, { r.getX() + (w + gap) * (float) i, r.getY(), w, r.getHeight() },
                        currentIndex() == i, false, onColour, labels[(size_t) i], ConsoleButtonStyle::Wide);
}
void HardwareChoice::mouseUp (const juce::MouseEvent& e)
{
    if (! getLocalBounds().contains (e.getPosition())) return;
    const int index = juce::jlimit (0, numChoices - 1, (int) ((float) e.x / juce::jmax (1.0f, (float) getWidth() / (float) numChoices)));
    chooseIndex (index, true);
}
void HardwareChoice::exerciseForTest() { chooseIndex ((currentIndex() + 1) % numChoices, true); }

HardwareActionButton::HardwareActionButton (juce::String componentName, juce::String buttonText, juce::Colour newAccent,
                                            std::function<void()> newAction, std::function<bool()> newStateProvider)
    : text (std::move (buttonText)), accent (newAccent), action (std::move (newAction)), stateProvider (std::move (newStateProvider))
{
    setName (std::move (componentName));
}
void HardwareActionButton::paint (juce::Graphics& g)
{
    drawButtonBody (g, getLocalBounds().toFloat().reduced (0.5f), stateProvider ? stateProvider() : false, pressed,
                    accent, text, ConsoleButtonStyle::Square);
}
void HardwareActionButton::mouseDown (const juce::MouseEvent&) { pressed = true; repaint(); }
void HardwareActionButton::mouseUp (const juce::MouseEvent& e)
{
    const bool trigger = pressed && getLocalBounds().contains (e.getPosition()); pressed = false; repaint(); if (trigger && action) action();
}
void HardwareActionButton::triggerForTest() { if (action) action(); repaint(); }

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setOpaque (true);

    // All GUI controls live on one fixed design surface.  Only this surface is
    // scaled.  Scaling every knob/button separately caused the controls to move
    // relative to one another in Cubase when zoom changed.
    addAndMakeVisible (designSurface);
    designSurface.setInterceptsMouseClicks (false, true);
    designSurface.setBounds (0, 0, designWidth, designHeight);

    createControlsFromLayout();

    powerButton = std::make_unique<HardwareActionButton> ("ui_power", "POWER", C::amber,
        [this]
        {
            if (auto* q = audioProcessor.parameters().getParameter ("bypass"))
            {
                q->beginChangeGesture(); q->setValueNotifyingHost (q->getValue() < 0.5f ? 1.0f : 0.0f); q->endChangeGesture();
            }
        },
        [this]
        {
            if (auto* q = audioProcessor.parameters().getParameter ("bypass")) return q->getValue() < 0.5f;
            return false;
        });
    undoButton = std::make_unique<HardwareActionButton> ("ui_undo", "UNDO", C::grey, [this] { audioProcessor.undo(); });
    redoButton = std::make_unique<HardwareActionButton> ("ui_redo", "REDO", C::grey, [this] { audioProcessor.redo(); });
    initButton = std::make_unique<HardwareActionButton> ("ui_init", "A: DEFAULT / INIT", C::amber, [this] { resetToInit(); });
    zoomOutButton = std::make_unique<HardwareActionButton> ("ui_zoom_out", "-", C::active, [this] { setUiScale (uiScale - 0.10f); });
    zoomResetButton = std::make_unique<HardwareActionButton> ("ui_zoom_reset", "100%", C::active, [this] { setUiScale (1.0f); });
    zoomInButton = std::make_unique<HardwareActionButton> ("ui_zoom_in", "+", C::active, [this] { setUiScale (uiScale + 0.10f); });

    for (auto* c : { powerButton.get(), undoButton.get(), redoButton.get(), initButton.get(), zoomOutButton.get(), zoomResetButton.get(), zoomInButton.get() })
        designSurface.addAndMakeVisible (*c);

    // Zoom is explicit and deterministic (50%..150%).  Do not expose a free
    // bottom-right resizer: arbitrary host drag-resizing was another route to
    // fractional layout states and made the hardware panel look unstable.
    setResizable (false, false);
    uiScale = 0.75f;
    setSize (juce::roundToInt ((float) designWidth * uiScale),
             juce::roundToInt ((float) designHeight * uiScale));
    rebuildStaticLayer();
    startTimerHz (60);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor() { stopTimer(); }

void ConsoleChannelStripXAudioProcessorEditor::createControlsFromLayout()
{
    for (const auto& s : knobSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareKnob> (s, p);
            c->setValueReporter ([this] (const juce::String& id, const juce::String& value) { showParameterValue (id, value); });
            designSurface.addAndMakeVisible (*c); knobs.emplace (s.paramId, std::move (c));
        }
    }
    for (const auto& s : faderSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareFader> (s, p);
            c->setValueReporter ([this] (const juce::String& id, const juce::String& value) { showParameterValue (id, value); });
            designSurface.addAndMakeVisible (*c); faders.emplace (s.paramId, std::move (c));
        }
    }
    for (const auto& s : buttonSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareToggle> (s, p); designSurface.addAndMakeVisible (*c); toggles.emplace (s.paramId, std::move (c));
        }
    }
    // Compressor detector controls live together in the compressor block.
    const ButtonSpec compPeak { "compPeak", "PEAK", 680, 555, 96, 32, ConsoleButtonStyle::Square, 0xffb02a26, true };
    if (auto* p = audioProcessor.parameters().getParameter (compPeak.paramId))
    {
        auto c = std::make_unique<HardwareToggle> (compPeak, p); designSurface.addAndMakeVisible (*c); toggles.emplace (compPeak.paramId, std::move (c));
    }

    const ButtonSpec compFast { "compFast", "FAST ATTACK", 790, 555, 126, 32, ConsoleButtonStyle::Square, 0xffd98222, true };
    if (auto* p = audioProcessor.parameters().getParameter (compFast.paramId))
    {
        auto c = std::make_unique<HardwareToggle> (compFast, p); designSurface.addAndMakeVisible (*c); toggles.emplace (compFast.paramId, std::move (c));
    }
    for (const auto& s : choiceSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareChoice> (s, p); designSurface.addAndMakeVisible (*c); choices.emplace (s.paramId, std::move (c));
        }
    }
}

void ConsoleChannelStripXAudioProcessorEditor::setParameterActual (const char* id, float actual)
{
    if (auto* p = audioProcessor.parameters().getParameter (id))
    {
        p->beginChangeGesture(); p->setValueNotifyingHost (p->convertTo0to1 (actual)); p->endChangeGesture();
    }
}
float ConsoleChannelStripXAudioProcessorEditor::parameterActual (const char* id) const
{
    if (auto* p = audioProcessor.parameters().getParameter (id)) return p->convertFrom0to1 (p->getValue());
    return 0.0f;
}

void ConsoleChannelStripXAudioProcessorEditor::showParameterValue (const juce::String& id, const juce::String& value)
{
    activeParameterName = friendlyParameterName (id);
    activeParameterValue = value;
    repaint();
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double v, ConsoleValueStyle style) { return formatConsoleValue (v, style); }

void ConsoleChannelStripXAudioProcessorEditor::drawScrew (juce::Graphics& g, float x, float y, float angle)
{
    auto r = juce::Rectangle<float> (x - 6.5f, y - 6.5f, 13.0f, 13.0f);
    g.setColour (juce::Colour (0xff202427)); g.fillEllipse (r);
    g.setColour (juce::Colour (0xff45494d)); g.drawEllipse (r, 1.0f);
    const float d = 4.0f; const float dx = std::cos (angle) * d, dy = std::sin (angle) * d;
    g.setColour (juce::Colour (0xff34383c));
    g.drawLine (x - dx, y - dy, x + dx, y + dy, 1.4f);
    g.drawLine (x + dy, y - dx, x - dy, y + dx, 1.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, const SectionSpec& s)
{
    auto r = juce::Rectangle<float> ((float) s.x, (float) s.y, (float) s.w, (float) s.h);
    juce::ColourGradient grad (C::panelA, r.getX(), r.getY(), C::panelB, r.getX(), r.getBottom(), false);
    g.setGradientFill (grad); g.fillRoundedRectangle (r, 5.0f);
    g.setColour (C::border); g.drawRoundedRectangle (r, 5.0f, 1.0f);
    if (s.title != nullptr && *s.title != 0)
    {
        g.setColour (C::text); g.setFont (juce::Font (14.0f, juce::Font::bold));
        g.drawText (s.title, s.x + 20, s.y + 8, s.w - 40, 22, juce::Justification::centred);
    }
    if (s.hasScrews)
    {
        drawScrew (g, (float) s.x + 13, (float) s.y + 17, 0.25f);
        drawScrew (g, (float) s.x + s.w - 13, (float) s.y + 17, -0.45f);
        drawScrew (g, (float) s.x + 13, (float) s.y + s.h - 17, -0.30f);
        drawScrew (g, (float) s.x + s.w - 13, (float) s.y + s.h - 17, 0.65f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawLed (juce::Graphics& g, float x, float y, bool on, juce::Colour colour)
{
    if (on)
    {
        for (const auto& q : std::array<std::pair<float,float>,3> {{{ 6.0f,0.09f }, { 4.0f,0.18f }, { 2.0f,0.30f }}})
        {
            g.setColour (colour.withAlpha (q.second)); g.fillEllipse (x - 4.5f - q.first, y - 4.5f - q.first, 9.0f + 2.0f * q.first, 9.0f + 2.0f * q.first);
        }
    }
    g.setColour (on ? colour : juce::Colour (0xff1e2224)); g.fillEllipse (x - 4.5f, y - 4.5f, 9.0f, 9.0f);
    g.setColour (juce::Colour (0xff3a3e42)); g.drawEllipse (x - 4.5f, y - 4.5f, 9.0f, 9.0f, 1.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawBandCurve (juce::Graphics& g, juce::Rectangle<float> r, bool shelf, bool high)
{
    juce::Path p;
    if (shelf)
    {
        if (high) { p.startNewSubPath (r.getX(), r.getBottom() - 3); p.cubicTo (r.getCentreX(), r.getBottom() - 3, r.getCentreX(), r.getY() + 3, r.getRight(), r.getY() + 3); }
        else      { p.startNewSubPath (r.getX(), r.getY() + 3); p.cubicTo (r.getCentreX(), r.getY() + 3, r.getCentreX(), r.getBottom() - 3, r.getRight(), r.getBottom() - 3); }
    }
    else
    {
        p.startNewSubPath (r.getX(), r.getCentreY()); p.quadraticTo (r.getCentreX(), r.getY() + 2, r.getRight(), r.getCentreY());
    }
    g.setColour (C::muted.withAlpha (0.75f)); g.strokePath (p, juce::PathStrokeType (1.2f));
}

void ConsoleChannelStripXAudioProcessorEditor::drawStereoMeter (juce::Graphics& g, juce::Rectangle<int> b,
                                                                 float leftDb, float rightDb, bool scaleOnRight,
                                                                 const juce::String& title)
{
    leftDb = juce::jlimit (-100.0f, 24.0f, leftDb);
    rightDb = juce::jlimit (-100.0f, 24.0f, rightDb);

    g.setColour (C::text); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (title, b.getX(), b.getY(), b.getWidth(), 18, juce::Justification::centred);

    const bool overload = leftDb > 0.0f || rightDb > 0.0f;
    g.setColour (overload ? juce::Colour (0xffef3434) : C::muted);
    g.setFont (juce::Font (9.0f, overload ? juce::Font::bold : juce::Font::plain));
    g.drawText ("OVL", b.getX(), b.getY() + 20, b.getWidth(), 14, juce::Justification::centred);

    const int top = b.getY() + 44, bottom = b.getBottom() - 46;
    const int segH = 7, gap = 1, segments = juce::jmax (2, (bottom - top) / (segH + gap));
    const int colW = 12;
    const int cx = b.getCentreX();
    const int leftX = cx - 22, rightX = cx + 10;

    auto segmentDb = [segments] (int i)
    {
        // Exact linear dBFS axis: top = 0 dBFS, bottom = -60 dBFS.
        return -60.0f * (float) i / (float) (segments - 1);
    };

    for (int i = 0; i < segments; ++i)
    {
        const float thresholdDb = segmentDb (i);
        juce::Colour base = thresholdDb > -3.0f ? juce::Colour (0xffcc2222)
                           : thresholdDb > -12.0f ? juce::Colour (0xffe8c832)
                                                 : juce::Colour (0xff35a83a);
        const bool litL = leftDb >= thresholdDb;
        const bool litR = rightDb >= thresholdDb;
        const int y = top + i * (segH + gap);
        g.setColour (litL ? base : base.withAlpha (0.12f)); g.fillRect (leftX, y, colW, segH);
        g.setColour (litR ? base : base.withAlpha (0.12f)); g.fillRect (rightX, y, colW, segH);
    }

    static const std::array<int, 13> scaleDb {{ 0, -3, -6, -9, -12, -15, -18, -21, -24, -27, -30, -40, -60 }};
    g.setColour (C::muted); g.setFont (juce::Font (9.5f));
    for (const int db : scaleDb)
    {
        const float norm = (float) (-db) / 60.0f;
        const int y = juce::roundToInt ((float) top + norm * (float) (bottom - top)) - 6;
        const juce::String t = juce::String (-db);
        const int tx = scaleOnRight ? cx + 28 : b.getX();
        const int tw = scaleOnRight ? b.getRight() - tx : cx - 28 - b.getX();
        g.drawText (t, tx, y, tw, 12, scaleOnRight ? juce::Justification::centredLeft : juce::Justification::centredRight);
    }

    // Numeric sample-peak values are the exact dBFS values delivered by the DSP
    // block measurement, not values inferred back from LED positions.
    g.setColour (C::text.withAlpha (0.94f));
    g.setFont (juce::Font (9.2f, juce::Font::bold));
    const auto fmt = [] (float db)
    {
        return db <= -99.0f ? juce::String ("-INF") : juce::String (db, 2);
    };
    g.drawFittedText ("L " + fmt (leftDb) + "  R " + fmt (rightDb) + " dBFS",
                      b.getX() + 2, b.getBottom() - 38, b.getWidth() - 4, 16,
                      juce::Justification::centred, 1, 0.72f);
    g.setColour (C::muted); g.setFont (juce::Font (9.0f));
    g.drawText ("SAMPLE PEAK", b.getX(), b.getBottom() - 20, b.getWidth(), 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawDynamicsGrMeter (juce::Graphics& g, juce::Rectangle<int> b,
                                                                      float grDb, const juce::String& title,
                                                                      juce::Colour activeColour)
{
    grDb = juce::jlimit (0.0f, 40.0f, grDb);

    auto panel = b.toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.48f));
    g.fillRoundedRectangle (panel.translated (1.5f, 2.0f), 6.0f);
    g.setColour (juce::Colour (0xff0a0d0f));
    g.fillRoundedRectangle (panel, 6.0f);
    g.setColour (C::border.brighter (0.12f));
    g.drawRoundedRectangle (panel, 6.0f, 1.1f);

    // Matched, large meters: same geometry for gate and compressor.
    g.setColour (activeColour.brighter (0.22f));
    g.fillRoundedRectangle ((float) b.getX() + 9.0f, (float) b.getY() + 8.0f, 5.0f, 14.0f, 2.0f);
    g.setColour (C::text);
    g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawFittedText (title, b.getX() + 18, b.getY() + 5, b.getWidth() - 28, 20,
                      juce::Justification::centred, 1, 0.88f);

    const int top = b.getY() + 34;
    const int bottom = b.getBottom() - 34;
    const int segH = 4;
    const int gap = 2;
    const int segments = juce::jmax (2, (bottom - top) / (segH + gap));
    const int scaleW = 30;
    const int barX = b.getX() + scaleW + 9;
    const int barW = b.getWidth() - scaleW - 18;

    auto well = juce::Rectangle<float> ((float) barX - 4.0f, (float) top - 4.0f,
                                        (float) barW + 8.0f, (float) (bottom - top) + 8.0f);
    g.setColour (juce::Colour (0xff040607));
    g.fillRoundedRectangle (well, 3.0f);
    g.setColour (juce::Colour (0xff2c3135));
    g.drawRoundedRectangle (well, 3.0f, 0.9f);

    // Full 0..40 dB visual axis matches the numerical measurement range.
    // The number remains the exact smoothed display value; the LED position is
    // a direct linear mapping of that same dB quantity.
    for (int i = 0; i < segments; ++i)
    {
        const float segmentGr = 40.0f * (float) i / (float) (segments - 1);
        const bool lit = segmentGr <= grDb;
        g.setColour (lit ? activeColour.brighter (0.16f) : activeColour.withAlpha (0.085f));
        g.fillRoundedRectangle ((float) barX, (float) (top + i * (segH + gap)),
                                (float) barW, (float) segH, 1.1f);
    }

    static const std::array<int, 7> grScale {{ 0, 5, 10, 15, 20, 30, 40 }};
    g.setColour (C::muted.brighter (0.10f));
    g.setFont (juce::Font (9.8f, juce::Font::bold));
    for (const int db : grScale)
    {
        const int y = juce::roundToInt ((float) top + ((float) db / 40.0f) * (float) (bottom - top)) - 6;
        g.drawText (juce::String (db), b.getX() + 3, y, scaleW, 12, juce::Justification::centredRight);
    }

    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (12.8f, juce::Font::bold));
    g.drawFittedText (juce::String (grDb, 2) + " dB",
                      b.getX() + 5, b.getBottom() - 27, b.getWidth() - 10, 18,
                      juce::Justification::centred, 1, 0.88f);
}

void ConsoleChannelStripXAudioProcessorEditor::paintStaticDesign (juce::Graphics& g)
{
    g.fillAll (C::bg);
    g.setColour (C::top); g.fillRect (0, 0, designWidth, 54); g.fillRect (0, 970, designWidth, 54);
    g.setColour (C::border); g.drawHorizontalLine (53, 0.0f, (float) designWidth); g.drawHorizontalLine (969, 0.0f, (float) designWidth);

    g.setColour (C::text); g.setFont (juce::Font (17.0f, juce::Font::bold));
    g.drawText ("Console Channel Strip X", 18, 13, 300, 28, juce::Justification::centredLeft);
    // Large live parameter readout: remains legible even when the editor is at 75% zoom.
    auto liveBox = juce::Rectangle<float> (885.0f, 8.0f, 350.0f, 38.0f);
    g.setColour (juce::Colour (0xff07090b)); g.fillRoundedRectangle (liveBox, 4.0f);
    g.setColour (C::active.withAlpha (0.70f)); g.drawRoundedRectangle (liveBox, 4.0f, 1.0f);

    g.setColour (C::muted); g.setFont (juce::Font (10.5f));
    g.drawText ("ZOOM", 1270, 18, 44, 18, juce::Justification::centredRight);

    for (const auto& s : sectionSpecs) drawPanel (g, s);

    // EQ labels and simple filter-shape glyphs.
    const std::array<std::tuple<const char*, int, int, juce::Colour, bool, bool>, 4> bands {{
        { "HF", 228, 145, C::red, true, true }, { "HMF", 228, 305, C::orange, false, true },
        { "LMF",228, 465, C::green, false, true }, { "LF", 228, 625, C::blue, true, false }
    }};
    for (const auto& b : bands)
    {
        g.setColour (std::get<3> (b).brighter (0.12f)); g.setFont (juce::Font (13.0f, juce::Font::bold));
        g.drawText (std::get<0> (b), std::get<1> (b), std::get<2> (b), 40, 18, juce::Justification::centredLeft);
        drawBandCurve (g, { (float) std::get<1> (b), (float) std::get<2> (b) + 20.0f, 36.0f, 16.0f }, std::get<4> (b), std::get<5> (b));
    }
    g.setColour (C::text.withAlpha (0.90f)); g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("FILTERS", 228, 760, 334, 20, juce::Justification::centred);
    g.setColour (C::border); g.drawHorizontalLine (752, 228.0f, 566.0f);

    // Dynamics headings and separators. No decorative ATTACK knobs: program dependence stays real.
    g.setColour (C::text); g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("GATE / EXPANDER", 606, 90, 370, 22, juce::Justification::centred);
    g.drawText ("COMPRESSOR", 606, 525, 370, 22, juce::Justification::centred);
    g.setColour (C::border); g.drawHorizontalLine (510, 606.0f, 976.0f);
    g.setColour (C::muted); g.setFont (juce::Font (10.0f));
    g.drawText ("NORMAL ATTACK: PROGRAM 3-30 ms", 732, 788, 122, 34, juce::Justification::centred);
    g.drawText ("AUTO MAKE-UP", 732, 832, 112, 18, juce::Justification::centredRight);
    drawLed (g, 853.0f, 841.0f, true, C::lamp);

    // Meter interior.
    auto meterInner = juce::Rectangle<float> (1010.0f, 82.0f, 272.0f, 852.0f);
    g.setColour (juce::Colour (0xff0b0d0e)); g.fillRoundedRectangle (meterInner, 4.0f);
    g.setColour (juce::Colour (0xff303438)); g.drawRoundedRectangle (meterInner, 4.0f, 1.0f);

    // Output sections.
    g.setColour (C::border); g.drawHorizontalLine (540, 1318.0f, 1508.0f);
    g.setColour (C::muted); g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawText ("MATCHES PROCESSED RMS TO INPUT", 1318, 526, 190, 16, juce::Justification::centred);
    g.setColour (C::border); g.drawHorizontalLine (684, 1318.0f, 1508.0f);
    g.setColour (C::text); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("STEREO IMAGE", 1320, 686, 186, 18, juce::Justification::centred);

    // Footer branding: own name only.
    g.setColour (C::text.withAlpha (0.88f)); g.setFont (juce::Font (14.0f));
    g.drawText ("CONSOLE CHANNEL STRIP", 20, 985, 240, 24, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xffcc2222)); g.setFont (juce::Font (15.0f, juce::Font::bold));
    g.drawText ("X", 246, 985, 24, 24, juce::Justification::centredLeft);
    g.setColour (C::text.withAlpha (0.78f)); g.setFont (juce::Font (16.0f, juce::Font::bold));
    g.drawText ("OPENWORKSTATION X", 570, 985, 400, 24, juce::Justification::centred);
    g.setColour (C::muted); g.setFont (juce::Font (11.0f));
    g.drawText ("v0.4.1 WIEN RC", 1320, 985, 188, 24, juce::Justification::centredRight);
}

void ConsoleChannelStripXAudioProcessorEditor::paintDynamicDesign (juce::Graphics& g)
{
    g.setColour (C::muted); g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawFittedText (activeParameterName, 896, 11, 154, 14, juce::Justification::centredLeft, 1, 0.85f);
    g.setColour (juce::Colours::white); g.setFont (juce::Font (15.0f, juce::Font::bold));
    g.drawFittedText (activeParameterValue, 1048, 10, 176, 25, juce::Justification::centredRight, 1, 0.82f);

    // Level meters remain in the central meter bay.  Dynamics reduction is no
    // longer combined here; each reduction meter lives with the circuit it represents.
    drawStereoMeter (g, { 1015, 105, 112, 790 }, inputPeakDisplayL, inputPeakDisplayR, false, "INPUT");
    drawStereoMeter (g, { 1156,105, 112, 790 }, outputPeakDisplayL, outputPeakDisplayR, true, "OUTPUT");

    // Gate / expander reduction belongs to the upper dynamics block.
    drawDynamicsGrMeter (g, { 862, 166, 120, 309 }, gateGrDisplayDb, "GATE GR", C::green);

    // Compressor reduction belongs to the lower dynamics block.
    drawDynamicsGrMeter (g, { 862, 610, 120, 295 }, compGrDisplayDb, "COMP GR", C::blue);
}

void ConsoleChannelStripXAudioProcessorEditor::rebuildStaticLayer()
{
    staticLayer = juce::Image (juce::Image::RGB, designWidth, designHeight, true);
    juce::Graphics gg (staticLayer); paintStaticDesign (gg);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    if (staticLayer.isNull()) rebuildStaticLayer();

    g.fillAll (C::bg);
    const float s = juce::jmin ((float) getWidth() / (float) designWidth,
                                (float) getHeight() / (float) designHeight);
    juce::Graphics::ScopedSaveState save (g);
    g.addTransform (juce::AffineTransform::scale (s));
    g.drawImageAt (staticLayer, 0, 0);
    paintDynamicDesign (g);
}

void ConsoleChannelStripXAudioProcessorEditor::placeDesignBounds (juce::Component& c, int x, int y, int w, int h)
{
    // Child controls never receive their own scale transform.  They stay permanently
    // in 1536x1024 design coordinates; the single parent designSurface is transformed
    // in resized().  This is the key invariant that keeps every knob aligned.
    c.setTransform (juce::AffineTransform());
    c.setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    // IMPORTANT: never derive uiScale back from the integer window size here.
    // setSize() necessarily rounds designWidth*uiScale/designHeight*uiScale to
    // whole pixels. Feeding that rounded result back into uiScale caused a small
    // loss on every zoom step (1.10 -> 1.0996 -> ... -> ~1.498), so five +10%
    // steps no longer reached the exact 150% size. uiScale is authoritative and
    // is changed only by setUiScale().
    const float surfaceScale = juce::jlimit (0.50f, 1.50f,
                                             juce::jmin ((float) getWidth() / (float) designWidth,
                                                         (float) getHeight() / (float) designHeight));

    designSurface.setTransform (juce::AffineTransform());
    designSurface.setBounds (0, 0, designWidth, designHeight);
    designSurface.setTransform (juce::AffineTransform::scale (surfaceScale));

    for (const auto& spec : knobSpecs)
        if (auto it = knobs.find (spec.paramId); it != knobs.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    for (const auto& spec : faderSpecs)
        if (auto it = faders.find (spec.paramId); it != faders.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    for (const auto& spec : buttonSpecs)
        if (auto it = toggles.find (spec.paramId); it != toggles.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    if (auto it = toggles.find ("compPeak"); it != toggles.end())
        placeDesignBounds (*it->second, 680, 555, 96, 32);
    if (auto it = toggles.find ("compFast"); it != toggles.end())
        placeDesignBounds (*it->second, 790, 555, 126, 32);
    for (const auto& spec : choiceSpecs)
        if (auto it = choices.find (spec.paramId); it != choices.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);

    placeDesignBounds (*powerButton, 330, 10, 64, 34);
    placeDesignBounds (*undoButton, 405, 10, 62, 34);
    placeDesignBounds (*redoButton, 475, 10, 62, 34);
    placeDesignBounds (*initButton, 555, 10, 310, 34);
    placeDesignBounds (*zoomOutButton, 1320, 10, 38, 34);
    placeDesignBounds (*zoomResetButton, 1364, 10, 72, 34);
    placeDesignBounds (*zoomInButton, 1442, 10, 38, 34);
}

void ConsoleChannelStripXAudioProcessorEditor::setUiScale (float newScale)
{
    newScale = juce::jlimit (0.50f, 1.50f, newScale);
    uiScale = newScale;
    setSize (juce::roundToInt ((float) designWidth * uiScale), juce::roundToInt ((float) designHeight * uiScale));
}

void ConsoleChannelStripXAudioProcessorEditor::resetToInit() { audioProcessor.resetParametersToDefaults(); repaint(); }

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    // Consume the maximum sample peak seen since the previous GUI tick first.
    // Besides driving the level meter, this lets the GR display recognise a true
    // transport/silence stop. The compressor's real RC release may remain charged
    // for seconds; with no audible input there is no useful reason to leave stale
    // GR digits crawling down that slowly.
    const float inL = audioProcessor.inputMeterL();
    const float inR = audioProcessor.inputMeterR();
    const float outL = audioProcessor.outputMeterL();
    const float outR = audioProcessor.outputMeterR();

    const float measuredCompGr = juce::jlimit (0.0f, 40.0f, audioProcessor.compressorMeter());
    const float measuredGateGr = juce::jlimit (0.0f, 40.0f, audioProcessor.gateMeter());
    const bool audibleInput = juce::jmax (inL, inR) > -80.0f;

    // Meter ballistics only: DSP gain reduction itself is untouched. At 60 Hz
    // the display uses a modest 70 ms attack and 220 ms release so active GR is
    // readable instead of twitching block-to-block. When transport/input is
    // silent we deliberately return the display to zero faster (75 ms), while
    // the compressor circuit is still free to complete its physical release.
    const auto followGr = [] (float current, float measured, bool signalPresent)
    {
        const float target = signalPresent ? measured : 0.0f;
        const float tauSeconds = ! signalPresent ? 0.075f
                               : (target > current ? 0.070f : 0.220f);
        const float alpha = std::exp (-1.0f / (60.0f * tauSeconds));
        float next = target + (current - target) * alpha;
        if (! signalPresent && next < 0.01f)
            next = 0.0f;
        return juce::jlimit (0.0f, 40.0f, next);
    };

    compGrDisplayDb = followGr (compGrDisplayDb, measuredCompGr, audibleInput);
    gateGrDisplayDb = followGr (gateGrDisplayDb, measuredGateGr, audibleInput);

    // The level meters themselves remain true sample-peak measurements. The DSP
    // accumulates these atomically across all intervening audio blocks, preventing
    // a one-block transient from being missed by the slower GUI refresh.
    if (inL > -99.9f) inputPeakDisplayL = inL;
    if (inR > -99.9f) inputPeakDisplayR = inR;
    if (outL > -99.9f) outputPeakDisplayL = outL;
    if (outR > -99.9f) outputPeakDisplayR = outR;

    for (auto& kv : knobs) kv.second->repaint();
    for (auto& kv : faders) kv.second->repaint();
    for (auto& kv : toggles) kv.second->repaint();
    for (auto& kv : choices) kv.second->repaint();
    if (powerButton) powerButton->repaint();
    repaint();
}
