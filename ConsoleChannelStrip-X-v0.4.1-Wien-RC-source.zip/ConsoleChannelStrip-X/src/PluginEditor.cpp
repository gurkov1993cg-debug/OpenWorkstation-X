#include "PluginEditor.h"
#include <cmath>
#include <tuple>

namespace
{
    namespace C
    {
        const juce::Colour bg       { 0xff0a0c0e };
        const juce::Colour top      { 0xff0d0f11 };
        const juce::Colour panelA   { 0xff1c1f22 };
        const juce::Colour panelB   { 0xff16191c };
        const juce::Colour border   { 0xff3a3e42 };
        const juce::Colour text     { 0xffe8e8e8 };
        const juce::Colour muted    { 0xff9a9a9a };
        const juce::Colour tick     { 0xff8f9296 };
        const juce::Colour red      { 0xffb02a26 };
        const juce::Colour orange   { 0xffc06a1e };
        const juce::Colour green    { 0xff2f7a3a };
        const juce::Colour blue     { 0xff1f5fb8 };
        const juce::Colour grey     { 0xff45494d };
        const juce::Colour active   { 0xff1663d8 };
        const juce::Colour lamp     { 0xff3fd44f };
        const juce::Colour amber    { 0xffd98222 };
    }

    const juce::String kInfinity (juce::CharPointer_UTF8 ("\xE2\x88\x9E"));
    const juce::String kPhase (juce::CharPointer_UTF8 ("\xC3\x98"));

    const std::array<SectionSpec, 5> sectionSpecs {{
        { "INPUT",      8,   56, 188, 908, true },
        { "EQUALISER", 202, 56, 350, 908, true },
        { "DYNAMICS",  557, 56, 368, 908, true },
        { "",          930, 56, 385, 908, true },
        { "OUTPUT",    1320,56, 208, 908, true }
    }};

    const std::array<KnobSpec, 22> knobSpecs {{
        { "inputDrive",    "GAIN",       42, 105, 126, 190, 0xffb02a26, "0",  "-20", "dB",  "+20", true,  ConsoleValueStyle::drive },

        { "hfGain",        "",          262, 120, 118, 145, 0xffb02a26, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "hfFreq",        "",          390, 120, 105, 145, 0xff45494d, "",   "1.5", "kHz", "16",  true,  ConsoleValueStyle::frequency },
        { "hmfGain",       "",          262, 280, 118, 145, 0xffc06a1e, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "hmfFreq",       "",          390, 280,  95, 145, 0xff45494d, "",   "0.6", "kHz", "7",   true,  ConsoleValueStyle::frequency },
        { "hmfQ",          "Q",         490, 345,  48,  82, 0xff45494d, "",   "0.1", "",    "3.5", false, ConsoleValueStyle::q },
        { "lmfGain",       "",          262, 440, 118, 145, 0xff2f7a3a, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "lmfFreq",       "",          390, 440,  95, 145, 0xff45494d, "",   "0.2", "kHz", "2.5", true,  ConsoleValueStyle::frequency },
        { "lmfQ",          "Q",         490, 505,  48,  82, 0xff45494d, "",   "0.1", "",    "3.5", false, ConsoleValueStyle::q },
        { "lfGain",        "",          262, 600, 118, 145, 0xff1f5fb8, "0",  "-15", "dB",  "+15", true,  ConsoleValueStyle::dB },
        { "lfFreq",        "",          390, 600, 105, 145, 0xff45494d, "",   "30",  "Hz",  "450", true,  ConsoleValueStyle::frequency },
        { "hpFreq",        "HPF",       250, 780, 120, 145, 0xff45494d, "",   "16",  "Hz",  "350", true,  ConsoleValueStyle::frequency },
        { "lpFreq",        "LPF",       402, 780, 120, 145, 0xff45494d, "",   "3",   "kHz", "22",  true,  ConsoleValueStyle::frequency },

        { "gateThreshold", "THRESHOLD", 586, 170, 104, 150, 0xff2f7a3a, "",   "-30", "dB",  "+10", true,  ConsoleValueStyle::dB },
        { "gateRange",     "RANGE",     703, 170, 104, 150, 0xff2f7a3a, "",   "0",   "dB",  "40",  true,  ConsoleValueStyle::dB },
        { "gateHold",      "HOLD",      586, 335, 104, 150, 0xff45494d, "",   "0",   "s",   "4",   true,  ConsoleValueStyle::hold },
        { "gateRelease",   "RELEASE",   703, 335, 104, 150, 0xff45494d, "",   "0.1", "s",   "4",   true,  ConsoleValueStyle::release },

        { "compThreshold", "THRESHOLD", 586, 610, 104, 150, 0xff1f5fb8, "",   "-20", "dB",  "+10", true,  ConsoleValueStyle::dB },
        { "compRatio",     "RATIO",     703, 610, 104, 150, 0xff1f5fb8, "",   "1:1", ":1",  "INF", true,  ConsoleValueStyle::ratio },
        { "compRelease",   "RELEASE",   820, 610,  92, 150, 0xff45494d, "",   "0.1", "s",   "4",   true,  ConsoleValueStyle::release },

        { "outputTrim",    "LEVEL",     1350,125, 146, 205, 0xff45494d, "0",  "-20", "dB",  "+20", true,  ConsoleValueStyle::dB },
        { "pan",           "PAN",       1360,380, 126, 190, 0xff45494d, "C",  "L",   "",    "R",   true,  ConsoleValueStyle::pan }
    }};

    const std::array<FaderSpec, 1> faderSpecs {{
        { "inputTrim", "INPUT TRIM", 38, 450, 135, 470, 0xff45494d, "+20", "-20", true, ConsoleValueStyle::dB }
    }};

    const std::array<ButtonSpec, 12> buttonSpecs {{
        { "inputPad",   "-20dB",       108, 365, 64, 34, ConsoleButtonStyle::Square, 0xffb02a26, false },
        { "polarity",   "PHASE",        43, 365, 56, 34, ConsoleButtonStyle::Square, 0xffd98222, false },
        { "eqOn",       "EQ IN",       218,  88, 72, 30, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "hfBell",     "BELL",        500, 230, 40, 28, ConsoleButtonStyle::Square, 0xffb02a26, false },
        { "lfBell",     "BELL",        500, 710, 40, 28, ConsoleButtonStyle::Square, 0xff1f5fb8, false },
        { "hpOn",       "IN",          294, 930, 42, 28, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "lpOn",       "IN",          446, 930, 42, 28, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "dynOn",      "DYN IN",      827,  82, 78, 28, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "gateOn",     "IN",          585, 118, 54, 30, ConsoleButtonStyle::Square, 0xff2f7a3a, true  },
        { "gateExpand", "EXPAND",      810, 118, 92, 30, ConsoleButtonStyle::Square, 0xff2f7a3a, true  },
        { "gateFast",   "FAST ATTACK", 810, 330, 92, 32, ConsoleButtonStyle::Square, 0xffd98222, true  },
        { "compOn",     "IN",          585, 555, 54, 30, ConsoleButtonStyle::Square, 0xff1f5fb8, true  }
    }};

    const std::array<ChoiceSpec, 3> choiceSpecs {{
        { "inputMode",   "LINE",   "MIC",      43, 315, 129, 34, 0xffd98222 },
        { "eqModel",     "BROWN",  "BLACK",   390, 88, 148, 30, 0xffd98222 },
        { "channelMode", "STEREO", "MID/SIDE",1342,790, 166, 42, 0xff1663d8 }
    }};

    const std::array<juce::Rectangle<int>, 6> ratioTabRects {{
        juce::Rectangle<int> { 580, 865, 50, 34 }, juce::Rectangle<int> { 635, 865, 50, 34 },
        juce::Rectangle<int> { 690, 865, 50, 34 }, juce::Rectangle<int> { 745, 865, 50, 34 },
        juce::Rectangle<int> { 800, 865, 50, 34 }, juce::Rectangle<int> { 855, 865, 50, 34 }
    }};
    const std::array<float, 6> ratioValues {{ 20.0f, 14.0f, 10.0f, 6.0f, 4.0f, 2.0f }};
    const std::array<const char*, 6> ratioLabels {{ "20:1", "14:1", "10:1", "6:1", "4:1", "2:1" }};

    juce::String formatConsoleValue (double v, ConsoleValueStyle style)
    {
        switch (style)
        {
            case ConsoleValueStyle::dB:
            case ConsoleValueStyle::drive:
            {
                const auto number = juce::String (v, std::abs (v) < 10.0 ? 1 : 0);
                return (v > 0.0005 ? "+" : "") + number + " dB";
            }
            case ConsoleValueStyle::frequency:
                return v >= 1000.0 ? juce::String (v / 1000.0, v >= 10000.0 ? 1 : 2) + " kHz"
                                   : juce::String (v, v >= 100.0 ? 0 : 1) + " Hz";
            case ConsoleValueStyle::q:
                return "Q " + juce::String (v, 2);
            case ConsoleValueStyle::ratio:
                return v >= 19.95 ? "INF:1" : juce::String (v, v < 3.0 ? 1 : 0) + ":1";
            case ConsoleValueStyle::release:
            case ConsoleValueStyle::hold:
                return juce::String (v, v < 1.0 ? 2 : 1) + " s";
            case ConsoleValueStyle::percent:
                return juce::String ((int) std::round (v)) + "%";
            case ConsoleValueStyle::pan:
                if (std::abs (v) < 0.015) return "C";
                return v < 0.0 ? "L " + juce::String ((int) std::round (-v * 100.0))
                               : "R " + juce::String ((int) std::round ( v * 100.0));
            case ConsoleValueStyle::plain:
            default:
                return juce::String (v, 2);
        }
    }

    juce::String friendlyParameterName (const juce::String& id)
    {
        static const std::map<juce::String, juce::String> names {
            { "inputDrive", "INPUT GAIN" }, { "inputTrim", "INPUT TRIM" },
            { "hfGain", "HF GAIN" }, { "hfFreq", "HF FREQ" },
            { "hmfGain", "HMF GAIN" }, { "hmfFreq", "HMF FREQ" }, { "hmfQ", "HMF Q" },
            { "lmfGain", "LMF GAIN" }, { "lmfFreq", "LMF FREQ" }, { "lmfQ", "LMF Q" },
            { "lfGain", "LF GAIN" }, { "lfFreq", "LF FREQ" },
            { "hpFreq", "HPF FREQ" }, { "lpFreq", "LPF FREQ" },
            { "gateThreshold", "GATE THRESHOLD" }, { "gateRange", "GATE RANGE" },
            { "gateHold", "GATE HOLD" }, { "gateRelease", "GATE RELEASE" },
            { "compThreshold", "COMP THRESHOLD" }, { "compRatio", "COMP RATIO" }, { "compPeak", "COMP PEAK" },
            { "compRelease", "COMP RELEASE" }, { "outputTrim", "OUTPUT LEVEL" },
            { "pan", "PAN" }
        };
        if (auto it = names.find (id); it != names.end()) return it->second;
        return id.toUpperCase();
    }

    void drawButtonBody (juce::Graphics& g, juce::Rectangle<float> r, bool on, bool pressed,
                         juce::Colour onColour, const juce::String& text, ConsoleButtonStyle style)
    {
        r = r.reduced (0.5f);
        const auto off = juce::Colour (0xff24282c);
        const auto fill = on ? onColour : off;
        g.setColour (juce::Colours::black.withAlpha (0.55f));
        g.fillRoundedRectangle (r.translated (1.0f, 2.0f), 3.0f);
        g.setColour (pressed ? fill.darker (0.16f) : fill);
        g.fillRoundedRectangle (r, 3.0f);
        g.setColour (on ? onColour.brighter (0.30f) : juce::Colour (0xff4a4e52));
        g.drawRoundedRectangle (r, 3.0f, 1.0f);
        g.setColour (on ? juce::Colours::white : juce::Colour (0xffc8c8c8));
        g.setFont (juce::Font (style == ConsoleButtonStyle::RatioTab ? 10.0f : 11.0f, juce::Font::bold));
        g.drawFittedText (text, r.toNearestInt().reduced (3, 1), juce::Justification::centred, 1, 0.85f);
    }

    void drawKnobBody (juce::Graphics& g, juce::Rectangle<float> knob, float norm, juce::Colour faceColour)
    {
        const float start = juce::degreesToRadians (-140.0f);
        const float end   = juce::degreesToRadians ( 140.0f);
        const float angle = start + juce::jlimit (0.0f, 1.0f, norm) * (end - start);
        const auto c = knob.getCentre();
        const float radius = knob.getWidth() * 0.5f;

        // Eleven external tick marks, before the body.
        g.setColour (C::tick);
        for (int i = 0; i <= 10; ++i)
        {
            const float a = start + (end - start) * (float) i / 10.0f;
            const float inner = radius * ((i == 0 || i == 10) ? 1.24f : 1.28f);
            const float outer = radius * 1.42f;
            const auto p1 = c + juce::Point<float> (std::sin (a) * inner, -std::cos (a) * inner);
            const auto p2 = c + juce::Point<float> (std::sin (a) * outer, -std::cos (a) * outer);
            g.drawLine (juce::Line<float> (p1, p2), 1.2f);
        }

        g.setColour (juce::Colour (0xff4a4e52));
        g.fillEllipse (knob.expanded (2.0f));

        juce::ColourGradient face (faceColour.brighter (0.12f), c.x, knob.getY(),
                                   faceColour.darker (0.40f), c.x, knob.getBottom(), false);
        g.setGradientFill (face);
        g.fillEllipse (knob);

        const float hiD = knob.getWidth() * 0.62f;
        auto hi = juce::Rectangle<float> (c.x - hiD * 0.5f, knob.getY() + knob.getHeight() * 0.08f,
                                          hiD, hiD * 0.48f);
        g.setColour (juce::Colours::white.withAlpha (0.10f));
        g.fillEllipse (hi);

        g.setColour (juce::Colours::black.withAlpha (0.35f));
        g.drawEllipse (knob.reduced (1.0f), 1.0f);

        const float len = radius * 0.92f;
        const auto p2 = c + juce::Point<float> (std::sin (angle) * len, -std::cos (angle) * len);
        g.setColour (juce::Colour (0xfff0f0f0));
        g.drawLine (juce::Line<float> (c, p2), 2.2f);
    }
}

ParameterHardwareControl::ParameterHardwareControl (juce::String parameterId, juce::RangedAudioParameter* parameter)
    : param (parameter)
{
    setComponentID (std::move (parameterId));
    setWantsKeyboardFocus (false);
}

float ParameterHardwareControl::normalisedValue() const noexcept { return param != nullptr ? param->getValue() : 0.0f; }
double ParameterHardwareControl::actualValue() const noexcept
{
    return param != nullptr ? (double) param->convertFrom0to1 (param->getValue()) : 0.0;
}
void ParameterHardwareControl::beginGesture()
{
    if (param != nullptr && ! gestureActive) { param->beginChangeGesture(); gestureActive = true; }
}
void ParameterHardwareControl::endGesture()
{
    if (param != nullptr && gestureActive) { param->endChangeGesture(); gestureActive = false; }
}
void ParameterHardwareControl::setNormalisedValue (float value, bool withGesture)
{
    if (param == nullptr) return;
    value = juce::jlimit (0.0f, 1.0f, value);
    if (withGesture) beginGesture();
    param->setValueNotifyingHost (value);
    if (withGesture) endGesture();
    repaint();
}
void ParameterHardwareControl::resetToDefault()
{
    if (param != nullptr) setNormalisedValue (param->getDefaultValue(), true);
}

HardwareKnob::HardwareKnob (const KnobSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.label), topText (s.topText), minText (s.minText),
      unitText (s.unitText), maxText (s.maxText), faceColour (s.faceColour), style (s.valueStyle), hasValueBox (s.hasValueBox)
{
}

void HardwareKnob::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const float valueH = hasValueBox ? 24.0f : 0.0f;
    if (hasValueBox) r.removeFromBottom (valueH);

    g.setColour (C::text.withAlpha (0.93f));
    g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawFittedText (label, 0, 0, getWidth(), 17, juce::Justification::centred, 1, 0.90f);

    g.setColour (C::muted);
    g.setFont (juce::Font (10.0f));
    g.drawText (topText, 0, 18, getWidth(), 14, juce::Justification::centred);

    auto zone = r.withTrimmedTop (30.0f).withTrimmedBottom (20.0f);
    const float d = juce::jmin (zone.getWidth() * 0.60f, zone.getHeight() * 0.72f);
    auto knob = zone.withSizeKeepingCentre (d, d);
    drawKnobBody (g, knob, normalisedValue(), faceColour);

    const int sy = (int) knob.getBottom() + 7;
    g.setColour (C::muted);
    g.setFont (juce::Font (10.0f));
    g.drawText (minText, 3, sy, getWidth() / 2 - 3, 14, juce::Justification::centredLeft);
    g.drawText (maxText, getWidth() / 2, sy, getWidth() / 2 - 3, 14, juce::Justification::centredRight);
    g.drawText (unitText, 0, sy, getWidth(), 14, juce::Justification::centred);

    if (hasValueBox)
    {
        auto vb = juce::Rectangle<float> (6.0f, (float) getHeight() - 23.0f, (float) getWidth() - 12.0f, 20.0f);
        g.setColour (juce::Colour (0xff080a0c));
        g.fillRoundedRectangle (vb, 3.0f);
        g.setColour (C::active.withAlpha (0.70f));
        g.drawRoundedRectangle (vb, 3.0f, 1.0f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::Font (12.0f, juce::Font::bold));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt().reduced (2, 0), juce::Justification::centred, 1, 0.78f);
    }
    else if (style == ConsoleValueStyle::q)
    {
        auto vb = juce::Rectangle<int> (1, getHeight() - 18, getWidth() - 2, 16);
        g.setColour (juce::Colour (0xff080a0c)); g.fillRoundedRectangle (vb.toFloat(), 2.0f);
        g.setColour (juce::Colours::white); g.setFont (juce::Font (9.5f, juce::Font::bold));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb, juce::Justification::centred, 1, 0.72f);
    }
}

void HardwareKnob::reportValue()
{
    if (valueReporter) valueReporter (getComponentID(), formatConsoleValue (actualValue(), style));
}

void HardwareKnob::mouseDown (const juce::MouseEvent& e)
{
    dragStartY = e.getScreenPosition().y; dragStartValue = normalisedValue(); beginGesture(); reportValue();
}
void HardwareKnob::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 900.0f : 280.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta));
    reportValue(); repaint();
}
void HardwareKnob::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareKnob::mouseDoubleClick (const juce::MouseEvent&) { resetToDefault(); reportValue(); }
void HardwareKnob::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
    reportValue();
}
void HardwareKnob::exerciseForTest()
{
    const float before = normalisedValue(); setNormalisedValue (before < 0.5f ? 0.73f : 0.27f, true);
}

HardwareFader::HardwareFader (const FaderSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.label), topText (s.topText), bottomText (s.bottomText),
      faceColour (s.faceColour), style (s.valueStyle), hasValueBox (s.hasValueBox)
{
}

void HardwareFader::reportValue()
{
    if (valueReporter) valueReporter (getComponentID(), formatConsoleValue (actualValue(), style));
}

void HardwareFader::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto labelBox = r.removeFromTop (22.0f);
    auto valueBox = hasValueBox ? r.removeFromBottom (26.0f) : juce::Rectangle<float>();
    auto track = r.reduced (32.0f, 15.0f);
    const float cx = track.getCentreX();

    g.setColour (C::text); g.setFont (juce::Font (11.0f, juce::Font::bold));
    g.drawFittedText (label, labelBox.toNearestInt(), juce::Justification::centred, 1, 0.85f);

    g.setColour (juce::Colour (0xff090b0c));
    g.fillRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, track.getY(), 10.0f, track.getHeight()), 3.0f);
    g.setColour (juce::Colour (0xff42474a));
    g.drawRoundedRectangle (juce::Rectangle<float> (cx - 5.0f, track.getY(), 10.0f, track.getHeight()), 3.0f, 1.0f);

    static const std::array<const char*, 5> marks {{ "+20", "+10", "0", "-10", "-20" }};
    for (int i = 0; i < (int) marks.size(); ++i)
    {
        const float y = track.getY() + track.getHeight() * (float) i / (float) (marks.size() - 1);
        g.setColour (C::tick); g.drawHorizontalLine ((int) y, cx - 27.0f, cx - 15.0f); g.drawHorizontalLine ((int) y, cx + 15.0f, cx + 27.0f);
        g.setColour (C::muted); g.setFont (juce::Font (9.5f));
        g.drawText (marks[(size_t) i], 0, (int) y - 7, (int) (cx - 30.0f), 14, juce::Justification::centredRight);
    }

    const float y = track.getBottom() - normalisedValue() * track.getHeight();
    auto handle = juce::Rectangle<float> (cx - 27.0f, y - 15.0f, 54.0f, 30.0f);
    juce::ColourGradient hgrad (juce::Colour (0xffd0d2d2), handle.getX(), handle.getY(),
                                faceColour.darker (0.45f), handle.getX(), handle.getBottom(), false);
    g.setGradientFill (hgrad); g.fillRoundedRectangle (handle, 3.0f);
    g.setColour (juce::Colour (0xff2b2e30)); g.drawRoundedRectangle (handle, 3.0f, 1.0f);
    g.setColour (juce::Colours::white.withAlpha (0.50f));
    for (int i = -2; i <= 2; ++i) g.drawHorizontalLine ((int) (y + i * 3.0f), handle.getX() + 7.0f, handle.getRight() - 7.0f);

    if (hasValueBox)
    {
        auto vb = valueBox.reduced (18.0f, 3.0f);
        g.setColour (juce::Colour (0xff0e1012)); g.fillRoundedRectangle (vb, 2.0f);
        g.setColour (C::border); g.drawRoundedRectangle (vb, 2.0f, 1.0f);
        g.setColour (C::text); g.setFont (juce::Font (12.0f));
        g.drawFittedText (formatConsoleValue (actualValue(), style), vb.toNearestInt(), juce::Justification::centred, 1, 0.9f);
    }
}
void HardwareFader::mouseDown (const juce::MouseEvent& e) { dragStartY = e.getScreenPosition().y; dragStartValue = normalisedValue(); beginGesture(); reportValue(); }
void HardwareFader::mouseDrag (const juce::MouseEvent& e)
{
    if (param == nullptr) return;
    const float sensitivity = e.mods.isShiftDown() ? 1000.0f : 420.0f;
    const float delta = (float) (dragStartY - e.getScreenPosition().y) / sensitivity;
    param->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, dragStartValue + delta)); reportValue(); repaint();
}
void HardwareFader::mouseUp (const juce::MouseEvent&) { endGesture(); }
void HardwareFader::mouseDoubleClick (const juce::MouseEvent&) { resetToDefault(); reportValue(); }
void HardwareFader::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& d)
{
    const float step = e.mods.isShiftDown() ? 0.0025f : 0.0125f;
    setNormalisedValue (normalisedValue() + (d.deltaY >= 0.0f ? step : -step), true);
    reportValue();
}
void HardwareFader::exerciseForTest() { const float before = normalisedValue(); setNormalisedValue (before < 0.5f ? 0.75f : 0.25f, true); }

HardwareToggle::HardwareToggle (const ButtonSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), label (s.text), onColour (s.onColour), buttonStyle (s.style), hasLed (s.hasLed)
{
    if (getComponentID() == "polarity") label = kPhase;
}
void HardwareToggle::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    auto button = hasLed ? r.withTrimmedRight (18.0f) : r;
    drawButtonBody (g, button, isOn(), false, onColour, label, buttonStyle);
    if (hasLed) ConsoleChannelStripXAudioProcessorEditor::drawLed (g, r.getRight() - 9.0f, r.getCentreY(), isOn(), C::lamp);
}
void HardwareToggle::mouseUp (const juce::MouseEvent& e)
{
    if (getLocalBounds().contains (e.getPosition())) setNormalisedValue (isOn() ? 0.0f : 1.0f, true);
}
void HardwareToggle::exerciseForTest() { setNormalisedValue (isOn() ? 0.0f : 1.0f, true); }

HardwareChoice::HardwareChoice (const ChoiceSpec& s, juce::RangedAudioParameter* p)
    : ParameterHardwareControl (s.paramId, p), a (s.labelA), b (s.labelB), onColour (s.onColour)
{
}
int HardwareChoice::currentIndex() const noexcept
{
    return param == nullptr ? 0 : juce::jlimit (0, 1, (int) std::round (param->convertFrom0to1 (param->getValue())));
}
void HardwareChoice::chooseIndex (int index, bool withGesture)
{
    if (param == nullptr) return; index = juce::jlimit (0, 1, index); setNormalisedValue (param->convertTo0to1 ((float) index), withGesture);
}
void HardwareChoice::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (0.5f); const float gap = 5.0f; const float w = (r.getWidth() - gap) * 0.5f;
    drawButtonBody (g, { r.getX(), r.getY(), w, r.getHeight() }, currentIndex() == 0, false, onColour, a, ConsoleButtonStyle::Wide);
    drawButtonBody (g, { r.getX() + w + gap, r.getY(), w, r.getHeight() }, currentIndex() == 1, false, onColour, b, ConsoleButtonStyle::Wide);
}
void HardwareChoice::mouseUp (const juce::MouseEvent& e)
{
    if (! getLocalBounds().contains (e.getPosition())) return; chooseIndex (e.x < getWidth() / 2 ? 0 : 1, true);
}
void HardwareChoice::exerciseForTest() { chooseIndex (1 - currentIndex(), true); }

HardwareActionButton::HardwareActionButton (juce::String componentName, juce::String buttonText, juce::Colour newAccent,
                                            std::function<void()> newAction, std::function<bool()> newStateProvider)
    : text (std::move (buttonText)), accent (newAccent), action (std::move (newAction)), stateProvider (std::move (newStateProvider))
{
    setName (std::move (componentName));
}
void HardwareActionButton::paint (juce::Graphics& g)
{
    drawButtonBody (g, getLocalBounds().toFloat().reduced (0.5f), stateProvider ? stateProvider() : false, pressed,
                    accent, text, ConsoleButtonStyle::Square);
}
void HardwareActionButton::mouseDown (const juce::MouseEvent&) { pressed = true; repaint(); }
void HardwareActionButton::mouseUp (const juce::MouseEvent& e)
{
    const bool trigger = pressed && getLocalBounds().contains (e.getPosition()); pressed = false; repaint(); if (trigger && action) action();
}
void HardwareActionButton::triggerForTest() { if (action) action(); repaint(); }

ConsoleChannelStripXAudioProcessorEditor::ConsoleChannelStripXAudioProcessorEditor (ConsoleChannelStripXAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setOpaque (true);

    // All GUI controls live on one fixed design surface.  Only this surface is
    // scaled.  Scaling every knob/button separately caused the controls to move
    // relative to one another in Cubase when zoom changed.
    addAndMakeVisible (designSurface);
    designSurface.setInterceptsMouseClicks (false, true);
    designSurface.setBounds (0, 0, designWidth, designHeight);

    createControlsFromLayout();

    powerButton = std::make_unique<HardwareActionButton> ("ui_power", "POWER", C::amber,
        [this]
        {
            if (auto* q = audioProcessor.parameters().getParameter ("bypass"))
            {
                q->beginChangeGesture(); q->setValueNotifyingHost (q->getValue() < 0.5f ? 1.0f : 0.0f); q->endChangeGesture();
            }
        },
        [this]
        {
            if (auto* q = audioProcessor.parameters().getParameter ("bypass")) return q->getValue() < 0.5f;
            return false;
        });
    undoButton = std::make_unique<HardwareActionButton> ("ui_undo", "UNDO", C::grey, [this] { audioProcessor.undo(); });
    redoButton = std::make_unique<HardwareActionButton> ("ui_redo", "REDO", C::grey, [this] { audioProcessor.redo(); });
    initButton = std::make_unique<HardwareActionButton> ("ui_init", "A: DEFAULT / INIT", C::amber, [this] { resetToInit(); });
    zoomOutButton = std::make_unique<HardwareActionButton> ("ui_zoom_out", "-", C::active, [this] { setUiScale (uiScale - 0.10f); });
    zoomResetButton = std::make_unique<HardwareActionButton> ("ui_zoom_reset", "100%", C::active, [this] { setUiScale (1.0f); });
    zoomInButton = std::make_unique<HardwareActionButton> ("ui_zoom_in", "+", C::active, [this] { setUiScale (uiScale + 0.10f); });

    for (auto* c : { powerButton.get(), undoButton.get(), redoButton.get(), initButton.get(), zoomOutButton.get(), zoomResetButton.get(), zoomInButton.get() })
        designSurface.addAndMakeVisible (*c);

    for (size_t i = 0; i < ratioTabs.size(); ++i)
    {
        ratioTabs[i] = std::make_unique<HardwareActionButton> (
            juce::String ("ui_ratio_") + juce::String ((int) i), ratioLabels[i], C::active,
            [this, i] { setParameterActual ("compRatio", ratioValues[i]); },
            [this, i] { return std::abs (parameterActual ("compRatio") - ratioValues[i]) < 0.05f; });
        designSurface.addAndMakeVisible (*ratioTabs[i]);
    }

    // Zoom is explicit and deterministic (50%..150%).  Do not expose a free
    // bottom-right resizer: arbitrary host drag-resizing was another route to
    // fractional layout states and made the hardware panel look unstable.
    setResizable (false, false);
    uiScale = 0.75f;
    setSize (juce::roundToInt ((float) designWidth * uiScale),
             juce::roundToInt ((float) designHeight * uiScale));
    rebuildStaticLayer();
    startTimerHz (60);
}

ConsoleChannelStripXAudioProcessorEditor::~ConsoleChannelStripXAudioProcessorEditor() { stopTimer(); }

void ConsoleChannelStripXAudioProcessorEditor::createControlsFromLayout()
{
    for (const auto& s : knobSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareKnob> (s, p);
            c->setValueReporter ([this] (const juce::String& id, const juce::String& value) { showParameterValue (id, value); });
            designSurface.addAndMakeVisible (*c); knobs.emplace (s.paramId, std::move (c));
        }
    }
    for (const auto& s : faderSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareFader> (s, p);
            c->setValueReporter ([this] (const juce::String& id, const juce::String& value) { showParameterValue (id, value); });
            designSurface.addAndMakeVisible (*c); faders.emplace (s.paramId, std::move (c));
        }
    }
    for (const auto& s : buttonSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareToggle> (s, p); designSurface.addAndMakeVisible (*c); toggles.emplace (s.paramId, std::move (c));
        }
    }
    // Compressor detector controls live together in the compressor block.
    const ButtonSpec compPeak { "compPeak", "PEAK", 660, 555, 92, 30, ConsoleButtonStyle::Square, 0xffb02a26, true };
    if (auto* p = audioProcessor.parameters().getParameter (compPeak.paramId))
    {
        auto c = std::make_unique<HardwareToggle> (compPeak, p); designSurface.addAndMakeVisible (*c); toggles.emplace (compPeak.paramId, std::move (c));
    }

    const ButtonSpec compFast { "compFast", "FAST ATTACK", 790, 555, 112, 30, ConsoleButtonStyle::Square, 0xffd98222, true };
    if (auto* p = audioProcessor.parameters().getParameter (compFast.paramId))
    {
        auto c = std::make_unique<HardwareToggle> (compFast, p); designSurface.addAndMakeVisible (*c); toggles.emplace (compFast.paramId, std::move (c));
    }
    for (const auto& s : choiceSpecs)
    {
        if (auto* p = audioProcessor.parameters().getParameter (s.paramId))
        {
            auto c = std::make_unique<HardwareChoice> (s, p); designSurface.addAndMakeVisible (*c); choices.emplace (s.paramId, std::move (c));
        }
    }
}

void ConsoleChannelStripXAudioProcessorEditor::setParameterActual (const char* id, float actual)
{
    if (auto* p = audioProcessor.parameters().getParameter (id))
    {
        p->beginChangeGesture(); p->setValueNotifyingHost (p->convertTo0to1 (actual)); p->endChangeGesture();
    }
}
float ConsoleChannelStripXAudioProcessorEditor::parameterActual (const char* id) const
{
    if (auto* p = audioProcessor.parameters().getParameter (id)) return p->convertFrom0to1 (p->getValue());
    return 0.0f;
}

void ConsoleChannelStripXAudioProcessorEditor::showParameterValue (const juce::String& id, const juce::String& value)
{
    activeParameterName = friendlyParameterName (id);
    activeParameterValue = value;
    repaint();
}

juce::String ConsoleChannelStripXAudioProcessorEditor::formatValue (double v, ConsoleValueStyle style) { return formatConsoleValue (v, style); }

void ConsoleChannelStripXAudioProcessorEditor::drawScrew (juce::Graphics& g, float x, float y, float angle)
{
    auto r = juce::Rectangle<float> (x - 6.5f, y - 6.5f, 13.0f, 13.0f);
    g.setColour (juce::Colour (0xff202427)); g.fillEllipse (r);
    g.setColour (juce::Colour (0xff45494d)); g.drawEllipse (r, 1.0f);
    const float d = 4.0f; const float dx = std::cos (angle) * d, dy = std::sin (angle) * d;
    g.setColour (juce::Colour (0xff34383c));
    g.drawLine (x - dx, y - dy, x + dx, y + dy, 1.4f);
    g.drawLine (x + dy, y - dx, x - dy, y + dx, 1.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawPanel (juce::Graphics& g, const SectionSpec& s)
{
    auto r = juce::Rectangle<float> ((float) s.x, (float) s.y, (float) s.w, (float) s.h);
    juce::ColourGradient grad (C::panelA, r.getX(), r.getY(), C::panelB, r.getX(), r.getBottom(), false);
    g.setGradientFill (grad); g.fillRoundedRectangle (r, 5.0f);
    g.setColour (C::border); g.drawRoundedRectangle (r, 5.0f, 1.0f);
    if (s.title != nullptr && *s.title != 0)
    {
        g.setColour (C::text); g.setFont (juce::Font (14.0f, juce::Font::bold));
        g.drawText (s.title, s.x + 20, s.y + 8, s.w - 40, 22, juce::Justification::centred);
    }
    if (s.hasScrews)
    {
        drawScrew (g, (float) s.x + 13, (float) s.y + 17, 0.25f);
        drawScrew (g, (float) s.x + s.w - 13, (float) s.y + 17, -0.45f);
        drawScrew (g, (float) s.x + 13, (float) s.y + s.h - 17, -0.30f);
        drawScrew (g, (float) s.x + s.w - 13, (float) s.y + s.h - 17, 0.65f);
    }
}

void ConsoleChannelStripXAudioProcessorEditor::drawLed (juce::Graphics& g, float x, float y, bool on, juce::Colour colour)
{
    if (on)
    {
        for (const auto& q : std::array<std::pair<float,float>,3> {{{ 6.0f,0.09f }, { 4.0f,0.18f }, { 2.0f,0.30f }}})
        {
            g.setColour (colour.withAlpha (q.second)); g.fillEllipse (x - 4.5f - q.first, y - 4.5f - q.first, 9.0f + 2.0f * q.first, 9.0f + 2.0f * q.first);
        }
    }
    g.setColour (on ? colour : juce::Colour (0xff1e2224)); g.fillEllipse (x - 4.5f, y - 4.5f, 9.0f, 9.0f);
    g.setColour (juce::Colour (0xff3a3e42)); g.drawEllipse (x - 4.5f, y - 4.5f, 9.0f, 9.0f, 1.0f);
}

void ConsoleChannelStripXAudioProcessorEditor::drawBandCurve (juce::Graphics& g, juce::Rectangle<float> r, bool shelf, bool high)
{
    juce::Path p;
    if (shelf)
    {
        if (high) { p.startNewSubPath (r.getX(), r.getBottom() - 3); p.cubicTo (r.getCentreX(), r.getBottom() - 3, r.getCentreX(), r.getY() + 3, r.getRight(), r.getY() + 3); }
        else      { p.startNewSubPath (r.getX(), r.getY() + 3); p.cubicTo (r.getCentreX(), r.getY() + 3, r.getCentreX(), r.getBottom() - 3, r.getRight(), r.getBottom() - 3); }
    }
    else
    {
        p.startNewSubPath (r.getX(), r.getCentreY()); p.quadraticTo (r.getCentreX(), r.getY() + 2, r.getRight(), r.getCentreY());
    }
    g.setColour (C::muted.withAlpha (0.75f)); g.strokePath (p, juce::PathStrokeType (1.2f));
}

void ConsoleChannelStripXAudioProcessorEditor::drawStereoMeter (juce::Graphics& g, juce::Rectangle<int> b,
                                                                 float leftDb, float rightDb, bool scaleOnRight,
                                                                 const juce::String& title)
{
    leftDb = juce::jlimit (-100.0f, 24.0f, leftDb);
    rightDb = juce::jlimit (-100.0f, 24.0f, rightDb);

    g.setColour (C::text); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText (title, b.getX(), b.getY(), b.getWidth(), 18, juce::Justification::centred);

    const bool overload = leftDb > 0.0f || rightDb > 0.0f;
    g.setColour (overload ? juce::Colour (0xffef3434) : C::muted);
    g.setFont (juce::Font (9.0f, overload ? juce::Font::bold : juce::Font::plain));
    g.drawText ("OVL", b.getX(), b.getY() + 20, b.getWidth(), 14, juce::Justification::centred);

    const int top = b.getY() + 44, bottom = b.getBottom() - 46;
    const int segH = 7, gap = 1, segments = juce::jmax (2, (bottom - top) / (segH + gap));
    const int colW = 12;
    const int cx = b.getCentreX();
    const int leftX = cx - 22, rightX = cx + 10;

    auto segmentDb = [segments] (int i)
    {
        // Exact linear dBFS axis: top = 0 dBFS, bottom = -60 dBFS.
        return -60.0f * (float) i / (float) (segments - 1);
    };

    for (int i = 0; i < segments; ++i)
    {
        const float thresholdDb = segmentDb (i);
        juce::Colour base = thresholdDb > -3.0f ? juce::Colour (0xffcc2222)
                           : thresholdDb > -12.0f ? juce::Colour (0xffe8c832)
                                                 : juce::Colour (0xff35a83a);
        const bool litL = leftDb >= thresholdDb;
        const bool litR = rightDb >= thresholdDb;
        const int y = top + i * (segH + gap);
        g.setColour (litL ? base : base.withAlpha (0.12f)); g.fillRect (leftX, y, colW, segH);
        g.setColour (litR ? base : base.withAlpha (0.12f)); g.fillRect (rightX, y, colW, segH);
    }

    static const std::array<int, 13> scaleDb {{ 0, -3, -6, -9, -12, -15, -18, -21, -24, -27, -30, -40, -60 }};
    g.setColour (C::muted); g.setFont (juce::Font (9.5f));
    for (const int db : scaleDb)
    {
        const float norm = (float) (-db) / 60.0f;
        const int y = juce::roundToInt ((float) top + norm * (float) (bottom - top)) - 6;
        const juce::String t = juce::String (-db);
        const int tx = scaleOnRight ? cx + 28 : b.getX();
        const int tw = scaleOnRight ? b.getRight() - tx : cx - 28 - b.getX();
        g.drawText (t, tx, y, tw, 12, scaleOnRight ? juce::Justification::centredLeft : juce::Justification::centredRight);
    }

    // Numeric sample-peak values are the exact dBFS values delivered by the DSP
    // block measurement, not values inferred back from LED positions.
    g.setColour (C::text.withAlpha (0.94f));
    g.setFont (juce::Font (9.2f, juce::Font::bold));
    const auto fmt = [] (float db)
    {
        return db <= -99.0f ? juce::String ("-INF") : juce::String (db, 2);
    };
    g.drawFittedText ("L " + fmt (leftDb) + "  R " + fmt (rightDb) + " dBFS",
                      b.getX() + 2, b.getBottom() - 38, b.getWidth() - 4, 16,
                      juce::Justification::centred, 1, 0.72f);
    g.setColour (C::muted); g.setFont (juce::Font (9.0f));
    g.drawText ("SAMPLE PEAK", b.getX(), b.getBottom() - 20, b.getWidth(), 14, juce::Justification::centred);
}

void ConsoleChannelStripXAudioProcessorEditor::drawDynamicsGrMeter (juce::Graphics& g, juce::Rectangle<int> b,
                                                                      float grDb, const juce::String& title,
                                                                      juce::Colour activeColour)
{
    grDb = juce::jlimit (0.0f, 40.0f, grDb);
    auto panel = b.toFloat();
    g.setColour (juce::Colour (0xff090b0d));
    g.fillRoundedRectangle (panel, 4.0f);
    g.setColour (activeColour.withAlpha (0.55f));
    g.drawRoundedRectangle (panel, 4.0f, 1.0f);

    g.setColour (activeColour.brighter (0.22f));
    g.setFont (juce::Font (10.0f, juce::Font::bold));
    g.drawFittedText (title, b.getX() + 3, b.getY() + 3, b.getWidth() - 6, 15,
                      juce::Justification::centred, 1, 0.76f);

    const int top = b.getY() + 23;
    const int bottom = b.getBottom() - 25;
    const int segH = 4, gap = 2;
    const int segments = juce::jmax (2, (bottom - top) / (segH + gap));
    const int barW = 13;
    const int barX = b.getX() + 30;

    // Exact GR axis: 0 dB at the top, 18 dB at the bottom. Reduction grows
    // downward, matching the SSL-style compression meter convention.
    for (int i = 0; i < segments; ++i)
    {
        const float segmentGr = 18.0f * (float) i / (float) (segments - 1);
        g.setColour (segmentGr <= grDb ? activeColour : activeColour.withAlpha (0.10f));
        g.fillRect (barX, top + i * (segH + gap), barW, segH);
    }

    static const std::array<int, 7> grScale {{ 0, 2, 4, 6, 10, 14, 18 }};
    g.setColour (C::muted); g.setFont (juce::Font (7.8f));
    for (const int db : grScale)
    {
        const int y = juce::roundToInt ((float) top + ((float) db / 18.0f) * (float) (bottom - top)) - 5;
        g.drawText (juce::String (db), b.getX() + 3, y, 23, 10, juce::Justification::centredRight);
    }

    g.setColour (C::text.withAlpha (0.95f));
    g.setFont (juce::Font (8.8f, juce::Font::bold));
    g.drawFittedText (juce::String (grDb, 2) + " dB",
                      b.getX() + 2, b.getBottom() - 20, b.getWidth() - 4, 15,
                      juce::Justification::centred, 1, 0.78f);
}

void ConsoleChannelStripXAudioProcessorEditor::paintStaticDesign (juce::Graphics& g)
{
    g.fillAll (C::bg);
    g.setColour (C::top); g.fillRect (0, 0, designWidth, 54); g.fillRect (0, 970, designWidth, 54);
    g.setColour (C::border); g.drawHorizontalLine (53, 0.0f, (float) designWidth); g.drawHorizontalLine (969, 0.0f, (float) designWidth);

    g.setColour (C::text); g.setFont (juce::Font (17.0f, juce::Font::bold));
    g.drawText ("Console Channel Strip X", 18, 13, 300, 28, juce::Justification::centredLeft);
    // Large live parameter readout: remains legible even when the editor is at 75% zoom.
    auto liveBox = juce::Rectangle<float> (885.0f, 8.0f, 350.0f, 38.0f);
    g.setColour (juce::Colour (0xff07090b)); g.fillRoundedRectangle (liveBox, 4.0f);
    g.setColour (C::active.withAlpha (0.70f)); g.drawRoundedRectangle (liveBox, 4.0f, 1.0f);

    g.setColour (C::muted); g.setFont (juce::Font (10.5f));
    g.drawText ("ZOOM", 1270, 18, 44, 18, juce::Justification::centredRight);

    for (const auto& s : sectionSpecs) drawPanel (g, s);

    // EQ labels and simple filter-shape glyphs.
    const std::array<std::tuple<const char*, int, int, juce::Colour, bool, bool>, 4> bands {{
        { "HF", 220, 145, C::red, true, true }, { "HMF", 220, 305, C::orange, false, true },
        { "LMF",220, 465, C::green, false, true }, { "LF", 220, 625, C::blue, true, false }
    }};
    for (const auto& b : bands)
    {
        g.setColour (std::get<3> (b).brighter (0.12f)); g.setFont (juce::Font (13.0f, juce::Font::bold));
        g.drawText (std::get<0> (b), std::get<1> (b), std::get<2> (b), 40, 18, juce::Justification::centredLeft);
        drawBandCurve (g, { (float) std::get<1> (b), (float) std::get<2> (b) + 20.0f, 36.0f, 16.0f }, std::get<4> (b), std::get<5> (b));
    }
    g.setColour (C::text.withAlpha (0.90f)); g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("FILTERS", 220, 760, 310, 20, juce::Justification::centred);
    g.setColour (C::border); g.drawHorizontalLine (752, 220.0f, 534.0f);

    // Dynamics headings and separators. No decorative ATTACK knobs: program dependence stays real.
    g.setColour (C::text); g.setFont (juce::Font (13.0f, juce::Font::bold));
    g.drawText ("GATE / EXPANDER", 580, 90, 320, 22, juce::Justification::centred);
    g.drawText ("COMPRESSOR", 580, 525, 320, 22, juce::Justification::centred);
    g.setColour (C::border); g.drawHorizontalLine (510, 580.0f, 902.0f);
    g.setColour (C::muted); g.setFont (juce::Font (10.0f));
    g.drawText ("NORMAL ATTACK: PROGRAM 3-30 ms", 580, 780, 322, 18, juce::Justification::centred);
    g.drawText ("AUTO MAKE-UP", 655, 812, 120, 18, juce::Justification::centredRight);
    drawLed (g, 786.0f, 821.0f, true, C::lamp);

    // Meter interior.
    auto meterInner = juce::Rectangle<float> (948.0f, 82.0f, 349.0f, 852.0f);
    g.setColour (juce::Colour (0xff0b0d0e)); g.fillRoundedRectangle (meterInner, 4.0f);
    g.setColour (juce::Colour (0xff303438)); g.drawRoundedRectangle (meterInner, 4.0f, 1.0f);

    // Output sections.
    g.setColour (C::border); g.drawHorizontalLine (690, 1340.0f, 1508.0f);
    g.setColour (C::text); g.setFont (juce::Font (12.0f, juce::Font::bold));
    g.drawText ("CHANNEL MODE", 1340, 748, 158, 22, juce::Justification::centred);
    drawLed (g, 1503.0f, 759.0f, true, C::lamp);

    // Footer branding: own name only.
    g.setColour (C::text.withAlpha (0.88f)); g.setFont (juce::Font (14.0f));
    g.drawText ("CONSOLE CHANNEL STRIP", 20, 985, 240, 24, juce::Justification::centredLeft);
    g.setColour (juce::Colour (0xffcc2222)); g.setFont (juce::Font (15.0f, juce::Font::bold));
    g.drawText ("X", 246, 985, 24, 24, juce::Justification::centredLeft);
    g.setColour (C::text.withAlpha (0.78f)); g.setFont (juce::Font (16.0f, juce::Font::bold));
    g.drawText ("OPENWORKSTATION X", 570, 985, 400, 24, juce::Justification::centred);
    g.setColour (C::muted); g.setFont (juce::Font (11.0f));
    g.drawText ("v0.4.1 WIEN RC", 1320, 985, 188, 24, juce::Justification::centredRight);
}

void ConsoleChannelStripXAudioProcessorEditor::paintDynamicDesign (juce::Graphics& g)
{
    g.setColour (C::muted); g.setFont (juce::Font (9.5f, juce::Font::bold));
    g.drawFittedText (activeParameterName, 896, 11, 154, 14, juce::Justification::centredLeft, 1, 0.85f);
    g.setColour (juce::Colours::white); g.setFont (juce::Font (15.0f, juce::Font::bold));
    g.drawFittedText (activeParameterValue, 1048, 10, 176, 25, juce::Justification::centredRight, 1, 0.82f);

    // Level meters remain in the central meter bay.  Dynamics reduction is no
    // longer combined here; each reduction meter lives with the circuit it represents.
    drawStereoMeter (g, { 970, 105, 130, 790 }, inputPeakDisplayL, inputPeakDisplayR, false, "INPUT");
    drawStereoMeter (g, { 1145,105, 130, 790 }, outputPeakDisplayL, outputPeakDisplayR, true, "OUTPUT");

    // Gate / expander reduction belongs to the upper dynamics block.
    drawDynamicsGrMeter (g, { 817, 370, 84, 124 }, gateGrDisplayDb, "GATE GR", C::green);

    // Compressor reduction belongs to the lower dynamics block.
    drawDynamicsGrMeter (g, { 817, 766, 84, 88 }, compGrDisplayDb, "COMP GR", C::blue);
}

void ConsoleChannelStripXAudioProcessorEditor::rebuildStaticLayer()
{
    staticLayer = juce::Image (juce::Image::RGB, designWidth, designHeight, true);
    juce::Graphics gg (staticLayer); paintStaticDesign (gg);
}

void ConsoleChannelStripXAudioProcessorEditor::paint (juce::Graphics& g)
{
    if (staticLayer.isNull()) rebuildStaticLayer();

    g.fillAll (C::bg);
    const float s = juce::jmin ((float) getWidth() / (float) designWidth,
                                (float) getHeight() / (float) designHeight);
    juce::Graphics::ScopedSaveState save (g);
    g.addTransform (juce::AffineTransform::scale (s));
    g.drawImageAt (staticLayer, 0, 0);
    paintDynamicDesign (g);
}

void ConsoleChannelStripXAudioProcessorEditor::placeDesignBounds (juce::Component& c, int x, int y, int w, int h)
{
    // Child controls never receive their own scale transform.  They stay permanently
    // in 1536x1024 design coordinates; the single parent designSurface is transformed
    // in resized().  This is the key invariant that keeps every knob aligned.
    c.setTransform (juce::AffineTransform());
    c.setBounds (x, y, w, h);
}

void ConsoleChannelStripXAudioProcessorEditor::resized()
{
    // IMPORTANT: never derive uiScale back from the integer window size here.
    // setSize() necessarily rounds designWidth*uiScale/designHeight*uiScale to
    // whole pixels. Feeding that rounded result back into uiScale caused a small
    // loss on every zoom step (1.10 -> 1.0996 -> ... -> ~1.498), so five +10%
    // steps no longer reached the exact 150% size. uiScale is authoritative and
    // is changed only by setUiScale().
    const float surfaceScale = juce::jlimit (0.50f, 1.50f,
                                             juce::jmin ((float) getWidth() / (float) designWidth,
                                                         (float) getHeight() / (float) designHeight));

    designSurface.setTransform (juce::AffineTransform());
    designSurface.setBounds (0, 0, designWidth, designHeight);
    designSurface.setTransform (juce::AffineTransform::scale (surfaceScale));

    for (const auto& spec : knobSpecs)
        if (auto it = knobs.find (spec.paramId); it != knobs.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    for (const auto& spec : faderSpecs)
        if (auto it = faders.find (spec.paramId); it != faders.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    for (const auto& spec : buttonSpecs)
        if (auto it = toggles.find (spec.paramId); it != toggles.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);
    if (auto it = toggles.find ("compPeak"); it != toggles.end())
        placeDesignBounds (*it->second, 660, 555, 92, 30);
    if (auto it = toggles.find ("compFast"); it != toggles.end())
        placeDesignBounds (*it->second, 790, 555, 112, 30);
    for (const auto& spec : choiceSpecs)
        if (auto it = choices.find (spec.paramId); it != choices.end())
            placeDesignBounds (*it->second, spec.x, spec.y, spec.w, spec.h);

    placeDesignBounds (*powerButton, 330, 10, 64, 34);
    placeDesignBounds (*undoButton, 405, 10, 62, 34);
    placeDesignBounds (*redoButton, 475, 10, 62, 34);
    placeDesignBounds (*initButton, 555, 10, 310, 34);
    placeDesignBounds (*zoomOutButton, 1320, 10, 38, 34);
    placeDesignBounds (*zoomResetButton, 1364, 10, 72, 34);
    placeDesignBounds (*zoomInButton, 1442, 10, 38, 34);
    for (size_t i = 0; i < ratioTabs.size(); ++i)
    {
        const auto r = ratioTabRects[i]; placeDesignBounds (*ratioTabs[i], r.getX(), r.getY(), r.getWidth(), r.getHeight());
    }
}

void ConsoleChannelStripXAudioProcessorEditor::setUiScale (float newScale)
{
    newScale = juce::jlimit (0.50f, 1.50f, newScale);
    uiScale = newScale;
    setSize (juce::roundToInt ((float) designWidth * uiScale), juce::roundToInt ((float) designHeight * uiScale));
}

void ConsoleChannelStripXAudioProcessorEditor::resetToInit() { audioProcessor.resetParametersToDefaults(); repaint(); }

void ConsoleChannelStripXAudioProcessorEditor::timerCallback()
{
    // Meter displays use the actual DSP measurements. No extra GUI ballistics or
    // smoothing is applied, so the number shown is not cosmetically delayed.
    compGrDisplayDb = juce::jlimit (0.0f, 40.0f, audioProcessor.compressorMeter());
    gateGrDisplayDb = juce::jlimit (0.0f, 40.0f, audioProcessor.gateMeter());

    // Consume the maximum sample peak seen since the previous GUI tick. The DSP
    // accumulates these atomically across all intervening audio blocks, preventing
    // a one-block transient from being missed by the slower GUI refresh.
    const float inL = audioProcessor.inputMeterL();
    const float inR = audioProcessor.inputMeterR();
    const float outL = audioProcessor.outputMeterL();
    const float outR = audioProcessor.outputMeterR();
    if (inL > -99.9f) inputPeakDisplayL = inL;
    if (inR > -99.9f) inputPeakDisplayR = inR;
    if (outL > -99.9f) outputPeakDisplayL = outL;
    if (outR > -99.9f) outputPeakDisplayR = outR;

    for (auto& kv : knobs) kv.second->repaint();
    for (auto& kv : faders) kv.second->repaint();
    for (auto& kv : toggles) kv.second->repaint();
    for (auto& kv : choices) kv.second->repaint();
    for (auto& b : ratioTabs) if (b) b->repaint();
    if (powerButton) powerButton->repaint();
    repaint();
}
