#pragma once

#include <algorithm>
#include <cmath>

namespace ssleq
{
    constexpr double pi = 3.1415926535897932384626433832795;

    enum class Revision { brown02, black242 };
    enum class Band { lf, lmf, hmf, hf };

    // Frequency-setting parts are taken from the published SSL drawings
    // T82002-71 (82E02) and T82242-70 (82E242).
    //
    // Fields that no code reads are NOT stored here.  A value nobody reads is a
    // promise, not documentation, so the remaining drawing detail lives in the
    // provenance string and in the comments in the .cpp.
    struct SchematicBand
    {
        Revision revision;
        Band band;

        double rSeriesOhm;
        double frequencyPotOhm;
        double timingCapFarads;

        // NETWORK Q of the LF/HF bell switch, i.e. the damping the components
        // impose.  It is NOT an effective/half-gain Q: on a real circuit the
        // component damping is fixed and the audible bandwidth therefore widens
        // as boost increases.  Zero for the mid bands, which are knob-controlled.
        double fixedBellQ;

        // Second-order shelf damping for the LF/HF shelf path.  Above 0.7071 the
        // shelf undershoots on the far side of the corner, which is the E-series
        // shelf signature: an HF boost dips the sibilance region before it lifts
        // the air.  Zero for the mid bands, which have no shelf path.
        double shelfQ;

        double documentedMinHz;
        double documentedMaxHz;
        const char* provenance;
    };

    struct FrequencyNetwork
    {
        double requestedHz = 1000.0;
        double actualHz = 1000.0;
        double potOhm = 0.0;
        double totalR = 1.0;
    };

    struct BiquadCoefficients
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
    };

    const SchematicBand& circuit (Revision revision, Band band) noexcept;
    FrequencyNetwork tuneFrequency (const SchematicBand& c, double wantedHz) noexcept;

    // Mid bands.  The panel marking is an EFFECTIVE (half-gain bandwidth) Q.  The
    // analog prototype Q is first compensated for bilinear bandwidth warping and
    // then the network damping is scaled by sqrt(G), keeping the marked Q true at
    // the digital sample rate wherever that bandwidth is physically representable.
    // There is no passive Q floor: the E circuit is active feedback.
    BiquadCoefficients reciprocalBell (double sampleRate,
                                       const SchematicBand& c,
                                       double wantedHz,
                                       double effectiveQ,
                                       double gainDb) noexcept;

    // LF/HF bell switch.  networkQ is used AS IS, with no sqrt(G) scaling, so the
    // bell widens with boost the way fixed components do.
    BiquadCoefficients fixedQBell (double sampleRate,
                                   const SchematicBand& c,
                                   double wantedHz,
                                   double networkQ,
                                   double gainDb) noexcept;

    // Second-order reciprocal shelves.  |H| at the marked corner is exactly half
    // the requested gain in dB; c.shelfQ sets the undershoot on the far side.
    BiquadCoefficients lowShelf (double sampleRate,
                                 const SchematicBand& c,
                                 double wantedHz,
                                 double gainDb) noexcept;

    BiquadCoefficients highShelf (double sampleRate,
                                  const SchematicBand& c,
                                  double wantedHz,
                                  double gainDb) noexcept;

    BiquadCoefficients firstOrderFromAnalog (double sampleRate,
                                             double b1, double b0,
                                             double a1, double a0,
                                             double prewarpHz) noexcept;

    BiquadCoefficients biquadFromAnalog (double sampleRate,
                                         double b2, double b1, double b0,
                                         double a2, double a1, double a0,
                                         double prewarpHz) noexcept;

    double maxPoleRadius (const BiquadCoefficients& c) noexcept;
    double responseMagnitudeDb (const BiquadCoefficients& c,
                                double sampleRate,
                                double frequencyHz) noexcept;
    bool coefficientsUsable (const BiquadCoefficients& c) noexcept;
}
