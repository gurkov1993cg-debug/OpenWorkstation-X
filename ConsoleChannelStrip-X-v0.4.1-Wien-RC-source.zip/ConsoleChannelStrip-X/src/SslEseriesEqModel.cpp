#include "SslEseriesEqModel.h"

#include <complex>

namespace ssleq
{
    namespace
    {
        // ------------------------------------------------------------------
        // Shelf damping.
        //
        // 1.2315606122497924 is the value the previous Wien shelf network
        // produced (Rq/R = 2.188022099721736 -> Q = 1/(3 - 2.188...)).  It is
        // kept EXACTLY so the shelf response is unchanged from the build whose
        // high end was chosen by ear.  At +12 dB it undershoots 1.70 dB on the
        // far side of the corner and overshoots to +13.6 dB past it.
        //
        // On the HF shelf that undershoot lands near 6 kHz and takes sibilance
        // out while the boost goes into the air band.  On the LF shelf the same
        // number puts a 1.70 dB hole at ~148 Hz, which thins body.  The two are
        // now separate fields precisely so they can be tuned apart: try the LF
        // shelf between 0.85 (dip only 0.26 dB) and 1.00 (dip 0.78 dB), and the
        // HF shelf up to 1.40 or 1.60 if a deeper de-ess is wanted.
        //
        // Sweep it by ear, then record the number AND what it does.  It is a
        // listening choice, not a drawing value.
        // ------------------------------------------------------------------
        constexpr double shelfQByEar = 1.2315606122497924;
        constexpr double lfShelfQ = shelfQByEar;   // change after listening
        constexpr double hfShelfQ = shelfQByEar;   // change after listening

        // Brown 82E02, drawing T82002-71, Rev.5 (3/84).
        //   HF  R4=4K3,  C3/C5=2n2 (+C4 220p)
        //   HMF R18=4K3, C9/C10=4n7
        //   LMF R28=4K3, C12/C13=15n
        //   LF  R42=4K3, C16/C18=33n + C17/C19=47n  (summed 80n)
        // Gain pots 25K, mid Q pots 10K dual: recorded here, not stored as
        // fields, because no equation in this file consumes them.
        constexpr SchematicBand brownLf {
            Revision::brown02, Band::lf,
            4300.0, 50000.0, 80.0e-9,
            0.60, lfShelfQ,
            30.0, 450.0,
            "82E02 T82002-71 Rev.5 - R42 4K3, LF freq 50K dual, C16/C18 33n + C17/C19 47n"
        };

        constexpr SchematicBand brownLmf {
            Revision::brown02, Band::lmf,
            4300.0, 50000.0, 15.0e-9,
            0.0, 0.0,
            200.0, 2500.0,
            "82E02 T82002-71 Rev.5 - R28 4K3, LMF freq 50K dual, C12/C13 15n, Q 10K dual"
        };

        constexpr SchematicBand brownHmf {
            Revision::brown02, Band::hmf,
            4300.0, 50000.0, 4.7e-9,
            0.0, 0.0,
            600.0, 7000.0,
            "82E02 T82002-71 Rev.5 - R18 4K3, HMF freq 50K dual, C9/C10 4n7, Q 10K dual"
        };

        constexpr SchematicBand brownHf {
            Revision::brown02, Band::hf,
            4300.0, 50000.0, 2.2e-9,
            0.60, hfShelfQ,
            1500.0, 16000.0,
            "82E02 T82002-71 Rev.5 - R4 4K3, HF freq 50K dual, C3/C5 2n2, C4 220p"
        };

        // Black 82E242, drawing T82242-70 plus the 15-Nov-1985 Rev.4 ECO.
        // The ECO documents 40..450, 160..2.2k, 600..10k and 1.5..20k, and the
        // bell Q values LF 1.7 / HF 1.0.  Those Q values are component damping,
        // so they are used as NETWORK Q by fixedQBell.
        constexpr SchematicBand blackLf {
            Revision::black242, Band::lf,
            4300.0, 50000.0, 80.0e-9,
            1.70, lfShelfQ,
            40.0, 450.0,
            "82E242 T82242-70 Rev.4 ECO - R42 4K3, C16/C18 33n + C17/C19 47n, RV4 5K"
        };

        constexpr SchematicBand blackLmf {
            Revision::black242, Band::lmf,
            3000.0, 50000.0, 22.0e-9,
            0.0, 0.0,
            160.0, 2200.0,
            "82E242 T82242-70 Rev.4 ECO - R28 3K0, LMF freq 50K dual, C12/C13 22n"
        };

        constexpr SchematicBand blackHmf {
            Revision::black242, Band::hmf,
            3000.0, 50000.0, 4.7e-9,
            0.0, 0.0,
            600.0, 10000.0,
            "82E242 T82242-70 Rev.4 ECO - R18 3K0, HMF freq 50K dual, C9/C10 4n7"
        };

        constexpr SchematicBand blackHf {
            Revision::black242, Band::hf,
            3000.0, 50000.0, 2.2e-9,
            1.00, hfShelfQ,
            1500.0, 20000.0,
            "82E242 T82242-70 Rev.4 ECO - R4 3K0, C3/C5 2n2, C4 220p, RV1 10K"
        };

        double gainAbs (double gainDb) noexcept
        {
            return std::pow (10.0, std::abs (gainDb) / 20.0);
        }

        double clampedPrewarpHz (double sampleRate, double hz) noexcept
        {
            return std::clamp (hz, 1.0, sampleRate * 0.45);
        }

        double solvedCentreHz (double sr, const SchematicBand& c, double wantedHz) noexcept
        {
            return std::clamp (tuneFrequency (c, wantedHz).actualHz, 1.0, sr * 0.45);
        }
    }

    const SchematicBand& circuit (Revision revision, Band band) noexcept
    {
        if (revision == Revision::black242)
        {
            switch (band)
            {
                case Band::lf:  return blackLf;
                case Band::lmf: return blackLmf;
                case Band::hmf: return blackHmf;
                case Band::hf:  return blackHf;
            }
        }

        switch (band)
        {
            case Band::lf:  return brownLf;
            case Band::lmf: return brownLmf;
            case Band::hmf: return brownHmf;
            case Band::hf:  return brownHf;
        }
        return brownLmf;
    }

    FrequencyNetwork tuneFrequency (const SchematicBand& c, double wantedHz) noexcept
    {
        const double safeHz = std::max (1.0, wantedHz);
        const double requiredTotalR = 1.0 / (2.0 * pi * safeHz * c.timingCapFarads);
        const double pot = std::clamp (requiredTotalR - c.rSeriesOhm,
                                       0.0, c.frequencyPotOhm);
        const double totalR = c.rSeriesOhm + pot;
        const double actualHz = 1.0 / (2.0 * pi * totalR * c.timingCapFarads);
        return { wantedHz, actualHz, pot, totalR };
    }

    BiquadCoefficients firstOrderFromAnalog (double sr,
                                             double b1, double b0,
                                             double a1, double a0,
                                             double prewarpHz) noexcept
    {
        prewarpHz = clampedPrewarpHz (sr, prewarpHz);
        const double k = (2.0 * pi * prewarpHz) / std::tan (pi * prewarpHz / sr);
        const double B0 = b1*k + b0;
        const double B1 = b0 - b1*k;
        const double A0 = a1*k + a0;
        const double A1 = a0 - a1*k;
        if (! std::isfinite (A0) || std::abs (A0) < 1.0e-30)
            return {};
        return { B0/A0, B1/A0, 0.0, A1/A0, 0.0 };
    }

    BiquadCoefficients biquadFromAnalog (double sr,
                                         double b2, double b1, double b0,
                                         double a2, double a1, double a0,
                                         double prewarpHz) noexcept
    {
        prewarpHz = clampedPrewarpHz (sr, prewarpHz);
        const double K = 2.0 * sr * std::tan (pi * prewarpHz / sr)
                         / (2.0 * pi * prewarpHz);
        const double k = 2.0 * sr / K;
        const double B0 = b2*k*k + b1*k + b0;
        const double B1 = 2.0*(b0 - b2*k*k);
        const double B2 = b2*k*k - b1*k + b0;
        const double A0 = a2*k*k + a1*k + a0;
        const double A1 = 2.0*(a0 - a2*k*k);
        const double A2 = a2*k*k - a1*k + a0;
        if (! std::isfinite (A0) || std::abs (A0) < 1.0e-30)
            return {};
        return { B0/A0, B1/A0, B2/A0, A1/A0, A2/A0 };
    }

    namespace
    {
        BiquadCoefficients bellFromNetworkQ (double sr, double f,
                                             double networkQ, double gainDb) noexcept
        {
            const double w = 2.0 * pi * f;
            const double G = gainAbs (gainDb);
            const double q = std::max (0.05, networkQ);

            if (gainDb >= 0.0)
                return biquadFromAnalog (sr, 1.0, G*w/q, w*w,
                                         1.0, w/q, w*w, f);
            return biquadFromAnalog (sr, 1.0, w/q, w*w,
                                     1.0, G*w/q, w*w, f);
        }
    }

    BiquadCoefficients reciprocalBell (double sr,
                                       const SchematicBand& c,
                                       double wantedHz,
                                       double effectiveQ,
                                       double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        // Half-gain bandwidth of this reciprocal transfer gives
        // Qeff = Qnetwork / sqrt(G), so the marked knob value stays true at any
        // boost.  No passive Q floor: the E circuit is active feedback, and the
        // bottom of the Q control must actually reach a wide, gentle bell.
        const double qEff = std::clamp (effectiveQ, 0.05, 8.0);
        const double qNetwork = std::max (0.05, qEff * std::sqrt (gainAbs (gainDb)));

        return bellFromNetworkQ (sr, solvedCentreHz (sr, c, wantedHz), qNetwork, gainDb);
    }

    BiquadCoefficients fixedQBell (double sr,
                                   const SchematicBand& c,
                                   double wantedHz,
                                   double networkQ,
                                   double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        // Deliberately NOT scaled by sqrt(G).  The LF/HF bell damping is set by
        // components, so the audible bandwidth widens as boost increases.  This
        // is the analog behaviour; scaling here would give constant-Q, which is
        // what makes large digital LF boosts sound narrow and honky.
        return bellFromNetworkQ (sr, solvedCentreHz (sr, c, wantedHz),
                                 std::clamp (networkQ, 0.05, 8.0), gainDb);
    }

    BiquadCoefficients lowShelf (double sr,
                                 const SchematicBand& c,
                                 double wantedHz,
                                 double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        const double f = solvedCentreHz (sr, c, wantedHz);
        const double w = 2.0 * pi * f;
        const double G = gainAbs (gainDb);
        const double A = std::sqrt (G);
        const double rootA = std::sqrt (A);
        const double Q = std::max (0.05, c.shelfQ);

        // Second-order reciprocal shelf.  Boost: DC = G, HF = 1, |H(fc)| = sqrt(G).
        // Both numerator and denominator carry a real s^2 term, so there is no
        // pole/zero cancellation at z = -1.  Cut is the exact reciprocal.
        const double nb2 = 1.0;
        const double nb1 = rootA*w/Q;
        const double nb0 = A*w*w;
        const double da2 = A;
        const double da1 = rootA*w/Q;
        const double da0 = w*w;

        if (gainDb >= 0.0)
            return biquadFromAnalog (sr, A*nb2, A*nb1, A*nb0, da2, da1, da0, f);
        return biquadFromAnalog (sr, da2, da1, da0, A*nb2, A*nb1, A*nb0, f);
    }

    BiquadCoefficients highShelf (double sr,
                                  const SchematicBand& c,
                                  double wantedHz,
                                  double gainDb) noexcept
    {
        if (std::abs (gainDb) < 1.0e-12)
            return {};

        const double f = solvedCentreHz (sr, c, wantedHz);
        const double w = 2.0 * pi * f;
        const double G = gainAbs (gainDb);
        const double A = std::sqrt (G);
        const double rootA = std::sqrt (A);
        const double Q = std::max (0.05, c.shelfQ);

        // Frequency-inverted counterpart of lowShelf: LF = 1, HF = G.
        const double nb2 = A;
        const double nb1 = rootA*w/Q;
        const double nb0 = w*w;
        const double da2 = 1.0;
        const double da1 = rootA*w/Q;
        const double da0 = A*w*w;

        if (gainDb >= 0.0)
            return biquadFromAnalog (sr, A*nb2, A*nb1, A*nb0, da2, da1, da0, f);
        return biquadFromAnalog (sr, da2, da1, da0, A*nb2, A*nb1, A*nb0, f);
    }

    double maxPoleRadius (const BiquadCoefficients& c) noexcept
    {
        using C = std::complex<double>;
        const C disc = C (c.a1*c.a1 - 4.0*c.a2, 0.0);
        const C root = std::sqrt (disc);
        const C p1 = (-c.a1 + root) * 0.5;
        const C p2 = (-c.a1 - root) * 0.5;
        return std::max (std::abs (p1), std::abs (p2));
    }

    double responseMagnitudeDb (const BiquadCoefficients& c,
                                double sampleRate,
                                double frequencyHz) noexcept
    {
        using C = std::complex<double>;
        const double omega = 2.0*pi*frequencyHz/sampleRate;
        const C z1 = std::exp (C (0.0, -omega));
        const C z2 = z1*z1;
        const C num = c.b0 + c.b1*z1 + c.b2*z2;
        const C den = 1.0 + c.a1*z1 + c.a2*z2;
        return 20.0*std::log10 (std::max (1.0e-15, std::abs (num/den)));
    }

    bool coefficientsUsable (const BiquadCoefficients& c) noexcept
    {
        const bool finite = std::isfinite (c.b0) && std::isfinite (c.b1)
                         && std::isfinite (c.b2) && std::isfinite (c.a1)
                         && std::isfinite (c.a2);
        if (! finite)
            return false;
        const double radius = maxPoleRadius (c);
        return std::isfinite (radius) && radius < 0.9999999;
    }
}
