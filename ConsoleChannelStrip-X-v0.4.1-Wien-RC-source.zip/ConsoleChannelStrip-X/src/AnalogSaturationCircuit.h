#pragma once

#include <vector>

// Pure C++ saturation circuit.  No JUCE DSP processor is used here.
//
// The nonlinear core is an emitter-degenerated bipolar differential pair.
// For each sample we solve the physical implicit transfer
//
//   v = 2*n*Vt*atanh(m) + 2*Re*Itail*m
//
// for m = Idiff / Itail with Newton iterations.  The emitter-degeneration term
// keeps the centre linear while the finite tail current creates progressive,
// analogue-style compression as the pair runs out of current steering range.
// A small device mismatch creates controlled even harmonics.  Only the generated
// nonlinear residual is bandwidth-limited, so the clean programme path keeps its
// full high-frequency response.  A DC servo removes the tiny offset caused by the
// deliberate mismatch.
class AnalogSaturationCircuit
{
public:
    void prepare (double sampleRate, int numChannels);
    void reset() noexcept;

    // amount is 0..1.  amount == 0 is a mathematically exact bypass after reset.
    float processSample (float input, int channel, float amount) noexcept;

private:
    struct ChannelState
    {
        double smoothedAmount = 0.0;
        double residualIntegrator = 0.0;
        double dcEstimate = 0.0;
        double previousPairState = 0.0;
    };

    static double solveDifferentialPair (double differentialVoltage,
                                         double thermalTerm,
                                         double emitterDegenerationTerm,
                                         double initial) noexcept;
    static double fastDbToGain (double db) noexcept;
    static double clampUnit (double x) noexcept;

    double sr = 48000.0;
    double amountAlpha = 1.0;
    std::vector<ChannelState> states;
};
