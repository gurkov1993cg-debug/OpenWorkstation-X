#pragma once

#include <array>
#include <vector>

// Pure project-owned saturation DSP. No JUCE DSP processor/design utility is used.
//
// The nonlinear core is the existing emitter-degenerated bipolar differential-pair
// model. Version 3 keeps that transfer and the original base-rate residual/DC
// filtering, but evaluates the static nonlinearity at 4x. A symmetric 193-tap
// equiripple FIR is used in project-owned polyphase interpolation and decimation.
// Only the nonlinear residual is decimated; the programme path is delayed by the
// exact linear-phase group delay so residual and dry remain phase-coherent.
//
// Two 193-tap FIRs contribute 24 base samples each, therefore this block has a
// fixed 48-sample latency. DspEngine aligns its dry/reference path to the same
// delay and PluginProcessor reports it to the host.
class AnalogSaturationCircuit
{
public:
    void prepare (double sampleRate, int numChannels);
    void reset() noexcept;

    float processSample (float input, int channel, float amount) noexcept;
    static constexpr int latencySamples() noexcept { return totalLatencySamples; }

private:
    static constexpr int oversampleFactor = 4;
    static constexpr int firTaps = 193;
    static constexpr int interpolationLatencySamples = (firTaps - 1) / (2 * oversampleFactor);
    static constexpr int decimationLatencySamples = interpolationLatencySamples;
    static constexpr int totalLatencySamples = interpolationLatencySamples + decimationLatencySamples;
    static constexpr int inputHistorySamples = (firTaps + oversampleFactor - 1) / oversampleFactor + 2;

    struct ChannelState
    {
        double smoothedAmount = 0.0;
        std::array<double, interpolationLatencySamples + 1> amountDelay {};
        int amountWriteIndex = 0;
        bool antiAliasActive = false;

        double residualIntegrator = 0.0;
        double dcEstimate = 0.0;
        double previousPairState = 0.0;

        std::array<double, inputHistorySamples> inputHistory {};
        int inputWriteIndex = 0;

        std::array<double, firTaps> residualHistory {};
        int residualWriteIndex = 0;

        std::array<double, totalLatencySamples + 1> dryDelay {};
        int dryWriteIndex = 0;
    };

    static double solveDifferentialPair (double differentialVoltage,
                                         double thermalTerm,
                                         double emitterDegenerationTerm,
                                         double initial) noexcept;
    static double fastDbToGain (double db) noexcept;
    static double clampUnit (double x) noexcept;
    static double nonlinearResidual (double input,
                                     double amount,
                                     ChannelState& state) noexcept;
    static double delayAmount (double amount, ChannelState& state) noexcept;
    static double interpolatePhase (const ChannelState& state, int phase) noexcept;
    static double decimateResidual (ChannelState& state) noexcept;
    static double delayDry (double input, ChannelState& state) noexcept;

    double sr = 48000.0;
    double amountAlpha = 1.0;
    std::vector<ChannelState> states;
};
