#include "DspEngine.h"
#include "WienEqModel.h"
#include <algorithm>
#include <cmath>

namespace
{
    inline float dbToGain (float db) { return juce::Decibels::decibelsToGain (db); }

    void runFilter (DspEngine::IIR& filter, juce::AudioBuffer<float>& buffer)
    {
        juce::dsp::AudioBlock<float> block (buffer);
        juce::dsp::ProcessContextReplacing<float> context (block);
        filter.process (context);
    }

    DspEngine::CoeffPtr toJuce (const wieneq::BiquadCoefficients& c)
    {
        return new DspEngine::Coefficients ((float) c.b0, (float) c.b1, (float) c.b2,
                                            1.0f, (float) c.a1, (float) c.a2);
    }
}

void DspEngine::prepare (double sampleRate, int maximumBlockSize, int numChannels)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate,
                                  static_cast<juce::uint32> (juce::jmax (1, maximumBlockSize)),
                                  static_cast<juce::uint32> (juce::jmax (1, numChannels)) };

    hp1.prepare (spec); hp2.prepare (spec); lp.prepare (spec);
    lf.prepare (spec); lmf.prepare (spec); hmf.prepare (spec); hf.prepare (spec);

    globalDryBuffer.setSize (juce::jmax (1, numChannels), juce::jmax (1, maximumBlockSize), false, false, true);
    const int stereoDelaySamples = juce::jmax (16, (int) std::ceil (sampleRate * 0.080) + 8);
    stereoDelayLine.assign ((size_t) stereoDelaySamples, 0.0f);

    inputTrimGain.reset (sr, 0.020);
    inputDriveGain.reset (sr, 0.020);
    panLeftGain.reset (sr, 0.020);
    panRightGain.reset (sr, 0.020);
    vcaGain.reset (sr, 0.020);
    outputTrimGain.reset (sr, 0.020);
    mixSmoother.reset (sr, 0.020);
    vcaSaturationSmoother.reset (sr, 0.020);
    dynamicsCircuit.prepare (sr);
    saturationCircuit.prepare (sr, juce::jmax (1, numChannels));

    reset();
}

void DspEngine::reset()
{
    hp1.reset(); hp2.reset(); lp.reset();
    lf.reset(); lmf.reset(); hmf.reset(); hf.reset();

    dynamicsCircuit.reset();
    saturationCircuit.reset();

    inputTrimGain.setCurrentAndTargetValue (1.0f);
    inputDriveGain.setCurrentAndTargetValue (1.0f);
    panLeftGain.setCurrentAndTargetValue (1.0f);
    panRightGain.setCurrentAndTargetValue (1.0f);
    vcaGain.setCurrentAndTargetValue (1.0f);
    outputTrimGain.setCurrentAndTargetValue (1.0f);
    mixSmoother.setCurrentAndTargetValue (1.0f);
    vcaSaturationSmoother.setCurrentAndTargetValue (0.0f);

    autoInputPower = 0.0;
    autoOutputPower = 0.0;
    autoMatchGainDb = 0.0f;
    autoMatchAppliedGain = 1.0f;

    std::fill (stereoDelayLine.begin(), stereoDelayLine.end(), 0.0f);
    stereoDelayWriteIndex = 0;
    stereoLfoPhaseL = 0.0;
    stereoLfoPhaseR = juce::MathConstants<double>::pi;
    stereoFocusLowState = 0.0f;

    compMeterDb.store (0.0f);
    gateMeterDb.store (0.0f);
    inputPeakDb.store (-100.0f);
    outputPeakDb.store (-100.0f);
    inputLeftPeakDb.store (-100.0f);
    inputRightPeakDb.store (-100.0f);
    outputLeftPeakDb.store (-100.0f);
    outputRightPeakDb.store (-100.0f);
    inputLeftPeakHeldDb.store (-100.0f);
    inputRightPeakHeldDb.store (-100.0f);
    outputLeftPeakHeldDb.store (-100.0f);
    outputRightPeakHeldDb.store (-100.0f);

    filterCacheValid = false;
    filterStatesInitialised = false;
    gainSmoothersInitialised = false;
    hp1Target = nullptr; hp2Target = nullptr; lpTarget = nullptr;
    lfTarget = nullptr; lmfTarget = nullptr; hmfTarget = nullptr; hfTarget = nullptr;
}

float DspEngine::transformerSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Deliberately audible console-input nonlinearity. DRIVE itself is applied as
    // real pre-gain before this function; this stage then adds asymmetric soft
    // saturation instead of cancelling that gain back out. At 0 dB LINE mode the
    // whole input stage remains mathematically clean.
    const float hardness = 1.0f + 1.9f * a;
    const float bias = 0.010f + 0.026f * a;
    const float positive = std::tanh (hardness * (x + bias));
    const float negative = std::tanh ((hardness * (0.92f + 0.18f * a)) * (x - bias * 0.55f));
    const float asymmetric = 0.54f * positive + 0.46f * negative;

    // Keep the centre close to zero while preserving the asymmetry that produces
    // even harmonics. The dry blend is only a safety rail at low drive.
    const float dc = 0.54f * std::tanh (hardness * bias)
                   + 0.46f * std::tanh (-(hardness * (0.92f + 0.18f * a)) * bias * 0.55f);
    const float shaped = asymmetric - dc;
    const float blend = 0.30f + 0.70f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::vcaSaturate (float x, float amount)
{
    const float a = juce::jlimit (0.0f, 1.0f, amount);
    if (a <= 0.0001f)
        return x;

    // Output VCA colour is separate from the input transformer model and is zero
    // at a 0 dB fader setting. It becomes progressively firmer only above unity.
    const float drive = 1.0f + 2.2f * a;
    const float shaped = std::tanh (drive * x) / drive;
    const float blend = 0.08f + 0.52f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::bufferPeakDb (const juce::AudioBuffer<float>& buffer)
{
    float peak = 0.0f;
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        peak = juce::jmax (peak, buffer.getMagnitude (ch, 0, buffer.getNumSamples()));
    return juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -100.0f);
}

float DspEngine::channelPeakDb (const juce::AudioBuffer<float>& buffer, int channel)
{
    if (buffer.getNumChannels() <= 0) return -100.0f;
    channel = juce::jlimit (0, buffer.getNumChannels() - 1, channel);
    const float peak = buffer.getMagnitude (channel, 0, buffer.getNumSamples());
    return juce::Decibels::gainToDecibels (juce::jmax (peak, 1.0e-9f), -100.0f);
}

double DspEngine::bufferMeanSquare (const juce::AudioBuffer<float>& buffer, int numSamples) noexcept
{
    const int channels = buffer.getNumChannels();
    const int samples = juce::jlimit (0, buffer.getNumSamples(), numSamples);
    if (channels <= 0 || samples <= 0)
        return 0.0;

    double sum = 0.0;
    for (int ch = 0; ch < channels; ++ch)
    {
        const float* x = buffer.getReadPointer (ch);
        for (int i = 0; i < samples; ++i)
            sum += static_cast<double> (x[i]) * static_cast<double> (x[i]);
    }
    return sum / static_cast<double> (channels * samples);
}

void DspEngine::accumulatePeak (std::atomic<float>& destination, float candidate) noexcept
{
    float previous = destination.load (std::memory_order_relaxed);
    while (candidate > previous
           && ! destination.compare_exchange_weak (previous, candidate,
                                                   std::memory_order_relaxed,
                                                   std::memory_order_relaxed))
    {
    }
}

void DspEngine::processInputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    inputTrimGain.setTargetValue (dbToGain (p.inputTrimDb));
    inputDriveGain.setTargetValue (dbToGain (juce::jlimit (-20.0f, 20.0f, p.inputDrive)));
    const float polarityGain = p.polarity ? -1.0f : 1.0f;
    const float padGain = p.inputPad ? 0.1f : 1.0f; // -20 dB

    // INPUT DRIVE is a real -20..+20 dB preamp drive. Negative settings are clean
    // attenuation, 0 dB LINE is a true clean/null point, and positive settings
    // feed progressively more level into the transformer-style stage. MIC keeps a
    // subtle baseline colour even at 0 dB.
    const float positiveDrive = juce::jmax (0.0f, p.inputDrive);
    const float modeBias = p.inputMode == 1 ? 0.12f : 0.0f;
    const float saturationAmount = juce::jlimit (0.0f, 1.0f, positiveDrive / 20.0f + modeBias);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float trim = inputTrimGain.getNextValue() * polarityGain;
        const float drive = inputDriveGain.getNextValue();

        for (int ch = 0; ch < channels; ++ch)
        {
            float v = buffer.getSample (ch, i) * trim * padGain * drive;
            if (saturationAmount > 0.0001f)
                v = transformerSaturate (v, saturationAmount);
            buffer.setSample (ch, i, v);
        }
    }
}

bool DspEngine::filterParametersChanged (const Params& p) const noexcept
{
    if (! filterCacheValid)
        return true;

    return p.hpFreq != lastFilterParams.hpFreq
        || p.lpFreq != lastFilterParams.lpFreq
        || p.blackEq != lastFilterParams.blackEq
        || p.lfBell != lastFilterParams.lfBell
        || p.lfFreq != lastFilterParams.lfFreq
        || p.lfGain != lastFilterParams.lfGain
        || p.lmfFreq != lastFilterParams.lmfFreq
        || p.lmfGain != lastFilterParams.lmfGain
        || p.lmfQ != lastFilterParams.lmfQ
        || p.hmfFreq != lastFilterParams.hmfFreq
        || p.hmfGain != lastFilterParams.hmfGain
        || p.hmfQ != lastFilterParams.hmfQ
        || p.hfBell != lastFilterParams.hfBell
        || p.hfFreq != lastFilterParams.hfFreq
        || p.hfGain != lastFilterParams.hfGain;
}

void DspEngine::setFilterTargets (const Params& p)
{
    using namespace wieneq;

    const float nyquistSafe = static_cast<float> (0.45 * sr);
    const float hpHz = juce::jlimit (16.0f, juce::jmin (350.0f, nyquistSafe), p.hpFreq);
    const float lpHz = juce::jlimit (3000.0f, nyquistSafe, p.lpFreq);

    // SSL-E EQ bands are NOT designed with JUCE makePeakFilter/makeShelf calls.
    // Frequency -> R -> Wien network -> analog coefficients -> bilinear transform.
    // The [FIT] components in WienEqModel.cpp define the available band ranges.
    const float lfGainLimit = (! p.blackEq || ! p.lfBell) ? 15.0f : 18.0f;
    const float hfGainLimit = (! p.blackEq || ! p.hfBell) ? 15.0f : 18.0f;
    const float midGainLimit = p.blackEq ? 18.0f : 15.0f;
    const float lfGain = juce::jlimit (-lfGainLimit, lfGainLimit, p.lfGain);
    const float hfGain = juce::jlimit (-hfGainLimit, hfGainLimit, p.hfGain);
    const float lmGain = juce::jlimit (-midGainLimit, midGainLimit, p.lmfGain);
    const float hmGain = juce::jlimit (-midGainLimit, midGainLimit, p.hmfGain);

    const auto& lfC = circuit (Band::lf);
    const auto& lmC = circuit (Band::lmf);
    const auto& hmC = circuit (Band::hmf);
    const auto& hfC = circuit (Band::hf);

    lfTarget = p.lfBell
        ? toJuce (reciprocalBell (sr, tuneFixedQBell (lfC, p.lfFreq, 1.0, lfGain), lfGain))
        : toJuce (lowShelf (sr, lfC, p.lfFreq, lfGain));

    lmfTarget = toJuce (reciprocalBell (sr,
        tuneBell (lmC, p.lmfFreq, p.lmfQ, lmGain), lmGain));
    hmfTarget = toJuce (reciprocalBell (sr,
        tuneBell (hmC, p.hmfFreq, p.hmfQ, hmGain), hmGain));

    hfTarget = p.hfBell
        ? toJuce (reciprocalBell (sr, tuneFixedQBell (hfC, p.hfFreq, 1.7, hfGain), hfGain))
        : toJuce (highShelf (sr, hfC, p.hfFreq, hfGain));

    // Filter section correction from the published -3 dB point behaviour:
    // Brown = one 2nd-order Butterworth-like section (~12 dB/oct).
    // Black = Q=1 second-order + first-order (~18 dB/oct), -3 dB at fc.
    hp1Target = Coefficients::makeFirstOrderHighPass (sr, hpHz);
    hp2Target = Coefficients::makeHighPass (sr, hpHz, p.blackEq ? 1.0f : 0.70710678f);
    lpTarget = Coefficients::makeLowPass (sr, lpHz, 0.70710678f);

    lastFilterParams = p;
    filterCacheValid = true;
}

void DspEngine::moveCoefficientsTowards (IIR& filter, const CoeffPtr& target, float alpha)
{
    if (target == nullptr)
        return;

    auto& current = filter.state->coefficients;
    const auto& destination = target->coefficients;
    if (current.size() != destination.size())
    {
        *filter.state = *target;
        return;
    }

    for (int i = 0; i < current.size(); ++i)
        current.set (i, current[i] + (destination[i] - current[i]) * alpha);
}

void DspEngine::smoothFilterCoefficients (int blockSamples)
{
    if (! filterStatesInitialised)
    {
        if (hp1Target != nullptr) *hp1.state = *hp1Target;
        if (hp2Target != nullptr) *hp2.state = *hp2Target;
        if (lpTarget != nullptr) *lp.state = *lpTarget;
        if (lfTarget != nullptr) *lf.state = *lfTarget;
        if (lmfTarget != nullptr) *lmf.state = *lmfTarget;
        if (hmfTarget != nullptr) *hmf.state = *hmfTarget;
        if (hfTarget != nullptr) *hf.state = *hfTarget;
        filterStatesInitialised = true;
        return;
    }

    // 20 ms coefficient glide. The exponential is computed from elapsed samples,
    // not an arbitrary per-block constant, which keeps automation behaviour close
    // across different host block sizes.
    const float alpha = 1.0f - std::exp (-static_cast<float> (juce::jmax (1, blockSamples))
                                         / static_cast<float> (0.020 * sr));
    moveCoefficientsTowards (hp1, hp1Target, alpha);
    moveCoefficientsTowards (hp2, hp2Target, alpha);
    moveCoefficientsTowards (lp, lpTarget, alpha);
    moveCoefficientsTowards (lf, lfTarget, alpha);
    moveCoefficientsTowards (lmf, lmfTarget, alpha);
    moveCoefficientsTowards (hmf, hmfTarget, alpha);
    moveCoefficientsTowards (hf, hfTarget, alpha);
}

void DspEngine::updateFilters (const Params& p, int blockSamples)
{
    if (filterParametersChanged (p))
        setFilterTargets (p);
    smoothFilterCoefficients (blockSamples);
}

void DspEngine::processFilters (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.hpOn)
    {
        runFilter (hp2, buffer);
        if (p.blackEq)
            runFilter (hp1, buffer);
    }

    if (p.lpOn)
        runFilter (lp, buffer);
}

void DspEngine::processEQ (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.eqOn)
        return;

    runFilter (lf, buffer);
    runFilter (lmf, buffer);
    runFilter (hmf, buffer);
    runFilter (hf, buffer);
}

void DspEngine::processDynamics (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.dynOn)
    {
        dynamicsCircuit.reset();
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    dynamicsCircuit.setCircuit (p.dynamicsCircuit);

    for (int i = 0; i < samples; ++i)
    {
        // One linked RMS detector path for compressor and gate/expander.
        // Summing energy rather than L+R audio prevents phase cancellation from
        // fooling the control path.
        double linkedPower = 0.0;
        double linkedPeakPower = 0.0;
        for (int ch = 0; ch < channels; ++ch)
        {
            const double x = buffer.getSample (ch, i);
            const double x2 = x * x;
            linkedPower += x2;
            linkedPeakPower = std::max (linkedPeakPower, x2);
        }
        linkedPower /= static_cast<double> (juce::jmax (1, channels));

        // Normal compressor and gate use the linked RMS energy. COMP PEAK instead
        // sees the largest instantaneous linked channel sample and switches the
        // gain computer to hard-knee operation inside SslDynamicsCircuit.
        const float dynamicsGain = dynamicsCircuit.processPowers (linkedPower, linkedPeakPower);
        for (int ch = 0; ch < channels; ++ch)
            buffer.setSample (ch, i, buffer.getSample (ch, i) * dynamicsGain);
    }

    compMeterDb.store (static_cast<float> (dynamicsCircuit.compressorReductionDb()));
    gateMeterDb.store (static_cast<float> (dynamicsCircuit.gateReductionDb()));
}

float DspEngine::readStereoDelay (float delaySamples) const noexcept
{
    const int size = (int) stereoDelayLine.size();
    if (size < 4)
        return 0.0f;

    float read = (float) stereoDelayWriteIndex - delaySamples;
    while (read < 0.0f) read += (float) size;
    while (read >= (float) size) read -= (float) size;

    const int i0 = (int) std::floor (read);
    const int i1 = (i0 + 1) % size;
    const float frac = read - (float) i0;
    return stereoDelayLine[(size_t) i0]
         + frac * (stereoDelayLine[(size_t) i1] - stereoDelayLine[(size_t) i0]);
}

void DspEngine::processStereoWidth (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (buffer.getNumChannels() != 2 || buffer.getNumSamples() <= 0 || stereoDelayLine.size() < 4)
        return;

    const float width = juce::jlimit (0.0f, 1.0f, p.stereoWidth * 0.01f);
    if (width <= 0.00001f)
        return;

    // User-facing FOCUS direction: turning the control UP must widen progressively
    // more of the spectrum; turning it DOWN must keep progressively more content
    // centred.  The signal crossover therefore moves in the opposite direction.
    // Invert in log-frequency space so the musical spacing remains natural.
    const float focusMinHz = 20.0f;
    const float focusMaxHz = juce::jmin (10000.0f, (float) (0.45 * sr));
    const float focusControlHz = juce::jlimit (focusMinHz, focusMaxHz, p.stereoFocusHz);
    const float focusHz = juce::jlimit (focusMinHz, focusMaxHz,
                                       (focusMinHz * focusMaxHz) / juce::jmax (focusMinHz, focusControlHz));
    const float lowPole = std::exp ((float) (-juce::MathConstants<double>::twoPi * focusHz / sr));
    const float baseDelaySamples = juce::jlimit (0.0f, (float) (0.025 * sr), p.stereoDelayMs * 0.001f * (float) sr);
    const float cents = juce::jlimit (0.0f, 20.0f, p.stereoDetune);

    // A sinusoidally moving delay is a continuously varying micro-pitch shifter.
    // Pick the modulation excursion from the requested cents so the peak delay
    // slope is in the same order as +/- the chosen micro-pitch offset.
    constexpr double nominalRate = 0.34;
    const double pitchSlope = std::pow (2.0, (double) cents / 1200.0) - 1.0;
    const float modDepthSamples = (float) juce::jlimit (0.0, 0.006 * sr,
        (pitchSlope / (juce::MathConstants<double>::twoPi * nominalRate)) * sr);

    constexpr double rateL = 0.31;
    constexpr double rateR = 0.37;
    const double phaseStepL = juce::MathConstants<double>::twoPi * rateL / sr;
    const double phaseStepR = juce::MathConstants<double>::twoPi * rateR / sr;
    const float maxReadable = (float) stereoDelayLine.size() - 3.0f;

    auto* left = buffer.getWritePointer (0);
    auto* right = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float dryL = left[i];
        const float dryR = right[i];
        const float mid = 0.5f * (dryL + dryR);

        stereoFocusLowState = (1.0f - lowPole) * mid + lowPole * stereoFocusLowState;
        const float high = mid - stereoFocusLowState;
        stereoDelayLine[(size_t) stereoDelayWriteIndex] = high;

        const float modL = modDepthSamples * std::sin ((float) stereoLfoPhaseL);
        const float modR = modDepthSamples * std::sin ((float) stereoLfoPhaseR);
        const float delayL = juce::jlimit (1.0f, maxReadable, 1.0f + baseDelaySamples * 0.82f + modL);
        const float delayR = juce::jlimit (1.0f, maxReadable, 1.0f + baseDelaySamples * 1.18f + modR);
        const float shiftedL = readStereoDelay (delayL);
        const float shiftedR = readStereoDelay (delayR);

        // Add only the difference component.  The dry MID remains intact, lows
        // below FOCUS stay centred, and a mono signal acquires genuine SIDE energy.
        const float generatedSide = 0.5f * (shiftedL - shiftedR);
        left[i] = dryL + generatedSide * width;
        right[i] = dryR - generatedSide * width;

        if (++stereoDelayWriteIndex >= (int) stereoDelayLine.size())
            stereoDelayWriteIndex = 0;
        stereoLfoPhaseL += phaseStepL;
        stereoLfoPhaseR += phaseStepR;
        if (stereoLfoPhaseL >= juce::MathConstants<double>::twoPi) stereoLfoPhaseL -= juce::MathConstants<double>::twoPi;
        if (stereoLfoPhaseR >= juce::MathConstants<double>::twoPi) stereoLfoPhaseR -= juce::MathConstants<double>::twoPi;
    }
}

void DspEngine::processSaturation (juce::AudioBuffer<float>& buffer, const Params& p)
{
    const float amount = juce::jlimit (0.0f, 1.0f, p.saturation * 0.01f);

    // Always clock the circuit, even at a 0% target. This lets its own 15 ms
    // analogue-control smoothing return to true bypass cleanly after automation
    // instead of leaving a stale high-drive state waiting for the next move.
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int ch = 0; ch < channels; ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        for (int i = 0; i < samples; ++i)
            data[i] = saturationCircuit.processSample (data[i], ch, amount);
    }
}

void DspEngine::processAutoLevelMatch (juce::AudioBuffer<float>& buffer,
                                           const juce::AudioBuffer<float>& reference,
                                           const Params& p)
{
    const int samples = buffer.getNumSamples();
    if (samples <= 0 || buffer.getNumChannels() <= 0)
        return;

    // 350 ms broadband RMS/energy detector.  This is deliberately slower than
    // individual audio cycles so EQ and compression are compared by programme
    // level rather than by instantaneous sample peaks.
    const double detectorTau = 0.350;
    const double detectorAlpha = 1.0 - std::exp (-static_cast<double> (samples) / (detectorTau * sr));
    const double inputBlockPower = bufferMeanSquare (reference, samples);
    const double outputBlockPower = bufferMeanSquare (buffer, samples);
    const bool gateActuallyReducing = gateMeterDb.load (std::memory_order_relaxed) > 0.50f;
    const bool inputBlockActive = inputBlockPower > 1.0e-12;

    // Do not teach the matcher from silence or from portions intentionally removed
    // by the gate. Otherwise the next open note could receive a temporary boost
    // based on the gate's attenuation, partially defeating the gate's purpose.
    if (inputBlockActive && ! gateActuallyReducing)
    {
        autoInputPower += detectorAlpha * (inputBlockPower - autoInputPower);
        autoOutputPower += detectorAlpha * (outputBlockPower - autoOutputPower);
    }

    float desiredDb = 0.0f;
    const bool inputActive = autoInputPower > 1.0e-12; // valid learned programme level

    if (p.autoLevelMatch && inputActive && autoOutputPower > 1.0e-12 && ! gateActuallyReducing)
    {
        // sqrt(Pin/Pout) in linear gain == 10*log10(Pin/Pout) in dB.
        desiredDb = static_cast<float> (10.0 * std::log10 (autoInputPower / autoOutputPower));
        desiredDb = juce::jlimit (-18.0f, 18.0f, desiredDb);
    }
    else if (p.autoLevelMatch)
    {
        // During silence or while the gate is intentionally closing, freeze the
        // last valid compensation.  This prevents the level matcher from undoing
        // the gate by trying to amplify material that the gate is meant to remove.
        desiredDb = autoMatchGainDb;
    }

    // Gain-servo ballistics: attenuation catches up faster than boost, while the
    // boost side is slower to avoid audible pumping between notes.  Turning AUTO
    // LEVEL off returns to unity smoothly rather than producing a click.
    const double gainTau = ! p.autoLevelMatch ? 0.060
                           : (desiredDb < autoMatchGainDb ? 0.180 : 0.550);
    const float gainAlpha = static_cast<float> (1.0 - std::exp (-static_cast<double> (samples) / (gainTau * sr)));
    autoMatchGainDb += (desiredDb - autoMatchGainDb) * gainAlpha;

    if (std::abs (autoMatchGainDb) < 1.0e-5f)
        autoMatchGainDb = 0.0f;

    const float targetGain = dbToGain (autoMatchGainDb);
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
        buffer.applyGainRamp (ch, 0, samples, autoMatchAppliedGain, targetGain);
    autoMatchAppliedGain = targetGain;
}

void DspEngine::processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    vcaGain.setTargetValue (dbToGain (p.vcaFaderDb));
    outputTrimGain.setTargetValue (dbToGain (p.outputTrimDb));
    const float pan = juce::jlimit (-1.0f, 1.0f, p.pan);
    panLeftGain.setTargetValue (pan > 0.0f ? 1.0f - pan : 1.0f);
    panRightGain.setTargetValue (pan < 0.0f ? 1.0f + pan : 1.0f);

    const float push = juce::jlimit (0.0f, 1.0f, p.vcaFaderDb / 10.0f);
    const float targetSaturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
    vcaSaturationSmoother.setTargetValue (targetSaturation);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float fader = vcaGain.getNextValue();
        const float trim = outputTrimGain.getNextValue();
        const float saturation = vcaSaturationSmoother.getNextValue();
        const float leftBalance = panLeftGain.getNextValue();
        const float rightBalance = panRightGain.getNextValue();
        for (int ch = 0; ch < channels; ++ch)
        {
            const float balance = channels == 2 ? (ch == 0 ? leftBalance : rightBalance) : 1.0f;
            float v = buffer.getSample (ch, i) * fader;
            if (saturation > 0.0001f)
                v = vcaSaturate (v, saturation);
            buffer.setSample (ch, i, v * trim * balance);
        }
    }
}

void DspEngine::process (juce::AudioBuffer<float>& buffer, const Params& p)
{
    const float inPeak = bufferPeakDb (buffer);
    const float inLeft = channelPeakDb (buffer, 0);
    const float inRight = channelPeakDb (buffer, buffer.getNumChannels() > 1 ? 1 : 0);
    inputPeakDb.store (inPeak);
    inputLeftPeakDb.store (inLeft);
    inputRightPeakDb.store (inRight);
    accumulatePeak (inputLeftPeakHeldDb, inLeft);
    accumulatePeak (inputRightPeakHeldDb, inRight);

    if (p.bypass)
    {
        outputPeakDb.store (inPeak);
        outputLeftPeakDb.store (inLeft);
        outputRightPeakDb.store (inRight);
        accumulatePeak (outputLeftPeakHeldDb, inLeft);
        accumulatePeak (outputRightPeakHeldDb, inRight);
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    // On the first active block, initialise the smoothers from the restored/current
    // parameter values instead of ramping from factory defaults. Subsequent changes
    // use the normal 20 ms ramps. This keeps session recall and MIX=0 null-safe.
    if (! gainSmoothersInitialised)
    {
        inputTrimGain.setCurrentAndTargetValue (dbToGain (p.inputTrimDb));
        inputDriveGain.setCurrentAndTargetValue (dbToGain (juce::jlimit (-20.0f, 20.0f, p.inputDrive)));
        vcaGain.setCurrentAndTargetValue (dbToGain (p.vcaFaderDb));
        outputTrimGain.setCurrentAndTargetValue (dbToGain (p.outputTrimDb));
        const float pan = juce::jlimit (-1.0f, 1.0f, p.pan);
        panLeftGain.setCurrentAndTargetValue (pan > 0.0f ? 1.0f - pan : 1.0f);
        panRightGain.setCurrentAndTargetValue (pan < 0.0f ? 1.0f + pan : 1.0f);
        mixSmoother.setCurrentAndTargetValue (juce::jlimit (0.0f, 1.0f, p.mix));
        const float push = juce::jlimit (0.0f, 1.0f, p.vcaFaderDb / 10.0f);
        const float saturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
        vcaSaturationSmoother.setCurrentAndTargetValue (saturation);
        gainSmoothersInitialised = true;
    }

    // Hosts normally respect prepareToPlay's maximum block size, but Release builds
    // must never rely on jassert for buffer safety. Grow only on an unexpected host
    // violation instead of risking an out-of-bounds dry-path copy.
    if (channels > globalDryBuffer.getNumChannels() || samples > globalDryBuffer.getNumSamples())
        globalDryBuffer.setSize (juce::jmax (channels, globalDryBuffer.getNumChannels()),
                                 juce::jmax (samples, globalDryBuffer.getNumSamples()),
                                 false, false, true);

    for (int ch = 0; ch < channels; ++ch)
        globalDryBuffer.copyFrom (ch, 0, buffer, ch, 0, samples);

    processInputStage (buffer, p);
    updateFilters (p, samples);

    switch (p.routing)
    {
        case 1: // FILTER -> DYN -> EQ
            processFilters (buffer, p); processDynamics (buffer, p); processEQ (buffer, p); break;
        case 2: // DYN -> FILTER -> EQ
            processDynamics (buffer, p); processFilters (buffer, p); processEQ (buffer, p); break;
        default: // FILTER -> EQ -> DYN
            processFilters (buffer, p); processEQ (buffer, p); processDynamics (buffer, p); break;
    }

    // TODO: a future sidechain-routing revision can feed HPF/LPF into the shared
    // dynamics detector without changing the main audio routing.

    // MicroShift-inspired stereo image stage: dual time-varying delays create
    // decorrelated micro-pitch side energy. It remains before AUTO LEVEL so level
    // matching includes any energy added by the width effect.
    processStereoWidth (buffer, p);

    // Dedicated circuit saturation is deliberately after the strip/stereo stages
    // and before AUTO LEVEL. This makes the SATURATION control audible while the
    // final programme loudness is still matched back to the untouched input.
    processSaturation (buffer, p);

    // Compare the processed wet strip against the untouched input reference.
    // This happens before the manual OUTPUT LEVEL/PAN stage, so the user's output
    // trim remains an intentional offset rather than something AUTO LEVEL fights.
    processAutoLevelMatch (buffer, globalDryBuffer, p);
    processOutputStage (buffer, p);

    mixSmoother.setTargetValue (juce::jlimit (0.0f, 1.0f, p.mix));
    for (int i = 0; i < samples; ++i)
    {
        const float mix = mixSmoother.getNextValue();
        if (mix >= 0.999999f)
            continue;

        const float dryGain = 1.0f - mix;
        for (int ch = 0; ch < channels; ++ch)
        {
            const float dry = globalDryBuffer.getSample (ch, i);
            const float wet = buffer.getSample (ch, i);
            buffer.setSample (ch, i, dry * dryGain + wet * mix);
        }
    }

    // MUTE is deliberately last so no dry/wet setting can leak signal around it.
    if (p.mute)
        buffer.clear();

    const float outPeak = bufferPeakDb (buffer);
    const float outLeft = channelPeakDb (buffer, 0);
    const float outRight = channelPeakDb (buffer, buffer.getNumChannels() > 1 ? 1 : 0);
    outputPeakDb.store (outPeak);
    outputLeftPeakDb.store (outLeft);
    outputRightPeakDb.store (outRight);
    accumulatePeak (outputLeftPeakHeldDb, outLeft);
    accumulatePeak (outputRightPeakHeldDb, outRight);
}
