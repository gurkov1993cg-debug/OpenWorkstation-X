#include "DspEngine.h"
#include "WienEqModel.h"
#include "SslEseriesEqModel.h"
#include <algorithm>
#include <cmath>

namespace
{
    inline float dbToGain (float db) noexcept { return consoledsp::dbToGain (db); }

    void runFilter (consoledsp::BiquadBank& filter, juce::AudioBuffer<float>& buffer)
    {
        const int channels = buffer.getNumChannels();
        const int samples = buffer.getNumSamples();
        for (int ch = 0; ch < channels; ++ch)
        {
            float* data = buffer.getWritePointer (ch);
            for (int i = 0; i < samples; ++i)
                data[i] = filter.processSample (ch, data[i]);
        }
    }

    consoledsp::BiquadCoefficients toCore (const wieneq::BiquadCoefficients& c) noexcept
    {
        return { c.b0, c.b1, c.b2, c.a1, c.a2 };
    }

    consoledsp::BiquadCoefficients toCore (const ssleq::BiquadCoefficients& c) noexcept
    {
        return { c.b0, c.b1, c.b2, c.a1, c.a2 };
    }

    consoledsp::BiquadCoefficients chooseEqModel (const ssleq::BiquadCoefficients& schematic,
                                                  const wieneq::BiquadCoefficients& legacy) noexcept
    {
#if defined(CONSOLE_EQ_FORCE_LEGACY_WIEN)
        (void) schematic;
        return toCore (legacy);
#else
        // The old Wien/RC transfer is deliberately kept as a safety fallback.
        // The selection itself is pure project DSP; no JUCE filter/designer is used.
        return ssleq::coefficientsUsable (schematic) ? toCore (schematic)
                                                      : toCore (legacy);
#endif
    }
}

void DspEngine::prepare (double sampleRate, int maximumBlockSize, int numChannels)
{
    sr = sampleRate;
    const int channels = std::max (1, numChannels);
    hp1.prepare (channels); hp2.prepare (channels); lp.prepare (channels);
    lf.prepare (channels); lmf.prepare (channels); hmf.prepare (channels); hf.prepare (channels);

    globalDryBuffer.setSize (channels, std::max (1, maximumBlockSize), false, false, true);
    dryLatencyLines.assign ((size_t) channels,
                            std::vector<float> ((size_t) std::max (1, latencySamples()), 0.0f));
    dryLatencyWriteIndex = 0;
    const int stereoDelaySamples = std::max (16, (int) std::ceil (sampleRate * 0.080) + 8);
    stereoDelayLine.assign ((size_t) stereoDelaySamples, 0.0f);

    inputTrimGain.reset (sr, 0.020);
    inputDriveGain.reset (sr, 0.020);
    panLeftGain.reset (sr, 0.020);
    panRightGain.reset (sr, 0.020);
    vcaGain.reset (sr, 0.020);
    outputTrimGain.reset (sr, 0.020);
    mixSmoother.reset (sr, 0.020);
    vcaSaturationSmoother.reset (sr, 0.020);
    saturationDriveGain.reset (sr, 0.020);
    dynamicsCircuit.prepare (sr);
    saturationCircuit.prepare (sr, std::max (1, numChannels));

    reset();
}

void DspEngine::reset()
{
    hp1.reset(); hp2.reset(); lp.reset();
    lf.reset(); lmf.reset(); hmf.reset(); hf.reset();

    dynamicsCircuit.reset();
    saturationCircuit.reset();

    inputTrimGain.setCurrentAndTargetValue (1.0f);
    inputDriveGain.setCurrentAndTargetValue (1.0f);
    panLeftGain.setCurrentAndTargetValue (1.0f);
    panRightGain.setCurrentAndTargetValue (1.0f);
    vcaGain.setCurrentAndTargetValue (1.0f);
    outputTrimGain.setCurrentAndTargetValue (1.0f);
    mixSmoother.setCurrentAndTargetValue (1.0f);
    vcaSaturationSmoother.setCurrentAndTargetValue (0.0f);
    saturationDriveGain.setCurrentAndTargetValue (1.0f);

    autoInputPower = 0.0;
    autoOutputPower = 0.0;
    autoMatchGainDb = 0.0f;
    autoMatchAppliedGain = 1.0f;

    for (auto& line : dryLatencyLines)
        std::fill (line.begin(), line.end(), 0.0f);
    dryLatencyWriteIndex = 0;

    std::fill (stereoDelayLine.begin(), stereoDelayLine.end(), 0.0f);
    stereoDelayWriteIndex = 0;
    stereoLfoPhaseL = 0.0;
    stereoLfoPhaseR = consoledsp::pi;
    stereoFocusLowState = 0.0f;
    stereoSideLowState = 0.0f;

    compMeterDb.store (0.0f);
    gateMeterDb.store (0.0f);
    compReductionHeldDb.store (0.0f);
    gateReductionHeldDb.store (0.0f);
    inputPeakDb.store (-100.0f);
    outputPeakDb.store (-100.0f);
    inputLeftPeakDb.store (-100.0f);
    inputRightPeakDb.store (-100.0f);
    outputLeftPeakDb.store (-100.0f);
    outputRightPeakDb.store (-100.0f);
    preSaturationPeakDb.store (-100.0f);
    inputLeftPeakHeldDb.store (-100.0f);
    inputRightPeakHeldDb.store (-100.0f);
    outputLeftPeakHeldDb.store (-100.0f);
    outputRightPeakHeldDb.store (-100.0f);
    preSaturationPeakHeldDb.store (-100.0f);

    filterCacheValid = false;
    filterStatesInitialised = false;
    gainSmoothersInitialised = false;
    stereoWidthWasActive = false;
    hp1Target = {}; hp2Target = {}; lpTarget = {};
    lfTarget = {}; lmfTarget = {}; hmfTarget = {}; hfTarget = {};
}

float DspEngine::transformerSaturate (float x, float amount)
{
    const float a = std::clamp (amount, 0.0f, 1.0f);
    if (a <= 0.0001f)
        return x;

    // Deliberately audible console-input nonlinearity. DRIVE itself is applied as
    // real pre-gain before this function; this stage then adds asymmetric soft
    // saturation instead of cancelling that gain back out. At 0 dB LINE mode the
    // whole input stage remains mathematically clean.
    const float hardness = 1.0f + 1.9f * a;
    const float bias = 0.010f + 0.026f * a;
    const float positive = std::tanh (hardness * (x + bias));
    const float negative = std::tanh ((hardness * (0.92f + 0.18f * a)) * (x - bias * 0.55f));
    const float asymmetric = 0.54f * positive + 0.46f * negative;

    // Keep the centre close to zero while preserving the asymmetry that produces
    // even harmonics. The dry blend is only a safety rail at low drive.
    const float dc = 0.54f * std::tanh (hardness * bias)
                   + 0.46f * std::tanh (-(hardness * (0.92f + 0.18f * a)) * bias * 0.55f);
    const float shaped = asymmetric - dc;
    const float blend = 0.30f + 0.70f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::vcaSaturate (float x, float amount)
{
    const float a = std::clamp (amount, 0.0f, 1.0f);
    if (a <= 0.0001f)
        return x;

    // Output VCA colour is separate from the input transformer model and is zero
    // at a 0 dB fader setting. It becomes progressively firmer only above unity.
    const float drive = 1.0f + 2.2f * a;
    const float shaped = std::tanh (drive * x) / drive;
    const float blend = 0.08f + 0.52f * a;
    return x + (shaped - x) * blend;
}

float DspEngine::bufferPeakDb (const juce::AudioBuffer<float>& buffer)
{
    float peak = 0.0f;
    const int samples = buffer.getNumSamples();
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
    {
        const float* data = buffer.getReadPointer (ch);
        for (int i = 0; i < samples; ++i)
            peak = std::max (peak, std::abs (data[i]));
    }
    return consoledsp::gainToDb (peak, -100.0f);
}

float DspEngine::channelPeakDb (const juce::AudioBuffer<float>& buffer, int channel)
{
    if (buffer.getNumChannels() <= 0)
        return -100.0f;

    channel = std::clamp (channel, 0, buffer.getNumChannels() - 1);
    const float* data = buffer.getReadPointer (channel);
    float peak = 0.0f;
    for (int i = 0; i < buffer.getNumSamples(); ++i)
        peak = std::max (peak, std::abs (data[i]));
    return consoledsp::gainToDb (peak, -100.0f);
}

double DspEngine::bufferMeanSquare (const juce::AudioBuffer<float>& buffer, int numSamples) noexcept
{
    const int channels = buffer.getNumChannels();
    const int samples = std::clamp (numSamples, 0, buffer.getNumSamples());
    if (channels <= 0 || samples <= 0)
        return 0.0;

    double sum = 0.0;
    for (int ch = 0; ch < channels; ++ch)
    {
        const float* x = buffer.getReadPointer (ch);
        for (int i = 0; i < samples; ++i)
            sum += static_cast<double> (x[i]) * static_cast<double> (x[i]);
    }
    return sum / static_cast<double> (channels * samples);
}
void DspEngine::accumulatePeak (std::atomic<float>& destination, float candidate) noexcept
{
    float previous = destination.load (std::memory_order_relaxed);
    while (candidate > previous
           && ! destination.compare_exchange_weak (previous, candidate,
                                                   std::memory_order_relaxed,
                                                   std::memory_order_relaxed))
    {
    }
}

void DspEngine::processInputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    inputTrimGain.setTargetValue (dbToGain (p.inputTrimDb));
    inputDriveGain.setTargetValue (dbToGain (std::clamp (p.inputDrive, -20.0f, 20.0f)));
    const float polarityGain = p.polarity ? -1.0f : 1.0f;
    const float padGain = p.inputPad ? 0.1f : 1.0f; // -20 dB

    // INPUT DRIVE is a real -20..+20 dB preamp drive. Negative settings are clean
    // attenuation, 0 dB LINE is a true clean/null point, and positive settings
    // feed progressively more level into the transformer-style stage. MIC keeps a
    // subtle baseline colour even at 0 dB.
    const float positiveDrive = std::max (0.0f, p.inputDrive);
    const float modeBias = p.inputMode == 1 ? 0.12f : 0.0f;
    const float saturationAmount = std::clamp (positiveDrive / 20.0f + modeBias, 0.0f, 1.0f);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float trim = inputTrimGain.getNextValue() * polarityGain;
        const float drive = inputDriveGain.getNextValue();

        for (int ch = 0; ch < channels; ++ch)
        {
            float v = buffer.getSample (ch, i) * trim * padGain * drive;
            if (saturationAmount > 0.0001f)
                v = transformerSaturate (v, saturationAmount);
            buffer.setSample (ch, i, v);
        }
    }
}

bool DspEngine::filterParametersChanged (const Params& p) const noexcept
{
    if (! filterCacheValid)
        return true;

    return p.hpFreq != lastFilterParams.hpFreq
        || p.lpFreq != lastFilterParams.lpFreq
        || p.blackEq != lastFilterParams.blackEq
        || p.lfBell != lastFilterParams.lfBell
        || p.lfFreq != lastFilterParams.lfFreq
        || p.lfGain != lastFilterParams.lfGain
        || p.lmfFreq != lastFilterParams.lmfFreq
        || p.lmfGain != lastFilterParams.lmfGain
        || p.lmfQ != lastFilterParams.lmfQ
        || p.hmfFreq != lastFilterParams.hmfFreq
        || p.hmfGain != lastFilterParams.hmfGain
        || p.hmfQ != lastFilterParams.hmfQ
        || p.hfBell != lastFilterParams.hfBell
        || p.hfFreq != lastFilterParams.hfFreq
        || p.hfGain != lastFilterParams.hfGain;
}

void DspEngine::setFilterTargets (const Params& p)
{
    const float nyquistSafe = static_cast<float> (0.45 * sr);
    const float hpHz = std::clamp (p.hpFreq, 16.0f, std::min (350.0f, nyquistSafe));
    const float lpHz = std::clamp (p.lpFreq, 3000.0f, nyquistSafe);

    // v0.4.1 schematic EQ path:
    // - T82002-71 / T82242-70 component values set the frequency-control RC core.
    // - the mid E-series bells are reciprocal constant-bandwidth, so the former
    //   passive-Wien Q floor is gone;
    // - LF/HF bell mode uses fixed network damping, so bandwidth widens with boost;
    // - LF/HF shelf mode uses the second-order reciprocal shelf damping that
    //   preserves the accepted Wien shelf voicing;
    // - the previous Wien model is still calculated as an automatic safety
    //   fallback and can be forced at build time with CONSOLE_EQ_FORCE_LEGACY_WIEN.
    const float lfGainLimit = (! p.blackEq || ! p.lfBell) ? 15.0f : 18.0f;
    const float hfGainLimit = (! p.blackEq || ! p.hfBell) ? 15.0f : 18.0f;
    const float midGainLimit = p.blackEq ? 18.0f : 15.0f;
    const float lfGain = std::clamp (p.lfGain, -lfGainLimit, lfGainLimit);
    const float hfGain = std::clamp (p.hfGain, -hfGainLimit, hfGainLimit);
    const float lmGain = std::clamp (p.lmfGain, -midGainLimit, midGainLimit);
    const float hmGain = std::clamp (p.hmfGain, -midGainLimit, midGainLimit);

    const auto revision = p.blackEq ? ssleq::Revision::black242 : ssleq::Revision::brown02;
    const auto& sslLf = ssleq::circuit (revision, ssleq::Band::lf);
    const auto& sslLm = ssleq::circuit (revision, ssleq::Band::lmf);
    const auto& sslHm = ssleq::circuit (revision, ssleq::Band::hmf);
    const auto& sslHf = ssleq::circuit (revision, ssleq::Band::hf);

    // Legacy coefficients are intentionally left bit-for-bit on the old model.
    // They are only selected if the new model fails the pole/finite validation or
    // if a rollback build is explicitly requested.
    const auto& oldLf = wieneq::circuit (wieneq::Band::lf);
    const auto& oldLm = wieneq::circuit (wieneq::Band::lmf);
    const auto& oldHm = wieneq::circuit (wieneq::Band::hmf);
    const auto& oldHf = wieneq::circuit (wieneq::Band::hf);

    const auto sslLfCoeff = p.lfBell
        ? ssleq::fixedQBell (sr, sslLf, p.lfFreq, sslLf.fixedBellQ, lfGain)
        : ssleq::lowShelf (sr, sslLf, p.lfFreq, lfGain);
    const auto oldLfCoeff = p.lfBell
        ? wieneq::reciprocalBell (sr, wieneq::tuneFixedQBell (oldLf, p.lfFreq, 1.0, lfGain), lfGain)
        : wieneq::lowShelf (sr, oldLf, p.lfFreq, lfGain);
    lfTarget = chooseEqModel (sslLfCoeff, oldLfCoeff);

    const auto sslLmCoeff = ssleq::reciprocalBell (sr, sslLm, p.lmfFreq, p.lmfQ, lmGain);
    const auto oldLmCoeff = wieneq::reciprocalBell (sr,
        wieneq::tuneBell (oldLm, p.lmfFreq, p.lmfQ, lmGain), lmGain);
    lmfTarget = chooseEqModel (sslLmCoeff, oldLmCoeff);

    const auto sslHmCoeff = ssleq::reciprocalBell (sr, sslHm, p.hmfFreq, p.hmfQ, hmGain);
    const auto oldHmCoeff = wieneq::reciprocalBell (sr,
        wieneq::tuneBell (oldHm, p.hmfFreq, p.hmfQ, hmGain), hmGain);
    hmfTarget = chooseEqModel (sslHmCoeff, oldHmCoeff);

    const auto sslHfCoeff = p.hfBell
        ? ssleq::fixedQBell (sr, sslHf, p.hfFreq, sslHf.fixedBellQ, hfGain)
        : ssleq::highShelf (sr, sslHf, p.hfFreq, hfGain);
    const auto oldHfCoeff = p.hfBell
        ? wieneq::reciprocalBell (sr, wieneq::tuneFixedQBell (oldHf, p.hfFreq, 1.7, hfGain), hfGain)
        : wieneq::highShelf (sr, oldHf, p.hfFreq, hfGain);
    hfTarget = chooseEqModel (sslHfCoeff, oldHfCoeff);

    // Filter section: Brown 02 is ~12 dB/oct HPF, Black 242 adds the third pole
    // for ~18 dB/oct.  This is kept separate from the four-band EQ model.
    hp1Target = consoledsp::firstOrderHighPass (sr, hpHz);
    hp2Target = consoledsp::highPass (sr, hpHz, p.blackEq ? 1.0 : 0.70710678);
    lpTarget = consoledsp::lowPass (sr, lpHz, 0.70710678);

    lastFilterParams = p;
    filterCacheValid = true;
}

void DspEngine::smoothFilterCoefficients (int blockSamples)
{
    if (! filterStatesInitialised)
    {
        hp1.setCoefficients (hp1Target);
        hp2.setCoefficients (hp2Target);
        lp.setCoefficients (lpTarget);
        lf.setCoefficients (lfTarget);
        lmf.setCoefficients (lmfTarget);
        hmf.setCoefficients (hmfTarget);
        hf.setCoefficients (hfTarget);
        filterStatesInitialised = true;
        return;
    }

    // 20 ms coefficient glide, implemented by our own biquad bank.
    const double alpha = 1.0 - std::exp (-static_cast<double> (std::max (1, blockSamples))
                                         / (0.020 * sr));
    hp1.moveCoefficientsTowards (hp1Target, alpha);
    hp2.moveCoefficientsTowards (hp2Target, alpha);
    lp.moveCoefficientsTowards (lpTarget, alpha);
    lf.moveCoefficientsTowards (lfTarget, alpha);
    lmf.moveCoefficientsTowards (lmfTarget, alpha);
    hmf.moveCoefficientsTowards (hmfTarget, alpha);
    hf.moveCoefficientsTowards (hfTarget, alpha);
}
void DspEngine::updateFilters (const Params& p, int blockSamples)
{
    if (filterParametersChanged (p))
        setFilterTargets (p);
    smoothFilterCoefficients (blockSamples);
}

void DspEngine::processFilters (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (p.hpOn)
    {
        runFilter (hp2, buffer);
        if (p.blackEq)
            runFilter (hp1, buffer);
    }
    else
    {
        // Do not preserve old filter memory while the section is bypassed. Without
        // this, re-enabling HPF after a long pause can emit samples from the old state.
        hp1.reset();
        hp2.reset();
    }

    if (p.lpOn)
        runFilter (lp, buffer);
    else
        lp.reset();
}

void DspEngine::processEQ (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.eqOn)
    {
        // Clear inactive IIR memory so switching EQ back in cannot replay a stale
        // resonant state from material heard before the EQ was bypassed.
        lf.reset(); lmf.reset(); hmf.reset(); hf.reset();
        return;
    }

    runFilter (lf, buffer);
    runFilter (lmf, buffer);
    runFilter (hmf, buffer);
    runFilter (hf, buffer);
}

void DspEngine::processDynamics (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (! p.dynOn)
    {
        dynamicsCircuit.reset();
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        compReductionHeldDb.store (0.0f);
        gateReductionHeldDb.store (0.0f);
        return;
    }

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    dynamicsCircuit.setCircuit (p.dynamicsCircuit);

    for (int i = 0; i < samples; ++i)
    {
        // One linked RMS detector path for compressor and gate/expander.
        // Summing energy rather than L+R audio prevents phase cancellation from
        // fooling the control path.
        double linkedPower = 0.0;
        double linkedPeakPower = 0.0;
        for (int ch = 0; ch < channels; ++ch)
        {
            const double x = buffer.getSample (ch, i);
            const double x2 = x * x;
            linkedPower += x2;
            linkedPeakPower = std::max (linkedPeakPower, x2);
        }
        linkedPower /= static_cast<double> (std::max (1, channels));

        // Normal compressor and gate use the linked RMS energy. COMP PEAK instead
        // sees the largest instantaneous linked channel sample and switches the
        // gain computer to hard-knee operation inside SslDynamicsCircuit.
        const float dynamicsGain = dynamicsCircuit.processPowers (linkedPower, linkedPeakPower);
        for (int ch = 0; ch < channels; ++ch)
            buffer.setSample (ch, i, buffer.getSample (ch, i) * dynamicsGain);
    }

    const float compNow = static_cast<float> (dynamicsCircuit.compressorReductionDb());
    const float gateNow = static_cast<float> (dynamicsCircuit.gateReductionDb());
    const float compPeak = static_cast<float> (dynamicsCircuit.consumeMaxCompressorReductionDb());
    const float gatePeak = static_cast<float> (dynamicsCircuit.consumeMaxGateReductionDb());
    compMeterDb.store (compNow);
    gateMeterDb.store (gateNow);
    accumulatePeak (compReductionHeldDb, compPeak);
    accumulatePeak (gateReductionHeldDb, gatePeak);
}

float DspEngine::readStereoDelay (float delaySamples) const noexcept
{
    const int size = (int) stereoDelayLine.size();
    if (size < 4)
        return 0.0f;

    float read = (float) stereoDelayWriteIndex - delaySamples;
    while (read < 0.0f) read += (float) size;
    while (read >= (float) size) read -= (float) size;

    const int i0 = (int) std::floor (read);
    const int i1 = (i0 + 1) % size;
    const float frac = read - (float) i0;
    return stereoDelayLine[(size_t) i0]
         + frac * (stereoDelayLine[(size_t) i1] - stereoDelayLine[(size_t) i0]);
}

void DspEngine::processStereoWidth (juce::AudioBuffer<float>& buffer, const Params& p)
{
    if (buffer.getNumChannels() != 2 || buffer.getNumSamples() <= 0 || stereoDelayLine.size() < 4)
        return;

    const float width = std::clamp (p.stereoWidth * 0.01f, 0.0f, 1.0f);
    if (width <= 0.00001f)
    {
        if (stereoWidthWasActive)
        {
            std::fill (stereoDelayLine.begin(), stereoDelayLine.end(), 0.0f);
            stereoDelayWriteIndex = 0;
            stereoLfoPhaseL = 0.0;
            stereoLfoPhaseR = consoledsp::pi;
            stereoFocusLowState = 0.0f;
            stereoSideLowState = 0.0f;
            stereoWidthWasActive = false;
        }
        return;
    }
    stereoWidthWasActive = true;

    // User-facing FOCUS direction: turning the control UP widens progressively
    // more of the spectrum; turning it DOWN leaves progressively more programme
    // at its original width. The crossover therefore moves in the opposite
    // direction in log-frequency space.
    const float focusMinHz = 20.0f;
    const float focusMaxHz = std::min (10000.0f, (float) (0.45 * sr));
    const float focusControlHz = std::clamp (p.stereoFocusHz, focusMinHz, focusMaxHz);
    const float focusHz = std::clamp ((focusMinHz * focusMaxHz) / std::max (focusMinHz, focusControlHz),
                                      focusMinHz, focusMaxHz);
    const float lowPole = std::exp ((float) (-consoledsp::twoPi * focusHz / sr));
    const float baseDelaySamples = std::clamp (p.stereoDelayMs * 0.001f * (float) sr, 0.0f, (float) (0.025 * sr));
    const float cents = std::clamp (p.stereoDetune, 0.0f, 20.0f);

    // A sinusoidally moving delay is a continuously varying micro-pitch shifter.
    // DELAY creates a fixed L/R decorrelation and DETUNE adds slow independent
    // movement.  Both feed genuine SIDE energy even from dual-mono material.
    constexpr double nominalRate = 0.34;
    const double pitchSlope = std::pow (2.0, (double) cents / 1200.0) - 1.0;
    const float modDepthSamples = (float) std::clamp ((pitchSlope / (consoledsp::twoPi * nominalRate)) * sr,
                                                      0.0, 0.006 * sr);

    constexpr double rateL = 0.31;
    constexpr double rateR = 0.37;
    const double phaseStepL = consoledsp::twoPi * rateL / sr;
    const double phaseStepR = consoledsp::twoPi * rateR / sr;
    const float maxReadable = (float) stereoDelayLine.size() - 3.0f;

    auto* left = buffer.getWritePointer (0);
    auto* right = buffer.getWritePointer (1);
    for (int i = 0; i < buffer.getNumSamples(); ++i)
    {
        const float dryL = left[i];
        const float dryR = right[i];
        const float mid = 0.5f * (dryL + dryR);
        const float drySide = 0.5f * (dryL - dryR);

        // Apply FOCUS to both the existing stereo SIDE and the newly generated
        // decorrelated SIDE. Existing low-frequency width is preserved exactly;
        // only the band above the focus crossover is widened.
        stereoFocusLowState = (1.0f - lowPole) * mid + lowPole * stereoFocusLowState;
        const float midHigh = mid - stereoFocusLowState;
        stereoSideLowState = (1.0f - lowPole) * drySide + lowPole * stereoSideLowState;
        const float sideHigh = drySide - stereoSideLowState;

        stereoDelayLine[(size_t) stereoDelayWriteIndex] = midHigh;

        const float modL = modDepthSamples * std::sin ((float) stereoLfoPhaseL);
        const float modR = modDepthSamples * std::sin ((float) stereoLfoPhaseR);
        const float delayL = std::clamp (1.0f + baseDelaySamples * 0.82f + modL, 1.0f, maxReadable);
        const float delayR = std::clamp (1.0f + baseDelaySamples * 1.18f + modR, 1.0f, maxReadable);
        const float shiftedL = readStereoDelay (delayL);
        const float shiftedR = readStereoDelay (delayR);

        const float generatedSide = 0.5f * (shiftedL - shiftedR);

        // WIDTH now does two useful jobs:
        //   1) it widens stereo material by increasing only the focused SIDE band;
        //   2) it creates real stereo SIDE from mono/dual-mono material.
        // At WIDTH=0 this function returns before touching the signal, so the
        // bypass point remains sample-exact.
        const float widenedExistingSide = stereoSideLowState + sideHigh * (1.0f + width);
        const float totalSide = widenedExistingSide + generatedSide * (1.15f * width);

        left[i] = mid + totalSide;
        right[i] = mid - totalSide;

        if (++stereoDelayWriteIndex >= (int) stereoDelayLine.size())
            stereoDelayWriteIndex = 0;
        stereoLfoPhaseL += phaseStepL;
        stereoLfoPhaseR += phaseStepR;
        if (stereoLfoPhaseL >= consoledsp::twoPi) stereoLfoPhaseL -= consoledsp::twoPi;
        if (stereoLfoPhaseR >= consoledsp::twoPi) stereoLfoPhaseR -= consoledsp::twoPi;
    }
}

void DspEngine::processSaturation (juce::AudioBuffer<float>& buffer, const Params& p)
{
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();

    // SAT IN is a real section bypass.  We still clock the project-owned
    // anti-alias/delay path at zero colour so the plug-in's fixed 48-sample
    // latency never changes and MIX/PDC remain phase coherent.
    if (! p.saturationOn)
    {
        saturationDriveGain.setCurrentAndTargetValue (1.0f);
        for (int i = 0; i < samples; ++i)
            for (int ch = 0; ch < channels; ++ch)
            {
                float* data = buffer.getWritePointer (ch);
                data[i] = saturationCircuit.processSample (data[i], ch, 0.0f);
            }

        preSaturationPeakDb.store (-100.0f);
        preSaturationPeakHeldDb.store (-100.0f);
        return;
    }

    const float rawAmount = std::clamp (p.saturation * 0.01f, 0.0f, 1.0f);

    // Console-density control law: make the useful 20..70% region more audible
    // without increasing the 100% endpoint.  The added term is zero at both
    // endpoints, so SAT 0% stays clean and SAT 100% retains the accepted v2
    // maximum drive/voicing.
    const float midCurve = 4.0f * rawAmount * (1.0f - rawAmount);
    const float amount = std::clamp (rawAmount + 0.030f * midCurve, 0.0f, 1.0f);

    saturationDriveGain.setTargetValue (dbToGain (std::clamp (p.saturationGainDb, -12.0f, 18.0f)));

    // SAT GAIN is a true pre-gain into the nonlinear stage. The meter is sampled
    // after this gain and immediately before the saturation circuit, so GLOBAL
    // AUTO LEVEL cannot hide how hard the user is driving the stage.
    float preSatPeak = 0.0f;

    // Clock gain smoothing once per sample and apply the same linked gain to all
    // channels, preserving stereo balance.
    for (int i = 0; i < samples; ++i)
    {
        const float drive = saturationDriveGain.getNextValue();
        for (int ch = 0; ch < channels; ++ch)
        {
            float* data = buffer.getWritePointer (ch);
            const float driven = data[i] * drive;
            preSatPeak = std::max (preSatPeak, std::abs (driven));
            data[i] = saturationCircuit.processSample (driven, ch, amount);
        }
    }

    const float peakDb = consoledsp::gainToDb (preSatPeak, -100.0f);
    preSaturationPeakDb.store (peakDb);
    accumulatePeak (preSaturationPeakHeldDb, peakDb);
}

void DspEngine::processAutoLevelMatch (juce::AudioBuffer<float>& buffer,
                                           const juce::AudioBuffer<float>& reference,
                                           const Params& p)
{
    const int samples = buffer.getNumSamples();
    if (samples <= 0 || buffer.getNumChannels() <= 0)
        return;

    // 350 ms broadband RMS/energy detector.  This is deliberately slower than
    // individual audio cycles so EQ and compression are compared by programme
    // level rather than by instantaneous sample peaks.
    const double detectorTau = 0.350;
    const double detectorAlpha = 1.0 - std::exp (-static_cast<double> (samples) / (detectorTau * sr));
    const double inputBlockPower = bufferMeanSquare (reference, samples);
    const double outputBlockPower = bufferMeanSquare (buffer, samples);
    const bool gateActuallyReducing = gateMeterDb.load (std::memory_order_relaxed) > 0.50f;
    const bool inputBlockActive = inputBlockPower > 1.0e-12;

    // Do not teach the matcher from silence or from portions intentionally removed
    // by the gate. Otherwise the next open note could receive a temporary boost
    // based on the gate's attenuation, partially defeating the gate's purpose.
    if (inputBlockActive && ! gateActuallyReducing)
    {
        autoInputPower += detectorAlpha * (inputBlockPower - autoInputPower);
        autoOutputPower += detectorAlpha * (outputBlockPower - autoOutputPower);
    }

    float desiredDb = 0.0f;
    const bool inputActive = autoInputPower > 1.0e-12; // valid learned programme level

    if (p.autoLevelMatch && inputActive && autoOutputPower > 1.0e-12 && ! gateActuallyReducing)
    {
        // sqrt(Pin/Pout) in linear gain == 10*log10(Pin/Pout) in dB.
        desiredDb = static_cast<float> (10.0 * std::log10 (autoInputPower / autoOutputPower));
        desiredDb = std::clamp (desiredDb, -18.0f, 18.0f);
    }
    else if (p.autoLevelMatch)
    {
        // During silence or while the gate is intentionally closing, freeze the
        // last valid compensation.  This prevents the level matcher from undoing
        // the gate by trying to amplify material that the gate is meant to remove.
        desiredDb = autoMatchGainDb;
    }

    // Gain-servo ballistics: attenuation catches up faster than boost, while the
    // boost side is slower to avoid audible pumping between notes.  Turning AUTO
    // LEVEL off returns to unity smoothly rather than producing a click.
    const double gainTau = ! p.autoLevelMatch ? 0.060
                           : (desiredDb < autoMatchGainDb ? 0.180 : 0.550);
    const float gainAlpha = static_cast<float> (1.0 - std::exp (-static_cast<double> (samples) / (gainTau * sr)));
    autoMatchGainDb += (desiredDb - autoMatchGainDb) * gainAlpha;

    if (std::abs (autoMatchGainDb) < 1.0e-5f)
        autoMatchGainDb = 0.0f;

    const float targetGain = dbToGain (autoMatchGainDb);
    const float gainStep = (targetGain - autoMatchAppliedGain) / static_cast<float> (std::max (1, samples));
    for (int ch = 0; ch < buffer.getNumChannels(); ++ch)
    {
        float* data = buffer.getWritePointer (ch);
        float gain = autoMatchAppliedGain;
        for (int i = 0; i < samples; ++i)
        {
            data[i] *= gain;
            gain += gainStep;
        }
    }
    autoMatchAppliedGain = targetGain;
}

void DspEngine::processOutputStage (juce::AudioBuffer<float>& buffer, const Params& p)
{
    vcaGain.setTargetValue (dbToGain (p.vcaFaderDb));
    outputTrimGain.setTargetValue (dbToGain (p.outputTrimDb));
    const float pan = std::clamp (p.pan, -1.0f, 1.0f);
    panLeftGain.setTargetValue (pan > 0.0f ? 1.0f - pan : 1.0f);
    panRightGain.setTargetValue (pan < 0.0f ? 1.0f + pan : 1.0f);

    const float push = std::clamp (p.vcaFaderDb / 10.0f, 0.0f, 1.0f);
    const float targetSaturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
    vcaSaturationSmoother.setTargetValue (targetSaturation);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    for (int i = 0; i < samples; ++i)
    {
        const float fader = vcaGain.getNextValue();
        const float trim = outputTrimGain.getNextValue();
        const float saturation = vcaSaturationSmoother.getNextValue();
        const float leftBalance = panLeftGain.getNextValue();
        const float rightBalance = panRightGain.getNextValue();
        for (int ch = 0; ch < channels; ++ch)
        {
            const float balance = channels == 2 ? (ch == 0 ? leftBalance : rightBalance) : 1.0f;
            float v = buffer.getSample (ch, i) * fader;
            if (saturation > 0.0001f)
                v = vcaSaturate (v, saturation);
            buffer.setSample (ch, i, v * trim * balance);
        }
    }
}

void DspEngine::process (juce::AudioBuffer<float>& buffer, const Params& p)
{
    const float inPeak = bufferPeakDb (buffer);
    const float inLeft = channelPeakDb (buffer, 0);
    const float inRight = channelPeakDb (buffer, buffer.getNumChannels() > 1 ? 1 : 0);
    inputPeakDb.store (inPeak);
    inputLeftPeakDb.store (inLeft);
    inputRightPeakDb.store (inRight);
    accumulatePeak (inputLeftPeakHeldDb, inLeft);
    accumulatePeak (inputRightPeakHeldDb, inRight);

    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels <= 0 || samples <= 0)
        return;

    // On the first active block, initialise the smoothers from the restored/current
    // parameter values instead of ramping from factory defaults. Subsequent changes
    // use the normal 20 ms ramps. This keeps session recall and MIX=0 null-safe.
    if (! gainSmoothersInitialised)
    {
        inputTrimGain.setCurrentAndTargetValue (dbToGain (p.inputTrimDb));
        inputDriveGain.setCurrentAndTargetValue (dbToGain (std::clamp (p.inputDrive, -20.0f, 20.0f)));
        vcaGain.setCurrentAndTargetValue (dbToGain (p.vcaFaderDb));
        outputTrimGain.setCurrentAndTargetValue (dbToGain (p.outputTrimDb));
        const float pan = std::clamp (p.pan, -1.0f, 1.0f);
        panLeftGain.setCurrentAndTargetValue (pan > 0.0f ? 1.0f - pan : 1.0f);
        panRightGain.setCurrentAndTargetValue (pan < 0.0f ? 1.0f + pan : 1.0f);
        mixSmoother.setCurrentAndTargetValue (std::clamp (p.mix, 0.0f, 1.0f));
        const float push = std::clamp (p.vcaFaderDb / 10.0f, 0.0f, 1.0f);
        const float saturation = push <= 0.0f ? 0.0f : 0.36f * std::pow (push, 1.55f);
        vcaSaturationSmoother.setCurrentAndTargetValue (saturation);
        gainSmoothersInitialised = true;
    }

    // Hosts normally respect prepareToPlay's maximum block size, but Release builds
    // must never rely on jassert for buffer safety. Grow only on an unexpected host
    // violation instead of risking an out-of-bounds dry-path copy.
    if (channels > globalDryBuffer.getNumChannels() || samples > globalDryBuffer.getNumSamples())
        globalDryBuffer.setSize (std::max (channels, globalDryBuffer.getNumChannels()),
                                 std::max (samples, globalDryBuffer.getNumSamples()),
                                 false, false, true);

    // The linear-phase 4x saturation anti-alias path has a fixed 48-sample
    // latency. Keep the untouched dry/reference path at exactly the same delay so
    // MIX, AUTO LEVEL, internal bypass and host parallel compensation remain phase
    // coherent. This delay is project-owned; JUCE is used only to report it.
    const int latency = latencySamples();
    for (int i = 0; i < samples; ++i)
    {
        for (int ch = 0; ch < channels; ++ch)
        {
            auto& line = dryLatencyLines[(size_t) std::min (ch, (int) dryLatencyLines.size() - 1)];
            const float current = buffer.getSample (ch, i);
            const float delayed = latency > 0 ? line[(size_t) dryLatencyWriteIndex] : current;
            if (latency > 0)
                line[(size_t) dryLatencyWriteIndex] = current;
            globalDryBuffer.setSample (ch, i, delayed);
        }

        if (latency > 0 && ++dryLatencyWriteIndex >= latency)
            dryLatencyWriteIndex = 0;
    }

    // Internal/host bypass still runs the strip state in the background.  This
    // keeps compressor envelopes, filter memory, stereo delay/LFO state, gain
    // smoothers, saturation FIR history and AUTO LEVEL current with the incoming
    // programme.  The audible output is replaced by the latency-aligned dry path
    // below, so bypass remains sample-exact without a stale-state burst when it is
    // released.
    const bool bypassOutput = p.bypass;
    processInputStage (buffer, p);
    updateFilters (p, samples);

    switch (p.routing)
    {
        case 1: // FILTER -> DYN -> EQ
            processFilters (buffer, p); processDynamics (buffer, p); processEQ (buffer, p); break;
        case 2: // DYN -> FILTER -> EQ
            processDynamics (buffer, p); processFilters (buffer, p); processEQ (buffer, p); break;
        default: // FILTER -> EQ -> DYN
            processFilters (buffer, p); processEQ (buffer, p); processDynamics (buffer, p); break;
    }

    // TODO: a future sidechain-routing revision can feed HPF/LPF into the shared
    // dynamics detector without changing the main audio routing.

    // MicroShift-inspired stereo image stage: dual time-varying delays create
    // decorrelated micro-pitch side energy. It remains before AUTO LEVEL so level
    // matching includes any energy added by the width effect.
    processStereoWidth (buffer, p);

    // Dedicated circuit saturation is deliberately after the strip/stereo stages
    // and before AUTO LEVEL. This makes the SATURATION control audible while the
    // final programme loudness is still matched back to the untouched input.
    processSaturation (buffer, p);

    // Compare the processed wet strip against the untouched input reference.
    // This happens before the manual OUTPUT LEVEL/PAN stage, so the user's output
    // trim remains an intentional offset rather than something AUTO LEVEL fights.
    processAutoLevelMatch (buffer, globalDryBuffer, p);
    processOutputStage (buffer, p);

    mixSmoother.setTargetValue (std::clamp (p.mix, 0.0f, 1.0f));
    for (int i = 0; i < samples; ++i)
    {
        const float mix = mixSmoother.getNextValue();
        if (mix >= 0.999999f)
            continue;

        const float dryGain = 1.0f - mix;
        for (int ch = 0; ch < channels; ++ch)
        {
            const float dry = globalDryBuffer.getSample (ch, i);
            const float wet = buffer.getSample (ch, i);
            buffer.setSample (ch, i, dry * dryGain + wet * mix);
        }
    }

    // MUTE is deliberately last so no dry/wet setting can leak signal around it.
    if (p.mute)
        buffer.clear();

    // Bypass supersedes every strip control (including MUTE/MIX), but only after
    // the hidden wet path has advanced all internal states.  The reference path is
    // already delayed by the same fixed 48 samples as the saturation FIR.
    if (bypassOutput)
    {
        for (int ch = 0; ch < channels; ++ch)
            buffer.copyFrom (ch, 0, globalDryBuffer, ch, 0, samples);

        // Hide internal dynamics activity while the plug-in is bypassed, without
        // resetting the actual compressor/gate state that is being kept warm.
        compMeterDb.store (0.0f);
        gateMeterDb.store (0.0f);
        compReductionHeldDb.store (0.0f);
        gateReductionHeldDb.store (0.0f);
    }

    const float outPeak = bufferPeakDb (buffer);
    const float outLeft = channelPeakDb (buffer, 0);
    const float outRight = channelPeakDb (buffer, buffer.getNumChannels() > 1 ? 1 : 0);
    outputPeakDb.store (outPeak);
    outputLeftPeakDb.store (outLeft);
    outputRightPeakDb.store (outRight);
    accumulatePeak (outputLeftPeakHeldDb, outLeft);
    accumulatePeak (outputRightPeakHeldDb, outRight);
}
