# DSP fix report — next build candidate after ГОТОВА ВЕРСИЯ 1

This source is an experimental successor to the locked ГОТОВА ВЕРСИЯ 1 source. It is **not** called ГОТОВА ВЕРСИЯ 2 until the GitHub Intel/macOS 10.13 build and smoke tests complete successfully.

## 1. High-frequency EQ Q correction

The old schematic EQ prewarped the centre frequency but not the bandwidth. At Black HMF 10 kHz, +12 dB, marked Q=1 this measured approximately:

- 44.1 kHz: Q 1.55
- 48 kHz: Q 1.45

The new `SslEseriesEqModel` solves the exact bilinear tan() mapping for the analog prototype Q before coefficient generation. Local pure-C++ checks now give:

- 44.1 kHz, 10 kHz, Q=1 -> measured Q 1.000
- 48 kHz, 10 kHz, Q=1 -> measured Q 1.000
- 44.1/48 kHz, 10 kHz, Q=3.5 -> measured Q 3.500

A very wide Q such as 0.1 at 10 kHz cannot be represented literally at 44.1/48 kHz because the required upper half-gain edge lies beyond Nyquist. The solver therefore reaches the widest physically representable digital bandwidth rather than fabricating it.

A standalone stability sweep covered 67,872 Brown/Black bell coefficient cases at 44.1/48/96/192 kHz with zero invalid/unstable cases. Worst pole radius remained approximately 0.999909.

## 2. Dedicated saturation anti-aliasing

`AnalogSaturationCircuit` now uses true project-owned 4x multirate processing around the static transistor-pair nonlinearity. A symmetric 193-tap equiripple FIR is used in polyphase interpolation and again for decimation. The decimator is sampled on oversampled phase zero, so the two linear-phase filters contribute an exact 48 base-sample delay (24 + 24 samples) with no fractional dry/residual skew.

The untouched programme/reference path is delayed by the same 48 samples in `DspEngine`, and `PluginProcessor` reports that latency to the host. This keeps internal MIX, AUTO LEVEL, bypass and host parallel compensation phase coherent. The original base-rate residual bandwidth pole and 4 Hz DC servo are retained after decimation, preserving the accepted saturation voicing. No JUCE DSP, JUCE oversampling or JUCE filter designer is used.

Local regression at 48 kHz, 7 kHz tone, SAT 100%, equivalent +12 dB pre-drive:
- v1 base-rate fold at 1 kHz: about -19.89 dBc
- corrected 4x path: about -60.28 dBc
- v1 fundamental gain: about -12.03 dB
- corrected path fundamental gain: about -11.98 dB

The previous residual-only 8th-order IIR attempt reached similar alias rejection but shifted the hard-drive HF fundamental by more than 14 dB in the worst probe. That approach is rejected; the linear-phase multirate path replaces it.

## 3. Protected areas

- `WienEqModel.cpp/.h` rollback model: not changed.
- compressor/gate/shared VCA model: not changed.
- GUI geometry and controls: not changed.
- public parameter IDs: not changed.
- no `juce::dsp` in the audio DSP source.
