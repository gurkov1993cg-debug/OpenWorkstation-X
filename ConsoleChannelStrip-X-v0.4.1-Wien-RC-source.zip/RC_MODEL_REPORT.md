# Console Channel Strip X v0.4.1 — Wien/RC implementation report

## Defect -> change -> file

| Defect | Change | File |
|---|---|---|
| RC constants did not affect transfer | Frequency knob now solves R; Wien network calculates w0/Qn; reciprocal bell receives those network values | `ConsoleChannelStrip-X/src/WienEqModel.cpp`, `DspEngine.cpp` |
| JUCE stock EQ designers in four EQ bands | Removed `makePeakFilter/makeLowShelf/makeHighShelf` from LF/LMF/HMF/HF design path | `DspEngine.cpp` |
| Mid Q knob meant generic biquad Q | Q knob maps engraved effective Q -> network Qn -> ganged Rq/R | `WienEqModel.cpp` |
| First-order shelf wrapped as biquad | Replaced by genuine second-order analog shelf with nonzero s^2 terms and RC-derived damping | `WienEqModel.cpp` |
| Hidden shelf correction peaks | Removed LF/HF dip filters; shoulder/dip now comes from shelf prototype itself | `DspEngine.cpp`, `DspEngine.h` |
| LF/HF bell Q swapped | LF effective Q=1.0, HF effective Q=1.7 | `DspEngine.cpp` |
| Expanded unsupported frequency ranges | Restored 30..450, 200..2500, 600..7000, 1500..16000 Hz | `PluginProcessor.cpp` + [FIT] circuits |
| Wrong HPF corner/slope mapping | Brown: Q=.7071 second-order; Black: Q=1 second-order + first-order | `DspEngine.cpp` |
| CI rewrote source during build | New workflow builds normal source tree only; no source patch step | `.github/workflows/build-console-channelstrip-x.yml` |
| Old tests could pass with decorative RC | Added component sensitivity, RC range, Q, stability, shelf and fixed-bell tests | `tests/ParameterSmokeTests.cpp` |

## [FIT] components

These are fitted values, not SSL schematic values.

| Band | C1 | C2 | rMin | rMax | rqFracMax | Achieved frequency | Effective Q @ +12 dB |
|---|---:|---:|---:|---:|---:|---:|---:|
| LF | 100 nF | 100 nF | 3.5368 kOhm | 53.0516 kOhm | 2.86 | 30..450 Hz | fixed bell 1.0 |
| LMF | 22 nF | 22 nF | 2.8937 kOhm | 36.1716 kOhm | 2.86 | 200..2500 Hz | 0.167..3.5 |
| HMF | 6.8 nF | 6.8 nF | 3.3436 kOhm | 39.0086 kOhm | 2.86 | 600..7000 Hz | 0.167..3.5 |
| HF | 2.2 nF | 2.2 nF | 4.5214 kOhm | 48.2288 kOhm | 2.86 | 1500..16000 Hz | fixed bell 1.7 |

## Component-sensitivity regression

At the test point Rq=2R, increasing C1 by +10% produces the same analytic sensitivity in all four equal-C fitted bands:

| Band | f0 change | Qn change |
|---|---:|---:|
| LF | -4.65374% | +4.88088% |
| LMF | -4.65374% | +4.88088% |
| HMF | -4.65374% | +4.88088% |
| HF | -4.65374% | +4.88088% |

This is the key proof that component values are connected to the transfer function.

## Shelf measurements from the new second-order prototype

48 kHz, +12 dB:

- LF shelf, fc=80 Hz: +6.000 dB at fc; -1.49994 dB at 2.2*fc.
- HF shelf, fc=10 kHz: +6.000 dB at fc; -1.24905 dB at fc/2.2. Bilinear warping near Nyquist prevents the exact analog -1.5 dB target at this high corner; no corrective peak filter was added.

## Deliberately not faked

1. **Q minimum:** with the required equal-R/equal-C Wien equation and passive `Rq >= 0`, Qn cannot go below 1/3. At +12 dB this means effective Q cannot go below about 0.167. The requested nominal 0.10 point is therefore not physically reachable without changing the topology or using a negative resistance. The implementation clamps to 0.167 and reports it.
2. **Strict pole margin `<0.999`:** the complete legal reciprocal-cut sweep remains stable (`radius < 1.0`), but the worst tested radius is about **0.999725** at high sample rate/low-frequency cut. The requested 0.999 margin is therefore not universally achievable with the preserved reciprocal analog form. CI hard-fails only actual instability (`>=1.0`) and reports the strict-margin miss.
3. **SSL schematic claim:** none is made. The RC components are `[FIT]` values fitted to documented E-series ranges, not copied 82E02/82E242 component values.

## Local verification completed

The standalone `WienEqModel.cpp` compiles cleanly with `g++ -std=c++17 -Wall -Wextra -Werror -pedantic`.
The RC regression executable passes component sensitivity, exact range coverage, physical Q range and unit-circle stability checks.

A complete JUCE/macOS VST3 build cannot be executed in the local Linux container because JUCE/macOS toolchains are not present. The supplied GitHub workflow is the intended Intel macOS 10.13 build gate.
