# Console Channel Strip X v0.1

Clean-room channel-strip project for old Intel Macs and Cubase-era VST3 hosts.

## v0.1 real DSP
- Input trim ±20 dB and polarity invert
- 18 dB/oct HPF, 20–500 Hz
- 12 dB/oct LPF, 3–22 kHz
- Four-band EQ: LF 40–600 Hz, LMF 200 Hz–2 kHz, HMF 600 Hz–7 kHz, HF 1.5–22 kHz
- LF/HF shelf or bell
- E/G-style curve-character switch (clean-room approximation from published behavior, not SSL code)
- Compressor: threshold -20…+10 dB, 1:1 to limiting, RMS/Peak, Fast attack, 0.1–4 s release, linked auto makeup, parallel mix
- Gate/expander: hysteresis, 0–40 dB range, hold, release, fast attack, 2:1 expand mode
- Four valid audio routing orders
- Compressor and gate GR meters

## Target
- macOS Intel x86_64
- deployment target 10.13
- VST3
- intended for 2011 Intel iMac systems where the host can load VST3

## Legal / implementation note
This is an original clean-room implementation based on publicly documented console-channel behavior. It does not contain Solid State Logic source code, binary code, trademarks as product branding, or copied GUI assets.
