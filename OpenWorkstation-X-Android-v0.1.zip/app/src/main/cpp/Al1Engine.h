#pragma once

#include <array>
#include <atomic>
#include <cstdint>

class Al1Engine {
public:
    Al1Engine();

    void setSampleRate(float sampleRate);
    void noteOn(int note, float velocity);
    void noteOff(int note);
    void setParameter(int id, float normalizedValue);
    void render(float* interleavedStereo, int32_t frames);

private:
    enum class EnvStage : uint8_t { Idle, Attack, Decay, Sustain, Release };

    struct Voice {
        int note = -1;
        float velocity = 0.0f;
        float phase1 = 0.0f;
        float phase2 = 0.0f;
        float subPhase = 0.0f;
        float env = 0.0f;
        float lp1 = 0.0f;
        float lp2 = 0.0f;
        EnvStage stage = EnvStage::Idle;
    };

    enum class EventType : uint8_t { NoteOn, NoteOff };

    struct NoteEvent {
        EventType type = EventType::NoteOff;
        int note = 0;
        float velocity = 0.0f;
    };

    static constexpr uint32_t kEventCapacity = 128;

    class EventQueue {
    public:
        bool push(const NoteEvent& event);
        bool pop(NoteEvent& event);

    private:
        std::array<NoteEvent, kEventCapacity> events_{};
        std::atomic<uint32_t> write_{0};
        std::atomic<uint32_t> read_{0};
    };

    static float midiToHz(int note);
    static float polyBlep(float t, float dt);
    static float saw(float phase, float increment);
    static float advance(float& phase, float increment);

    void processEvents();
    void applyNoteOn(int note, float velocity);
    void applyNoteOff(int note);
    Voice& allocateVoice();
    float renderVoice(Voice& voice);

    std::array<Voice, 16> voices_{};
    EventQueue events_{};

    float sampleRate_ = 48000.0f;

    std::atomic<float> cutoffNorm_{0.68f};
    std::atomic<float> resonanceNorm_{0.22f};
    std::atomic<float> detuneNorm_{0.28f};
    std::atomic<float> attackNorm_{0.07f};
    std::atomic<float> releaseNorm_{0.20f};
};
