#include "Al1Engine.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace {
constexpr float kPi = 3.14159265358979323846f;
}

Al1Engine::Al1Engine() = default;

void Al1Engine::setSampleRate(float sampleRate) {
    if (sampleRate > 8000.0f) sampleRate_ = sampleRate;
}

bool Al1Engine::EventQueue::push(const NoteEvent& event) {
    const uint32_t write = write_.load(std::memory_order_relaxed);
    const uint32_t next = (write + 1u) % kEventCapacity;
    if (next == read_.load(std::memory_order_acquire)) return false;
    events_[write] = event;
    write_.store(next, std::memory_order_release);
    return true;
}

bool Al1Engine::EventQueue::pop(NoteEvent& event) {
    const uint32_t read = read_.load(std::memory_order_relaxed);
    if (read == write_.load(std::memory_order_acquire)) return false;
    event = events_[read];
    read_.store((read + 1u) % kEventCapacity, std::memory_order_release);
    return true;
}

void Al1Engine::noteOn(int note, float velocity) {
    NoteEvent e;
    e.type = EventType::NoteOn;
    e.note = std::clamp(note, 0, 127);
    e.velocity = std::clamp(velocity, 0.0f, 1.0f);
    events_.push(e);
}

void Al1Engine::noteOff(int note) {
    NoteEvent e;
    e.type = EventType::NoteOff;
    e.note = std::clamp(note, 0, 127);
    events_.push(e);
}

void Al1Engine::setParameter(int id, float normalizedValue) {
    const float v = std::clamp(normalizedValue, 0.0f, 1.0f);
    switch (id) {
        case 0: cutoffNorm_.store(v, std::memory_order_relaxed); break;
        case 1: resonanceNorm_.store(v, std::memory_order_relaxed); break;
        case 2: detuneNorm_.store(v, std::memory_order_relaxed); break;
        case 3: attackNorm_.store(v, std::memory_order_relaxed); break;
        case 4: releaseNorm_.store(v, std::memory_order_relaxed); break;
        default: break;
    }
}

float Al1Engine::midiToHz(int note) {
    return 440.0f * std::exp2((static_cast<float>(note) - 69.0f) / 12.0f);
}

float Al1Engine::polyBlep(float t, float dt) {
    if (dt <= 0.0f) return 0.0f;
    if (t < dt) {
        t /= dt;
        return t + t - t * t - 1.0f;
    }
    if (t > 1.0f - dt) {
        t = (t - 1.0f) / dt;
        return t * t + t + t + 1.0f;
    }
    return 0.0f;
}

float Al1Engine::saw(float phase, float increment) {
    float value = 2.0f * phase - 1.0f;
    value -= polyBlep(phase, increment);
    return value;
}

float Al1Engine::advance(float& phase, float increment) {
    phase += increment;
    phase -= std::floor(phase);
    return phase;
}

void Al1Engine::processEvents() {
    NoteEvent e;
    while (events_.pop(e)) {
        if (e.type == EventType::NoteOn) applyNoteOn(e.note, e.velocity);
        else applyNoteOff(e.note);
    }
}

Al1Engine::Voice& Al1Engine::allocateVoice() {
    for (auto& voice : voices_) {
        if (voice.stage == EnvStage::Idle) return voice;
    }

    auto* quietest = &voices_.front();
    for (auto& voice : voices_) {
        if (voice.env < quietest->env) quietest = &voice;
    }
    return *quietest;
}

void Al1Engine::applyNoteOn(int note, float velocity) {
    for (auto& voice : voices_) {
        if (voice.note == note && voice.stage != EnvStage::Idle) {
            voice.velocity = velocity;
            voice.stage = EnvStage::Attack;
            return;
        }
    }

    Voice& v = allocateVoice();
    v.note = note;
    v.velocity = velocity;
    v.phase1 = 0.0f;
    v.phase2 = 0.17f;
    v.subPhase = 0.0f;
    v.env = 0.0f;
    v.lp1 = 0.0f;
    v.lp2 = 0.0f;
    v.stage = EnvStage::Attack;
}

void Al1Engine::applyNoteOff(int note) {
    for (auto& voice : voices_) {
        if (voice.note == note && voice.stage != EnvStage::Idle) {
            voice.stage = EnvStage::Release;
        }
    }
}

float Al1Engine::renderVoice(Voice& v) {
    if (v.stage == EnvStage::Idle) return 0.0f;

    const float attackNorm = attackNorm_.load(std::memory_order_relaxed);
    const float releaseNorm = releaseNorm_.load(std::memory_order_relaxed);
    const float attackSeconds = 0.002f + attackNorm * attackNorm * 1.8f;
    const float decaySeconds = 0.18f;
    const float sustain = 0.74f;
    const float releaseSeconds = 0.02f + releaseNorm * releaseNorm * 3.5f;

    switch (v.stage) {
        case EnvStage::Attack:
            v.env += 1.0f / std::max(1.0f, attackSeconds * sampleRate_);
            if (v.env >= 1.0f) {
                v.env = 1.0f;
                v.stage = EnvStage::Decay;
            }
            break;
        case EnvStage::Decay: {
            const float c = 1.0f - std::exp(-1.0f / (decaySeconds * sampleRate_));
            v.env += (sustain - v.env) * c;
            if (std::fabs(v.env - sustain) < 0.001f) {
                v.env = sustain;
                v.stage = EnvStage::Sustain;
            }
            break;
        }
        case EnvStage::Sustain:
            v.env = sustain;
            break;
        case EnvStage::Release: {
            const float c = 1.0f - std::exp(-1.0f / (releaseSeconds * sampleRate_));
            v.env += (0.0f - v.env) * c;
            if (v.env < 0.0001f) {
                v.env = 0.0f;
                v.stage = EnvStage::Idle;
                v.note = -1;
                return 0.0f;
            }
            break;
        }
        case EnvStage::Idle:
            return 0.0f;
    }

    const float baseHz = midiToHz(v.note);
    const float detuneCents = detuneNorm_.load(std::memory_order_relaxed) * 18.0f;
    const float detuneRatio = std::exp2(detuneCents / 1200.0f);

    const float inc1 = std::min(baseHz / sampleRate_, 0.45f);
    const float inc2 = std::min((baseHz * detuneRatio) / sampleRate_, 0.45f);
    const float subInc = std::min((baseHz * 0.5f) / sampleRate_, 0.45f);

    const float osc1 = saw(v.phase1, inc1);
    const float osc2 = saw(v.phase2, inc2);
    const float sub = v.subPhase < 0.5f ? 1.0f : -1.0f;

    advance(v.phase1, inc1);
    advance(v.phase2, inc2);
    advance(v.subPhase, subInc);

    float x = (osc1 * 0.47f + osc2 * 0.43f + sub * 0.10f);

    const float cutoffNorm = cutoffNorm_.load(std::memory_order_relaxed);
    const float resonance = resonanceNorm_.load(std::memory_order_relaxed) * 0.92f;
    float cutoffHz = 70.0f * std::pow(240.0f, cutoffNorm);
    cutoffHz = std::min(cutoffHz, sampleRate_ * 0.44f);

    const float g = std::clamp(
            1.0f - std::exp(-2.0f * kPi * cutoffHz / sampleRate_),
            0.001f, 0.98f);

    x -= resonance * 1.35f * v.lp2;
    v.lp1 += g * (x - v.lp1);
    v.lp2 += g * (v.lp1 - v.lp2);

    return std::tanh(v.lp2 * 1.25f) * v.env * v.velocity;
}

void Al1Engine::render(float* out, int32_t frames) {
    processEvents();

    for (int32_t i = 0; i < frames; ++i) {
        float sample = 0.0f;
        for (auto& voice : voices_) sample += renderVoice(voice);

        sample *= 0.16f;
        sample = std::tanh(sample * 1.15f);

        out[i * 2] = sample;
        out[i * 2 + 1] = sample;
    }
}
