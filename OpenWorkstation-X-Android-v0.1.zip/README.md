# OpenWorkstation-X

Android-only open workstation synthesizer.

## v0.1

This first foundation is intentionally focused on the audio architecture:

- Native C++20 DSP through Android NDK
- AAudio low-latency output on Android 8.0+
- AL-1-class virtual-analog foundation
  - 16-voice polyphony
  - dual anti-aliased PolyBLEP saw oscillators
  - oscillator detune
  - sub oscillator
  - resonant 2-pole low-pass filter
  - ADSR envelope
  - soft saturation
- Lock-free note-event queue between the Android UI and real-time audio callback
- Multi-touch two-octave keyboard
- Program-style controls for Cutoff, Resonance, Detune, Attack and Release
- Engine tabs prepared for later engines
- GitHub Actions workflow that builds a debug APK

## Planned workstation engines

- HD-1-style PCM / multisample / sampler engine
- MOD-7-style FM/VPM engine
- CX-3-style tonewheel organ engine
- STR-1-style physical-modelling engine
- Electric-piano modelling engine
- Acoustic-piano sample-streaming engine
- MS-20-style modular VA engine
- Polysix-style vintage VA engine
- Program / Combi / Set List / FX / Sequencer / Sampling architecture

This is an original implementation inspired by workstation architecture. It does not contain Korg firmware, ROM samples, copied presets or proprietary Korg source code.
